import os
import random

files = os.listdir("Videos")
videos = list(range(1,77))
recent_videos = set()
while True:
    video_input = input("Press 'enter' to play next and 'q' to quit:")
    video_num = random.choice(videos)
    
    if video_num in videos:
        videos.remove(video_num)
        recent_videos.add(video_num)
        if video_input == "":
            os.startfile(f"E:\\Python Programmes\\Video Player\\Videos\\{video_num}.mp4")
        elif video_input.lower() == "q":
            break
        else:
            print("Invalid! Press 'enter' or 'q'")
