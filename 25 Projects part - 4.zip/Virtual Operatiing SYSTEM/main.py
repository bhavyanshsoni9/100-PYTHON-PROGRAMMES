import os
import sys
import time
import getpass
import platform
import random

# Simple color and emoji support for terminal
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
except ImportError:
    class Fore:
        RED = ''
        GREEN = ''
        CYAN = ''
        YELLOW = ''
        MAGENTA = ''
        RESET = ''
    class Style:
        BRIGHT = ''
        RESET_ALL = ''

EMOJI_CHECK = '✅'
EMOJI_CROSS = '❌'
EMOJI_FIRE = '🔥'
EMOJI_STAR = '🌟'
EMOJI_LOCK = '🔒'
EMOJI_NOTE = '📝'
EMOJI_GAME = '🎮'
EMOJI_TOOL = '🛠️'
EMOJI_CHAT = '🤖'
EMOJI_EXIT = '🚪'

# Users database (username: password)
USERS_DB = {
    'admin': 'password123',
    'bhavyansh': 'sonee2025'
}

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def slow_print(text, delay=0.03):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def login():
    clear()
    print(f"{Fore.CYAN}{Style.BRIGHT}Welcome to Ultimate Terminal AI Assistant {EMOJI_FIRE}\n")
    for _ in range(3):
        username = input(f"{Fore.YELLOW}Username: {Fore.GREEN}")
        password = getpass.getpass(f"{Fore.YELLOW}Password: {Fore.GREEN}")
        if USERS_DB.get(username) == password:
            print(f"{Fore.GREEN}{EMOJI_CHECK} Login successful! Welcome, {username}!\n")
            time.sleep(1)
            return username
        else:
            print(f"{Fore.RED}{EMOJI_CROSS} Incorrect username or password. Try again.\n")
    print(f"{Fore.RED}Too many failed attempts. Exiting... {EMOJI_EXIT}")
    sys.exit()

def show_menu(username):
    clear()
    print(f"{Fore.MAGENTA}{Style.BRIGHT}Hello {username}! {EMOJI_STAR} Choose your option:\n")
    print(f"{Fore.CYAN}1.{Fore.YELLOW} Chat with AI {EMOJI_CHAT}")
    print(f"{Fore.CYAN}2.{Fore.YELLOW} Password Manager {EMOJI_LOCK}")
    print(f"{Fore.CYAN}3.{Fore.YELLOW} Notes Saver {EMOJI_NOTE}")
    print(f"{Fore.CYAN}4.{Fore.YELLOW} File Manager {EMOJI_TOOL}")
    print(f"{Fore.CYAN}5.{Fore.YELLOW} Calculator {EMOJI_TOOL}")
    print(f"{Fore.CYAN}6.{Fore.YELLOW} Games Zone {EMOJI_GAME}")
    print(f"{Fore.CYAN}7.{Fore.YELLOW} System Info {EMOJI_TOOL}")
    print(f"{Fore.CYAN}8.{Fore.YELLOW} Exit {EMOJI_EXIT}\n")

def chat_ai():
    clear()
    print(f"{Fore.GREEN}{EMOJI_CHAT} Chat mode activated. Type 'exit' to return.\n")
    while True:
        inp = input(f"{Fore.YELLOW}You: {Fore.GREEN}")
        if inp.lower() in ['exit', 'quit']:
            break
        # Simple echo AI with random fun responses
        responses = [
            "Hmm, tell me more!",
            "That's interesting!",
            "I see, go on...",
            "Can you explain further?",
            "Absolutely!",
            "I'm here for you.",
            "Let's solve it together."
        ]
        print(f"{Fore.CYAN}AI: {random.choice(responses)}\n")

def password_manager():
    clear()
    print(f"{Fore.MAGENTA}{EMOJI_LOCK} Password Manager\n")
    print("Feature under construction. Stay tuned!\n")
    input("Press Enter to return to menu...")

def notes_saver():
    clear()
    print(f"{Fore.YELLOW}{EMOJI_NOTE} Notes Saver\n")
    filename = 'user_notes.txt'
    print("Type your notes below. Type 'save' alone on a line to save and exit.\n")
    lines = []
    while True:
        line = input()
        if line.strip().lower() == 'save':
            with open(filename, 'a', encoding='utf-8') as f:
                for l in lines:
                    f.write(l + '\n')
            print(f"{Fore.GREEN}Notes saved to {filename}\n")
            break
        else:
            lines.append(line)
    input("Press Enter to return to menu...")

def file_manager():
    clear()
    print(f"{Fore.CYAN}{EMOJI_TOOL} File Manager\n")
    path = input("Enter directory path to list files (leave blank for current dir): ").strip()
    if not path:
        path = '.'
    if os.path.isdir(path):
        files = os.listdir(path)
        print(f"\nFiles in {path}:")
        for f in files:
            print(f" - {f}")
    else:
        print(f"{Fore.RED}Invalid directory path.")
    input("\nPress Enter to return to menu...")

def calculator():
    clear()
    print(f"{Fore.YELLOW}{EMOJI_TOOL} Calculator\n")
    print("Type 'exit' to return to menu.\n")
    while True:
        expr = input(f"{Fore.GREEN}Expr> ")
        if expr.lower() in ['exit', 'quit']:
            break
        try:
            # Warning: eval is dangerous; used here only for simplicity
            result = eval(expr, {"__builtins__": None}, {})
            print(f"{Fore.CYAN}Result: {result}\n")
        except Exception as e:
            print(f"{Fore.RED}Error: {e}\n")

def games_zone():
    clear()
    print(f"{Fore.MAGENTA}{EMOJI_GAME} Games Zone\n")
    print("1. Snake Game (WASD to move)")
    print("2. Tic-Tac-Toe")
    print("3. Back to Menu\n")
    choice = input("Choose game: ").strip()
    if choice == '1':
        snake_game()
    elif choice == '2':
        tic_tac_toe()
    else:
        return

def snake_game():
    clear()
    print(f"{Fore.GREEN}Snake game coming soon... Stay tuned!\n")
    input("Press Enter to return to menu...")

def tic_tac_toe():
    clear()
    board = [' '] * 9
    def print_board():
        print()
        print(f" {board[0]} | {board[1]} | {board[2]} ")
        print("---+---+---")
        print(f" {board[3]} | {board[4]} | {board[5]} ")
        print("---+---+---")
        print(f" {board[6]} | {board[7]} | {board[8]} ")
        print()
    def check_win(mark):
        wins = [
            [0,1,2],[3,4,5],[6,7,8],
            [0,3,6],[1,4,7],[2,5,8],
            [0,4,8],[2,4,6]
        ]
        for line in wins:
            if all(board[i] == mark for i in line):
                return True
        return False
    current_player = 'X'
    while True:
        print_board()
        move = input(f"Player {current_player}, enter move (1-9): ").strip()
        if not move.isdigit() or int(move) < 1 or int(move) > 9:
            print(f"{Fore.RED}Invalid move. Try again.\n")
            continue
        pos = int(move) - 1
        if board[pos] != ' ':
            print(f"{Fore.RED}Position already taken. Try again.\n")
            continue
        board[pos] = current_player
        if check_win(current_player):
            print_board()
            print(f"{Fore.GREEN}Player {current_player} wins! Congratulations!\n")
            break
        if ' ' not in board:
            print_board()
            print(f"{Fore.YELLOW}It's a draw!\n")
            break
        current_player = 'O' if current_player == 'X' else 'X'
    input("Press Enter to return to menu...")

def system_info():
    clear()
    print(f"{Fore.CYAN}{EMOJI_TOOL} System Info\n")
    print(f"Platform: {platform.system()}")
    print(f"Platform Release: {platform.release()}")
    print(f"Platform Version: {platform.version()}")
    print(f"Processor: {platform.processor()}")
    print(f"Python Version: {platform.python_version()}")
    input("\nPress Enter to return to menu...")

def main():
    username = login()
    while True:
        show_menu(username)
        choice = input(f"{Fore.YELLOW}Enter choice (1-8): {Fore.GREEN}")
        if choice == '1':
            chat_ai()
        elif choice == '2':
            password_manager()
        elif choice == '3':
            notes_saver()
        elif choice == '4':
            file_manager()
        elif choice == '5':
            calculator()
        elif choice == '6':
            games_zone()
        elif choice == '7':
            system_info()
        elif choice == '8':
            print(f"{Fore.MAGENTA}Thank you for using Ultimate Terminal AI! {EMOJI_EXIT}\n")
            break
        else:
            print(f"{Fore.RED}Invalid choice. Try again.\n")
            time.sleep(1)

if __name__ == "__main__":
    main()
