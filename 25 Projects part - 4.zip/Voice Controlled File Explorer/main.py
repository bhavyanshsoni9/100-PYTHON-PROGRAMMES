import speech_recognition as sr
import os

paths = {
    "desktop": os.path.join(os.path.expanduser("~"), "Desktop"),
    "downloads": os.path.join(os.path.expanduser("~"), "Downloads"),
    "pictures": os.path.join(os.path.expanduser("~"), "Pictures"),
}

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎙 Speak command...")
        audio = r.listen(source)

    try:
        query = r.recognize_google(audio).lower()
        return query
    except:
        return ""

while True:
    command = listen()
    print("You said:", command)

    for key in paths:
        if key in command:
            os.startfile(paths[key])
            print(f"Opening {key} folder...")
