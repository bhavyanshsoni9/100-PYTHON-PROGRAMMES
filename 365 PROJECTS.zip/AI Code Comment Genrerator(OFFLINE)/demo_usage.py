#!/usr/bin/env python3
"""
Demonstration script showing how to use the AI Code Comment Generator programmatically.
This script shows different ways to use the tool beyond the command line interface.
"""

from main import CommentGenerator, CodeAnalyzer
import os

def demo_single_file_processing():
    """Demonstrate processing a single file."""
    print("=== Single File Processing Demo ===")
    
    generator = CommentGenerator()
    
    # Process a file and create a new commented version
    result = generator.process_file('sample_code.py', 'sample_demo_output.py')
    print(f"Result: {result}")
    
    # Check if the output file was created
    if os.path.exists('sample_demo_output.py'):
        print("✓ Output file created successfully")
        # Clean up
        os.remove('sample_demo_output.py')
    else:
        print("✗ Output file not created")

def demo_analyzer_only():
    """Demonstrate using just the analyzer without generating files."""
    print("\n=== Code Analyzer Demo ===")
    
    analyzer = CodeAnalyzer()
    
    # Read and parse a file
    with open('sample_code.py', 'r') as f:
        source = f.read()
    
    import ast
    tree = ast.parse(source)
    
    # Analyze all functions and classes
    print("Analyzing code structure...")
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            analysis = analyzer.analyze_function(node)
            print(f"Function: {analysis['name']}")
            print(f"  Purpose: {analysis['purpose']}")
            print(f"  Complexity: {analysis['complexity']}")
            print(f"  Parameters: {[arg['name'] for arg in analysis['args']]}")
            print(f"  Returns: {analysis['returns']}")
            print()
        
        elif isinstance(node, ast.ClassDef):
            analysis = analyzer.analyze_class(node)
            print(f"Class: {analysis['name']}")
            print(f"  Purpose: {analysis['purpose']}")
            print(f"  Methods: {len(analysis['methods'])}")
            print(f"  Inheritance: {analysis['bases']}")
            print()

def demo_batch_processing():
    """Demonstrate batch processing of multiple files."""
    print("\n=== Batch Processing Demo ===")
    
    generator = CommentGenerator()
    
    # Create a test directory with multiple Python files
    test_dir = "test_batch"
    if not os.path.exists(test_dir):
        os.makedirs(test_dir)
    
    # Create some test files
    test_files = [
        ("test_batch/file1.py", "def get_data(): return 'data'"),
        ("test_batch/file2.py", "class DataProcessor: pass"),
        ("test_batch/file3.py", "def calculate_sum(a, b): return a + b")
    ]
    
    for file_path, content in test_files:
        with open(file_path, 'w') as f:
            f.write(content)
    
    # Process all files in the directory
    results = generator.process_directory(test_dir, "test_batch_output")
    
    print("Batch processing results:")
    for result in results:
        print(f"  {result}")
    
    # Clean up
    import shutil
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    if os.path.exists("test_batch_output"):
        shutil.rmtree("test_batch_output")

def demo_pattern_recognition():
    """Demonstrate the pattern recognition capabilities."""
    print("\n=== Pattern Recognition Demo ===")
    
    analyzer = CodeAnalyzer()
    
    # Test different function patterns
    test_functions = [
        "get_user_data",
        "set_user_preferences", 
        "is_user_active",
        "has_user_permission",
        "add_user_to_group",
        "remove_user_from_group",
        "create_user_account",
        "update_user_profile",
        "delete_user_account",
        "validate_user_input",
        "parse_config_file",
        "format_user_data",
        "calculate_user_score",
        "process_user_request",
        "generate_user_report",
        "find_user_by_email",
        "sort_users_by_name",
        "filter_active_users",
        "transform_user_data",
        "convert_user_format"
    ]
    
    print("Pattern recognition results:")
    for func_name in test_functions:
        purpose = analyzer._determine_purpose(func_name)
        print(f"  {func_name:25} → {purpose}")
    
    # Test class patterns
    test_classes = [
        "UserManager",
        "DataHandler", 
        "ConfigService",
        "ReportFactory",
        "DatabaseBuilder"
    ]
    
    print("\nClass pattern recognition:")
    for class_name in test_classes:
        purpose = analyzer._determine_class_purpose(class_name, [])
        print(f"  {class_name:15} → {purpose}")

def main():
    """Run all demonstrations."""
    print("AI Code Comment Generator - Programmatic Usage Demo")
    print("=" * 50)
    
    try:
        demo_single_file_processing()
        demo_analyzer_only()
        demo_batch_processing()
        demo_pattern_recognition()
        
        print("\n" + "=" * 50)
        print("All demonstrations completed successfully!")
        print("\nTo use the tool from command line:")
        print("  python main.py --help")
        print("\nTo process your own files:")
        print("  python main.py your_file.py")
        print("  python main.py your_directory/")
        
    except Exception as e:
        print(f"Error during demonstration: {e}")

if __name__ == "__main__":
    main() 