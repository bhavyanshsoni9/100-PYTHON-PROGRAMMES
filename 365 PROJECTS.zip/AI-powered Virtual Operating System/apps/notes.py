import tkinter as tk
from tkinter import filedialog

def save_note():
    file = filedialog.asksaveasfilename(defaultextension=".txt")
    if file:
        with open(file, 'w') as f:
            f.write(text.get("1.0", tk.END))

win = tk.Tk()
win.title("Notes")
win.geometry("400x400")
text = tk.Text(win, wrap='word')
text.pack(expand=True, fill='both')

tk.Button(win, text="💾 Save", command=save_note).pack()
win.mainloop()
