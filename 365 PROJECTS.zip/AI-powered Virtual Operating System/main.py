import tkinter as tk
import os
import subprocess
import speech_recognition as sr
import threading

def launch_app(app_name):
    subprocess.Popen(['python', f'apps/{app_name}.py'])

def voice_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Listening...")
        audio = recognizer.listen(source)
    try:
        command = recognizer.recognize_google(audio).lower()
        print("🗣️ You said:", command)

        if "open notes" in command:
            launch_app("notes")
        elif "open file manager" in command:
            launch_app("file_manager")
        elif "open chat" in command:
            launch_app("chatbot")
        else:
            print("❌ Unknown command")

    except sr.UnknownValueError:
        print("🤐 Couldn't understand you")

app = tk.Tk()
app.title("AI Virtual OS")
app.geometry("400x500")
app.configure(bg="#1e1e2f")

tk.Label(app, text="🧠 AI Virtual OS", font=("Arial", 20), bg="#1e1e2f", fg="white").pack(pady=20)

tk.Button(app, text="📝 Open Notes", command=lambda: launch_app("notes"), width=25).pack(pady=10)
tk.Button(app, text="🗂️ Open File Manager", command=lambda: launch_app("file_manager"), width=25).pack(pady=10)
tk.Button(app, text="🤖 Chat with AI", command=lambda: launch_app("chatbot"), width=25).pack(pady=10)
tk.Button(app, text="🎙️ Voice Command", command=lambda: threading.Thread(target=voice_command).start(), width=25).pack(pady=10)

app.mainloop()
