#!/usr/bin/env python3
"""
AiScribe - AI-Powered Text Generator and Editor
Created by BHAVYANSH SONI
A retro-style AI text generation and editing tool
"""

import os
import sys
import time
import random
from datetime import datetime
from colorama import init, Fore, Back, Style
import json
import re

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.BLUE}{'='*60}
{Fore.CYAN}     █████╗ ██╗███████╗ ██████╗██████╗ ██╗██████╗ ███████╗
{Fore.CYAN}    ██╔══██╗██║██╔════╝██╔════╝██╔══██╗██║██╔══██╗██╔════╝
{Fore.CYAN}    ███████║██║███████╗██║     ██████╔╝██║██████╔╝█████╗  
{Fore.CYAN}    ██╔══██║██║╚════██║██║     ██╔══██╗██║██╔══██╗██╔══╝  
{Fore.CYAN}    ██║  ██║██║███████║╚██████╗██║  ██║██║██████╔╝███████╗
{Fore.CYAN}    ╚═╝  ╚═╝╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝
{Fore.BLUE}{'='*60}
{Fore.YELLOW}    ✍️  AI-Powered Text Generator & Editor
{Fore.MAGENTA}    🤖 Created by: BHAVYANSH SONI
{Fore.BLUE}{'='*60}
"""
    print(header)

class AITextGenerator:
    """AI Text Generator class"""
    
    def __init__(self):
        self.writing_styles = {
            'formal': {'tone': 'professional', 'complexity': 'high'},
            'casual': {'tone': 'friendly', 'complexity': 'medium'},
            'creative': {'tone': 'imaginative', 'complexity': 'varied'},
            'technical': {'tone': 'precise', 'complexity': 'high'},
            'persuasive': {'tone': 'convincing', 'complexity': 'medium'}
        }
        
        self.text_templates = {
            'email': "Subject: {subject}\n\nDear {recipient},\n\n{content}\n\nBest regards,\n{sender}",
            'article': "# {title}\n\n{intro}\n\n## Main Content\n\n{content}\n\n## Conclusion\n\n{conclusion}",
            'story': "Once upon a time, {opening}. {development} In the end, {conclusion}.",
            'poem': "{line1}\n{line2}\n{line3}\n{line4}",
            'report': "## Executive Summary\n\n{summary}\n\n## Analysis\n\n{analysis}\n\n## Recommendations\n\n{recommendations}"
        }
        
        self.word_banks = {
            'adjectives': ['innovative', 'dynamic', 'sophisticated', 'remarkable', 'exceptional', 'outstanding', 'impressive', 'revolutionary', 'cutting-edge', 'state-of-the-art'],
            'nouns': ['solution', 'approach', 'methodology', 'framework', 'system', 'process', 'strategy', 'technique', 'innovation', 'advancement'],
            'verbs': ['implement', 'optimize', 'enhance', 'develop', 'create', 'establish', 'improve', 'transform', 'revolutionize', 'streamline']
        }

    def generate_text(self, prompt, style='casual', length='medium'):
        """Generate AI text based on prompt"""
        # Simulate AI text generation
        templates = [
            "This is an AI-generated response to your prompt about {prompt}. The {style} style approach emphasizes {emphasis}.",
            "Based on your request regarding {prompt}, I would suggest considering {suggestion}. This {style} perspective offers {benefit}.",
            "In response to '{prompt}', it's important to note that {insight}. The {style} approach would involve {approach}.",
            "Your prompt about {prompt} raises interesting points. From a {style} standpoint, {analysis}.",
            "Regarding {prompt}, the key consideration is {consideration}. A {style} response would highlight {highlight}."
        ]
        
        emphasis_words = {
            'formal': 'professional communication and structured presentation',
            'casual': 'accessibility and natural flow',
            'creative': 'originality and engaging narrative',
            'technical': 'precision and detailed explanation',
            'persuasive': 'compelling arguments and clear benefits'
        }
        
        template = random.choice(templates)
        
        # Generate contextual content
        emphasis = emphasis_words.get(style, 'clear communication')
        suggestion = f"implementing {random.choice(self.word_banks['adjectives'])} {random.choice(self.word_banks['nouns'])}"
        insight = f"the {random.choice(self.word_banks['adjectives'])} nature of this topic"
        analysis = f"we should {random.choice(self.word_banks['verbs'])} the core elements"
        consideration = f"finding a {random.choice(self.word_banks['adjectives'])} {random.choice(self.word_banks['nouns'])}"
        highlight = f"the need to {random.choice(self.word_banks['verbs'])} existing {random.choice(self.word_banks['nouns'])}"
        approach = f"{random.choice(self.word_banks['verbs'])}ing {random.choice(self.word_banks['adjectives'])} {random.choice(self.word_banks['nouns'])}"
        benefit = f"{random.choice(self.word_banks['adjectives'])} advantages"
        
        generated_text = template.format(
            prompt=prompt,
            style=style,
            emphasis=emphasis,
            suggestion=suggestion,
            insight=insight,
            analysis=analysis,
            consideration=consideration,
            highlight=highlight,
            approach=approach,
            benefit=benefit
        )
        
        # Adjust length
        if length == 'short':
            return generated_text.split('.')[0] + '.'
        elif length == 'long':
            return generated_text + f" Furthermore, this {style} approach ensures {random.choice(self.word_banks['adjectives'])} results through {random.choice(self.word_banks['adjectives'])} {random.choice(self.word_banks['nouns'])}."
        
        return generated_text

    def improve_text(self, text):
        """Improve existing text"""
        improvements = []
        
        # Check for basic improvements
        if len(text.split()) < 10:
            improvements.append("Consider expanding with more details")
        
        if not any(char in text for char in '.!?'):
            improvements.append("Add punctuation for better readability")
        
        if text.islower():
            improvements.append("Use proper capitalization")
        
        if len(text.split('.')) < 2:
            improvements.append("Break into multiple sentences")
        
        # Generate improved version
        words = text.split()
        improved_words = []
        
        for word in words:
            if len(word) > 3 and random.random() < 0.2:  # 20% chance to improve
                if word.lower() in ['good', 'nice', 'great']:
                    improved_words.append(random.choice(self.word_banks['adjectives']))
                elif word.lower() in ['do', 'make', 'get']:
                    improved_words.append(random.choice(self.word_banks['verbs']))
                else:
                    improved_words.append(word)
            else:
                improved_words.append(word)
        
        improved_text = ' '.join(improved_words)
        
        return improved_text, improvements

    def analyze_text(self, text):
        """Analyze text for insights"""
        words = text.split()
        sentences = text.split('.')
        
        analysis = {
            'word_count': len(words),
            'sentence_count': len([s for s in sentences if s.strip()]),
            'avg_word_length': sum(len(word) for word in words) / len(words) if words else 0,
            'readability': self.calculate_readability(text),
            'sentiment': self.analyze_sentiment(text),
            'complexity': self.analyze_complexity(text)
        }
        
        return analysis

    def calculate_readability(self, text):
        """Calculate readability score"""
        words = text.split()
        sentences = len([s for s in text.split('.') if s.strip()])
        
        if sentences == 0:
            return 0
        
        avg_sentence_length = len(words) / sentences
        
        # Simple readability calculation
        if avg_sentence_length < 10:
            return "Easy"
        elif avg_sentence_length < 20:
            return "Medium"
        else:
            return "Difficult"

    def analyze_sentiment(self, text):
        """Analyze text sentiment"""
        positive_words = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'outstanding', 'remarkable', 'impressive', 'exceptional']
        negative_words = ['bad', 'terrible', 'awful', 'horrible', 'disappointing', 'poor', 'inadequate', 'unsatisfactory', 'problematic', 'concerning']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return "Positive"
        elif negative_count > positive_count:
            return "Negative"
        else:
            return "Neutral"

    def analyze_complexity(self, text):
        """Analyze text complexity"""
        words = text.split()
        complex_words = [word for word in words if len(word) > 6]
        complexity_ratio = len(complex_words) / len(words) if words else 0
        
        if complexity_ratio < 0.2:
            return "Simple"
        elif complexity_ratio < 0.4:
            return "Moderate"
        else:
            return "Complex"

def display_text_with_highlighting(text, title="Generated Text"):
    """Display text with syntax highlighting"""
    slow_print(f"\n{Fore.CYAN}📝 {title}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    # Add line numbers and formatting
    lines = text.split('\n')
    for i, line in enumerate(lines, 1):
        if line.strip():
            slow_print(f"{Fore.BLUE}{i:2d} | {Fore.WHITE}{line}", 0.01)
        else:
            slow_print(f"{Fore.BLUE}{i:2d} | ", 0.01)
    
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)

def display_analysis_results(analysis):
    """Display text analysis results"""
    slow_print(f"\n{Fore.CYAN}📊 Text Analysis Results", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Word Count: {Fore.WHITE}{analysis['word_count']}", 0.02)
    slow_print(f"{Fore.GREEN}Sentences: {Fore.WHITE}{analysis['sentence_count']}", 0.02)
    slow_print(f"{Fore.GREEN}Avg Word Length: {Fore.WHITE}{analysis['avg_word_length']:.1f} characters", 0.02)
    slow_print(f"{Fore.GREEN}Readability: {Fore.WHITE}{analysis['readability']}", 0.02)
    slow_print(f"{Fore.GREEN}Sentiment: {Fore.WHITE}{analysis['sentiment']}", 0.02)
    slow_print(f"{Fore.GREEN}Complexity: {Fore.WHITE}{analysis['complexity']}", 0.02)

def main():
    """Main function"""
    print_header()
    
    generator = AITextGenerator()
    
    while True:
        slow_print(f"\n{Fore.CYAN}✍️ AiScribe Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Generate AI Text", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Improve Text", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Analyze Text", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Create Template", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Writing Assistant", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-6): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}🤖 AI Text Generation", 0.02)
            
            prompt = input(f"{Fore.YELLOW}Enter your prompt: ").strip()
            if not prompt:
                slow_print(f"{Fore.RED}❌ Please enter a prompt", 0.02)
                continue
            
            style = input(f"{Fore.YELLOW}Writing style (formal/casual/creative/technical/persuasive): ").strip() or 'casual'
            length = input(f"{Fore.YELLOW}Length (short/medium/long): ").strip() or 'medium'
            
            slow_print(f"\n{Fore.YELLOW}🤖 AI is generating text...", 0.02)
            time.sleep(2)
            
            generated_text = generator.generate_text(prompt, style, length)
            display_text_with_highlighting(generated_text, f"AI Generated Text ({style} style)")
            
            # Analyze generated text
            analysis = generator.analyze_text(generated_text)
            display_analysis_results(analysis)
        
        elif choice == '2':
            slow_print(f"\n{Fore.CYAN}✨ Text Improvement", 0.02)
            
            text = input(f"{Fore.YELLOW}Enter text to improve: ").strip()
            if not text:
                slow_print(f"{Fore.RED}❌ Please enter text", 0.02)
                continue
            
            slow_print(f"\n{Fore.YELLOW}🔄 Analyzing and improving text...", 0.02)
            time.sleep(1)
            
            improved_text, suggestions = generator.improve_text(text)
            
            display_text_with_highlighting(text, "Original Text")
            display_text_with_highlighting(improved_text, "Improved Text")
            
            if suggestions:
                slow_print(f"\n{Fore.CYAN}💡 Improvement Suggestions:", 0.02)
                for i, suggestion in enumerate(suggestions, 1):
                    slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{suggestion}", 0.02)
        
        elif choice == '3':
            slow_print(f"\n{Fore.CYAN}📊 Text Analysis", 0.02)
            
            text = input(f"{Fore.YELLOW}Enter text to analyze: ").strip()
            if not text:
                slow_print(f"{Fore.RED}❌ Please enter text", 0.02)
                continue
            
            slow_print(f"\n{Fore.YELLOW}🔍 Analyzing text...", 0.02)
            time.sleep(1)
            
            analysis = generator.analyze_text(text)
            display_analysis_results(analysis)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}📋 Template Creation", 0.02)
            
            template_types = list(generator.text_templates.keys())
            slow_print(f"{Fore.YELLOW}Available templates:", 0.02)
            for i, template_type in enumerate(template_types, 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{template_type.title()}", 0.02)
            
            try:
                template_choice = int(input(f"\n{Fore.YELLOW}Select template (1-{len(template_types)}): ").strip()) - 1
                if 0 <= template_choice < len(template_types):
                    template_type = template_types[template_choice]
                    template = generator.text_templates[template_type]
                    
                    slow_print(f"\n{Fore.CYAN}📝 {template_type.title()} Template:", 0.02)
                    display_text_with_highlighting(template, f"{template_type.title()} Template")
                else:
                    slow_print(f"{Fore.RED}❌ Invalid template choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Please enter a valid number", 0.02)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}🎯 Writing Assistant", 0.02)
            
            slow_print(f"{Fore.YELLOW}Writing Tips:", 0.02)
            tips = [
                "Use active voice for clarity",
                "Vary sentence length for rhythm",
                "Start with strong opening sentences",
                "Use specific examples and details",
                "Edit ruthlessly - remove unnecessary words",
                "Read your writing aloud",
                "Use transitions between paragraphs",
                "End with a clear conclusion"
            ]
            
            for i, tip in enumerate(tips, 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{tip}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Writing Styles Available:", 0.02)
            for style, info in generator.writing_styles.items():
                slow_print(f"{Fore.CYAN}• {style.title()}: {Fore.WHITE}{info['tone']} tone, {info['complexity']} complexity", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using AiScribe! Keep writing!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '6':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
