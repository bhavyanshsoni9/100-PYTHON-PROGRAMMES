import os
import json
import time
import random
from colorama import init, Fore, Style

init(autoreset=True)

MOCKS_DIR = os.path.join(os.path.dirname(__file__), 'mocks')

EMOJIS = {
    200: '✅',
    201: '✅',
    400: '⚠️',
    401: '❌',
    403: '⛔',
    500: '💥',
}

COLORS = {
    'GET': Fore.CYAN,
    'POST': Fore.MAGENTA,
    'status_2xx': Fore.GREEN,
    'status_4xx': Fore.YELLOW,
    'status_5xx': Fore.RED,
    'endpoint': Fore.BLUE,
    'reset': Style.RESET_ALL
}

def list_mocks():
    mocks = []
    for fname in os.listdir(MOCKS_DIR):
        if fname.endswith('.json'):
            with open(os.path.join(MOCKS_DIR, fname), 'r') as f:
                try:
                    data = json.load(f)
                    mocks.append((fname, data))
                except Exception:
                    continue
    return mocks

def print_request(req):
    method = req.get('method', 'GET')
    endpoint = req.get('endpoint', '/')
    color = COLORS.get(method, '')
    print(f"{color}{method}{COLORS['reset']} {COLORS['endpoint']}{endpoint}{COLORS['reset']}")

def print_response(resp):
    status = resp.get('status', 0)
    emoji = EMOJIS.get(status, '❓')
    if 200 <= status < 300:
        color = COLORS['status_2xx']
    elif 400 <= status < 500:
        color = COLORS['status_4xx']
    elif 500 <= status < 600:
        color = COLORS['status_5xx']
    else:
        color = COLORS['reset']
    print(f"{color}Status: {status} {emoji}{COLORS['reset']}")
    print(f"{color}Response Body:{COLORS['reset']}")
    print(json.dumps(resp.get('body', {}), indent=2))

def main():
    mocks = list_mocks()
    if not mocks:
        print(Fore.RED + "No mock files found in /mocks!" + Style.RESET_ALL)
        return
    print(Fore.YELLOW + "\nAvailable API Mocks:" + Style.RESET_ALL)
    for i, (fname, data) in enumerate(mocks):
        req = data.get('request', {})
        print(f"[{i+1}] {req.get('method', 'GET')} {req.get('endpoint', '/')} ({fname})")
    try:
        choice = int(input("\nSelect a mock to test (number): ")) - 1
        if not (0 <= choice < len(mocks)):
            raise ValueError
    except ValueError:
        print(Fore.RED + "Invalid selection!" + Style.RESET_ALL)
        return
    mock = mocks[choice][1]
    req = mock.get('request', {})
    resp = mock.get('response', {})
    latency = input("Simulate network latency? Enter seconds (e.g., 1.5) or leave blank for random (0.5-2s): ")
    try:
        delay = float(latency) if latency else random.uniform(0.5, 2.0)
    except ValueError:
        delay = random.uniform(0.5, 2.0)
    print(Fore.CYAN + f"\n--- Sending Request ---" + Style.RESET_ALL)
    print_request(req)
    print(Fore.YELLOW + f"\nSimulating network latency: {delay:.2f}s..." + Style.RESET_ALL)
    time.sleep(delay)
    print(Fore.GREEN + f"\n--- Response ---" + Style.RESET_ALL)
    print_response(resp)

if __name__ == "__main__":
    main() 