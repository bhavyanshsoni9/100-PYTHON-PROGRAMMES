import os
import time
import random
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

# Dictionary of basic ASCII art fonts
FONTS = {
    'standard': {
        'A': ['  #  ', ' # # ', '#####', '#   #', '#   #'],
        'B': ['#### ', '#   #', '#### ', '#   #', '#### '],
        'C': [' ####', '#    ', '#    ', '#    ', ' ####'],
        # Add more letters as needed
    },
    'block': {
        'A': ['█████', '█   █', '█████', '█   █', '█   █'],
        'B': ['████ ', '█   █', '████ ', '█   █', '████ '],
        'C': ['█████', '█    ', '█    ', '█    ', '█████'],
        # Add more letters as needed
    }
}

class ASCIIBannerMaker:
    def __init__(self):
        self.colors = [Fore.RED, Fore.GREEN, Fore.BLUE, Fore.YELLOW, Fore.MAGENTA, Fore.CYAN]
        self.current_font = 'standard'

    def welcome_screen(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║     Welcome to ASCII Banner Maker      ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(random.choice(self.colors) + line + Style.RESET_ALL)
        time.sleep(1)

    def get_banner_text(self):
        """Get text input from user"""
        while True:
            text = input(Fore.CYAN + "\nEnter your banner text (letters A-C only): " + Style.RESET_ALL).upper()
            if all(char in 'ABC ' for char in text):
                return text
            slow_print(Fore.RED + "Error: Only letters A-C are supported for now!" + Style.RESET_ALL)

    def create_banner(self, text):
        """Create ASCII art banner from text"""
        # Initialize empty lines for the banner
        banner_lines = [''] * 5
        
        # Build each line of the banner
        for char in text:
            if char == ' ':
                for i in range(5):
                    banner_lines[i] += '  '
            else:
                for i in range(5):
                    banner_lines[i] += FONTS[self.current_font][char][i] + ' '
        
        return banner_lines

    def display_banner(self, banner_lines):
        """Display the banner with colors"""
        print("\nYour Banner:\n")
        for line in banner_lines:
            color = random.choice(self.colors)
            slow_print(color + line + Style.RESET_ALL, delay=0.01)

    def main_menu(self):
        """Main program loop"""
        while True:
            clear_screen()
            self.welcome_screen()
            
            slow_print(Fore.YELLOW + "\nOptions:" + Style.RESET_ALL)
            slow_print("1. Create New Banner")
            slow_print("2. Change Font Style")
            slow_print("3. Exit")
            
            choice = input(Fore.GREEN + "\nEnter your choice (1-3): " + Style.RESET_ALL)
            
            if choice == '1':
                text = self.get_banner_text()
                banner = self.create_banner(text)
                self.display_banner(banner)
                input(Fore.CYAN + "\nPress Enter to continue..." + Style.RESET_ALL)
            
            elif choice == '2':
                self.current_font = 'block' if self.current_font == 'standard' else 'standard'
                slow_print(Fore.GREEN + f"\nFont style changed to {self.current_font}!" + Style.RESET_ALL)
                time.sleep(1)
            
            elif choice == '3':
                slow_print(Fore.YELLOW + "\nThank you for using ASCII Banner Maker!" + Style.RESET_ALL)
                break
            
            else:
                slow_print(Fore.RED + "\nInvalid choice! Please try again." + Style.RESET_ALL)
                time.sleep(1)

if __name__ == "__main__":
    try:
        banner_maker = ASCIIBannerMaker()
        banner_maker.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "\nProgram terminated by user. Goodbye!" + Style.RESET_ALL)
    except Exception as e:
        slow_print(Fore.RED + f"\nAn error occurred: {str(e)}" + Style.RESET_ALL)