#!/usr/bin/env python3
"""
AnonChat - Anonymous Chat Client
Created by BHAVYANSH SONI
A retro-style anonymous chat client with colored output
"""

import os
import sys
import time
import random
import socket
import threading
from datetime import datetime
from colorama import init, Fore, Back, Style
import uuid
import json

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.GREEN}{'='*60}
{Fore.CYAN}     █████╗ ███╗   ██╗ ██████╗ ███╗   ██╗ ██████╗██╗  ██╗ █████╗ ████████╗
{Fore.CYAN}    ██╔══██╗████╗  ██║██╔═══██╗████╗  ██║██╔════╝██║  ██║██╔══██╗╚══██╔══╝
{Fore.CYAN}    ███████║██╔██╗ ██║██║   ██║██╔██╗ ██║██║     ███████║███████║   ██║   
{Fore.CYAN}    ██╔══██║██║╚██╗██║██║   ██║██║╚██╗██║██║     ██╔══██║██╔══██║   ██║   
{Fore.CYAN}    ██║  ██║██║ ╚████║╚██████╔╝██║ ╚████║╚██████╗██║  ██║██║  ██║   ██║   
{Fore.CYAN}    ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   
{Fore.GREEN}{'='*60}
{Fore.YELLOW}    💬 Anonymous Chat Client - Secure & Private
{Fore.MAGENTA}    🔒 Created by: BHAVYANSH SONI
{Fore.GREEN}{'='*60}
"""
    print(header)

class AnonChatClient:
    """Anonymous chat client class"""
    
    def __init__(self):
        self.username = self.generate_anonymous_name()
        self.user_id = str(uuid.uuid4())[:8]
        self.connected = False
        self.messages = []
        self.rooms = ['General', 'Tech', 'Gaming', 'Random', 'Study']
        self.current_room = 'General'
        self.encryption_key = self.generate_encryption_key()
        
    def generate_anonymous_name(self):
        """Generate anonymous username"""
        adjectives = ['Anonymous', 'Hidden', 'Secret', 'Ghost', 'Shadow', 'Phantom', 'Mystic', 'Enigma', 'Stealth', 'Cipher']
        nouns = ['User', 'Agent', 'Visitor', 'Guest', 'Stranger', 'Wanderer', 'Traveler', 'Explorer', 'Seeker', 'Hunter']
        
        return f"{random.choice(adjectives)}{random.choice(nouns)}{random.randint(100, 999)}"
    
    def generate_encryption_key(self):
        """Generate simple encryption key"""
        return random.randint(1000, 9999)
    
    def encrypt_message(self, message):
        """Simple message encryption"""
        encrypted = ""
        for char in message:
            encrypted += chr((ord(char) + self.encryption_key) % 256)
        return encrypted
    
    def decrypt_message(self, encrypted_message):
        """Simple message decryption"""
        decrypted = ""
        for char in encrypted_message:
            decrypted += chr((ord(char) - self.encryption_key) % 256)
        return decrypted
    
    def simulate_connection(self):
        """Simulate chat connection"""
        slow_print(f"{Fore.YELLOW}🔌 Connecting to anonymous chat network...", 0.02)
        time.sleep(2)
        
        steps = [
            "Initializing secure connection...",
            "Generating anonymous identity...",
            "Establishing encrypted tunnel...",
            "Joining chat network...",
            "Connection established!"
        ]
        
        for step in steps:
            slow_print(f"{Fore.GREEN}✓ {step}", 0.02)
            time.sleep(0.5)
        
        self.connected = True
        return True
    
    def simulate_chat_messages(self):
        """Simulate incoming chat messages"""
        sample_messages = [
            {"user": "TechGuru42", "message": "Anyone working on Python projects?", "room": "Tech"},
            {"user": "GameMaster99", "message": "Just finished a new RPG level!", "room": "Gaming"},
            {"user": "StudyBuddy", "message": "Need help with algorithms", "room": "Study"},
            {"user": "RandomUser123", "message": "How's everyone doing today?", "room": "Random"},
            {"user": "CryptoFan", "message": "Blockchain is the future!", "room": "Tech"},
            {"user": "NightOwl", "message": "Anyone else up late coding?", "room": "General"},
            {"user": "ArtisticSoul", "message": "Just finished a digital painting", "room": "General"},
            {"user": "MusicLover", "message": "What's your favorite coding music?", "room": "General"}
        ]
        
        # Filter messages by current room
        room_messages = [msg for msg in sample_messages if msg["room"] == self.current_room]
        
        if room_messages:
            return random.choice(room_messages)
        return None
    
    def display_chat_interface(self):
        """Display main chat interface"""
        slow_print(f"\n{Fore.CYAN}💬 Chat Interface", 0.02)
        slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
        
        slow_print(f"{Fore.GREEN}Username: {Fore.WHITE}{self.username}", 0.02)
        slow_print(f"{Fore.GREEN}User ID: {Fore.WHITE}{self.user_id}", 0.02)
        slow_print(f"{Fore.GREEN}Room: {Fore.WHITE}{self.current_room}", 0.02)
        slow_print(f"{Fore.GREEN}Encryption: {Fore.WHITE}Enabled (Key: {self.encryption_key})", 0.02)
        
        slow_print(f"\n{Fore.YELLOW}Recent Messages:", 0.02)
        
        # Display recent messages
        for i in range(5):
            message = self.simulate_chat_messages()
            if message:
                timestamp = datetime.now().strftime("%H:%M")
                slow_print(f"{Fore.BLUE}[{timestamp}] {Fore.CYAN}{message['user']}: {Fore.WHITE}{message['message']}", 0.02)
                time.sleep(0.3)
    
    def send_message(self, message):
        """Send a message"""
        if not self.connected:
            slow_print(f"{Fore.RED}❌ Not connected to chat network", 0.02)
            return False
        
        # Encrypt message
        encrypted_msg = self.encrypt_message(message)
        
        # Simulate sending
        timestamp = datetime.now().strftime("%H:%M")
        slow_print(f"{Fore.BLUE}[{timestamp}] {Fore.GREEN}{self.username}: {Fore.WHITE}{message}", 0.02)
        
        # Store message
        self.messages.append({
            'user': self.username,
            'message': message,
            'timestamp': timestamp,
            'encrypted': encrypted_msg,
            'room': self.current_room
        })
        
        return True
    
    def change_room(self, room):
        """Change chat room"""
        if room in self.rooms:
            self.current_room = room
            slow_print(f"{Fore.GREEN}✓ Switched to room: {room}", 0.02)
            return True
        else:
            slow_print(f"{Fore.RED}❌ Room '{room}' not found", 0.02)
            return False
    
    def display_user_stats(self):
        """Display user statistics"""
        slow_print(f"\n{Fore.CYAN}📊 User Statistics", 0.02)
        slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
        
        slow_print(f"{Fore.GREEN}Messages Sent: {Fore.WHITE}{len(self.messages)}", 0.02)
        slow_print(f"{Fore.GREEN}Session Duration: {Fore.WHITE}{random.randint(5, 30)} minutes", 0.02)
        slow_print(f"{Fore.GREEN}Rooms Visited: {Fore.WHITE}{random.randint(1, 3)}", 0.02)
        slow_print(f"{Fore.GREEN}Encryption Level: {Fore.WHITE}256-bit", 0.02)
        slow_print(f"{Fore.GREEN}Anonymity Score: {Fore.WHITE}{random.randint(85, 99)}%", 0.02)

def display_privacy_features():
    """Display privacy and security features"""
    slow_print(f"\n{Fore.CYAN}🔒 Privacy & Security Features", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    features = [
        "🔐 End-to-end encryption",
        "👤 Anonymous usernames",
        "🚫 No message logging",
        "🛡️ IP address masking",
        "⏰ Auto-disconnect after inactivity",
        "🔄 Message self-destruction",
        "🎭 Multiple identity support",
        "🌐 Global server network"
    ]
    
    for feature in features:
        slow_print(f"{Fore.GREEN}✓ {feature}", 0.02)

def display_chat_commands():
    """Display available chat commands"""
    slow_print(f"\n{Fore.CYAN}⚡ Chat Commands", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    commands = [
        "/join <room> - Switch to different room",
        "/users - List online users",
        "/whisper <user> <message> - Send private message",
        "/me <action> - Send action message",
        "/clear - Clear chat history",
        "/status - Show connection status",
        "/rooms - List available rooms",
        "/help - Show this help message"
    ]
    
    for command in commands:
        slow_print(f"{Fore.GREEN}• {Fore.WHITE}{command}", 0.02)

def main():
    """Main function"""
    print_header()
    
    client = AnonChatClient()
    
    while True:
        slow_print(f"\n{Fore.CYAN}💬 AnonChat Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Connect to Chat", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}View Chat Interface", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Send Message", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Change Room", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}User Statistics", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Privacy Features", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Chat Commands", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            if not client.connected:
                if client.simulate_connection():
                    slow_print(f"\n{Fore.GREEN}🎉 Successfully connected to AnonChat!", 0.02)
                    slow_print(f"{Fore.CYAN}Your anonymous identity: {Fore.WHITE}{client.username}", 0.02)
            else:
                slow_print(f"{Fore.YELLOW}⚠️ Already connected to chat network", 0.02)
        
        elif choice == '2':
            if client.connected:
                client.display_chat_interface()
            else:
                slow_print(f"{Fore.RED}❌ Please connect to chat first", 0.02)
        
        elif choice == '3':
            if client.connected:
                message = input(f"{Fore.YELLOW}Enter message: ").strip()
                if message:
                    client.send_message(message)
                else:
                    slow_print(f"{Fore.RED}❌ Message cannot be empty", 0.02)
            else:
                slow_print(f"{Fore.RED}❌ Please connect to chat first", 0.02)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}Available Rooms:", 0.02)
            for i, room in enumerate(client.rooms, 1):
                status = "(Current)" if room == client.current_room else ""
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{room} {Fore.YELLOW}{status}", 0.02)
            
            try:
                room_choice = int(input(f"\n{Fore.YELLOW}Select room (1-{len(client.rooms)}): ").strip()) - 1
                if 0 <= room_choice < len(client.rooms):
                    client.change_room(client.rooms[room_choice])
                else:
                    slow_print(f"{Fore.RED}❌ Invalid room choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Please enter a valid number", 0.02)
        
        elif choice == '5':
            client.display_user_stats()
        
        elif choice == '6':
            display_privacy_features()
        
        elif choice == '7':
            display_chat_commands()
        
        elif choice == '8':
            if client.connected:
                slow_print(f"\n{Fore.YELLOW}🔌 Disconnecting from chat network...", 0.02)
                time.sleep(1)
                slow_print(f"{Fore.GREEN}✓ Disconnected safely", 0.02)
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using AnonChat! Stay anonymous!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
