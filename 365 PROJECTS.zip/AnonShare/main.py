#!/usr/bin/env python3
"""
AnonShare - Anonymous File Sharing System
Created by BHAVYANSH SONI
A retro-style anonymous file sharing platform with colored output
"""

import os
import sys
import time
import random
import hashlib
import base64
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import uuid
import json

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.MAGENTA}{'='*60}
{Fore.CYAN}     █████╗ ███╗   ██╗ ██████╗ ███╗   ██╗███████╗██╗  ██╗ █████╗ ██████╗ ███████╗
{Fore.CYAN}    ██╔══██╗████╗  ██║██╔═══██╗████╗  ██║██╔════╝██║  ██║██╔══██╗██╔══██╗██╔════╝
{Fore.CYAN}    ███████║██╔██╗ ██║██║   ██║██╔██╗ ██║███████╗███████║███████║██████╔╝█████╗  
{Fore.CYAN}    ██╔══██║██║╚██╗██║██║   ██║██║╚██╗██║╚════██║██╔══██║██╔══██║██╔══██╗██╔══╝  
{Fore.CYAN}    ██║  ██║██║ ╚████║╚██████╔╝██║ ╚████║███████║██║  ██║██║  ██║██║  ██║███████╗
{Fore.CYAN}    ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝
{Fore.MAGENTA}{'='*60}
{Fore.YELLOW}    📁 Anonymous File Sharing System - Secure & Private
{Fore.MAGENTA}    🔒 Created by: BHAVYANSH SONI
{Fore.MAGENTA}{'='*60}
"""
    print(header)

class AnonShare:
    """Anonymous file sharing system"""
    
    def __init__(self):
        self.shared_files = {}
        self.download_links = {}
        self.upload_history = []
        self.max_file_size = 100 * 1024 * 1024  # 100MB limit
        self.supported_formats = ['.txt', '.pdf', '.doc', '.docx', '.jpg', '.png', '.gif', '.mp3', '.mp4', '.zip', '.tar', '.gz']
        self.encryption_enabled = True
        
    def generate_share_id(self):
        """Generate unique share ID"""
        return str(uuid.uuid4()).replace('-', '')[:12]
    
    def generate_download_link(self, share_id):
        """Generate anonymous download link"""
        return f"https://anonshare.secure/{share_id}"
    
    def encrypt_file_name(self, filename):
        """Encrypt filename for anonymity"""
        hash_obj = hashlib.sha256(filename.encode())
        return hash_obj.hexdigest()[:16]
    
    def calculate_file_hash(self, file_path):
        """Calculate file hash for integrity"""
        if not os.path.exists(file_path):
            return None
        
        hash_obj = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_obj.update(chunk)
        return hash_obj.hexdigest()
    
    def get_file_size(self, file_path):
        """Get file size in bytes"""
        if os.path.exists(file_path):
            return os.path.getsize(file_path)
        return 0
    
    def format_file_size(self, size_bytes):
        """Format file size in human readable format"""
        if size_bytes == 0:
            return "0 B"
        
        size_names = ["B", "KB", "MB", "GB", "TB"]
        i = 0
        
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
        
        return f"{size_bytes:.1f} {size_names[i]}"
    
    def is_file_supported(self, filename):
        """Check if file format is supported"""
        _, ext = os.path.splitext(filename)
        return ext.lower() in self.supported_formats
    
    def upload_file(self, file_path, expire_hours=24, password=None):
        """Upload file for anonymous sharing"""
        if not os.path.exists(file_path):
            return {"success": False, "error": "File not found"}
        
        filename = os.path.basename(file_path)
        file_size = self.get_file_size(file_path)
        
        # Check file size limit
        if file_size > self.max_file_size:
            return {"success": False, "error": "File too large (max 100MB)"}
        
        # Check supported format
        if not self.is_file_supported(filename):
            return {"success": False, "error": "File format not supported"}
        
        # Generate share details
        share_id = self.generate_share_id()
        file_hash = self.calculate_file_hash(file_path)
        encrypted_name = self.encrypt_file_name(filename)
        download_link = self.generate_download_link(share_id)
        
        # Calculate expiration
        expire_time = datetime.now() + timedelta(hours=expire_hours)
        
        # Store file info
        file_info = {
            'share_id': share_id,
            'original_name': filename,
            'encrypted_name': encrypted_name,
            'file_size': file_size,
            'file_hash': file_hash,
            'upload_time': datetime.now().isoformat(),
            'expire_time': expire_time.isoformat(),
            'download_link': download_link,
            'password_protected': password is not None,
            'download_count': 0,
            'max_downloads': 10
        }
        
        self.shared_files[share_id] = file_info
        self.download_links[share_id] = download_link
        self.upload_history.append(file_info)
        
        return {"success": True, "file_info": file_info}
    
    def get_file_info(self, share_id):
        """Get file information by share ID"""
        if share_id in self.shared_files:
            return self.shared_files[share_id]
        return None
    
    def download_file(self, share_id, password=None):
        """Download file by share ID"""
        file_info = self.get_file_info(share_id)
        
        if not file_info:
            return {"success": False, "error": "File not found"}
        
        # Check expiration
        expire_time = datetime.fromisoformat(file_info['expire_time'])
        if datetime.now() > expire_time:
            return {"success": False, "error": "File has expired"}
        
        # Check download limit
        if file_info['download_count'] >= file_info['max_downloads']:
            return {"success": False, "error": "Download limit reached"}
        
        # Check password
        if file_info['password_protected'] and not password:
            return {"success": False, "error": "Password required"}
        
        # Increment download count
        file_info['download_count'] += 1
        
        return {"success": True, "file_info": file_info}
    
    def list_shared_files(self):
        """List all shared files"""
        active_files = []
        
        for share_id, file_info in self.shared_files.items():
            expire_time = datetime.fromisoformat(file_info['expire_time'])
            if datetime.now() <= expire_time:
                active_files.append(file_info)
        
        return active_files
    
    def delete_file(self, share_id):
        """Delete shared file"""
        if share_id in self.shared_files:
            del self.shared_files[share_id]
            if share_id in self.download_links:
                del self.download_links[share_id]
            return True
        return False
    
    def get_system_stats(self):
        """Get system statistics"""
        total_files = len(self.shared_files)
        active_files = len(self.list_shared_files())
        total_size = sum(file['file_size'] for file in self.shared_files.values())
        total_downloads = sum(file['download_count'] for file in self.shared_files.values())
        
        return {
            'total_files': total_files,
            'active_files': active_files,
            'total_size': total_size,
            'total_downloads': total_downloads,
            'supported_formats': len(self.supported_formats)
        }

def display_upload_result(result):
    """Display upload result"""
    if result['success']:
        file_info = result['file_info']
        slow_print(f"\n{Fore.GREEN}✅ File uploaded successfully!", 0.02)
        slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
        
        slow_print(f"{Fore.CYAN}Share ID: {Fore.WHITE}{file_info['share_id']}", 0.02)
        slow_print(f"{Fore.CYAN}Download Link: {Fore.WHITE}{file_info['download_link']}", 0.02)
        slow_print(f"{Fore.CYAN}File Size: {Fore.WHITE}{AnonShare().format_file_size(file_info['file_size'])}", 0.02)
        slow_print(f"{Fore.CYAN}Expires: {Fore.WHITE}{file_info['expire_time'][:19]}", 0.02)
        slow_print(f"{Fore.CYAN}Max Downloads: {Fore.WHITE}{file_info['max_downloads']}", 0.02)
        
        slow_print(f"\n{Fore.YELLOW}⚠️ Important:", 0.02)
        slow_print(f"{Fore.WHITE}• Save the Share ID and Download Link", 0.02)
        slow_print(f"{Fore.WHITE}• File will auto-delete after expiration", 0.02)
        slow_print(f"{Fore.WHITE}• Maximum {file_info['max_downloads']} downloads allowed", 0.02)
    else:
        slow_print(f"\n{Fore.RED}❌ Upload failed: {result['error']}", 0.02)

def display_file_list(files):
    """Display list of shared files"""
    if not files:
        slow_print(f"{Fore.YELLOW}📁 No active files found", 0.02)
        return
    
    slow_print(f"\n{Fore.CYAN}📂 Active Shared Files:", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    for i, file_info in enumerate(files, 1):
        expire_time = datetime.fromisoformat(file_info['expire_time'])
        time_left = expire_time - datetime.now()
        hours_left = int(time_left.total_seconds() / 3600)
        
        slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{file_info['original_name']}", 0.02)
        slow_print(f"   {Fore.CYAN}Share ID: {Fore.WHITE}{file_info['share_id']}", 0.02)
        slow_print(f"   {Fore.CYAN}Size: {Fore.WHITE}{AnonShare().format_file_size(file_info['file_size'])}", 0.02)
        slow_print(f"   {Fore.CYAN}Downloads: {Fore.WHITE}{file_info['download_count']}/{file_info['max_downloads']}", 0.02)
        slow_print(f"   {Fore.CYAN}Expires in: {Fore.WHITE}{hours_left} hours", 0.02)
        slow_print(f"   {Fore.CYAN}Protected: {Fore.WHITE}{'Yes' if file_info['password_protected'] else 'No'}", 0.02)
        print()

def display_system_stats(stats):
    """Display system statistics"""
    slow_print(f"\n{Fore.CYAN}📊 System Statistics", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Total Files: {Fore.WHITE}{stats['total_files']}", 0.02)
    slow_print(f"{Fore.GREEN}Active Files: {Fore.WHITE}{stats['active_files']}", 0.02)
    slow_print(f"{Fore.GREEN}Total Size: {Fore.WHITE}{AnonShare().format_file_size(stats['total_size'])}", 0.02)
    slow_print(f"{Fore.GREEN}Total Downloads: {Fore.WHITE}{stats['total_downloads']}", 0.02)
    slow_print(f"{Fore.GREEN}Supported Formats: {Fore.WHITE}{stats['supported_formats']}", 0.02)

def display_security_features():
    """Display security features"""
    slow_print(f"\n{Fore.CYAN}🔒 Security Features", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    features = [
        "🔐 End-to-end encryption",
        "🎭 Anonymous uploads (no registration)",
        "⏰ Auto-expiration of files",
        "🔢 Download count limits",
        "🛡️ Password protection option",
        "🔍 File integrity verification",
        "🚫 No personal data collection",
        "🌐 Secure HTTPS connections"
    ]
    
    for feature in features:
        slow_print(f"{Fore.GREEN}✓ {feature}", 0.02)

def main():
    """Main function"""
    print_header()
    
    anon_share = AnonShare()
    
    while True:
        slow_print(f"\n{Fore.CYAN}📁 AnonShare Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Upload File", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Download File", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}List Shared Files", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Delete File", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}System Statistics", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Security Features", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Supported Formats", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}📤 File Upload", 0.02)
            
            file_path = input(f"{Fore.YELLOW}Enter file path: ").strip()
            if not file_path:
                slow_print(f"{Fore.RED}❌ Please enter a file path", 0.02)
                continue
            
            # Get upload options
            expire_hours = input(f"{Fore.YELLOW}Expiration hours (1-168, default 24): ").strip()
            try:
                expire_hours = int(expire_hours) if expire_hours else 24
                expire_hours = max(1, min(168, expire_hours))  # Limit 1-168 hours
            except ValueError:
                expire_hours = 24
            
            password = input(f"{Fore.YELLOW}Password (optional): ").strip() or None
            
            slow_print(f"\n{Fore.YELLOW}🔄 Uploading file...", 0.02)
            time.sleep(2)
            
            result = anon_share.upload_file(file_path, expire_hours, password)
            display_upload_result(result)
        
        elif choice == '2':
            slow_print(f"\n{Fore.CYAN}📥 File Download", 0.02)
            
            share_id = input(f"{Fore.YELLOW}Enter Share ID: ").strip()
            if not share_id:
                slow_print(f"{Fore.RED}❌ Please enter a Share ID", 0.02)
                continue
            
            # Check if password is needed
            file_info = anon_share.get_file_info(share_id)
            if file_info and file_info['password_protected']:
                password = input(f"{Fore.YELLOW}Enter password: ").strip()
            else:
                password = None
            
            slow_print(f"\n{Fore.YELLOW}🔄 Downloading file...", 0.02)
            time.sleep(1)
            
            result = anon_share.download_file(share_id, password)
            
            if result['success']:
                file_info = result['file_info']
                slow_print(f"\n{Fore.GREEN}✅ Download successful!", 0.02)
                slow_print(f"{Fore.CYAN}File: {Fore.WHITE}{file_info['original_name']}", 0.02)
                slow_print(f"{Fore.CYAN}Size: {Fore.WHITE}{anon_share.format_file_size(file_info['file_size'])}", 0.02)
                slow_print(f"{Fore.CYAN}Downloads: {Fore.WHITE}{file_info['download_count']}/{file_info['max_downloads']}", 0.02)
            else:
                slow_print(f"\n{Fore.RED}❌ Download failed: {result['error']}", 0.02)
        
        elif choice == '3':
            files = anon_share.list_shared_files()
            display_file_list(files)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}🗑️ Delete File", 0.02)
            
            share_id = input(f"{Fore.YELLOW}Enter Share ID to delete: ").strip()
            if not share_id:
                slow_print(f"{Fore.RED}❌ Please enter a Share ID", 0.02)
                continue
            
            if anon_share.delete_file(share_id):
                slow_print(f"\n{Fore.GREEN}✅ File deleted successfully", 0.02)
            else:
                slow_print(f"\n{Fore.RED}❌ File not found", 0.02)
        
        elif choice == '5':
            stats = anon_share.get_system_stats()
            display_system_stats(stats)
        
        elif choice == '6':
            display_security_features()
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}📋 Supported File Formats", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            formats = anon_share.supported_formats
            for i, fmt in enumerate(formats, 1):
                slow_print(f"{Fore.GREEN}{i:2d}. {Fore.WHITE}{fmt}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}📏 File Size Limit: {Fore.WHITE}{anon_share.format_file_size(anon_share.max_file_size)}", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using AnonShare! Share securely!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
