import time
from datetime import datetime
import win32gui

def get_active_window_title():
    window = win32gui.GetForegroundWindow()
    title = win32gui.GetWindowText(window)
    return title

def app_usage_tracker():
    last_window = ""
    log_file = "app_usage_log.txt"

    while True:
        current_window = get_active_window_title()

        if current_window != last_window and current_window.strip() != "":
            last_window = current_window
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log = f"[{now}] {current_window}"
            print(log)

            with open(log_file, "a", encoding="utf-8") as f:
                f.write(log + "\n")

        time.sleep(1)

if __name__ == "__main__":
    print("🖥️ App Usage Tracker is Running... Ctrl+C to stop.")
    app_usage_tracker()
