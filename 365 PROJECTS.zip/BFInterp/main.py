#!/usr/bin/env python3
"""
BFInterp - Brainfuck Interpreter
Created by BHAVYANSH SONI
A retro-style Brainfuck programming language interpreter with colored output
"""

import os
import sys
import time
from colorama import init, Fore, Back, Style

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.RED}{'='*60}
{Fore.CYAN}    ██████╗ ███████╗██╗███╗   ██╗████████╗███████╗██████╗ ██████╗ 
{Fore.CYAN}    ██╔══██╗██╔════╝██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗██╔══██╗
{Fore.CYAN}    ██████╔╝█████╗  ██║██╔██╗ ██║   ██║   █████╗  ██████╔╝██████╔╝
{Fore.CYAN}    ██╔══██╗██╔══╝  ██║██║╚██╗██║   ██║   ██╔══╝  ██╔══██╗██╔═══╝ 
{Fore.CYAN}    ██████╔╝██║     ██║██║ ╚████║   ██║   ███████╗██║  ██║██║     
{Fore.CYAN}    ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     
{Fore.RED}{'='*60}
{Fore.YELLOW}    🧠 Brainfuck Interpreter - Esoteric Programming Language
{Fore.MAGENTA}    🎯 Created by: BHAVYANSH SONI
{Fore.RED}{'='*60}
"""
    print(header)

class BrainfuckInterpreter:
    """Brainfuck interpreter class"""
    
    def __init__(self):
        self.memory = [0] * 30000  # 30k memory cells
        self.pointer = 0           # Data pointer
        self.instruction_pointer = 0  # Code pointer
        self.input_buffer = ""     # Input buffer
        self.output_buffer = ""    # Output buffer
        self.loop_stack = []       # Stack for loop handling
        self.debug_mode = False
        self.step_mode = False
        self.max_iterations = 1000000  # Prevent infinite loops
        
    def reset(self):
        """Reset interpreter state"""
        self.memory = [0] * 30000
        self.pointer = 0
        self.instruction_pointer = 0
        self.input_buffer = ""
        self.output_buffer = ""
        self.loop_stack = []
        
    def set_input(self, input_string):
        """Set input buffer"""
        self.input_buffer = input_string
        
    def get_output(self):
        """Get output buffer"""
        return self.output_buffer
        
    def execute(self, code):
        """Execute Brainfuck code"""
        code = self.clean_code(code)
        
        if not self.validate_brackets(code):
            return {"success": False, "error": "Unmatched brackets in code"}
        
        self.reset()
        iterations = 0
        
        slow_print(f"{Fore.YELLOW}🔄 Executing Brainfuck code...", 0.02)
        
        while self.instruction_pointer < len(code) and iterations < self.max_iterations:
            if self.debug_mode:
                self.debug_step(code)
            
            command = code[self.instruction_pointer]
            
            if command == '>':
                self.pointer += 1
                if self.pointer >= len(self.memory):
                    self.pointer = 0  # Wrap around
                    
            elif command == '<':
                self.pointer -= 1
                if self.pointer < 0:
                    self.pointer = len(self.memory) - 1  # Wrap around
                    
            elif command == '+':
                self.memory[self.pointer] = (self.memory[self.pointer] + 1) % 256
                
            elif command == '-':
                self.memory[self.pointer] = (self.memory[self.pointer] - 1) % 256
                
            elif command == '.':
                char = chr(self.memory[self.pointer])
                self.output_buffer += char
                if self.debug_mode:
                    slow_print(f"{Fore.GREEN}Output: {char}", 0.02)
                    
            elif command == ',':
                if self.input_buffer:
                    self.memory[self.pointer] = ord(self.input_buffer[0])
                    self.input_buffer = self.input_buffer[1:]
                else:
                    self.memory[self.pointer] = 0
                    
            elif command == '[':
                if self.memory[self.pointer] == 0:
                    # Jump to matching ]
                    bracket_count = 1
                    temp_pointer = self.instruction_pointer + 1
                    while temp_pointer < len(code) and bracket_count > 0:
                        if code[temp_pointer] == '[':
                            bracket_count += 1
                        elif code[temp_pointer] == ']':
                            bracket_count -= 1
                        temp_pointer += 1
                    self.instruction_pointer = temp_pointer - 1
                else:
                    self.loop_stack.append(self.instruction_pointer)
                    
            elif command == ']':
                if self.memory[self.pointer] != 0:
                    # Jump back to matching [
                    self.instruction_pointer = self.loop_stack[-1]
                else:
                    self.loop_stack.pop()
            
            self.instruction_pointer += 1
            iterations += 1
            
            if self.step_mode:
                input(f"{Fore.YELLOW}Press Enter to continue...")
        
        if iterations >= self.max_iterations:
            return {"success": False, "error": "Maximum iterations exceeded (possible infinite loop)"}
        
        return {"success": True, "output": self.output_buffer, "iterations": iterations}
    
    def clean_code(self, code):
        """Remove non-Brainfuck characters"""
        valid_chars = set('><+-.,[]')
        return ''.join(c for c in code if c in valid_chars)
    
    def validate_brackets(self, code):
        """Validate bracket matching"""
        bracket_count = 0
        for char in code:
            if char == '[':
                bracket_count += 1
            elif char == ']':
                bracket_count -= 1
                if bracket_count < 0:
                    return False
        return bracket_count == 0
    
    def debug_step(self, code):
        """Debug step display"""
        print(f"\n{Fore.CYAN}Debug Info:")
        print(f"IP: {self.instruction_pointer}, Command: {code[self.instruction_pointer]}")
        print(f"Pointer: {self.pointer}, Value: {self.memory[self.pointer]}")
        print(f"Memory around pointer: {self.memory[max(0, self.pointer-5):self.pointer+6]}")
        print(f"Output so far: {repr(self.output_buffer)}")
    
    def get_memory_dump(self, start=0, length=20):
        """Get memory dump"""
        end = min(start + length, len(self.memory))
        return self.memory[start:end]
    
    def analyze_code(self, code):
        """Analyze Brainfuck code"""
        code = self.clean_code(code)
        
        analysis = {
            'length': len(code),
            'commands': {},
            'complexity': 0,
            'loops': 0,
            'valid_brackets': self.validate_brackets(code)
        }
        
        # Count commands
        for command in '><+-.,[]':
            analysis['commands'][command] = code.count(command)
        
        # Calculate complexity
        analysis['complexity'] = (
            analysis['commands']['['] * 2 +  # Loops are complex
            analysis['commands'][']'] * 2 +
            analysis['commands'][','] * 1.5 +  # I/O is moderately complex
            analysis['commands']['.'] * 1.5 +
            analysis['commands']['+'] +
            analysis['commands']['-'] +
            analysis['commands']['>'] +
            analysis['commands']['<']
        )
        
        analysis['loops'] = analysis['commands']['[']
        
        return analysis

def get_sample_programs():
    """Get sample Brainfuck programs"""
    programs = {
        'Hello World': '++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]>>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++.',
        'Cat (Echo)': '+[,.+]',
        'ROT13': '+[>+<-]+[<]>[[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>>[<+>-]<[>+<-]>+[,.]',
        'Add Two Numbers': ',>,<[>+<-]>.',
        'Multiply Two Numbers': ',>,<[>[>+>+<<-]>>[<<+>>-]<<<-]>>>.',
        'Fibonacci': '+>+>,[<[>>+<<-]>[<+>-]>-]<<[>>+<<-]>>.'
    }
    return programs

def display_program_samples():
    """Display sample programs"""
    programs = get_sample_programs()
    
    slow_print(f"\n{Fore.CYAN}📋 Sample Brainfuck Programs:", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    for i, (name, code) in enumerate(programs.items(), 1):
        slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{name}", 0.02)
        slow_print(f"   {Fore.CYAN}Code: {Fore.WHITE}{code[:50]}{'...' if len(code) > 50 else ''}", 0.02)
        print()

def display_code_analysis(analysis):
    """Display code analysis"""
    slow_print(f"\n{Fore.CYAN}📊 Code Analysis:", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Length: {Fore.WHITE}{analysis['length']} characters", 0.02)
    slow_print(f"{Fore.GREEN}Valid Brackets: {Fore.WHITE}{'Yes' if analysis['valid_brackets'] else 'No'}", 0.02)
    slow_print(f"{Fore.GREEN}Loops: {Fore.WHITE}{analysis['loops']}", 0.02)
    slow_print(f"{Fore.GREEN}Complexity Score: {Fore.WHITE}{analysis['complexity']:.1f}", 0.02)
    
    slow_print(f"\n{Fore.YELLOW}Command Breakdown:", 0.02)
    for command, count in analysis['commands'].items():
        if count > 0:
            slow_print(f"{Fore.CYAN}{command}: {Fore.WHITE}{count} times", 0.02)

def display_memory_dump(interpreter, start=0, length=20):
    """Display memory dump"""
    memory = interpreter.get_memory_dump(start, length)
    
    slow_print(f"\n{Fore.CYAN}🧠 Memory Dump (cells {start}-{start+length-1}):", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    # Display memory in rows of 10
    for i in range(0, len(memory), 10):
        row = memory[i:i+10]
        addresses = [f"{start+i+j:3d}" for j in range(len(row))]
        values = [f"{val:3d}" for val in row]
        
        slow_print(f"{Fore.GREEN}Addr: {Fore.WHITE}{' '.join(addresses)}", 0.02)
        slow_print(f"{Fore.GREEN}Val:  {Fore.WHITE}{' '.join(values)}", 0.02)
        
        # Show pointer position
        if start <= interpreter.pointer < start + length:
            pointer_pos = interpreter.pointer - start
            if i <= pointer_pos < i + 10:
                pointer_line = "      " + "    " * (pointer_pos - i) + "^^^"
                slow_print(f"{Fore.RED}{pointer_line}", 0.02)
        print()

def main():
    """Main function"""
    print_header()
    
    interpreter = BrainfuckInterpreter()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🧠 BFInterp Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Execute Code", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Load Sample Program", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Analyze Code", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Debug Mode", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Memory Dump", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Language Guide", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-7): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}💻 Execute Brainfuck Code", 0.02)
            
            code = input(f"{Fore.YELLOW}Enter Brainfuck code: ").strip()
            if not code:
                slow_print(f"{Fore.RED}❌ Please enter some code", 0.02)
                continue
            
            # Get input if needed
            if ',' in code:
                user_input = input(f"{Fore.YELLOW}Enter input for program: ").strip()
                interpreter.set_input(user_input)
            
            start_time = time.time()
            result = interpreter.execute(code)
            end_time = time.time()
            
            if result['success']:
                slow_print(f"\n{Fore.GREEN}✅ Execution completed!", 0.02)
                slow_print(f"{Fore.CYAN}Output: {Fore.WHITE}{repr(result['output'])}", 0.02)
                slow_print(f"{Fore.CYAN}Iterations: {Fore.WHITE}{result['iterations']}", 0.02)
                slow_print(f"{Fore.CYAN}Execution time: {Fore.WHITE}{end_time - start_time:.4f}s", 0.02)
                
                if result['output']:
                    slow_print(f"\n{Fore.YELLOW}Readable output:", 0.02)
                    slow_print(f"{Fore.WHITE}{result['output']}", 0.02)
            else:
                slow_print(f"\n{Fore.RED}❌ Execution failed: {result['error']}", 0.02)
        
        elif choice == '2':
            slow_print(f"\n{Fore.CYAN}📋 Sample Programs", 0.02)
            display_program_samples()
            
            programs = get_sample_programs()
            program_names = list(programs.keys())
            
            try:
                program_choice = int(input(f"{Fore.YELLOW}Select program (1-{len(program_names)}): ").strip()) - 1
                if 0 <= program_choice < len(program_names):
                    program_name = program_names[program_choice]
                    code = programs[program_name]
                    
                    slow_print(f"\n{Fore.CYAN}Selected: {Fore.WHITE}{program_name}", 0.02)
                    slow_print(f"{Fore.CYAN}Code: {Fore.WHITE}{code}", 0.02)
                    
                    # Get input if needed
                    if ',' in code:
                        user_input = input(f"{Fore.YELLOW}Enter input for program: ").strip()
                        interpreter.set_input(user_input)
                    
                    result = interpreter.execute(code)
                    
                    if result['success']:
                        slow_print(f"\n{Fore.GREEN}✅ Execution completed!", 0.02)
                        slow_print(f"{Fore.CYAN}Output: {Fore.WHITE}{repr(result['output'])}", 0.02)
                        if result['output']:
                            slow_print(f"{Fore.YELLOW}Readable: {Fore.WHITE}{result['output']}", 0.02)
                    else:
                        slow_print(f"\n{Fore.RED}❌ Execution failed: {result['error']}", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid program choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Please enter a valid number", 0.02)
        
        elif choice == '3':
            slow_print(f"\n{Fore.CYAN}📊 Code Analysis", 0.02)
            
            code = input(f"{Fore.YELLOW}Enter Brainfuck code to analyze: ").strip()
            if not code:
                slow_print(f"{Fore.RED}❌ Please enter some code", 0.02)
                continue
            
            analysis = interpreter.analyze_code(code)
            display_code_analysis(analysis)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}🐛 Debug Mode", 0.02)
            
            interpreter.debug_mode = not interpreter.debug_mode
            status = "enabled" if interpreter.debug_mode else "disabled"
            slow_print(f"{Fore.GREEN}Debug mode {status}", 0.02)
            
            if interpreter.debug_mode:
                slow_print(f"{Fore.YELLOW}⚠️ Debug mode will show step-by-step execution", 0.02)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}🧠 Memory Dump", 0.02)
            
            start = input(f"{Fore.YELLOW}Start address (default 0): ").strip()
            length = input(f"{Fore.YELLOW}Length (default 20): ").strip()
            
            try:
                start = int(start) if start else 0
                length = int(length) if length else 20
                
                display_memory_dump(interpreter, start, length)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid address or length", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}📖 Brainfuck Language Guide", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            commands = [
                (">", "Move pointer right"),
                ("<", "Move pointer left"),
                ("+", "Increment memory cell"),
                ("-", "Decrement memory cell"),
                (".", "Output character"),
                (",", "Input character"),
                ("[", "Start loop (if cell != 0)"),
                ("]", "End loop (if cell != 0)")
            ]
            
            slow_print(f"{Fore.GREEN}Commands:", 0.02)
            for cmd, desc in commands:
                slow_print(f"{Fore.CYAN}{cmd}: {Fore.WHITE}{desc}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Example: Hello World", 0.02)
            slow_print(f"{Fore.WHITE}++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]>>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++.", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Memory Model:", 0.02)
            slow_print(f"{Fore.WHITE}• 30,000 memory cells (0-255 each)", 0.02)
            slow_print(f"{Fore.WHITE}• Pointer starts at position 0", 0.02)
            slow_print(f"{Fore.WHITE}• Memory wraps around at boundaries", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using BFInterp! Happy coding!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '7':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
