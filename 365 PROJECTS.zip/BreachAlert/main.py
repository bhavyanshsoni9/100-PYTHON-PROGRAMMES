#!/usr/bin/env python3
"""
BreachAlert - Security Breach Detection System
Created by BHAVYANSH SONI
A retro-style security monitoring and breach detection system with colored output
"""

import os
import sys
import time
import random
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import json
import hashlib

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.RED}{'='*60}
{Fore.CYAN}    ██████╗ ██████╗ ███████╗ █████╗  ██████╗██╗  ██╗ █████╗ ██╗     ███████╗██████╗ ████████╗
{Fore.CYAN}    ██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔════╝██║  ██║██╔══██╗██║     ██╔════╝██╔══██╗╚══██╔══╝
{Fore.CYAN}    ██████╔╝██████╔╝█████╗  ███████║██║     ███████║███████║██║     █████╗  ██████╔╝   ██║   
{Fore.CYAN}    ██╔══██╗██╔══██╗██╔══╝  ██╔══██║██║     ██╔══██║██╔══██║██║     ██╔══╝  ██╔══██╗   ██║   
{Fore.CYAN}    ██████╔╝██║  ██║███████╗██║  ██║╚██████╗██║  ██║██║  ██║███████╗███████╗██║  ██║   ██║   
{Fore.CYAN}    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝   
{Fore.RED}{'='*60}
{Fore.YELLOW}    🚨 Security Breach Detection System - Real-time Monitoring
{Fore.MAGENTA}    🛡️ Created by: BHAVYANSH SONI
{Fore.RED}{'='*60}
"""
    print(header)

class SecurityEvent:
    """Security event class"""
    
    def __init__(self, event_type, severity, source_ip, description, timestamp=None):
        self.event_id = hashlib.md5(f"{time.time()}{random.random()}".encode()).hexdigest()[:8]
        self.event_type = event_type
        self.severity = severity
        self.source_ip = source_ip
        self.description = description
        self.timestamp = timestamp or datetime.now()
        self.status = "Active"
        self.investigated = False

class BreachDetector:
    """Security breach detection system"""
    
    def __init__(self):
        self.events = []
        self.threat_patterns = self.load_threat_patterns()
        self.monitored_systems = []
        self.alert_rules = self.load_alert_rules()
        self.threat_intelligence = self.load_threat_intelligence()
        self.security_metrics = {
            'total_events': 0,
            'critical_events': 0,
            'blocked_attempts': 0,
            'false_positives': 0,
            'response_time': 0
        }
    
    def load_threat_patterns(self):
        """Load known threat patterns"""
        return {
            'bruteforce': {
                'pattern': 'Multiple failed login attempts',
                'threshold': 5,
                'timeframe': 300,  # 5 minutes
                'severity': 'High'
            },
            'sql_injection': {
                'pattern': 'SQL injection attempt detected',
                'keywords': ['union', 'select', 'drop', 'insert', 'update'],
                'severity': 'Critical'
            },
            'port_scan': {
                'pattern': 'Port scanning activity',
                'threshold': 10,
                'timeframe': 60,
                'severity': 'Medium'
            },
            'malware': {
                'pattern': 'Malware signature detected',
                'severity': 'Critical'
            },
            'data_exfiltration': {
                'pattern': 'Unusual data transfer volume',
                'threshold': 1000,  # MB
                'severity': 'High'
            },
            'privilege_escalation': {
                'pattern': 'Unauthorized privilege escalation attempt',
                'severity': 'Critical'
            }
        }
    
    def load_alert_rules(self):
        """Load alert rules"""
        return {
            'failed_login_threshold': 3,
            'suspicious_ip_timeout': 3600,
            'data_transfer_limit': 500,
            'after_hours_access': True,
            'geolocation_filter': True,
            'automated_response': True
        }
    
    def load_threat_intelligence(self):
        """Load threat intelligence data"""
        return {
            'malicious_ips': [
                '192.168.1.100',
                '10.0.0.50',
                '172.16.0.25',
                '203.0.113.0',
                '198.51.100.0'
            ],
            'known_signatures': [
                'suspicious_script.exe',
                'malware_payload.bin',
                'trojan_horse.dll'
            ],
            'attack_vectors': [
                'Web Application Attack',
                'Email Phishing',
                'USB Malware',
                'Network Intrusion',
                'Social Engineering'
            ]
        }
    
    def generate_security_event(self):
        """Generate simulated security event"""
        event_types = [
            'Failed Login Attempt',
            'Suspicious Network Traffic',
            'Malware Detection',
            'Unauthorized Access Attempt',
            'Data Breach Attempt',
            'Port Scan Detected',
            'SQL Injection Attempt',
            'Privilege Escalation',
            'DDoS Attack',
            'Phishing Attempt'
        ]
        
        severities = ['Low', 'Medium', 'High', 'Critical']
        
        # Generate random IP
        source_ip = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
        
        event_type = random.choice(event_types)
        severity = random.choice(severities)
        
        descriptions = {
            'Failed Login Attempt': f'Multiple failed login attempts from {source_ip}',
            'Suspicious Network Traffic': f'Unusual network patterns detected from {source_ip}',
            'Malware Detection': f'Malware signature found in file from {source_ip}',
            'Unauthorized Access Attempt': f'Unauthorized access attempt to restricted area from {source_ip}',
            'Data Breach Attempt': f'Potential data exfiltration detected from {source_ip}',
            'Port Scan Detected': f'Port scanning activity detected from {source_ip}',
            'SQL Injection Attempt': f'SQL injection attack attempted from {source_ip}',
            'Privilege Escalation': f'Unauthorized privilege escalation attempt from {source_ip}',
            'DDoS Attack': f'Distributed Denial of Service attack from {source_ip}',
            'Phishing Attempt': f'Phishing email detected from {source_ip}'
        }
        
        description = descriptions.get(event_type, f'Security event detected from {source_ip}')
        
        return SecurityEvent(event_type, severity, source_ip, description)
    
    def analyze_threat_level(self, event):
        """Analyze threat level and assign risk score"""
        risk_score = 0
        
        # Base score by severity
        severity_scores = {'Low': 10, 'Medium': 30, 'High': 60, 'Critical': 90}
        risk_score += severity_scores.get(event.severity, 10)
        
        # Check against threat intelligence
        if event.source_ip in self.threat_intelligence['malicious_ips']:
            risk_score += 40
        
        # Check event type
        critical_events = ['Malware Detection', 'Data Breach Attempt', 'SQL Injection Attempt']
        if event.event_type in critical_events:
            risk_score += 30
        
        # Time-based risk (after hours)
        current_hour = datetime.now().hour
        if current_hour < 6 or current_hour > 22:
            risk_score += 15
        
        return min(100, risk_score)
    
    def correlate_events(self, new_event):
        """Correlate events to detect attack patterns"""
        correlations = []
        
        # Check for similar events from same IP in last hour
        one_hour_ago = datetime.now() - timedelta(hours=1)
        similar_events = [
            e for e in self.events
            if e.source_ip == new_event.source_ip
            and e.timestamp > one_hour_ago
            and e.event_type == new_event.event_type
        ]
        
        if len(similar_events) >= 3:
            correlations.append(f"Multiple {new_event.event_type} events from {new_event.source_ip}")
        
        # Check for escalating attack pattern
        attack_progression = [
            'Port Scan Detected',
            'Failed Login Attempt',
            'Unauthorized Access Attempt',
            'Privilege Escalation'
        ]
        
        recent_events = [e.event_type for e in self.events[-10:] if e.source_ip == new_event.source_ip]
        for i, attack_type in enumerate(attack_progression[:-1]):
            if attack_type in recent_events and attack_progression[i+1] == new_event.event_type:
                correlations.append("Escalating attack pattern detected")
        
        return correlations
    
    def generate_response_action(self, event, risk_score):
        """Generate recommended response actions"""
        actions = []
        
        if risk_score >= 80:
            actions.extend([
                "IMMEDIATE: Block source IP",
                "IMMEDIATE: Isolate affected systems",
                "URGENT: Notify security team",
                "URGENT: Initiate incident response"
            ])
        elif risk_score >= 60:
            actions.extend([
                "Block source IP",
                "Monitor affected systems",
                "Notify security team",
                "Review access logs"
            ])
        elif risk_score >= 40:
            actions.extend([
                "Monitor source IP",
                "Increase logging",
                "Review security policies"
            ])
        else:
            actions.extend([
                "Log event",
                "Continue monitoring"
            ])
        
        return actions
    
    def update_metrics(self, event, risk_score):
        """Update security metrics"""
        self.security_metrics['total_events'] += 1
        
        if event.severity == 'Critical':
            self.security_metrics['critical_events'] += 1
        
        if risk_score >= 70:
            self.security_metrics['blocked_attempts'] += 1

def display_security_dashboard(detector):
    """Display security dashboard"""
    slow_print(f"\n{Fore.CYAN}🛡️ Security Dashboard", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    metrics = detector.security_metrics
    slow_print(f"{Fore.GREEN}Total Events: {Fore.WHITE}{metrics['total_events']}", 0.02)
    slow_print(f"{Fore.GREEN}Critical Events: {Fore.WHITE}{metrics['critical_events']}", 0.02)
    slow_print(f"{Fore.GREEN}Blocked Attempts: {Fore.WHITE}{metrics['blocked_attempts']}", 0.02)
    slow_print(f"{Fore.GREEN}Active Threats: {Fore.WHITE}{len([e for e in detector.events if e.status == 'Active'])}", 0.02)
    
    # Threat level indicator
    if metrics['critical_events'] > 5:
        threat_level = "HIGH"
        threat_color = Fore.RED
    elif metrics['critical_events'] > 2:
        threat_level = "MEDIUM"
        threat_color = Fore.YELLOW
    else:
        threat_level = "LOW"
        threat_color = Fore.GREEN
    
    slow_print(f"\n{Fore.GREEN}Current Threat Level: {threat_color}{threat_level}", 0.02)

def display_security_event(event, risk_score, correlations, actions):
    """Display detailed security event"""
    severity_colors = {
        'Low': Fore.GREEN,
        'Medium': Fore.YELLOW,
        'High': Fore.RED,
        'Critical': Fore.MAGENTA
    }
    
    color = severity_colors.get(event.severity, Fore.WHITE)
    
    slow_print(f"\n{Fore.RED}🚨 SECURITY ALERT", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
    
    slow_print(f"{Fore.CYAN}Event ID: {Fore.WHITE}{event.event_id}", 0.02)
    slow_print(f"{Fore.CYAN}Type: {Fore.WHITE}{event.event_type}", 0.02)
    slow_print(f"{Fore.CYAN}Severity: {color}{event.severity}", 0.02)
    slow_print(f"{Fore.CYAN}Source IP: {Fore.WHITE}{event.source_ip}", 0.02)
    slow_print(f"{Fore.CYAN}Timestamp: {Fore.WHITE}{event.timestamp.strftime('%Y-%m-%d %H:%M:%S')}", 0.02)
    slow_print(f"{Fore.CYAN}Risk Score: {Fore.WHITE}{risk_score}/100", 0.02)
    slow_print(f"{Fore.CYAN}Description: {Fore.WHITE}{event.description}", 0.02)
    
    if correlations:
        slow_print(f"\n{Fore.YELLOW}🔗 Event Correlations:", 0.02)
        for correlation in correlations:
            slow_print(f"{Fore.RED}• {correlation}", 0.02)
    
    slow_print(f"\n{Fore.YELLOW}⚡ Recommended Actions:", 0.02)
    for action in actions:
        if "IMMEDIATE" in action or "URGENT" in action:
            slow_print(f"{Fore.RED}• {action}", 0.02)
        else:
            slow_print(f"{Fore.CYAN}• {action}", 0.02)

def display_threat_intelligence(intel):
    """Display threat intelligence"""
    slow_print(f"\n{Fore.CYAN}🕵️ Threat Intelligence", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Known Malicious IPs:", 0.02)
    for ip in intel['malicious_ips'][:5]:
        slow_print(f"{Fore.RED}• {ip}", 0.02)
    
    slow_print(f"\n{Fore.GREEN}Attack Vectors:", 0.02)
    for vector in intel['attack_vectors']:
        slow_print(f"{Fore.YELLOW}• {vector}", 0.02)

def display_recent_events(events, limit=10):
    """Display recent security events"""
    slow_print(f"\n{Fore.CYAN}📋 Recent Security Events", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    recent_events = sorted(events, key=lambda x: x.timestamp, reverse=True)[:limit]
    
    if not recent_events:
        slow_print(f"{Fore.GREEN}No recent events", 0.02)
        return
    
    for event in recent_events:
        severity_colors = {
            'Low': Fore.GREEN,
            'Medium': Fore.YELLOW,
            'High': Fore.RED,
            'Critical': Fore.MAGENTA
        }
        
        color = severity_colors.get(event.severity, Fore.WHITE)
        timestamp = event.timestamp.strftime("%H:%M:%S")
        
        slow_print(f"{color}[{timestamp}] {event.event_type} - {event.source_ip} ({event.severity})", 0.02)

def main():
    """Main function"""
    print_header()
    
    detector = BreachDetector()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🚨 BreachAlert Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Security Dashboard", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Simulate Security Event", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}View Recent Events", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Threat Intelligence", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Real-time Monitoring", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Incident Response", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Security Reports", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            display_security_dashboard(detector)
        
        elif choice == '2':
            slow_print(f"\n{Fore.YELLOW}🔄 Generating security event...", 0.02)
            time.sleep(1)
            
            event = detector.generate_security_event()
            risk_score = detector.analyze_threat_level(event)
            correlations = detector.correlate_events(event)
            actions = detector.generate_response_action(event, risk_score)
            
            detector.events.append(event)
            detector.update_metrics(event, risk_score)
            
            display_security_event(event, risk_score, correlations, actions)
        
        elif choice == '3':
            display_recent_events(detector.events)
        
        elif choice == '4':
            display_threat_intelligence(detector.threat_intelligence)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}📡 Real-time Monitoring", 0.02)
            slow_print(f"{Fore.YELLOW}Monitoring for 30 seconds... (Press Ctrl+C to stop)", 0.02)
            
            try:
                for i in range(30):
                    if random.random() < 0.3:  # 30% chance of event each second
                        event = detector.generate_security_event()
                        risk_score = detector.analyze_threat_level(event)
                        
                        severity_colors = {
                            'Low': Fore.GREEN,
                            'Medium': Fore.YELLOW,
                            'High': Fore.RED,
                            'Critical': Fore.MAGENTA
                        }
                        
                        color = severity_colors.get(event.severity, Fore.WHITE)
                        timestamp = datetime.now().strftime("%H:%M:%S")
                        
                        print(f"{color}[{timestamp}] {event.event_type} - {event.source_ip} (Risk: {risk_score})")
                        
                        detector.events.append(event)
                        detector.update_metrics(event, risk_score)
                    
                    time.sleep(1)
                
                slow_print(f"\n{Fore.GREEN}✅ Monitoring completed", 0.02)
                
            except KeyboardInterrupt:
                slow_print(f"\n{Fore.YELLOW}⏹️ Monitoring stopped", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}🚨 Incident Response Protocol", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            protocols = [
                "1. IDENTIFICATION - Detect and analyze the incident",
                "2. CONTAINMENT - Isolate affected systems",
                "3. ERADICATION - Remove threats and vulnerabilities",
                "4. RECOVERY - Restore systems to normal operation",
                "5. LESSONS LEARNED - Document and improve processes"
            ]
            
            for protocol in protocols:
                slow_print(f"{Fore.GREEN}{protocol}", 0.02)
            
            critical_events = [e for e in detector.events if e.severity == 'Critical']
            if critical_events:
                slow_print(f"\n{Fore.RED}⚠️ {len(critical_events)} critical events require immediate attention", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}📊 Security Report", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            # Event breakdown by severity
            severity_count = {'Low': 0, 'Medium': 0, 'High': 0, 'Critical': 0}
            for event in detector.events:
                severity_count[event.severity] += 1
            
            slow_print(f"{Fore.GREEN}Events by Severity:", 0.02)
            for severity, count in severity_count.items():
                color = {'Low': Fore.GREEN, 'Medium': Fore.YELLOW, 'High': Fore.RED, 'Critical': Fore.MAGENTA}[severity]
                slow_print(f"{color}{severity}: {count} events", 0.02)
            
            # Top source IPs
            ip_count = {}
            for event in detector.events:
                ip_count[event.source_ip] = ip_count.get(event.source_ip, 0) + 1
            
            if ip_count:
                slow_print(f"\n{Fore.GREEN}Top Source IPs:", 0.02)
                top_ips = sorted(ip_count.items(), key=lambda x: x[1], reverse=True)[:5]
                for ip, count in top_ips:
                    slow_print(f"{Fore.CYAN}{ip}: {count} events", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using BreachAlert! Stay secure!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
