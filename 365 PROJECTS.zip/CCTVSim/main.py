#!/usr/bin/env python3
"""
CCTVSim - CCTV Surveillance System Simulator
Created by BHAVYANSH SONI
A retro-style CCTV monitoring and surveillance system simulator with colored output
"""

import os
import sys
import time
import random
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import json

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.BLUE}{'='*60}
{Fore.CYAN}     ██████╗ ██████╗████████╗██╗   ██╗███████╗██╗███╗   ███╗
{Fore.CYAN}    ██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔════╝██║████╗ ████║
{Fore.CYAN}    ██║     ██║        ██║   ██║   ██║███████╗██║██╔████╔██║
{Fore.CYAN}    ██║     ██║        ██║   ╚██╗ ██╔╝╚════██║██║██║╚██╔╝██║
{Fore.CYAN}    ╚██████╗╚██████╗   ██║    ╚████╔╝ ███████║██║██║ ╚═╝ ██║
{Fore.CYAN}     ╚═════╝ ╚═════╝   ╚═╝     ╚═══╝  ╚══════╝╚═╝╚═╝     ╚═╝
{Fore.BLUE}{'='*60}
{Fore.YELLOW}    📹 CCTV Surveillance System Simulator
{Fore.MAGENTA}    👁️ Created by: BHAVYANSH SONI
{Fore.BLUE}{'='*60}
"""
    print(header)

class Camera:
    """Individual camera class"""
    
    def __init__(self, camera_id, name, location, zone):
        self.camera_id = camera_id
        self.name = name
        self.location = location
        self.zone = zone
        self.status = "Online"
        self.resolution = "1920x1080"
        self.fps = 30
        self.recording = True
        self.motion_detection = True
        self.night_vision = True
        self.pan_tilt = random.choice([True, False])
        self.zoom_level = 1.0
        self.last_maintenance = datetime.now() - timedelta(days=random.randint(1, 30))
        self.alerts = []
        
    def get_status_color(self):
        """Get color based on camera status"""
        if self.status == "Online":
            return Fore.GREEN
        elif self.status == "Warning":
            return Fore.YELLOW
        else:
            return Fore.RED

class SecurityEvent:
    """Security event detected by cameras"""
    
    def __init__(self, camera_id, event_type, description, severity="Medium"):
        self.event_id = f"EVT{random.randint(10000, 99999)}"
        self.camera_id = camera_id
        self.event_type = event_type
        self.description = description
        self.severity = severity
        self.timestamp = datetime.now()
        self.investigated = False
        self.resolved = False

class CCTVSystem:
    """Main CCTV surveillance system"""
    
    def __init__(self):
        self.cameras = {}
        self.events = []
        self.recordings = []
        self.zones = ["Entrance", "Lobby", "Parking", "Corridor", "Emergency Exit", "Server Room", "Office", "Warehouse"]
        self.operators = ["Security Team", "Control Room", "Emergency Response"]
        self.system_status = "Operational"
        self.storage_capacity = 5000  # GB
        self.storage_used = random.randint(1000, 4000)
        self.initialize_cameras()
        
    def initialize_cameras(self):
        """Initialize camera network"""
        camera_configs = [
            ("CAM001", "Main Entrance", "Building A - Front Door", "Entrance"),
            ("CAM002", "Lobby Monitor", "Building A - Reception", "Lobby"),
            ("CAM003", "Parking Overview", "Parking Lot - East", "Parking"),
            ("CAM004", "Corridor Watch", "Building A - Floor 2", "Corridor"),
            ("CAM005", "Emergency Exit", "Building A - Rear", "Emergency Exit"),
            ("CAM006", "Server Room", "Building A - Basement", "Server Room"),
            ("CAM007", "Office Area", "Building A - Floor 3", "Office"),
            ("CAM008", "Warehouse", "Building B - Storage", "Warehouse"),
            ("CAM009", "Side Entrance", "Building A - Side Door", "Entrance"),
            ("CAM010", "Rooftop", "Building A - Roof Access", "Corridor")
        ]
        
        for cam_id, name, location, zone in camera_configs:
            camera = Camera(cam_id, name, location, zone)
            
            # Simulate some cameras with issues
            if random.random() < 0.1:  # 10% chance of issues
                camera.status = random.choice(["Offline", "Warning"])
            
            self.cameras[cam_id] = camera
    
    def generate_security_event(self):
        """Generate random security event"""
        event_types = [
            "Motion Detected",
            "Unauthorized Access",
            "Loitering Detected",
            "Object Left Behind",
            "Facial Recognition Alert",
            "Perimeter Breach",
            "Vehicle Detected",
            "Emergency Situation",
            "Vandalism Detected",
            "Crowd Formation"
        ]
        
        descriptions = {
            "Motion Detected": "Unexpected movement detected in restricted area",
            "Unauthorized Access": "Person attempting to access secured zone",
            "Loitering Detected": "Individual remaining in area beyond normal duration",
            "Object Left Behind": "Unattended object detected",
            "Facial Recognition Alert": "Person of interest identified",
            "Perimeter Breach": "Security perimeter has been compromised",
            "Vehicle Detected": "Unauthorized vehicle in restricted area",
            "Emergency Situation": "Potential emergency situation detected",
            "Vandalism Detected": "Suspicious activity suggesting vandalism",
            "Crowd Formation": "Unusual crowd gathering detected"
        }
        
        severities = ["Low", "Medium", "High", "Critical"]
        
        camera_id = random.choice(list(self.cameras.keys()))
        event_type = random.choice(event_types)
        description = descriptions.get(event_type, "Security event detected")
        severity = random.choice(severities)
        
        # Higher chance of critical events in sensitive areas
        camera = self.cameras[camera_id]
        if camera.zone in ["Server Room", "Emergency Exit"]:
            severity = random.choice(["High", "Critical"])
        
        return SecurityEvent(camera_id, event_type, description, severity)
    
    def get_system_statistics(self):
        """Get system-wide statistics"""
        online_cameras = sum(1 for cam in self.cameras.values() if cam.status == "Online")
        total_cameras = len(self.cameras)
        
        recent_events = [e for e in self.events if 
                        (datetime.now() - e.timestamp).total_seconds() < 3600]  # Last hour
        
        critical_events = [e for e in self.events if e.severity == "Critical"]
        
        storage_percentage = (self.storage_used / self.storage_capacity) * 100
        
        return {
            'online_cameras': online_cameras,
            'total_cameras': total_cameras,
            'camera_uptime': (online_cameras / total_cameras) * 100,
            'recent_events': len(recent_events),
            'total_events': len(self.events),
            'critical_events': len(critical_events),
            'storage_used': self.storage_used,
            'storage_capacity': self.storage_capacity,
            'storage_percentage': storage_percentage
        }
    
    def simulate_live_monitoring(self, duration=30):
        """Simulate live monitoring for specified duration"""
        slow_print(f"{Fore.YELLOW}📡 Starting live monitoring for {duration} seconds...", 0.02)
        
        for second in range(duration):
            # Random chance of events
            if random.random() < 0.1:  # 10% chance per second
                event = self.generate_security_event()
                self.events.append(event)
                
                # Display event immediately
                camera = self.cameras[event.camera_id]
                severity_colors = {
                    'Low': Fore.GREEN,
                    'Medium': Fore.YELLOW,
                    'High': Fore.RED,
                    'Critical': Fore.MAGENTA
                }
                
                color = severity_colors.get(event.severity, Fore.WHITE)
                timestamp = event.timestamp.strftime("%H:%M:%S")
                
                print(f"{color}[{timestamp}] {event.camera_id} ({camera.zone}): {event.event_type}")
            
            # Simulate camera status changes
            if random.random() < 0.01:  # 1% chance per second
                camera_id = random.choice(list(self.cameras.keys()))
                camera = self.cameras[camera_id]
                if camera.status == "Online":
                    camera.status = "Warning"
                elif camera.status == "Warning":
                    camera.status = "Online"
            
            time.sleep(1)
        
        slow_print(f"\n{Fore.GREEN}✅ Live monitoring completed", 0.02)

def display_camera_grid(cameras):
    """Display camera grid view"""
    slow_print(f"\n{Fore.CYAN}📹 Camera Grid View", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    # Group cameras by zone
    zones = {}
    for camera in cameras.values():
        if camera.zone not in zones:
            zones[camera.zone] = []
        zones[camera.zone].append(camera)
    
    for zone, zone_cameras in zones.items():
        slow_print(f"\n{Fore.CYAN}🏢 {zone}:", 0.02)
        for camera in zone_cameras:
            status_color = camera.get_status_color()
            recording_icon = "🔴" if camera.recording else "⚫"
            
            slow_print(f"  {recording_icon} {status_color}{camera.camera_id} - {camera.name}", 0.02)
            slow_print(f"     {Fore.WHITE}Location: {camera.location}", 0.02)
            slow_print(f"     {Fore.WHITE}Status: {status_color}{camera.status} {Fore.WHITE}| Resolution: {camera.resolution} | FPS: {camera.fps}", 0.02)

def display_security_events(events, limit=10):
    """Display recent security events"""
    slow_print(f"\n{Fore.CYAN}🚨 Recent Security Events", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    if not events:
        slow_print(f"{Fore.GREEN}No security events detected", 0.02)
        return
    
    recent_events = sorted(events, key=lambda x: x.timestamp, reverse=True)[:limit]
    
    severity_colors = {
        'Low': Fore.GREEN,
        'Medium': Fore.YELLOW,
        'High': Fore.RED,
        'Critical': Fore.MAGENTA
    }
    
    for event in recent_events:
        color = severity_colors.get(event.severity, Fore.WHITE)
        timestamp = event.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        status_icon = "🔍" if event.investigated else "❗"
        
        slow_print(f"{status_icon} {color}[{event.severity}] {event.event_type}", 0.02)
        slow_print(f"   {Fore.WHITE}Camera: {event.camera_id} | Time: {timestamp}", 0.02)
        slow_print(f"   {Fore.WHITE}Description: {event.description}", 0.02)
        slow_print(f"   {Fore.WHITE}Event ID: {event.event_id}", 0.02)
        print()

def display_system_dashboard(stats):
    """Display system dashboard"""
    slow_print(f"\n{Fore.CYAN}📊 System Dashboard", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Camera Network:", 0.02)
    slow_print(f"  Online Cameras: {Fore.WHITE}{stats['online_cameras']}/{stats['total_cameras']}", 0.02)
    slow_print(f"  Network Uptime: {Fore.WHITE}{stats['camera_uptime']:.1f}%", 0.02)
    
    slow_print(f"\n{Fore.GREEN}Security Events:", 0.02)
    slow_print(f"  Recent Events (1h): {Fore.WHITE}{stats['recent_events']}", 0.02)
    slow_print(f"  Total Events: {Fore.WHITE}{stats['total_events']}", 0.02)
    slow_print(f"  Critical Events: {Fore.WHITE}{stats['critical_events']}", 0.02)
    
    slow_print(f"\n{Fore.GREEN}Storage:", 0.02)
    storage_color = Fore.RED if stats['storage_percentage'] > 90 else Fore.YELLOW if stats['storage_percentage'] > 75 else Fore.GREEN
    slow_print(f"  Used: {storage_color}{stats['storage_used']} GB / {stats['storage_capacity']} GB ({stats['storage_percentage']:.1f}%)", 0.02)
    
    # Storage bar
    bar_width = 30
    filled = int((stats['storage_percentage'] / 100) * bar_width)
    bar = '█' * filled + '░' * (bar_width - filled)
    slow_print(f"  {storage_color}{bar}", 0.02)

def display_camera_details(camera):
    """Display detailed camera information"""
    slow_print(f"\n{Fore.CYAN}📹 Camera Details: {camera.camera_id}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
    
    status_color = camera.get_status_color()
    
    slow_print(f"{Fore.GREEN}Name: {Fore.WHITE}{camera.name}", 0.02)
    slow_print(f"{Fore.GREEN}Location: {Fore.WHITE}{camera.location}", 0.02)
    slow_print(f"{Fore.GREEN}Zone: {Fore.WHITE}{camera.zone}", 0.02)
    slow_print(f"{Fore.GREEN}Status: {status_color}{camera.status}", 0.02)
    slow_print(f"{Fore.GREEN}Resolution: {Fore.WHITE}{camera.resolution}", 0.02)
    slow_print(f"{Fore.GREEN}Frame Rate: {Fore.WHITE}{camera.fps} FPS", 0.02)
    slow_print(f"{Fore.GREEN}Recording: {Fore.WHITE}{'Yes' if camera.recording else 'No'}", 0.02)
    slow_print(f"{Fore.GREEN}Motion Detection: {Fore.WHITE}{'Enabled' if camera.motion_detection else 'Disabled'}", 0.02)
    slow_print(f"{Fore.GREEN}Night Vision: {Fore.WHITE}{'Enabled' if camera.night_vision else 'Disabled'}", 0.02)
    slow_print(f"{Fore.GREEN}Pan/Tilt: {Fore.WHITE}{'Available' if camera.pan_tilt else 'Fixed'}", 0.02)
    slow_print(f"{Fore.GREEN}Zoom Level: {Fore.WHITE}{camera.zoom_level}x", 0.02)
    slow_print(f"{Fore.GREEN}Last Maintenance: {Fore.WHITE}{camera.last_maintenance.strftime('%Y-%m-%d')}", 0.02)

def main():
    """Main function"""
    print_header()
    
    cctv_system = CCTVSystem()
    
    while True:
        slow_print(f"\n{Fore.CYAN}📹 CCTVSim Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}System Dashboard", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Camera Grid View", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Security Events", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Live Monitoring", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Camera Details", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Generate Event", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}System Settings", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            stats = cctv_system.get_system_statistics()
            display_system_dashboard(stats)
        
        elif choice == '2':
            display_camera_grid(cctv_system.cameras)
        
        elif choice == '3':
            display_security_events(cctv_system.events)
        
        elif choice == '4':
            duration = input(f"{Fore.YELLOW}Monitoring duration in seconds (default 30): ").strip()
            try:
                duration = int(duration) if duration else 30
                duration = max(5, min(120, duration))  # Limit between 5-120 seconds
            except ValueError:
                duration = 30
            
            cctv_system.simulate_live_monitoring(duration)
        
        elif choice == '5':
            slow_print(f"\n{Fore.YELLOW}Available Cameras:", 0.02)
            for cam_id, camera in cctv_system.cameras.items():
                status_color = camera.get_status_color()
                slow_print(f"{Fore.GREEN}{cam_id}: {Fore.WHITE}{camera.name} {status_color}({camera.status})", 0.02)
            
            camera_id = input(f"\n{Fore.YELLOW}Enter camera ID: ").strip().upper()
            if camera_id in cctv_system.cameras:
                display_camera_details(cctv_system.cameras[camera_id])
            else:
                slow_print(f"{Fore.RED}❌ Camera not found", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.YELLOW}🔄 Generating security event...", 0.02)
            time.sleep(1)
            
            event = cctv_system.generate_security_event()
            cctv_system.events.append(event)
            
            camera = cctv_system.cameras[event.camera_id]
            
            slow_print(f"\n{Fore.GREEN}✅ Event Generated:", 0.02)
            slow_print(f"{Fore.CYAN}Event ID: {Fore.WHITE}{event.event_id}", 0.02)
            slow_print(f"{Fore.CYAN}Type: {Fore.WHITE}{event.event_type}", 0.02)
            slow_print(f"{Fore.CYAN}Camera: {Fore.WHITE}{event.camera_id} ({camera.name})", 0.02)
            slow_print(f"{Fore.CYAN}Severity: {Fore.WHITE}{event.severity}", 0.02)
            slow_print(f"{Fore.CYAN}Description: {Fore.WHITE}{event.description}", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}⚙️ System Settings", 0.02)
            slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
            
            slow_print(f"{Fore.GREEN}Total Cameras: {Fore.WHITE}{len(cctv_system.cameras)}", 0.02)
            slow_print(f"{Fore.GREEN}Storage Capacity: {Fore.WHITE}{cctv_system.storage_capacity} GB", 0.02)
            slow_print(f"{Fore.GREEN}System Status: {Fore.WHITE}{cctv_system.system_status}", 0.02)
            slow_print(f"{Fore.GREEN}Monitoring Zones: {Fore.WHITE}{len(cctv_system.zones)}", 0.02)
            slow_print(f"{Fore.GREEN}Operators: {Fore.WHITE}{', '.join(cctv_system.operators)}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Zone Distribution:", 0.02)
            zone_counts = {}
            for camera in cctv_system.cameras.values():
                zone_counts[camera.zone] = zone_counts.get(camera.zone, 0) + 1
            
            for zone, count in zone_counts.items():
                slow_print(f"{Fore.CYAN}• {zone}: {Fore.WHITE}{count} cameras", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using CCTVSim! Stay secure!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
