import json
import os

FLASHCARDS_FILE = "flashcards.json"
PROGRESS_FILE = "progress.json"

def load_flashcards():
    if os.path.exists(FLASHCARDS_FILE):
        with open(FLASHCARDS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_flashcards(flashcards):
    with open(FLASHCARDS_FILE, "w") as f:
        json.dump(flashcards, f, indent=2)

def load_progress():
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_progress(progress):
    with open(PROGRESS_FILE, "w") as f:
        json.dump(progress, f, indent=2)

def add_flashcard(flashcards):
    question = input("Enter question: ").strip()
    answer = input("Enter answer: ").strip()
    if question and answer:
        flashcards[question] = answer
        save_flashcards(flashcards)
        print("Flashcard added!\n")
    else:
        print("Question and answer cannot be empty.\n")

def quiz(flashcards, progress):
    if not flashcards:
        print("No flashcards available. Add some first!\n")
        return

    for question, answer in flashcards.items():
        print(f"Question: {question}")
        user_answer = input("Your answer: ").strip()
        if user_answer.lower() == answer.lower():
            print("Correct!\n")
            progress[question] = progress.get(question, 0) + 1
        else:
            print(f"Wrong! Correct answer: {answer}\n")
            progress[question] = progress.get(question, 0) - 1
        save_progress(progress)

def main():
    flashcards = load_flashcards()
    progress = load_progress()

    while True:
        print("1. Add Flashcard")
        print("2. Take Quiz")
        print("3. View Progress")
        print("4. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            add_flashcard(flashcards)
        elif choice == "2":
            quiz(flashcards, progress)
        elif choice == "3":
            print("\nYour Progress:")
            for q, score in progress.items():
                print(f"{q}: {'👍' if score > 0 else '👎'} (Score: {score})")
            print()
        elif choice == "4":
            print("Good luck with your learning! 👋")
            break
        else:
            print("Invalid choice. Try again.\n")

if __name__ == "__main__":
    main()
