import random
import time
import os
from colorama import Fore, Back, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class Character:
    def __init__(self, name, hp, mp, strength, magic, defense):
        self.name = name
        self.max_hp = hp
        self.hp = hp
        self.max_mp = mp
        self.mp = mp
        self.strength = strength
        self.magic = magic
        self.defense = defense
        self.spells = []
        self.items = {'Potion': 3, 'Ether': 2}

    def attack(self, target):
        """Physical attack on target"""
        damage = random.randint(self.strength - 2, self.strength + 2)
        damage = max(1, damage - target.defense // 2)
        target.hp = max(0, target.hp - damage)
        return damage

    def cast_spell(self, spell, target):
        """Cast a spell on target"""
        if self.mp >= spell['cost']:
            self.mp -= spell['cost']
            damage = random.randint(spell['power'] - 5, spell['power'] + 5)
            if spell['type'] == 'heal':
                target.hp = min(target.max_hp, target.hp + damage)
                return -damage  # Negative damage indicates healing
            else:
                target.hp = max(0, target.hp - damage)
                return damage
        return 0

    def use_item(self, item):
        """Use an item from inventory"""
        if self.items.get(item, 0) > 0:
            self.items[item] -= 1
            if item == 'Potion':
                heal = 50
                self.hp = min(self.max_hp, self.hp + heal)
                return f"restored {heal} HP"
            elif item == 'Ether':
                restore = 30
                self.mp = min(self.max_mp, self.mp + restore)
                return f"restored {restore} MP"
        return "no effect"

    def status_bar(self):
        """Return a colored status bar"""
        hp_percent = self.hp / self.max_hp
        mp_percent = self.mp / self.max_mp
        
        hp_bar = '█' * int(hp_percent * 10) + '░' * (10 - int(hp_percent * 10))
        mp_bar = '█' * int(mp_percent * 10) + '░' * (10 - int(mp_percent * 10))
        
        hp_color = Fore.GREEN if hp_percent > 0.5 else Fore.YELLOW if hp_percent > 0.2 else Fore.RED
        
        return (f"{self.name}\n"
                f"HP: {hp_color}{hp_bar}{Style.RESET_ALL} {self.hp}/{self.max_hp}\n"
                f"MP: {Fore.BLUE}{mp_bar}{Style.RESET_ALL} {self.mp}/{self.max_mp}")

class RPGBattleGame:
    def __init__(self):
        # Define spells
        self.spells = {
            'Fire': {'cost': 10, 'power': 25, 'type': 'damage'},
            'Ice': {'cost': 12, 'power': 30, 'type': 'damage'},
            'Thunder': {'cost': 15, 'power': 35, 'type': 'damage'},
            'Heal': {'cost': 20, 'power': 40, 'type': 'heal'}
        }
        
        # Create player character
        self.player = Character("Hero", hp=100, mp=50, strength=15, magic=20, defense=10)
        self.player.spells = self.spells
        
        # Create enemy templates
        self.enemy_templates = [
            {"name": "Goblin", "hp": 60, "mp": 20, "strength": 12, "magic": 8, "defense": 5},
            {"name": "Orc", "hp": 80, "mp": 15, "strength": 18, "magic": 5, "defense": 8},
            {"name": "Dark Mage", "hp": 70, "mp": 40, "strength": 8, "magic": 25, "defense": 6}
        ]

    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║        CLI RPG Battle Game            ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def create_enemy(self):
        """Create a random enemy from templates"""
        template = random.choice(self.enemy_templates)
        enemy = Character(**template)
        enemy.spells = {k: v for k, v in self.spells.items() if v['type'] == 'damage'}
        return enemy

    def display_battle_status(self, player, enemy):
        """Display current battle status"""
        print("\n" + "═" * 40)
        print(player.status_bar())
        print("\n" + enemy.status_bar())
        print("═" * 40 + "\n")

    def player_turn(self, player, enemy):
        """Handle player's turn"""
        while True:
            slow_print(f"\n{Fore.YELLOW}Your turn! Choose your action:{Style.RESET_ALL}")
            slow_print("1. Attack")
            slow_print("2. Cast Spell")
            slow_print("3. Use Item")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-3): {Style.RESET_ALL}")
            
            if choice == '1':
                damage = player.attack(enemy)
                slow_print(f"\n{Fore.GREEN}You attacked {enemy.name} for {damage} damage!{Style.RESET_ALL}")
                break
                
            elif choice == '2':
                print(f"\n{Fore.CYAN}Available Spells:{Style.RESET_ALL}")
                for i, (name, spell) in enumerate(player.spells.items(), 1):
                    print(f"{i}. {name} (MP Cost: {spell['cost']}, Power: {spell['power']})")
                
                try:
                    spell_choice = int(input(f"\n{Fore.GREEN}Choose spell (1-{len(player.spells)}): {Style.RESET_ALL}"))
                    spell_name = list(player.spells.keys())[spell_choice - 1]
                    spell = player.spells[spell_name]
                    
                    if player.mp >= spell['cost']:
                        target = enemy if spell['type'] == 'damage' else player
                        damage = player.cast_spell(spell, target)
                        
                        if damage < 0:  # Healing
                            slow_print(f"\n{Fore.GREEN}You cast {spell_name} and healed for {-damage} HP!{Style.RESET_ALL}")
                        else:
                            slow_print(f"\n{Fore.GREEN}You cast {spell_name} on {enemy.name} for {damage} damage!{Style.RESET_ALL}")
                        break
                    else:
                        slow_print(f"\n{Fore.RED}Not enough MP!{Style.RESET_ALL}")
                except (ValueError, IndexError):
                    slow_print(f"\n{Fore.RED}Invalid choice!{Style.RESET_ALL}")
                    
            elif choice == '3':
                print(f"\n{Fore.CYAN}Available Items:{Style.RESET_ALL}")
                for item, count in player.items.items():
                    print(f"- {item} (x{count})")
                
                item_choice = input(f"\n{Fore.GREEN}Enter item name (or press Enter to cancel): {Style.RESET_ALL}")
                if item_choice in player.items and player.items[item_choice] > 0:
                    result = player.use_item(item_choice)
                    slow_print(f"\n{Fore.GREEN}Used {item_choice} and {result}!{Style.RESET_ALL}")
                    break
                elif item_choice:
                    slow_print(f"\n{Fore.RED}Invalid item or none remaining!{Style.RESET_ALL}")
            
            else:
                slow_print(f"\n{Fore.RED}Invalid choice!{Style.RESET_ALL}")

    def enemy_turn(self, enemy, player):
        """Handle enemy's turn"""
        # Enemy AI: Use spells if MP available, otherwise attack
        if enemy.mp >= 10 and random.random() < 0.3:  # 30% chance to use spell if possible
            spell_name = random.choice(list(enemy.spells.keys()))
            spell = enemy.spells[spell_name]
            damage = enemy.cast_spell(spell, player)
            slow_print(f"\n{Fore.RED}{enemy.name} cast {spell_name} for {damage} damage!{Style.RESET_ALL}")
        else:
            damage = enemy.attack(player)
            slow_print(f"\n{Fore.RED}{enemy.name} attacked you for {damage} damage!{Style.RESET_ALL}")

    def battle(self):
        """Main battle loop"""
        enemy = self.create_enemy()
        slow_print(f"\n{Fore.YELLOW}A wild {enemy.name} appears!{Style.RESET_ALL}")
        
        while True:
            self.display_battle_status(self.player, enemy)
            
            # Player's turn
            self.player_turn(self.player, enemy)
            if enemy.hp <= 0:
                slow_print(f"\n{Fore.GREEN}Victory! You defeated the {enemy.name}!{Style.RESET_ALL}")
                return True
            
            time.sleep(1)
            
            # Enemy's turn
            self.enemy_turn(enemy, self.player)
            if self.player.hp <= 0:
                slow_print(f"\n{Fore.RED}Game Over! You were defeated by the {enemy.name}!{Style.RESET_ALL}")
                return False
            
            time.sleep(1)

    def main_menu(self):
        """Main game loop"""
        while True:
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Choose an option:{Style.RESET_ALL}")
            slow_print("1. Start Battle")
            slow_print("2. View Character Status")
            slow_print("3. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-3): {Style.RESET_ALL}")
            
            if choice == '1':
                clear_screen()
                self.battle()
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
                
            elif choice == '2':
                clear_screen()
                print(self.player.status_bar())
                print(f"\n{Fore.CYAN}Items:{Style.RESET_ALL}")
                for item, count in self.player.items.items():
                    print(f"- {item}: {count}")
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
                
            elif choice == '3':
                slow_print(f"\n{Fore.YELLOW}Thanks for playing CLI RPG Battle Game!{Style.RESET_ALL}")
                break
                
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
                time.sleep(1)
            
            clear_screen()

if __name__ == "__main__":
    try:
        game = RPGBattleGame()
        game.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Game terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}") 