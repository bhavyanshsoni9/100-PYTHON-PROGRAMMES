import re
import time
import os
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

# Dictionary of elements and their atomic weights
ELEMENTS = {
    'H': 1.008, 'He': 4.003, 'Li': 6.941, 'Be': 9.012, 'B': 10.811, 'C': 12.011,
    'N': 14.007, 'O': 15.999, 'F': 18.998, 'Ne': 20.180, 'Na': 22.990, 'Mg': 24.305,
    'Al': 26.982, 'Si': 28.086, 'P': 30.974, 'S': 32.065, 'Cl': 35.453, 'Ar': 39.948,
    'K': 39.098, 'Ca': 40.078, 'Fe': 55.845, 'Cu': 63.546, 'Zn': 65.380, 'Ag': 107.868,
    'Au': 196.967, 'Hg': 200.59
}

class ChemicalFormulaParser:
    def __init__(self):
        self.history = []

    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║     Chemical Formula Parser            ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def parse_formula(self, formula):
        """Parse a chemical formula and return a dictionary of elements and their counts"""
        # Remove any whitespace
        formula = formula.strip()
        
        # Pattern to match elements and their counts
        pattern = r'([A-Z][a-z]?)(\d*)'
        matches = re.findall(pattern, formula)
        
        elements = {}
        for element, count in matches:
            if element not in ELEMENTS:
                raise ValueError(f"Unknown element: {element}")
            elements[element] = int(count) if count else 1
                
        return elements

    def calculate_molecular_weight(self, elements):
        """Calculate the molecular weight of a compound"""
        weight = 0
        for element, count in elements.items():
            weight += ELEMENTS[element] * count
        return weight

    def display_result(self, formula, elements, weight):
        """Display the parsed formula and molecular weight"""
        slow_print(f"\n{Fore.GREEN}Formula Analysis:{Style.RESET_ALL}")
        slow_print(f"{Fore.YELLOW}{'Element':<10} {'Count':<8} {'Mass':<10}{Style.RESET_ALL}")
        slow_print("─" * 28)
        
        for element, count in elements.items():
            element_mass = ELEMENTS[element] * count
            print(f"{Fore.CYAN}{element:<10}{Style.RESET_ALL}", end='')
            print(f"{Fore.GREEN}{count:<8}{Style.RESET_ALL}", end='')
            print(f"{Fore.MAGENTA}{element_mass:.3f}{Style.RESET_ALL}")
        
        slow_print("─" * 28)
        slow_print(f"{Fore.YELLOW}Total Molecular Weight: {Fore.GREEN}{weight:.3f} g/mol{Style.RESET_ALL}")
        
        # Add to history
        self.history.append((formula, weight))

    def show_history(self):
        """Display history of calculations"""
        if not self.history:
            slow_print(f"\n{Fore.YELLOW}No calculations in history!{Style.RESET_ALL}")
            return
            
        slow_print(f"\n{Fore.GREEN}Calculation History:{Style.RESET_ALL}")
        slow_print(f"{Fore.YELLOW}{'Formula':<15} {'Molecular Weight':<15}{Style.RESET_ALL}")
        slow_print("─" * 30)
        
        for formula, weight in self.history:
            print(f"{Fore.CYAN}{formula:<15}{Style.RESET_ALL}", end='')
            print(f"{Fore.GREEN}{weight:.3f} g/mol{Style.RESET_ALL}")

    def show_available_elements(self):
        """Display list of available elements"""
        slow_print(f"\n{Fore.GREEN}Available Elements:{Style.RESET_ALL}")
        elements = list(ELEMENTS.keys())
        
        # Display in columns
        col_width = 8
        cols = 8
        for i in range(0, len(elements), cols):
            row = elements[i:i+cols]
            print(Fore.CYAN + ''.join(f"{elem:<{col_width}}" for elem in row) + Style.RESET_ALL)

    def main_menu(self):
        """Main program loop"""
        while True:
            clear_screen()
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Options:{Style.RESET_ALL}")
            slow_print("1. Parse Chemical Formula")
            slow_print("2. View Available Elements")
            slow_print("3. View History")
            slow_print("4. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-4): {Style.RESET_ALL}")
            
            if choice == '1':
                formula = input(f"\n{Fore.CYAN}Enter chemical formula (e.g., H2O, NaCl): {Style.RESET_ALL}")
                try:
                    elements = self.parse_formula(formula)
                    weight = self.calculate_molecular_weight(elements)
                    self.display_result(formula, elements, weight)
                except ValueError as e:
                    slow_print(f"\n{Fore.RED}Error: {str(e)}{Style.RESET_ALL}")
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
                
            elif choice == '2':
                self.show_available_elements()
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
                
            elif choice == '3':
                self.show_history()
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
                
            elif choice == '4':
                slow_print(f"\n{Fore.YELLOW}Thank you for using Chemical Formula Parser!{Style.RESET_ALL}")
                break
                
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
                time.sleep(1)

if __name__ == "__main__":
    try:
        parser = ChemicalFormulaParser()
        parser.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Program terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}")