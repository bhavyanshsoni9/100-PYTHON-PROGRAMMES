#!/usr/bin/env python3
"""
CmdHub - Command Line Hub and Terminal Manager
Created by BHAVYANSH SONI
A retro-style command line interface hub with advanced terminal features
"""

import os
import sys
import time
import subprocess
import json
import shlex
from datetime import datetime
from colorama import init, Fore, Back, Style
import platform
import psutil

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.CYAN}{'='*60}
{Fore.GREEN}     ██████╗███╗   ███╗██████╗ ██╗  ██╗██╗   ██╗██████╗ 
{Fore.GREEN}    ██╔════╝████╗ ████║██╔══██╗██║  ██║██║   ██║██╔══██╗
{Fore.GREEN}    ██║     ██╔████╔██║██║  ██║███████║██║   ██║██████╔╝
{Fore.GREEN}    ██║     ██║╚██╔╝██║██║  ██║██╔══██║██║   ██║██╔══██╗
{Fore.GREEN}    ╚██████╗██║ ╚═╝ ██║██████╔╝██║  ██║╚██████╔╝██████╔╝
{Fore.GREEN}     ╚═════╝╚═╝     ╚═╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ 
{Fore.CYAN}{'='*60}
{Fore.YELLOW}    🖥️ Command Line Hub - Advanced Terminal Manager
{Fore.MAGENTA}    ⚡ Created by: BHAVYANSH SONI
{Fore.CYAN}{'='*60}
"""
    print(header)

class Command:
    """Command history entry"""
    
    def __init__(self, command, exit_code=0, output="", error=""):
        self.command = command
        self.timestamp = datetime.now()
        self.exit_code = exit_code
        self.output = output
        self.error = error
        self.execution_time = 0

class CommandHub:
    """Advanced command line hub"""
    
    def __init__(self):
        self.current_directory = os.getcwd()
        self.command_history = []
        self.aliases = self.load_default_aliases()
        self.environment_vars = dict(os.environ)
        self.bookmarks = {}
        self.scripts = {}
        self.load_config()
        
    def load_default_aliases(self):
        """Load default command aliases"""
        return {
            'll': 'ls -la' if os.name != 'nt' else 'dir',
            'la': 'ls -la' if os.name != 'nt' else 'dir /a',
            'cls': 'clear' if os.name != 'nt' else 'cls',
            'grep': 'findstr' if os.name == 'nt' else 'grep',
            'ps': 'tasklist' if os.name == 'nt' else 'ps aux',
            'kill': 'taskkill /PID' if os.name == 'nt' else 'kill',
            'md': 'mkdir',
            'rd': 'rmdir' if os.name == 'nt' else 'rm -rf',
            'copy': 'cp' if os.name != 'nt' else 'copy',
            'move': 'mv' if os.name != 'nt' else 'move'
        }
    
    def execute_command(self, command_line):
        """Execute a command and return result"""
        if not command_line.strip():
            return None
        
        # Handle built-in commands
        if command_line.startswith('cd '):
            return self.change_directory(command_line[3:].strip())
        elif command_line == 'pwd':
            return self.print_working_directory()
        elif command_line.startswith('alias '):
            return self.handle_alias(command_line[6:].strip())
        elif command_line == 'history':
            return self.show_history()
        elif command_line.startswith('bookmark '):
            return self.handle_bookmark(command_line[9:].strip())
        elif command_line == 'env':
            return self.show_environment()
        
        # Check for aliases
        cmd_parts = shlex.split(command_line)
        if cmd_parts[0] in self.aliases:
            alias_cmd = self.aliases[cmd_parts[0]]
            if len(cmd_parts) > 1:
                command_line = f"{alias_cmd} {' '.join(cmd_parts[1:])}"
            else:
                command_line = alias_cmd
        
        # Execute external command
        start_time = time.time()
        
        try:
            result = subprocess.run(
                command_line,
                shell=True,
                capture_output=True,
                text=True,
                cwd=self.current_directory,
                env=self.environment_vars
            )
            
            execution_time = time.time() - start_time
            
            cmd_entry = Command(
                command_line,
                result.returncode,
                result.stdout,
                result.stderr
            )
            cmd_entry.execution_time = execution_time
            
            self.command_history.append(cmd_entry)
            
            return cmd_entry
            
        except Exception as e:
            cmd_entry = Command(command_line, 1, "", str(e))
            self.command_history.append(cmd_entry)
            return cmd_entry
    
    def change_directory(self, path):
        """Change current directory"""
        try:
            if path == '..':
                new_path = os.path.dirname(self.current_directory)
            elif path == '~':
                new_path = os.path.expanduser('~')
            elif os.path.isabs(path):
                new_path = path
            else:
                new_path = os.path.join(self.current_directory, path)
            
            if os.path.exists(new_path) and os.path.isdir(new_path):
                self.current_directory = os.path.abspath(new_path)
                cmd_entry = Command(f"cd {path}", 0, f"Changed to {self.current_directory}")
                self.command_history.append(cmd_entry)
                return cmd_entry
            else:
                cmd_entry = Command(f"cd {path}", 1, "", "Directory not found")
                self.command_history.append(cmd_entry)
                return cmd_entry
                
        except Exception as e:
            cmd_entry = Command(f"cd {path}", 1, "", str(e))
            self.command_history.append(cmd_entry)
            return cmd_entry
    
    def print_working_directory(self):
        """Print current working directory"""
        cmd_entry = Command("pwd", 0, self.current_directory)
        self.command_history.append(cmd_entry)
        return cmd_entry
    
    def handle_alias(self, alias_def):
        """Handle alias definition"""
        if '=' in alias_def:
            name, command = alias_def.split('=', 1)
            self.aliases[name.strip()] = command.strip()
            cmd_entry = Command(f"alias {alias_def}", 0, f"Alias '{name}' created")
        else:
            # Show alias
            if alias_def in self.aliases:
                cmd_entry = Command(f"alias {alias_def}", 0, f"{alias_def}={self.aliases[alias_def]}")
            else:
                cmd_entry = Command(f"alias {alias_def}", 1, "", "Alias not found")
        
        self.command_history.append(cmd_entry)
        return cmd_entry
    
    def show_history(self):
        """Show command history"""
        output = ""
        for i, cmd in enumerate(self.command_history[-20:], 1):
            output += f"{i:3d}  {cmd.command}\n"
        
        cmd_entry = Command("history", 0, output)
        self.command_history.append(cmd_entry)
        return cmd_entry
    
    def handle_bookmark(self, bookmark_def):
        """Handle directory bookmarks"""
        if '=' in bookmark_def:
            name, path = bookmark_def.split('=', 1)
            self.bookmarks[name.strip()] = path.strip()
            cmd_entry = Command(f"bookmark {bookmark_def}", 0, f"Bookmark '{name}' created")
        else:
            # Go to bookmark
            if bookmark_def in self.bookmarks:
                return self.change_directory(self.bookmarks[bookmark_def])
            else:
                cmd_entry = Command(f"bookmark {bookmark_def}", 1, "", "Bookmark not found")
        
        self.command_history.append(cmd_entry)
        return cmd_entry
    
    def show_environment(self):
        """Show environment variables"""
        output = ""
        for key, value in sorted(self.environment_vars.items()):
            output += f"{key}={value}\n"
        
        cmd_entry = Command("env", 0, output)
        self.command_history.append(cmd_entry)
        return cmd_entry
    
    def get_system_info(self):
        """Get system information"""
        return {
            'platform': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python_version': platform.python_version(),
            'hostname': platform.node(),
            'user': os.getenv('USER', os.getenv('USERNAME', 'unknown')),
            'shell': os.getenv('SHELL', 'unknown'),
            'term': os.getenv('TERM', 'unknown')
        }
    
    def load_config(self):
        """Load configuration from file"""
        try:
            if os.path.exists('cmdhub_config.json'):
                with open('cmdhub_config.json', 'r') as f:
                    config = json.load(f)
                    self.aliases.update(config.get('aliases', {}))
                    self.bookmarks.update(config.get('bookmarks', {}))
                    self.scripts.update(config.get('scripts', {}))
        except Exception:
            pass
    
    def save_config(self):
        """Save configuration to file"""
        try:
            config = {
                'aliases': self.aliases,
                'bookmarks': self.bookmarks,
                'scripts': self.scripts
            }
            with open('cmdhub_config.json', 'w') as f:
                json.dump(config, f, indent=2)
        except Exception:
            pass

def display_command_result(cmd_entry):
    """Display command execution result"""
    if cmd_entry.exit_code == 0:
        print(f"{Fore.GREEN}✓ {cmd_entry.command}")
        if cmd_entry.output:
            print(f"{Fore.WHITE}{cmd_entry.output}")
    else:
        print(f"{Fore.RED}✗ {cmd_entry.command}")
        if cmd_entry.error:
            print(f"{Fore.RED}{cmd_entry.error}")
    
    if cmd_entry.execution_time > 0:
        print(f"{Fore.CYAN}Execution time: {cmd_entry.execution_time:.3f}s")

def display_system_info(info):
    """Display system information"""
    slow_print(f"\n{Fore.CYAN}🖥️ System Information", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Platform: {Fore.WHITE}{info['platform']} {info['release']}", 0.02)
    slow_print(f"{Fore.GREEN}Machine: {Fore.WHITE}{info['machine']}", 0.02)
    slow_print(f"{Fore.GREEN}Processor: {Fore.WHITE}{info['processor']}", 0.02)
    slow_print(f"{Fore.GREEN}Hostname: {Fore.WHITE}{info['hostname']}", 0.02)
    slow_print(f"{Fore.GREEN}User: {Fore.WHITE}{info['user']}", 0.02)
    slow_print(f"{Fore.GREEN}Shell: {Fore.WHITE}{info['shell']}", 0.02)
    slow_print(f"{Fore.GREEN}Python: {Fore.WHITE}{info['python_version']}", 0.02)

def display_process_list():
    """Display running processes"""
    slow_print(f"\n{Fore.CYAN}⚡ Running Processes", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
        try:
            processes.append(proc.info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    
    # Sort by CPU usage
    processes.sort(key=lambda x: x['cpu_percent'] or 0, reverse=True)
    
    slow_print(f"{Fore.GREEN}{'PID':<8} {'NAME':<20} {'CPU%':<8} {'MEM%':<8}", 0.01)
    slow_print(f"{Fore.YELLOW}{'-'*50}", 0.01)
    
    for proc in processes[:15]:  # Show top 15
        pid = proc['pid']
        name = (proc['name'] or 'N/A')[:18]
        cpu = proc['cpu_percent'] or 0
        mem = proc['memory_percent'] or 0
        
        slow_print(f"{Fore.WHITE}{pid:<8} {name:<20} {cpu:<8.1f} {mem:<8.1f}", 0.01)

def main():
    """Main function"""
    print_header()
    
    hub = CommandHub()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🖥️ CmdHub Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Interactive Terminal", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Execute Single Command", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Command History", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Manage Aliases", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Directory Bookmarks", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}System Information", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Process Monitor", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}🖥️ Interactive Terminal Mode", 0.02)
            slow_print(f"{Fore.YELLOW}Type 'exit' to return to main menu", 0.02)
            
            while True:
                # Show prompt with current directory
                rel_path = os.path.relpath(hub.current_directory, os.path.expanduser('~'))
                if rel_path.startswith('..'):
                    rel_path = hub.current_directory
                
                prompt = f"{Fore.GREEN}{os.getenv('USER', 'user')}@{platform.node().split('.')[0]}:{Fore.BLUE}~/{rel_path}{Fore.WHITE}$ "
                
                try:
                    command = input(prompt).strip()
                    
                    if command.lower() in ['exit', 'quit']:
                        break
                    
                    if command:
                        result = hub.execute_command(command)
                        if result:
                            display_command_result(result)
                
                except KeyboardInterrupt:
                    print(f"\n{Fore.YELLOW}Use 'exit' to return to main menu")
                except EOFError:
                    break
        
        elif choice == '2':
            command = input(f"{Fore.YELLOW}Enter command: ").strip()
            if command:
                slow_print(f"\n{Fore.YELLOW}🔄 Executing: {command}", 0.02)
                result = hub.execute_command(command)
                if result:
                    display_command_result(result)
        
        elif choice == '3':
            slow_print(f"\n{Fore.CYAN}📜 Command History", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
            
            if hub.command_history:
                for i, cmd in enumerate(hub.command_history[-20:], 1):
                    status_icon = "✓" if cmd.exit_code == 0 else "✗"
                    status_color = Fore.GREEN if cmd.exit_code == 0 else Fore.RED
                    time_str = cmd.timestamp.strftime("%H:%M:%S")
                    
                    slow_print(f"{status_color}{status_icon} {Fore.CYAN}[{time_str}] {Fore.WHITE}{cmd.command}", 0.01)
                    
                    if cmd.execution_time > 0:
                        slow_print(f"   {Fore.YELLOW}Time: {cmd.execution_time:.3f}s", 0.01)
            else:
                slow_print(f"{Fore.YELLOW}No command history available", 0.02)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}🔗 Alias Management", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}View All Aliases", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Create Alias", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Remove Alias", 0.02)
            
            alias_choice = input(f"\n{Fore.YELLOW}Select option (1-3): ").strip()
            
            if alias_choice == '1':
                slow_print(f"\n{Fore.CYAN}Current Aliases:", 0.02)
                for name, command in hub.aliases.items():
                    slow_print(f"{Fore.GREEN}{name}: {Fore.WHITE}{command}", 0.02)
            
            elif alias_choice == '2':
                name = input(f"{Fore.YELLOW}Alias name: ").strip()
                command = input(f"{Fore.YELLOW}Command: ").strip()
                if name and command:
                    hub.aliases[name] = command
                    hub.save_config()
                    slow_print(f"{Fore.GREEN}✅ Alias '{name}' created!", 0.02)
            
            elif alias_choice == '3':
                name = input(f"{Fore.YELLOW}Alias name to remove: ").strip()
                if name in hub.aliases:
                    del hub.aliases[name]
                    hub.save_config()
                    slow_print(f"{Fore.GREEN}✅ Alias '{name}' removed!", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Alias not found", 0.02)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}📁 Directory Bookmarks", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}View Bookmarks", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Add Bookmark", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Go to Bookmark", 0.02)
            
            bookmark_choice = input(f"\n{Fore.YELLOW}Select option (1-3): ").strip()
            
            if bookmark_choice == '1':
                if hub.bookmarks:
                    slow_print(f"\n{Fore.CYAN}Bookmarks:", 0.02)
                    for name, path in hub.bookmarks.items():
                        slow_print(f"{Fore.GREEN}{name}: {Fore.WHITE}{path}", 0.02)
                else:
                    slow_print(f"{Fore.YELLOW}No bookmarks defined", 0.02)
            
            elif bookmark_choice == '2':
                name = input(f"{Fore.YELLOW}Bookmark name: ").strip()
                path = input(f"{Fore.YELLOW}Path (current: {hub.current_directory}): ").strip()
                if not path:
                    path = hub.current_directory
                
                if name:
                    hub.bookmarks[name] = path
                    hub.save_config()
                    slow_print(f"{Fore.GREEN}✅ Bookmark '{name}' created!", 0.02)
            
            elif bookmark_choice == '3':
                if hub.bookmarks:
                    slow_print(f"\n{Fore.CYAN}Available bookmarks:", 0.02)
                    for name in hub.bookmarks.keys():
                        slow_print(f"{Fore.GREEN}• {name}", 0.02)
                    
                    name = input(f"\n{Fore.YELLOW}Bookmark name: ").strip()
                    if name in hub.bookmarks:
                        result = hub.change_directory(hub.bookmarks[name])
                        display_command_result(result)
                    else:
                        slow_print(f"{Fore.RED}❌ Bookmark not found", 0.02)
                else:
                    slow_print(f"{Fore.YELLOW}No bookmarks available", 0.02)
        
        elif choice == '6':
            info = hub.get_system_info()
            display_system_info(info)
        
        elif choice == '7':
            display_process_list()
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using CmdHub! Command on!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
