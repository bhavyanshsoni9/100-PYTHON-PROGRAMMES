#!/usr/bin/env python3
"""
CodeBot - AI Programming Assistant
Created by BHAVYANSH SONI
A retro-style AI-powered code generation and assistance tool
"""

import os
import sys
import time
import random
import re
from datetime import datetime
from colorama import init, Fore, Back, Style
import json

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.BLUE}{'='*60}
{Fore.CYAN}     ██████╗ ██████╗ ██████╗ ███████╗██████╗  ██████╗ ████████╗
{Fore.CYAN}    ██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝
{Fore.CYAN}    ██║     ██║   ██║██║  ██║█████╗  ██████╔╝██║   ██║   ██║   
{Fore.CYAN}    ██║     ██║   ██║██║  ██║██╔══╝  ██╔══██╗██║   ██║   ██║   
{Fore.CYAN}    ╚██████╗╚██████╔╝██████╔╝███████╗██████╔╝╚██████╔╝   ██║   
{Fore.CYAN}     ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═════╝  ╚═════╝    ╚═╝   
{Fore.BLUE}{'='*60}
{Fore.YELLOW}    🤖 AI Programming Assistant - Code Generation Helper
{Fore.MAGENTA}    💻 Created by: BHAVYANSH SONI
{Fore.BLUE}{'='*60}
"""
    print(header)

class CodeGenerator:
    """AI-powered code generation system"""
    
    def __init__(self):
        self.programming_languages = {
            'python': {
                'extension': '.py',
                'comment': '#',
                'templates': self.get_python_templates()
            },
            'javascript': {
                'extension': '.js',
                'comment': '//',
                'templates': self.get_javascript_templates()
            },
            'java': {
                'extension': '.java',
                'comment': '//',
                'templates': self.get_java_templates()
            },
            'cpp': {
                'extension': '.cpp',
                'comment': '//',
                'templates': self.get_cpp_templates()
            },
            'html': {
                'extension': '.html',
                'comment': '<!--',
                'templates': self.get_html_templates()
            },
            'css': {
                'extension': '.css',
                'comment': '/*',
                'templates': self.get_css_templates()
            }
        }
        
        self.code_patterns = self.load_code_patterns()
        self.generated_projects = []
    
    def get_python_templates(self):
        """Get Python code templates"""
        return {
            'basic_script': '''#!/usr/bin/env python3
"""
{project_name}
Created by: {author}
Description: {description}
"""

def main():
    """Main function"""
    print("Hello, World!")
    # Add your code here

if __name__ == "__main__":
    main()
''',
            'class_template': '''class {class_name}:
    """
    {description}
    """
    
    def __init__(self):
        """Initialize the {class_name}"""
        pass
    
    def method_example(self):
        """Example method"""
        return "Hello from {class_name}"
''',
            'web_scraper': '''import requests
from bs4 import BeautifulSoup
import time

class WebScraper:
    """Simple web scraper"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({{
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }})
    
    def scrape_url(self, url):
        """Scrape a single URL"""
        try:
            response = self.session.get(url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            return soup
            
        except requests.RequestException as e:
            print(f"Error scraping {{url}}: {{e}}")
            return None
''',
            'api_client': '''import requests
import json

class APIClient:
    """REST API client"""
    
    def __init__(self, base_url, api_key=None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()
        
        if api_key:
            self.session.headers.update({{'Authorization': f'Bearer {{api_key}}'}})
    
    def get(self, endpoint, params=None):
        """GET request"""
        url = f"{{self.base_url}}/{{endpoint.lstrip('/')}}"
        response = self.session.get(url, params=params)
        return self._handle_response(response)
    
    def post(self, endpoint, data=None):
        """POST request"""
        url = f"{{self.base_url}}/{{endpoint.lstrip('/')}}"
        response = self.session.post(url, json=data)
        return self._handle_response(response)
    
    def _handle_response(self, response):
        """Handle API response"""
        try:
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            print(f"API Error: {{e}}")
            return None
'''
        }
    
    def get_javascript_templates(self):
        """Get JavaScript code templates"""
        return {
            'basic_script': '''// {project_name}
// Created by: {author}
// Description: {description}

function main() {{
    console.log("Hello, World!");
    // Add your code here
}}

// Run the main function
main();
''',
            'class_template': '''class {class_name} {{
    /**
     * {description}
     */
    constructor() {{
        // Initialize the {class_name}
    }}
    
    /**
     * Example method
     */
    methodExample() {{
        return "Hello from {class_name}";
    }}
}}
''',
            'api_fetch': '''class APIClient {{
    constructor(baseUrl, apiKey = null) {{
        this.baseUrl = baseUrl.replace(/\\/$/, '');
        this.apiKey = apiKey;
    }}
    
    async get(endpoint, params = {{}}) {{
        const url = new URL(endpoint, this.baseUrl);
        Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
        
        const options = {{
            method: 'GET',
            headers: this._getHeaders()
        }};
        
        try {{
            const response = await fetch(url, options);
            return await this._handleResponse(response);
        }} catch (error) {{
            console.error('API Error:', error);
            return null;
        }}
    }}
    
    async post(endpoint, data = {{}}) {{
        const url = new URL(endpoint, this.baseUrl);
        
        const options = {{
            method: 'POST',
            headers: this._getHeaders(),
            body: JSON.stringify(data)
        }};
        
        try {{
            const response = await fetch(url, options);
            return await this._handleResponse(response);
        }} catch (error) {{
            console.error('API Error:', error);
            return null;
        }}
    }}
    
    _getHeaders() {{
        const headers = {{
            'Content-Type': 'application/json'
        }};
        
        if (this.apiKey) {{
            headers['Authorization'] = `Bearer ${{this.apiKey}}`;
        }}
        
        return headers;
    }}
    
    async _handleResponse(response) {{
        if (!response.ok) {{
            throw new Error(`HTTP error! status: ${{response.status}}`);
        }}
        
        return await response.json();
    }}
}}
'''
        }
    
    def get_java_templates(self):
        """Get Java code templates"""
        return {
            'basic_class': '''/**
 * {project_name}
 * Created by: {author}
 * Description: {description}
 */

public class {class_name} {{
    
    public static void main(String[] args) {{
        System.out.println("Hello, World!");
        // Add your code here
    }}
    
    /**
     * Example method
     */
    public void methodExample() {{
        System.out.println("Hello from {class_name}");
    }}
}}
''',
            'interface_template': '''/**
 * {interface_name} Interface
 * {description}
 */
public interface {interface_name} {{
    
    /**
     * Example method declaration
     */
    void methodExample();
    
    /**
     * Another method with return value
     */
    String getValue();
}}
'''
        }
    
    def get_cpp_templates(self):
        """Get C++ code templates"""
        return {
            'basic_program': '''/*
 * {project_name}
 * Created by: {author}
 * Description: {description}
 */

#include <iostream>
#include <string>

class {class_name} {{
private:
    std::string name;

public:
    {class_name}(const std::string& n) : name(n) {{}}
    
    void greet() {{
        std::cout << "Hello from " << name << std::endl;
    }}
}};

int main() {{
    {class_name} obj("{class_name}");
    obj.greet();
    
    return 0;
}}
''',
            'header_file': '''/*
 * {project_name}.h
 * Created by: {author}
 * Description: {description}
 */

#ifndef {header_guard}
#define {header_guard}

#include <string>

class {class_name} {{
private:
    std::string data;

public:
    {class_name}();
    ~{class_name}();
    
    void setData(const std::string& value);
    std::string getData() const;
}};

#endif // {header_guard}
'''
        }
    
    def get_html_templates(self):
        """Get HTML templates"""
        return {
            'basic_page': '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{project_name}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>{project_name}</h1>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section id="home">
            <h2>Welcome</h2>
            <p>This is the {project_name} homepage.</p>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 {author}. All rights reserved.</p>
    </footer>
    
    <script src="script.js"></script>
</body>
</html>
''',
            'form_template': '''<form id="{form_name}" class="form-container">
    <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
    </div>
    
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
    </div>
    
    <div class="form-group">
        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="4" required></textarea>
    </div>
    
    <button type="submit">Submit</button>
</form>
'''
        }
    
    def get_css_templates(self):
        """Get CSS templates"""
        return {
            'basic_styles': '''/* {project_name} Styles
 * Created by: {author}
 * Description: {description}
 */

/* Reset and base styles */
* {{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}}

body {{
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f4f4f4;
}}

/* Header styles */
header {{
    background: #333;
    color: #fff;
    padding: 1rem 0;
    text-align: center;
}}

header h1 {{
    margin-bottom: 0.5rem;
}}

/* Navigation styles */
nav ul {{
    list-style: none;
    display: flex;
    justify-content: center;
    gap: 2rem;
}}

nav a {{
    color: #fff;
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    transition: background-color 0.3s;
}}

nav a:hover {{
    background-color: #555;
}}

/* Main content styles */
main {{
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}}

/* Form styles */
.form-container {{
    max-width: 600px;
    margin: 0 auto;
    background: #fff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}}

.form-group {{
    margin-bottom: 1rem;
}}

label {{
    display: block;
    margin-bottom: 0.5rem;
    font-weight: bold;
}}

input, textarea {{
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 1rem;
}}

button {{
    background: #007bff;
    color: #fff;
    padding: 0.75rem 2rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1rem;
    transition: background-color 0.3s;
}}

button:hover {{
    background: #0056b3;
}}

/* Responsive design */
@media (max-width: 768px) {{
    nav ul {{
        flex-direction: column;
        gap: 1rem;
    }}
    
    main {{
        padding: 1rem;
    }}
}}
'''
        }
    
    def load_code_patterns(self):
        """Load common code patterns"""
        return {
            'algorithms': {
                'bubble_sort': '''def bubble_sort(arr):
    """Bubble sort algorithm"""
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr
''',
                'binary_search': '''def binary_search(arr, target):
    """Binary search algorithm"""
    left, right = 0, len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return -1
''',
                'fibonacci': '''def fibonacci(n):
    """Generate Fibonacci sequence"""
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    
    fib = [0, 1]
    for i in range(2, n):
        fib.append(fib[i-1] + fib[i-2])
    
    return fib
'''
            },
            'data_structures': {
                'linked_list': '''class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

class LinkedList:
    def __init__(self):
        self.head = None
    
    def append(self, val):
        if not self.head:
            self.head = ListNode(val)
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = ListNode(val)
    
    def display(self):
        result = []
        current = self.head
        while current:
            result.append(current.val)
            current = current.next
        return result
''',
                'stack': '''class Stack:
    def __init__(self):
        self.items = []
    
    def push(self, item):
        self.items.append(item)
    
    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        return None
    
    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        return None
    
    def is_empty(self):
        return len(self.items) == 0
    
    def size(self):
        return len(self.items)
'''
            }
        }
    
    def generate_code(self, language, template_type, project_info):
        """Generate code based on template"""
        if language not in self.programming_languages:
            return None
        
        templates = self.programming_languages[language]['templates']
        
        if template_type not in templates:
            return None
        
        template = templates[template_type]
        
        # Fill in template variables
        code = template.format(**project_info)
        
        return code
    
    def analyze_code_complexity(self, code):
        """Analyze code complexity"""
        lines = code.split('\n')
        non_empty_lines = [line for line in lines if line.strip()]
        
        # Count various elements
        functions = len(re.findall(r'def\s+\w+', code))
        classes = len(re.findall(r'class\s+\w+', code))
        loops = len(re.findall(r'(for|while)\s+', code))
        conditionals = len(re.findall(r'if\s+', code))
        comments = len([line for line in lines if line.strip().startswith('#')])
        
        complexity_score = (loops * 2) + conditionals + (functions * 0.5)
        
        return {
            'total_lines': len(lines),
            'code_lines': len(non_empty_lines),
            'functions': functions,
            'classes': classes,
            'loops': loops,
            'conditionals': conditionals,
            'comments': comments,
            'complexity_score': complexity_score,
            'comment_ratio': comments / len(non_empty_lines) if non_empty_lines else 0
        }
    
    def suggest_improvements(self, code_analysis):
        """Suggest code improvements"""
        suggestions = []
        
        if code_analysis['comment_ratio'] < 0.1:
            suggestions.append("Add more comments to improve code readability")
        
        if code_analysis['complexity_score'] > 10:
            suggestions.append("Consider breaking down complex functions into smaller ones")
        
        if code_analysis['functions'] == 0 and code_analysis['code_lines'] > 20:
            suggestions.append("Consider organizing code into functions for better structure")
        
        if code_analysis['classes'] == 0 and code_analysis['code_lines'] > 50:
            suggestions.append("Consider using classes for better code organization")
        
        return suggestions

def display_code_with_syntax_highlighting(code, language):
    """Display code with basic syntax highlighting"""
    lines = code.split('\n')
    
    for i, line in enumerate(lines, 1):
        line_num = f"{i:3d}"
        
        # Basic syntax highlighting
        if language == 'python':
            if line.strip().startswith('#'):
                line_color = Fore.GREEN
            elif 'def ' in line or 'class ' in line:
                line_color = Fore.CYAN
            elif any(keyword in line for keyword in ['if', 'else', 'for', 'while', 'try', 'except']):
                line_color = Fore.YELLOW
            else:
                line_color = Fore.WHITE
        else:
            line_color = Fore.WHITE
        
        slow_print(f"{Fore.BLUE}{line_num} | {line_color}{line}", 0.01)

def display_project_info(project):
    """Display generated project information"""
    slow_print(f"\n{Fore.CYAN}📁 Project: {project['name']}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Language: {Fore.WHITE}{project['language']}", 0.02)
    slow_print(f"{Fore.GREEN}Template: {Fore.WHITE}{project['template']}", 0.02)
    slow_print(f"{Fore.GREEN}Author: {Fore.WHITE}{project['author']}", 0.02)
    slow_print(f"{Fore.GREEN}Created: {Fore.WHITE}{project['created']}", 0.02)
    slow_print(f"{Fore.GREEN}Description: {Fore.WHITE}{project['description']}", 0.02)

def main():
    """Main function"""
    print_header()
    
    code_bot = CodeGenerator()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🤖 CodeBot Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Generate Code", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}View Templates", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Code Patterns", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Analyze Code", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Generated Projects", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Code Snippets", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-7): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}🛠️ Code Generation", 0.02)
            
            # Select language
            languages = list(code_bot.programming_languages.keys())
            slow_print(f"{Fore.YELLOW}Available languages:", 0.02)
            for i, lang in enumerate(languages, 1):
                slow_print(f"{Fore.GREEN}{i}. {lang.title()}", 0.02)
            
            try:
                lang_choice = int(input(f"\n{Fore.YELLOW}Select language (1-{len(languages)}): ").strip()) - 1
                if 0 <= lang_choice < len(languages):
                    language = languages[lang_choice]
                    
                    # Select template
                    templates = list(code_bot.programming_languages[language]['templates'].keys())
                    slow_print(f"\n{Fore.YELLOW}Available templates for {language.title()}:", 0.02)
                    for i, template in enumerate(templates, 1):
                        slow_print(f"{Fore.GREEN}{i}. {template.replace('_', ' ').title()}", 0.02)
                    
                    template_choice = int(input(f"\n{Fore.YELLOW}Select template (1-{len(templates)}): ").strip()) - 1
                    if 0 <= template_choice < len(templates):
                        template_type = templates[template_choice]
                        
                        # Get project information
                        project_name = input(f"{Fore.YELLOW}Project name: ").strip() or "MyProject"
                        author = input(f"{Fore.YELLOW}Author name: ").strip() or "Developer"
                        description = input(f"{Fore.YELLOW}Description: ").strip() or "Generated project"
                        class_name = input(f"{Fore.YELLOW}Class name (if applicable): ").strip() or project_name.replace(' ', '')
                        
                        project_info = {
                            'project_name': project_name,
                            'author': author,
                            'description': description,
                            'class_name': class_name,
                            'interface_name': class_name + 'Interface',
                            'header_guard': class_name.upper() + '_H',
                            'form_name': project_name.lower().replace(' ', '_')
                        }
                        
                        # Generate code
                        slow_print(f"\n{Fore.YELLOW}🔄 Generating code...", 0.02)
                        time.sleep(1)
                        
                        code = code_bot.generate_code(language, template_type, project_info)
                        
                        if code:
                            slow_print(f"\n{Fore.GREEN}✅ Code generated successfully!", 0.02)
                            
                            # Store project
                            project = {
                                'name': project_name,
                                'language': language,
                                'template': template_type,
                                'author': author,
                                'description': description,
                                'code': code,
                                'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            }
                            code_bot.generated_projects.append(project)
                            
                            # Display code
                            slow_print(f"\n{Fore.CYAN}📄 Generated Code:", 0.02)
                            slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
                            display_code_with_syntax_highlighting(code, language)
                            slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
                            
                            # Save to file option
                            save_file = input(f"\n{Fore.YELLOW}Save to file? (y/n): ").strip().lower()
                            if save_file == 'y':
                                extension = code_bot.programming_languages[language]['extension']
                                filename = f"{project_name.replace(' ', '_')}{extension}"
                                try:
                                    with open(filename, 'w') as f:
                                        f.write(code)
                                    slow_print(f"{Fore.GREEN}✅ Code saved to {filename}", 0.02)
                                except Exception as e:
                                    slow_print(f"{Fore.RED}❌ Error saving file: {str(e)}", 0.02)
                        else:
                            slow_print(f"{Fore.RED}❌ Failed to generate code", 0.02)
                    else:
                        slow_print(f"{Fore.RED}❌ Invalid template choice", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid language choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '2':
            slow_print(f"\n{Fore.CYAN}📋 Available Templates", 0.02)
            
            for language, info in code_bot.programming_languages.items():
                slow_print(f"\n{Fore.GREEN}{language.title()}:", 0.02)
                for template_name in info['templates'].keys():
                    slow_print(f"  {Fore.CYAN}• {template_name.replace('_', ' ').title()}", 0.02)
        
        elif choice == '3':
            slow_print(f"\n{Fore.CYAN}🧩 Code Patterns", 0.02)
            
            for category, patterns in code_bot.code_patterns.items():
                slow_print(f"\n{Fore.GREEN}{category.title()}:", 0.02)
                for pattern_name, pattern_code in patterns.items():
                    slow_print(f"  {Fore.CYAN}• {pattern_name.replace('_', ' ').title()}", 0.02)
                
                # Show a pattern
                pattern_choice = input(f"\n{Fore.YELLOW}View pattern (name) or Enter to skip: ").strip()
                if pattern_choice and pattern_choice.replace(' ', '_').lower() in patterns:
                    pattern_name = pattern_choice.replace(' ', '_').lower()
                    slow_print(f"\n{Fore.CYAN}📄 {pattern_name.replace('_', ' ').title()}:", 0.02)
                    slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
                    display_code_with_syntax_highlighting(patterns[pattern_name], 'python')
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}📊 Code Analysis", 0.02)
            
            code_input = input(f"{Fore.YELLOW}Enter code to analyze (or 'file' to load from file): ").strip()
            
            if code_input.lower() == 'file':
                filename = input(f"{Fore.YELLOW}Enter filename: ").strip()
                try:
                    with open(filename, 'r') as f:
                        code = f.read()
                except FileNotFoundError:
                    slow_print(f"{Fore.RED}❌ File not found", 0.02)
                    continue
                except Exception as e:
                    slow_print(f"{Fore.RED}❌ Error reading file: {str(e)}", 0.02)
                    continue
            else:
                slow_print(f"{Fore.YELLOW}Enter code (type 'END' on a new line to finish):", 0.02)
                code_lines = []
                while True:
                    line = input()
                    if line.strip() == 'END':
                        break
                    code_lines.append(line)
                code = '\n'.join(code_lines)
            
            if code.strip():
                slow_print(f"\n{Fore.YELLOW}🔄 Analyzing code...", 0.02)
                time.sleep(1)
                
                analysis = code_bot.analyze_code_complexity(code)
                suggestions = code_bot.suggest_improvements(analysis)
                
                slow_print(f"\n{Fore.CYAN}📊 Code Analysis Results:", 0.02)
                slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
                
                slow_print(f"{Fore.GREEN}Total Lines: {Fore.WHITE}{analysis['total_lines']}", 0.02)
                slow_print(f"{Fore.GREEN}Code Lines: {Fore.WHITE}{analysis['code_lines']}", 0.02)
                slow_print(f"{Fore.GREEN}Functions: {Fore.WHITE}{analysis['functions']}", 0.02)
                slow_print(f"{Fore.GREEN}Classes: {Fore.WHITE}{analysis['classes']}", 0.02)
                slow_print(f"{Fore.GREEN}Loops: {Fore.WHITE}{analysis['loops']}", 0.02)
                slow_print(f"{Fore.GREEN}Conditionals: {Fore.WHITE}{analysis['conditionals']}", 0.02)
                slow_print(f"{Fore.GREEN}Comments: {Fore.WHITE}{analysis['comments']}", 0.02)
                slow_print(f"{Fore.GREEN}Complexity Score: {Fore.WHITE}{analysis['complexity_score']:.1f}", 0.02)
                slow_print(f"{Fore.GREEN}Comment Ratio: {Fore.WHITE}{analysis['comment_ratio']:.1%}", 0.02)
                
                if suggestions:
                    slow_print(f"\n{Fore.YELLOW}💡 Suggestions for Improvement:", 0.02)
                    for suggestion in suggestions:
                        slow_print(f"{Fore.CYAN}• {suggestion}", 0.02)
                else:
                    slow_print(f"\n{Fore.GREEN}✅ Code looks good! No specific suggestions.", 0.02)
        
        elif choice == '5':
            if code_bot.generated_projects:
                slow_print(f"\n{Fore.CYAN}📁 Generated Projects", 0.02)
                slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
                
                for i, project in enumerate(code_bot.generated_projects, 1):
                    slow_print(f"\n{Fore.GREEN}{i}. {project['name']}", 0.02)
                    slow_print(f"   {Fore.CYAN}Language: {project['language']}", 0.02)
                    slow_print(f"   {Fore.CYAN}Template: {project['template']}", 0.02)
                    slow_print(f"   {Fore.CYAN}Created: {project['created']}", 0.02)
                
                try:
                    project_choice = int(input(f"\n{Fore.YELLOW}View project (1-{len(code_bot.generated_projects)}): ").strip()) - 1
                    if 0 <= project_choice < len(code_bot.generated_projects):
                        project = code_bot.generated_projects[project_choice]
                        display_project_info(project)
                        
                        view_code = input(f"\n{Fore.YELLOW}View code? (y/n): ").strip().lower()
                        if view_code == 'y':
                            slow_print(f"\n{Fore.CYAN}📄 Project Code:", 0.02)
                            slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
                            display_code_with_syntax_highlighting(project['code'], project['language'])
                            slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
                except (ValueError, IndexError):
                    slow_print(f"{Fore.RED}❌ Invalid project choice", 0.02)
            else:
                slow_print(f"{Fore.YELLOW}📁 No projects generated yet", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}🧩 Quick Code Snippets", 0.02)
            
            snippets = {
                'file_read': 'with open("filename.txt", "r") as f:\n    content = f.read()',
                'json_parse': 'import json\ndata = json.loads(json_string)',
                'http_request': 'import requests\nresponse = requests.get("https://api.example.com")',
                'list_comprehension': 'squares = [x**2 for x in range(10)]',
                'error_handling': 'try:\n    # risky code\n    pass\nexcept Exception as e:\n    print(f"Error: {e}")'
            }
            
            for name, code in snippets.items():
                slow_print(f"\n{Fore.GREEN}{name.replace('_', ' ').title()}:", 0.02)
                slow_print(f"{Fore.WHITE}{code}", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using CodeBot! Keep coding!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '7':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
