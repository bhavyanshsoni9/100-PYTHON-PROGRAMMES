from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from cryptography.fernet import Fernet
from datetime import datetime
import os
import json

class CryptoJournal:
    def __init__(self):
        self.console = Console()
        self.key_file = "journal_key.key"
        self.journal_file = "journal_entries.enc"
        self.fernet = self._setup_encryption()
        
    def _setup_encryption(self):
        if not os.path.exists(self.key_file):
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
        else:
            with open(self.key_file, "rb") as f:
                key = f.read()
        return Fernet(key)
    
    def add_entry(self):
        self.console.print(Panel("📝 New Journal Entry", style="bold green"))
        entry = Prompt.ask("Write your entry")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        entry_data = {
            "timestamp": timestamp,
            "content": entry
        }
        
        # Load existing entries
        entries = self.load_entries()
        entries.append(entry_data)
        
        # Encrypt and save
        encrypted_data = self.fernet.encrypt(json.dumps(entries).encode())
        with open(self.journal_file, "wb") as f:
            f.write(encrypted_data)
            
        self.console.print("✨ Entry saved securely!", style="bold green")
        
    def load_entries(self):
        if not os.path.exists(self.journal_file):
            return []
            
        with open(self.journal_file, "rb") as f:
            encrypted_data = f.read()
            
        try:
            decrypted_data = self.fernet.decrypt(encrypted_data)
            return json.loads(decrypted_data)
        except:
            return []
            
    def view_entries(self):
        entries = self.load_entries()
        if not entries:
            self.console.print("📚 No entries found", style="bold yellow")
            return
            
        self.console.print(Panel("📚 Your Journal Entries", style="bold blue"))
        for entry in entries:
            self.console.print(Panel(
                f"[bold blue]{entry['timestamp']}[/]\n\n{entry['content']}",
                border_style="blue"
            ))
            
    def run(self):
        while True:
            self.console.print("\n🔐 CryptoJournal - Secure Personal Journaling", style="bold magenta")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3"],
                default="1"
            )
            
            if choice == "1":
                self.add_entry()
            elif choice == "2":
                self.view_entries()
            elif choice == "3":
                self.console.print("👋 Goodbye!", style="bold magenta")
                break
                
if __name__ == "__main__":
    journal = CryptoJournal()
    journal.run() 