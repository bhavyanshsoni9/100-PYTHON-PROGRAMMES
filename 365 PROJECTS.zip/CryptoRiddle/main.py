from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
import random
import string
import base64

class CryptoRiddle:
    def __init__(self):
        self.console = Console()
        self.difficulty_levels = {
            "easy": {"length": 8, "complexity": 1},
            "medium": {"length": 12, "complexity": 2},
            "hard": {"length": 16, "complexity": 3}
        }
        
    def generate_riddle(self, difficulty="medium"):
        params = self.difficulty_levels[difficulty]
        
        # Generate random string
        text = ''.join(random.choices(
            string.ascii_letters + string.digits,
            k=params["length"]
        ))
        
        # Apply multiple layers of encoding based on complexity
        encoded = text
        steps = []
        
        for _ in range(params["complexity"]):
            operation = random.choice([
                "base64",
                "reverse",
                "caesar",
                "binary"
            ])
            
            if operation == "base64":
                encoded = base64.b64encode(encoded.encode()).decode()
                steps.append("base64 encode")
            elif operation == "reverse":
                encoded = encoded[::-1]
                steps.append("reverse")
            elif operation == "caesar":
                shift = random.randint(1, 25)
                encoded = ''.join(
                    chr((ord(c) - 65 + shift) % 26 + 65) if c.isupper()
                    else chr((ord(c) - 97 + shift) % 26 + 97) if c.islower()
                    else c
                    for c in encoded
                )
                steps.append(f"caesar shift {shift}")
            elif operation == "binary":
                encoded = ' '.join(format(ord(c), '08b') for c in encoded)
                steps.append("binary conversion")
                
        return {
            "original": text,
            "encoded": encoded,
            "steps": steps
        }
        
    def solve_riddle(self, encoded, steps):
        decoded = encoded
        
        # Reverse the steps
        for step in steps[::-1]:
            if step == "base64 encode":
                decoded = base64.b64decode(decoded.encode()).decode()
            elif step == "reverse":
                decoded = decoded[::-1]
            elif step.startswith("caesar shift"):
                shift = int(step.split()[-1])
                decoded = ''.join(
                    chr((ord(c) - 65 - shift) % 26 + 65) if c.isupper()
                    else chr((ord(c) - 97 - shift) % 26 + 97) if c.islower()
                    else c
                    for c in decoded
                )
            elif step == "binary conversion":
                decoded = ''.join(chr(int(b, 2)) for b in decoded.split())
                
        return decoded
        
    def run(self):
        while True:
            self.console.print("\n🔍 CryptoRiddle - Cryptographic Puzzle Generator", style="bold cyan")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3"],
                default="1"
            )
            
            if choice == "1":
                difficulty = Prompt.ask(
                    "Choose difficulty",
                    choices=["easy", "medium", "hard"],
                    default="medium"
                )
                
                riddle = self.generate_riddle(difficulty)
                self.console.print(Panel(
                    f"[bold green]Original Text:[/] {riddle['original']}\n"
                    f"[bold red]Encoded Text:[/] {riddle['encoded']}\n"
                    f"[bold yellow]Encoding Steps:[/] {' → '.join(riddle['steps'])}",
                    title="🎯 Generated Riddle",
                    border_style="cyan"
                ))
                
            elif choice == "2":
                encoded = Prompt.ask("Enter the encoded text")
                steps_str = Prompt.ask("Enter the steps (comma-separated)")
                steps = [s.strip() for s in steps_str.split(",")]
                
                try:
                    solution = self.solve_riddle(encoded, steps)
                    self.console.print(Panel(
                        f"[bold green]Decoded Text:[/] {solution}",
                        title="🎉 Solution",
                        border_style="green"
                    ))
                except Exception as e:
                    self.console.print(f"❌ Error solving riddle: {str(e)}", style="bold red")
                    
            elif choice == "3":
                self.console.print("👋 Goodbye!", style="bold cyan")
                break
                
if __name__ == "__main__":
    riddle = CryptoRiddle()
    riddle.run() 