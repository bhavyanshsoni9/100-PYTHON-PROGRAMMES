import os
import subprocess

def shell():
    while True:
        cmd = input("mysh> ").strip()
        if cmd.lower() in ["exit", "quit"]:
            print("Bye!")
            break
        elif cmd.startswith("cd "):
            path = cmd[3:].strip()
            try:
                os.chdir(path)
            except Exception as e:
                print(f"Error: {e}")
        elif cmd == "ls":
            print("\n".join(os.listdir()))
        elif cmd.startswith("mkdir "):
            dirname = cmd[6:].strip()
            try:
                os.mkdir(dirname)
            except Exception as e:
                print(f"Error: {e}")
        else:
            try:
                output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
                print(output)
            except subprocess.CalledProcessError as e:
                print(e.output)

if __name__ == "__main__":
    shell()
