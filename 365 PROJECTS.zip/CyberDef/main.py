#!/usr/bin/env python3
"""
CyberDef - Cybersecurity Defense Simulator
Created by BHAVYANSH SONI
A retro-style cybersecurity defense and incident response simulator
"""

import os
import sys
import time
import random
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import json
import hashlib

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.RED}{'='*60}
{Fore.CYAN}     ██████╗██╗   ██╗██████╗ ███████╗██████╗ ██████╗ ███████╗███████╗
{Fore.CYAN}    ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██╔════╝
{Fore.CYAN}    ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝██║  ██║█████╗  █████╗  
{Fore.CYAN}    ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██║  ██║██╔══╝  ██╔══╝  
{Fore.CYAN}    ╚██████╗   ██║   ██████╔╝███████╗██║  ██║██████╔╝███████╗██║     
{Fore.CYAN}     ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝     
{Fore.RED}{'='*60}
{Fore.YELLOW}    🛡️ Cybersecurity Defense Simulator - Protect & Defend
{Fore.MAGENTA}    🔒 Created by: BHAVYANSH SONI
{Fore.RED}{'='*60}
"""
    print(header)

class CyberThreat:
    """Cyber threat model"""
    
    def __init__(self, threat_type, severity, source, target, description):
        self.threat_id = f"THR{random.randint(10000, 99999)}"
        self.threat_type = threat_type
        self.severity = severity
        self.source = source
        self.target = target
        self.description = description
        self.timestamp = datetime.now()
        self.status = "Active"
        self.mitigated = False

class DefenseSystem:
    """Cybersecurity defense system"""
    
    def __init__(self):
        self.firewall_rules = []
        self.intrusion_detection = True
        self.antivirus_enabled = True
        self.threat_intelligence = True
        self.security_level = "Medium"
        self.active_threats = []
        self.blocked_ips = []
        self.security_logs = []
        self.defense_stats = {
            'threats_detected': 0,
            'threats_blocked': 0,
            'false_positives': 0,
            'system_uptime': 100
        }
        
    def generate_cyber_threat(self):
        """Generate simulated cyber threat"""
        threat_types = [
            "Malware Infection",
            "Phishing Attack",
            "DDoS Attack",
            "SQL Injection",
            "Ransomware",
            "Data Breach",
            "Man-in-the-Middle",
            "Zero-day Exploit",
            "Social Engineering",
            "Credential Stuffing"
        ]
        
        severities = ["Low", "Medium", "High", "Critical"]
        sources = [
            f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
            "unknown@malicious-domain.com",
            "compromised-server.net",
            "botnet-node-" + str(random.randint(1000, 9999)),
            "tor-exit-node.onion"
        ]
        
        targets = [
            "Web Server",
            "Database Server",
            "Email Server",
            "User Workstation",
            "Network Infrastructure",
            "Cloud Services",
            "Mobile Devices",
            "IoT Devices"
        ]
        
        descriptions = {
            "Malware Infection": "Malicious software detected attempting to compromise system",
            "Phishing Attack": "Fraudulent email attempting to steal credentials",
            "DDoS Attack": "Distributed denial of service attack overwhelming resources",
            "SQL Injection": "Attempt to inject malicious SQL code into database",
            "Ransomware": "Encryption-based extortion malware detected",
            "Data Breach": "Unauthorized access to sensitive data detected",
            "Man-in-the-Middle": "Interception of communications detected",
            "Zero-day Exploit": "Unknown vulnerability being exploited",
            "Social Engineering": "Attempt to manipulate users for information",
            "Credential Stuffing": "Automated login attempts with stolen credentials"
        }
        
        threat_type = random.choice(threat_types)
        severity = random.choice(severities)
        source = random.choice(sources)
        target = random.choice(targets)
        description = descriptions.get(threat_type, "Unknown threat detected")
        
        return CyberThreat(threat_type, severity, source, target, description)
    
    def detect_threat(self, threat):
        """Threat detection logic"""
        detection_probability = {
            "Low": 0.9,
            "Medium": 0.8,
            "High": 0.7,
            "Critical": 0.6
        }
        
        detected = random.random() < detection_probability.get(threat.severity, 0.8)
        
        if detected:
            self.active_threats.append(threat)
            self.defense_stats['threats_detected'] += 1
            
            log_entry = {
                'timestamp': threat.timestamp.isoformat(),
                'event': 'Threat Detected',
                'threat_id': threat.threat_id,
                'type': threat.threat_type,
                'severity': threat.severity,
                'source': threat.source
            }
            self.security_logs.append(log_entry)
            
            return True
        
        return False
    
    def mitigate_threat(self, threat):
        """Threat mitigation strategies"""
        mitigation_strategies = {
            "Malware Infection": [
                "Quarantine infected files",
                "Run full system scan",
                "Update antivirus signatures",
                "Isolate affected system"
            ],
            "Phishing Attack": [
                "Block sender email",
                "Add domain to blacklist",
                "User awareness training",
                "Email filtering enhancement"
            ],
            "DDoS Attack": [
                "Rate limiting implementation",
                "Traffic filtering",
                "CDN activation",
                "Upstream provider notification"
            ],
            "SQL Injection": [
                "Input validation enforcement",
                "WAF rule update",
                "Database connection review",
                "Code vulnerability patch"
            ],
            "Ransomware": [
                "System isolation",
                "Backup restoration",
                "Network segmentation",
                "Kill process execution"
            ]
        }
        
        strategies = mitigation_strategies.get(threat.threat_type, ["Generic security response"])
        
        # Simulate mitigation success rate
        success_rate = {
            "Low": 0.95,
            "Medium": 0.85,
            "High": 0.70,
            "Critical": 0.60
        }
        
        mitigation_success = random.random() < success_rate.get(threat.severity, 0.8)
        
        if mitigation_success:
            threat.status = "Mitigated"
            threat.mitigated = True
            self.defense_stats['threats_blocked'] += 1
            
            # Block source IP if applicable
            if threat.source.count('.') == 3:  # IP address
                self.blocked_ips.append(threat.source)
        
        return mitigation_success, strategies
    
    def update_firewall_rules(self, rule_type, value):
        """Update firewall rules"""
        rule = {
            'id': len(self.firewall_rules) + 1,
            'type': rule_type,
            'value': value,
            'action': 'BLOCK',
            'created': datetime.now().isoformat()
        }
        
        self.firewall_rules.append(rule)
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'event': 'Firewall Rule Added',
            'rule_type': rule_type,
            'value': value
        }
        self.security_logs.append(log_entry)
    
    def run_security_scan(self):
        """Run comprehensive security scan"""
        scan_results = {
            'vulnerabilities': random.randint(0, 15),
            'outdated_software': random.randint(0, 8),
            'weak_passwords': random.randint(0, 5),
            'open_ports': random.randint(0, 10),
            'suspicious_processes': random.randint(0, 3),
            'scan_duration': random.uniform(30, 120)
        }
        
        # Generate recommendations
        recommendations = []
        if scan_results['vulnerabilities'] > 5:
            recommendations.append("Apply security patches immediately")
        if scan_results['outdated_software'] > 3:
            recommendations.append("Update all software to latest versions")
        if scan_results['weak_passwords'] > 2:
            recommendations.append("Enforce strong password policy")
        if scan_results['open_ports'] > 5:
            recommendations.append("Close unnecessary network ports")
        if scan_results['suspicious_processes'] > 0:
            recommendations.append("Investigate suspicious processes")
        
        scan_results['recommendations'] = recommendations
        return scan_results
    
    def generate_security_report(self):
        """Generate security status report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'security_level': self.security_level,
            'active_threats': len([t for t in self.active_threats if not t.mitigated]),
            'total_threats': len(self.active_threats),
            'threats_mitigated': len([t for t in self.active_threats if t.mitigated]),
            'blocked_ips': len(self.blocked_ips),
            'firewall_rules': len(self.firewall_rules),
            'system_status': {
                'firewall': 'Active' if self.firewall_rules else 'Inactive',
                'ids': 'Active' if self.intrusion_detection else 'Inactive',
                'antivirus': 'Active' if self.antivirus_enabled else 'Inactive',
                'threat_intel': 'Active' if self.threat_intelligence else 'Inactive'
            },
            'stats': self.defense_stats
        }
        
        return report

def display_threat_dashboard(defense_system):
    """Display cyber threat dashboard"""
    slow_print(f"\n{Fore.CYAN}🛡️ Cyber Defense Dashboard", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    active_threats = [t for t in defense_system.active_threats if not t.mitigated]
    
    # Security status indicators
    firewall_status = f"{Fore.GREEN}🟢 Active" if defense_system.firewall_rules else f"{Fore.RED}🔴 Inactive"
    ids_status = f"{Fore.GREEN}🟢 Active" if defense_system.intrusion_detection else f"{Fore.RED}🔴 Inactive"
    av_status = f"{Fore.GREEN}🟢 Active" if defense_system.antivirus_enabled else f"{Fore.RED}🔴 Inactive"
    
    slow_print(f"{Fore.GREEN}Security Systems Status:", 0.02)
    slow_print(f"  Firewall: {firewall_status}", 0.02)
    slow_print(f"  Intrusion Detection: {ids_status}", 0.02)
    slow_print(f"  Antivirus: {av_status}", 0.02)
    
    slow_print(f"\n{Fore.YELLOW}Threat Statistics:", 0.02)
    slow_print(f"{Fore.GREEN}Active Threats: {Fore.WHITE}{len(active_threats)}", 0.02)
    slow_print(f"{Fore.GREEN}Total Detected: {Fore.WHITE}{defense_system.defense_stats['threats_detected']}", 0.02)
    slow_print(f"{Fore.GREEN}Threats Blocked: {Fore.WHITE}{defense_system.defense_stats['threats_blocked']}", 0.02)
    slow_print(f"{Fore.GREEN}Blocked IPs: {Fore.WHITE}{len(defense_system.blocked_ips)}", 0.02)

def display_active_threats(defense_system):
    """Display active cyber threats"""
    slow_print(f"\n{Fore.CYAN}🚨 Active Cyber Threats", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*100}", 0.01)
    
    active_threats = [t for t in defense_system.active_threats if not t.mitigated]
    
    if not active_threats:
        slow_print(f"{Fore.GREEN}✅ No active threats detected", 0.02)
        return
    
    severity_colors = {
        'Low': Fore.GREEN,
        'Medium': Fore.YELLOW,
        'High': Fore.RED,
        'Critical': Fore.MAGENTA
    }
    
    for threat in active_threats:
        color = severity_colors.get(threat.severity, Fore.WHITE)
        time_str = threat.timestamp.strftime("%H:%M:%S")
        
        slow_print(f"{color}🔥 {threat.threat_type} - {threat.severity}", 0.02)
        slow_print(f"   {Fore.WHITE}ID: {threat.threat_id} | Time: {time_str}", 0.02)
        slow_print(f"   {Fore.WHITE}Source: {threat.source} | Target: {threat.target}", 0.02)
        slow_print(f"   {Fore.WHITE}Description: {threat.description}", 0.02)
        print()

def display_security_scan_results(scan_results):
    """Display security scan results"""
    slow_print(f"\n{Fore.CYAN}🔍 Security Scan Results", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Scan Duration: {Fore.WHITE}{scan_results['scan_duration']:.1f} seconds", 0.02)
    
    # Color-code results based on severity
    vuln_color = Fore.RED if scan_results['vulnerabilities'] > 5 else Fore.YELLOW if scan_results['vulnerabilities'] > 0 else Fore.GREEN
    
    slow_print(f"\n{Fore.YELLOW}Findings:", 0.02)
    slow_print(f"{vuln_color}Vulnerabilities: {scan_results['vulnerabilities']}", 0.02)
    slow_print(f"{Fore.YELLOW}Outdated Software: {scan_results['outdated_software']}", 0.02)
    slow_print(f"{Fore.YELLOW}Weak Passwords: {scan_results['weak_passwords']}", 0.02)
    slow_print(f"{Fore.YELLOW}Open Ports: {scan_results['open_ports']}", 0.02)
    slow_print(f"{Fore.RED}Suspicious Processes: {scan_results['suspicious_processes']}", 0.02)
    
    if scan_results['recommendations']:
        slow_print(f"\n{Fore.CYAN}🔧 Recommendations:", 0.02)
        for rec in scan_results['recommendations']:
            slow_print(f"{Fore.GREEN}• {rec}", 0.02)

def main():
    """Main function"""
    print_header()
    
    defense_system = DefenseSystem()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🛡️ CyberDef Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Security Dashboard", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Active Threats", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Simulate Cyber Attack", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Mitigate Threats", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Security Scan", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Firewall Management", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Security Report", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            display_threat_dashboard(defense_system)
        
        elif choice == '2':
            display_active_threats(defense_system)
        
        elif choice == '3':
            slow_print(f"\n{Fore.RED}⚠️ Simulating Cyber Attack...", 0.02)
            time.sleep(2)
            
            threat = defense_system.generate_cyber_threat()
            detected = defense_system.detect_threat(threat)
            
            if detected:
                severity_color = {
                    'Low': Fore.GREEN,
                    'Medium': Fore.YELLOW,
                    'High': Fore.RED,
                    'Critical': Fore.MAGENTA
                }.get(threat.severity, Fore.WHITE)
                
                slow_print(f"\n{Fore.RED}🚨 THREAT DETECTED!", 0.02)
                slow_print(f"{severity_color}Type: {threat.threat_type}", 0.02)
                slow_print(f"{severity_color}Severity: {threat.severity}", 0.02)
                slow_print(f"{Fore.WHITE}Source: {threat.source}", 0.02)
                slow_print(f"{Fore.WHITE}Target: {threat.target}", 0.02)
                slow_print(f"{Fore.WHITE}Description: {threat.description}", 0.02)
            else:
                slow_print(f"\n{Fore.YELLOW}⚠️ Attack occurred but was not detected", 0.02)
        
        elif choice == '4':
            active_threats = [t for t in defense_system.active_threats if not t.mitigated]
            
            if not active_threats:
                slow_print(f"{Fore.GREEN}✅ No active threats to mitigate", 0.02)
                continue
            
            slow_print(f"\n{Fore.CYAN}🛠️ Threat Mitigation", 0.02)
            slow_print(f"{Fore.YELLOW}Active threats:", 0.02)
            
            for i, threat in enumerate(active_threats, 1):
                slow_print(f"{Fore.GREEN}{i}. {threat.threat_type} ({threat.severity}) - {threat.threat_id}", 0.02)
            
            try:
                threat_choice = int(input(f"\n{Fore.YELLOW}Select threat to mitigate (1-{len(active_threats)}): ").strip()) - 1
                if 0 <= threat_choice < len(active_threats):
                    threat = active_threats[threat_choice]
                    
                    slow_print(f"\n{Fore.YELLOW}🔄 Mitigating threat {threat.threat_id}...", 0.02)
                    time.sleep(2)
                    
                    success, strategies = defense_system.mitigate_threat(threat)
                    
                    if success:
                        slow_print(f"\n{Fore.GREEN}✅ Threat successfully mitigated!", 0.02)
                        slow_print(f"{Fore.CYAN}Mitigation strategies applied:", 0.02)
                        for strategy in strategies:
                            slow_print(f"{Fore.GREEN}• {strategy}", 0.02)
                    else:
                        slow_print(f"\n{Fore.RED}❌ Threat mitigation failed", 0.02)
                        slow_print(f"{Fore.YELLOW}Escalating to security team...", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid threat selection", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}🔍 Running Security Scan...", 0.02)
            time.sleep(3)
            
            scan_results = defense_system.run_security_scan()
            display_security_scan_results(scan_results)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}🔥 Firewall Management", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}View Firewall Rules", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Add IP Block Rule", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Add Domain Block Rule", 0.02)
            
            fw_choice = input(f"\n{Fore.YELLOW}Select option (1-3): ").strip()
            
            if fw_choice == '1':
                if defense_system.firewall_rules:
                    slow_print(f"\n{Fore.CYAN}Firewall Rules:", 0.02)
                    for rule in defense_system.firewall_rules:
                        slow_print(f"{Fore.GREEN}Rule {rule['id']}: {rule['type']} - {rule['value']} ({rule['action']})", 0.02)
                else:
                    slow_print(f"{Fore.YELLOW}No firewall rules configured", 0.02)
            
            elif fw_choice == '2':
                ip_address = input(f"{Fore.YELLOW}Enter IP address to block: ").strip()
                if ip_address:
                    defense_system.update_firewall_rules('IP', ip_address)
                    slow_print(f"{Fore.GREEN}✅ IP {ip_address} added to firewall block list", 0.02)
            
            elif fw_choice == '3':
                domain = input(f"{Fore.YELLOW}Enter domain to block: ").strip()
                if domain:
                    defense_system.update_firewall_rules('DOMAIN', domain)
                    slow_print(f"{Fore.GREEN}✅ Domain {domain} added to firewall block list", 0.02)
        
        elif choice == '7':
            report = defense_system.generate_security_report()
            
            slow_print(f"\n{Fore.CYAN}📊 Security Status Report", 0.02)
            slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
            slow_print(f"{Fore.GREEN}Report Generated: {Fore.WHITE}{report['timestamp'][:19]}", 0.02)
            slow_print(f"{Fore.GREEN}Security Level: {Fore.WHITE}{report['security_level']}", 0.02)
            slow_print(f"{Fore.GREEN}Active Threats: {Fore.WHITE}{report['active_threats']}", 0.02)
            slow_print(f"{Fore.GREEN}Total Threats: {Fore.WHITE}{report['total_threats']}", 0.02)
            slow_print(f"{Fore.GREEN}Threats Mitigated: {Fore.WHITE}{report['threats_mitigated']}", 0.02)
            slow_print(f"{Fore.GREEN}Blocked IPs: {Fore.WHITE}{report['blocked_ips']}", 0.02)
            slow_print(f"{Fore.GREEN}Firewall Rules: {Fore.WHITE}{report['firewall_rules']}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}System Status:", 0.02)
            for system, status in report['system_status'].items():
                status_color = Fore.GREEN if status == 'Active' else Fore.RED
                slow_print(f"{Fore.CYAN}{system.title()}: {status_color}{status}", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using CyberDef! Stay secure!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
