#!/usr/bin/env python3
"""
CyberKit - Cybersecurity Toolkit
Created by BHAVYANSH SONI
A retro-style comprehensive cybersecurity toolkit with various security utilities
"""

import os
import sys
import time
import random
import hashlib
import base64
import socket
import subprocess
from datetime import datetime
from colorama import init, Fore, Back, Style
import secrets
import string

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.GREEN}{'='*60}
{Fore.CYAN}     ██████╗██╗   ██╗██████╗ ███████╗██████╗ ██╗  ██╗██╗████████╗
{Fore.CYAN}    ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗██║ ██╔╝██║╚══██╔══╝
{Fore.CYAN}    ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝█████╔╝ ██║   ██║   
{Fore.CYAN}    ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗██╔═██╗ ██║   ██║   
{Fore.CYAN}    ╚██████╗   ██║   ██████╔╝███████╗██║  ██║██║  ██╗██║   ██║   
{Fore.CYAN}     ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ╚═╝   
{Fore.GREEN}{'='*60}
{Fore.YELLOW}    🔧 Cybersecurity Toolkit - Security Utilities Suite
{Fore.MAGENTA}    🛡️ Created by: BHAVYANSH SONI
{Fore.GREEN}{'='*60}
"""
    print(header)

class CyberKit:
    """Comprehensive cybersecurity toolkit"""
    
    def __init__(self):
        self.hash_algorithms = ['md5', 'sha1', 'sha256', 'sha512']
        self.encoding_methods = ['base64', 'hex', 'url', 'ascii']
        self.cipher_types = ['caesar', 'vigenere', 'atbash']
        
    def generate_secure_password(self, length=12, include_symbols=True):
        """Generate cryptographically secure password"""
        alphabet = string.ascii_letters + string.digits
        if include_symbols:
            alphabet += "!@#$%^&*"
        
        password = ''.join(secrets.choice(alphabet) for _ in range(length))
        
        # Calculate password strength
        strength = self.calculate_password_strength(password)
        
        return password, strength
    
    def calculate_password_strength(self, password):
        """Calculate password strength score"""
        score = 0
        feedback = []
        
        # Length check
        if len(password) >= 12:
            score += 25
        elif len(password) >= 8:
            score += 15
        else:
            feedback.append("Password should be at least 8 characters")
        
        # Character variety checks
        if any(c.islower() for c in password):
            score += 15
        else:
            feedback.append("Add lowercase letters")
        
        if any(c.isupper() for c in password):
            score += 15
        else:
            feedback.append("Add uppercase letters")
        
        if any(c.isdigit() for c in password):
            score += 15
        else:
            feedback.append("Add numbers")
        
        if any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
            score += 30
        else:
            feedback.append("Add special characters")
        
        # Determine strength level
        if score >= 80:
            strength = "Very Strong"
        elif score >= 60:
            strength = "Strong"
        elif score >= 40:
            strength = "Medium"
        elif score >= 20:
            strength = "Weak"
        else:
            strength = "Very Weak"
        
        return {
            'score': score,
            'strength': strength,
            'feedback': feedback
        }
    
    def hash_text(self, text, algorithm='sha256'):
        """Hash text using specified algorithm"""
        if algorithm not in self.hash_algorithms:
            return None
        
        text_bytes = text.encode('utf-8')
        
        if algorithm == 'md5':
            hash_obj = hashlib.md5(text_bytes)
        elif algorithm == 'sha1':
            hash_obj = hashlib.sha1(text_bytes)
        elif algorithm == 'sha256':
            hash_obj = hashlib.sha256(text_bytes)
        elif algorithm == 'sha512':
            hash_obj = hashlib.sha512(text_bytes)
        
        return hash_obj.hexdigest()
    
    def encode_decode_text(self, text, method, operation='encode'):
        """Encode or decode text using various methods"""
        try:
            if method == 'base64':
                if operation == 'encode':
                    return base64.b64encode(text.encode('utf-8')).decode('utf-8')
                else:
                    return base64.b64decode(text.encode('utf-8')).decode('utf-8')
            
            elif method == 'hex':
                if operation == 'encode':
                    return text.encode('utf-8').hex()
                else:
                    return bytes.fromhex(text).decode('utf-8')
            
            elif method == 'url':
                if operation == 'encode':
                    return ''.join(f'%{ord(c):02X}' for c in text)
                else:
                    return ''.join(chr(int(text[i:i+2], 16)) for i in range(1, len(text), 3) if text[i-1] == '%')
            
            elif method == 'ascii':
                if operation == 'encode':
                    return ' '.join(str(ord(c)) for c in text)
                else:
                    return ''.join(chr(int(code)) for code in text.split())
        
        except Exception as e:
            return f"Error: {str(e)}"
    
    def caesar_cipher(self, text, shift, operation='encrypt'):
        """Caesar cipher encryption/decryption"""
        if operation == 'decrypt':
            shift = -shift
        
        result = ""
        for char in text:
            if char.isalpha():
                ascii_offset = ord('A') if char.isupper() else ord('a')
                shifted = (ord(char) - ascii_offset + shift) % 26
                result += chr(shifted + ascii_offset)
            else:
                result += char
        
        return result
    
    def vigenere_cipher(self, text, key, operation='encrypt'):
        """Vigenère cipher encryption/decryption"""
        key = key.upper()
        result = ""
        key_index = 0
        
        for char in text:
            if char.isalpha():
                shift = ord(key[key_index % len(key)]) - ord('A')
                if operation == 'decrypt':
                    shift = -shift
                
                ascii_offset = ord('A') if char.isupper() else ord('a')
                shifted = (ord(char) - ascii_offset + shift) % 26
                result += chr(shifted + ascii_offset)
                key_index += 1
            else:
                result += char
        
        return result
    
    def atbash_cipher(self, text):
        """Atbash cipher (substitution cipher)"""
        result = ""
        for char in text:
            if char.isalpha():
                if char.isupper():
                    result += chr(ord('Z') - (ord(char) - ord('A')))
                else:
                    result += chr(ord('z') - (ord(char) - ord('a')))
            else:
                result += char
        
        return result
    
    def check_port(self, host, port, timeout=3):
        """Check if a port is open on a host"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()
            return result == 0
        except Exception:
            return False
    
    def scan_common_ports(self, host):
        """Scan common ports on a host"""
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 3389, 5432, 3306]
        open_ports = []
        
        for port in common_ports:
            if self.check_port(host, port):
                open_ports.append(port)
        
        return open_ports
    
    def generate_hash_rainbow_table(self, wordlist, algorithm='md5'):
        """Generate rainbow table for given wordlist"""
        rainbow_table = {}
        
        for word in wordlist:
            hash_value = self.hash_text(word, algorithm)
            rainbow_table[hash_value] = word
        
        return rainbow_table
    
    def check_hash_against_rainbow(self, hash_value, rainbow_table):
        """Check if hash exists in rainbow table"""
        return rainbow_table.get(hash_value, None)

def display_password_analysis(password, strength_info):
    """Display password strength analysis"""
    slow_print(f"\n{Fore.CYAN}🔐 Password Analysis", 0.02)
    slow_print(f"{Fore.YELLOW}{'─'*50}", 0.01)
    
    slow_print(f"{Fore.GREEN}Password: {Fore.WHITE}{'*' * len(password)}", 0.02)
    slow_print(f"{Fore.GREEN}Length: {Fore.WHITE}{len(password)} characters", 0.02)
    slow_print(f"{Fore.GREEN}Strength Score: {Fore.WHITE}{strength_info['score']}/100", 0.02)
    
    # Color-code strength
    strength_colors = {
        'Very Strong': Fore.GREEN,
        'Strong': Fore.CYAN,
        'Medium': Fore.YELLOW,
        'Weak': Fore.RED,
        'Very Weak': Fore.MAGENTA
    }
    
    strength_color = strength_colors.get(strength_info['strength'], Fore.WHITE)
    slow_print(f"{Fore.GREEN}Strength Level: {strength_color}{strength_info['strength']}", 0.02)
    
    if strength_info['feedback']:
        slow_print(f"\n{Fore.YELLOW}💡 Recommendations:", 0.02)
        for feedback in strength_info['feedback']:
            slow_print(f"{Fore.CYAN}• {feedback}", 0.02)

def display_hash_results(text, results):
    """Display hash results for all algorithms"""
    slow_print(f"\n{Fore.CYAN}🔒 Hash Results for: '{text}'", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    algorithms = ['md5', 'sha1', 'sha256', 'sha512']
    
    for algo in algorithms:
        hash_value = results.get(algo, 'N/A')
        slow_print(f"{Fore.GREEN}{algo.upper()}: {Fore.WHITE}{hash_value}", 0.02)

def display_encoding_results(text, method, encoded, decoded):
    """Display encoding/decoding results"""
    slow_print(f"\n{Fore.CYAN}🔄 Encoding Results ({method.title()})", 0.02)
    slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Original: {Fore.WHITE}{text}", 0.02)
    slow_print(f"{Fore.GREEN}Encoded: {Fore.WHITE}{encoded}", 0.02)
    slow_print(f"{Fore.GREEN}Decoded: {Fore.WHITE}{decoded}", 0.02)

def display_port_scan_results(host, open_ports):
    """Display port scan results"""
    slow_print(f"\n{Fore.CYAN}🔍 Port Scan Results for {host}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─'*50}", 0.01)
    
    if open_ports:
        slow_print(f"{Fore.GREEN}Open Ports Found:", 0.02)
        for port in open_ports:
            service = get_service_name(port)
            slow_print(f"{Fore.CYAN}Port {port}: {Fore.WHITE}{service}", 0.02)
    else:
        slow_print(f"{Fore.YELLOW}No open ports found in common range", 0.02)

def get_service_name(port):
    """Get common service name for port"""
    services = {
        21: "FTP",
        22: "SSH",
        23: "Telnet",
        25: "SMTP",
        53: "DNS",
        80: "HTTP",
        110: "POP3",
        143: "IMAP",
        443: "HTTPS",
        993: "IMAPS",
        995: "POP3S",
        3389: "RDP",
        5432: "PostgreSQL",
        3306: "MySQL"
    }
    
    return services.get(port, "Unknown")

def main():
    """Main function"""
    print_header()
    
    cyberkit = CyberKit()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🔧 CyberKit Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Password Generator & Analyzer", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Hash Generator", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Text Encoder/Decoder", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Cipher Tools", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Network Scanner", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Rainbow Table Generator", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Security Utilities", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}🔐 Password Tools", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Generate Secure Password", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Analyze Password Strength", 0.02)
            
            pwd_choice = input(f"\n{Fore.YELLOW}Select option (1-2): ").strip()
            
            if pwd_choice == '1':
                try:
                    length = int(input(f"{Fore.YELLOW}Password length (8-50): ").strip())
                    length = max(8, min(50, length))
                    
                    include_symbols = input(f"{Fore.YELLOW}Include symbols? (y/n): ").strip().lower() == 'y'
                    
                    password, strength = cyberkit.generate_secure_password(length, include_symbols)
                    
                    slow_print(f"\n{Fore.GREEN}✅ Generated Password:", 0.02)
                    slow_print(f"{Fore.CYAN}Password: {Fore.WHITE}{password}", 0.02)
                    
                    display_password_analysis(password, strength)
                
                except ValueError:
                    slow_print(f"{Fore.RED}❌ Invalid length", 0.02)
            
            elif pwd_choice == '2':
                password = input(f"{Fore.YELLOW}Enter password to analyze: ").strip()
                if password:
                    strength = cyberkit.calculate_password_strength(password)
                    display_password_analysis(password, strength)
        
        elif choice == '2':
            text = input(f"{Fore.YELLOW}Enter text to hash: ").strip()
            if text:
                slow_print(f"\n{Fore.YELLOW}🔄 Generating hashes...", 0.02)
                time.sleep(1)
                
                results = {}
                for algo in cyberkit.hash_algorithms:
                    results[algo] = cyberkit.hash_text(text, algo)
                
                display_hash_results(text, results)
        
        elif choice == '3':
            text = input(f"{Fore.YELLOW}Enter text to encode/decode: ").strip()
            if text:
                slow_print(f"\n{Fore.YELLOW}Encoding methods:", 0.02)
                for i, method in enumerate(cyberkit.encoding_methods, 1):
                    slow_print(f"{Fore.GREEN}{i}. {method.title()}", 0.02)
                
                try:
                    method_choice = int(input(f"\n{Fore.YELLOW}Select method (1-{len(cyberkit.encoding_methods)}): ").strip()) - 1
                    if 0 <= method_choice < len(cyberkit.encoding_methods):
                        method = cyberkit.encoding_methods[method_choice]
                        
                        encoded = cyberkit.encode_decode_text(text, method, 'encode')
                        decoded = cyberkit.encode_decode_text(encoded, method, 'decode')
                        
                        display_encoding_results(text, method, encoded, decoded)
                    else:
                        slow_print(f"{Fore.RED}❌ Invalid method choice", 0.02)
                except ValueError:
                    slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}🔒 Cipher Tools", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Caesar Cipher", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Vigenère Cipher", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Atbash Cipher", 0.02)
            
            cipher_choice = input(f"\n{Fore.YELLOW}Select cipher (1-3): ").strip()
            
            if cipher_choice == '1':
                text = input(f"{Fore.YELLOW}Enter text: ").strip()
                if text:
                    try:
                        shift = int(input(f"{Fore.YELLOW}Enter shift value (1-25): ").strip())
                        operation = input(f"{Fore.YELLOW}Operation (encrypt/decrypt): ").strip().lower()
                        
                        if operation in ['encrypt', 'decrypt']:
                            result = cyberkit.caesar_cipher(text, shift, operation)
                            slow_print(f"\n{Fore.GREEN}Result: {Fore.WHITE}{result}", 0.02)
                        else:
                            slow_print(f"{Fore.RED}❌ Invalid operation", 0.02)
                    except ValueError:
                        slow_print(f"{Fore.RED}❌ Invalid shift value", 0.02)
            
            elif cipher_choice == '2':
                text = input(f"{Fore.YELLOW}Enter text: ").strip()
                key = input(f"{Fore.YELLOW}Enter key: ").strip()
                if text and key:
                    operation = input(f"{Fore.YELLOW}Operation (encrypt/decrypt): ").strip().lower()
                    
                    if operation in ['encrypt', 'decrypt']:
                        result = cyberkit.vigenere_cipher(text, key, operation)
                        slow_print(f"\n{Fore.GREEN}Result: {Fore.WHITE}{result}", 0.02)
                    else:
                        slow_print(f"{Fore.RED}❌ Invalid operation", 0.02)
            
            elif cipher_choice == '3':
                text = input(f"{Fore.YELLOW}Enter text: ").strip()
                if text:
                    result = cyberkit.atbash_cipher(text)
                    slow_print(f"\n{Fore.GREEN}Result: {Fore.WHITE}{result}", 0.02)
        
        elif choice == '5':
            host = input(f"{Fore.YELLOW}Enter host to scan: ").strip()
            if host:
                slow_print(f"\n{Fore.YELLOW}🔍 Scanning {host}...", 0.02)
                time.sleep(2)
                
                open_ports = cyberkit.scan_common_ports(host)
                display_port_scan_results(host, open_ports)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}🌈 Rainbow Table Generator", 0.02)
            
            wordlist_input = input(f"{Fore.YELLOW}Enter wordlist (comma-separated): ").strip()
            if wordlist_input:
                wordlist = [word.strip() for word in wordlist_input.split(',')]
                algorithm = input(f"{Fore.YELLOW}Hash algorithm (md5/sha1/sha256): ").strip().lower() or 'md5'
                
                slow_print(f"\n{Fore.YELLOW}🔄 Generating rainbow table...", 0.02)
                time.sleep(1)
                
                rainbow_table = cyberkit.generate_hash_rainbow_table(wordlist, algorithm)
                
                slow_print(f"\n{Fore.GREEN}Rainbow Table ({algorithm.upper()}):", 0.02)
                slow_print(f"{Fore.YELLOW}{'─'*80}", 0.01)
                
                for hash_val, word in rainbow_table.items():
                    slow_print(f"{Fore.CYAN}{word}: {Fore.WHITE}{hash_val}", 0.02)
                
                # Test lookup
                test_hash = input(f"\n{Fore.YELLOW}Enter hash to lookup (optional): ").strip()
                if test_hash:
                    result = cyberkit.check_hash_against_rainbow(test_hash, rainbow_table)
                    if result:
                        slow_print(f"{Fore.GREEN}✅ Hash found: {result}", 0.02)
                    else:
                        slow_print(f"{Fore.RED}❌ Hash not found in rainbow table", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}🛡️ Security Utilities", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Generate Random Key", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Check Hash Collision", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Security Best Practices", 0.02)
            
            util_choice = input(f"\n{Fore.YELLOW}Select utility (1-3): ").strip()
            
            if util_choice == '1':
                try:
                    key_length = int(input(f"{Fore.YELLOW}Key length in bytes (16-64): ").strip())
                    key_length = max(16, min(64, key_length))
                    
                    random_key = secrets.token_hex(key_length)
                    slow_print(f"\n{Fore.GREEN}Random Key ({key_length} bytes): {Fore.WHITE}{random_key}", 0.02)
                except ValueError:
                    slow_print(f"{Fore.RED}❌ Invalid key length", 0.02)
            
            elif util_choice == '2':
                text1 = input(f"{Fore.YELLOW}Enter first text: ").strip()
                text2 = input(f"{Fore.YELLOW}Enter second text: ").strip()
                
                if text1 and text2:
                    hash1 = cyberkit.hash_text(text1, 'sha256')
                    hash2 = cyberkit.hash_text(text2, 'sha256')
                    
                    slow_print(f"\n{Fore.CYAN}Hash Comparison:", 0.02)
                    slow_print(f"{Fore.GREEN}Text 1 Hash: {Fore.WHITE}{hash1}", 0.02)
                    slow_print(f"{Fore.GREEN}Text 2 Hash: {Fore.WHITE}{hash2}", 0.02)
                    
                    if hash1 == hash2:
                        slow_print(f"{Fore.RED}⚠️ COLLISION DETECTED!", 0.02)
                    else:
                        slow_print(f"{Fore.GREEN}✅ No collision - hashes are different", 0.02)
            
            elif util_choice == '3':
                slow_print(f"\n{Fore.CYAN}🔒 Security Best Practices", 0.02)
                slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
                
                practices = [
                    "Use strong, unique passwords for each account",
                    "Enable two-factor authentication (2FA)",
                    "Keep software and systems updated",
                    "Use HTTPS for web communications",
                    "Regularly backup important data",
                    "Be cautious with email attachments and links",
                    "Use a reputable antivirus program",
                    "Limit administrative privileges",
                    "Monitor system logs and network activity",
                    "Encrypt sensitive data at rest and in transit"
                ]
                
                for i, practice in enumerate(practices, 1):
                    slow_print(f"{Fore.GREEN}{i:2d}. {Fore.WHITE}{practice}", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using CyberKit! Stay secure!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
