import random
import time
from rich.console import Console
from rich.panel import Panel
from rich.columns import Columns
from rich.text import Text
import json
import os
from datetime import datetime

# Initialize Rich console
console = Console()

# Dream symbols and their meanings
DREAM_SYMBOLS = {
    "water": ["emotions", "unconscious mind", "purification", "life force"],
    "flying": ["freedom", "transcendence", "escape", "spiritual journey"],
    "falling": ["loss of control", "anxiety", "letting go", "surrender"],
    "teeth": ["confidence", "power", "life transitions", "anxiety"],
    "house": ["self", "personality", "mind", "personal space"],
    "door": ["opportunities", "transitions", "choices", "new beginnings"],
    "animals": ["instincts", "nature", "primal desires", "connection"],
    "colors": {
        "red": ["passion", "energy", "anger", "life force"],
        "blue": ["peace", "tranquility", "depth", "wisdom"],
        "green": ["growth", "harmony", "healing", "nature"],
        "purple": ["spirituality", "mystery", "transformation"],
        "gold": ["divine", "value", "wisdom", "enlightenment"]
    }
}

# Mystical symbols for decoration
MYSTICAL_SYMBOLS = '✨🌙⭐🔮🌟✧⋆｡°✩'

def type_print(text, delay=0.03):
    """Print text with mystical typing effect"""
    for char in text:
        style = random.choice(['bold purple', 'bold blue', 'bold cyan'])
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def save_dream(dream_text, interpretation):
    """Save dream and interpretation to journal"""
    dreams_file = "dream_journal.json"
    dreams = []
    
    if os.path.exists(dreams_file):
        try:
            with open(dreams_file, 'r') as f:
                dreams = json.load(f)
        except:
            pass
    
    dream_entry = {
        'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'dream': dream_text,
        'interpretation': interpretation
    }
    dreams.append(dream_entry)
    
    with open(dreams_file, 'w') as f:
        json.dump(dreams, f, indent=2)

def analyze_dream_symbols(dream_text):
    """Analyze dream text for symbolic meanings"""
    dream_text = dream_text.lower()
    interpretations = []
    
    # Check for symbols
    for symbol, meanings in DREAM_SYMBOLS.items():
        if symbol != "colors" and symbol in dream_text:
            meaning = random.choice(meanings)
            interpretations.append(f"The presence of {symbol} suggests {meaning}")
    
    # Check for colors
    for color, meanings in DREAM_SYMBOLS["colors"].items():
        if color in dream_text:
            meaning = random.choice(meanings)
            interpretations.append(f"The color {color} represents {meaning}")
    
    # Add some mystical insights
    mystical_insights = [
        "The cosmic energies align with your inner vision",
        "Your higher self is sending you a message",
        "This dream reflects your spiritual journey",
        "The universe is guiding you through symbols",
        "Ancient wisdom speaks through your dreams"
    ]
    
    interpretations.append(random.choice(mystical_insights))
    return interpretations

def create_interpretation_panel(dream_text, interpretations):
    """Create a beautifully styled interpretation panel"""
    # Create dream text display
    dream_display = Text()
    dream_display.append("Your Dream Vision:\n", style="bold purple")
    dream_display.append(dream_text + "\n\n", style="italic cyan")
    
    # Add interpretations with mystical symbols
    dream_display.append("Mystical Interpretation:\n", style="bold purple")
    for interp in interpretations:
        symbol = random.choice(MYSTICAL_SYMBOLS)
        dream_display.append(f"{symbol} ", style="yellow")
        dream_display.append(interp + "\n", style="cyan")
    
    # Add cosmic guidance
    dream_display.append("\nCosmic Guidance:\n", style="bold purple")
    guidance = random.choice([
        "Trust in the wisdom of your dreams",
        "Your subconscious holds the key to understanding",
        "The dream realm reveals hidden truths",
        "Listen to the whispers of your soul",
        "Your dreams are a bridge to higher consciousness"
    ])
    dream_display.append(f"✨ {guidance}", style="italic magenta")
    
    return Panel(
        dream_display,
        title="[bold purple]Dream Decoder[/]",
        border_style="purple",
        subtitle=f"[dim purple]{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/]"
    )

def view_dream_journal():
    """View previously recorded dreams"""
    dreams_file = "dream_journal.json"
    if not os.path.exists(dreams_file):
        console.print(Panel("No dreams recorded yet...",
                          style="dim purple",
                          title="Dream Journal"))
        return
    
    try:
        with open(dreams_file, 'r') as f:
            dreams = json.load(f)
        
        if not dreams:
            console.print(Panel("Dream journal is empty...",
                              style="dim purple",
                              title="Dream Journal"))
            return
        
        for dream in dreams:
            panel = Panel(
                f"[bold cyan]Dream:[/]\n{dream['dream']}\n\n"
                f"[bold purple]Interpretation:[/]\n{dream['interpretation']}",
                title=f"[purple]{dream['date']}[/]",
                border_style="blue"
            )
            console.print(panel)
            time.sleep(0.5)  # Dramatic pause between dreams
            
    except Exception as e:
        console.print(f"[red]Error reading dream journal: {e}[/]")

def main():
    """Main program with mystical interface"""
    console.clear()
    type_print("✨ Welcome to DreamDecoder", delay=0.05)
    type_print("   Unlock the Mysteries of Your Dreams", delay=0.03)
    print()
    
    while True:
        try:
            console.print("\n[purple]Mystical Options:[/]")
            console.print("1. [cyan]Interpret New Dream[/]")
            console.print("2. [cyan]View Dream Journal[/]")
            console.print("3. [cyan]Exit[/]")
            
            choice = input("\nChoose your path (1-3): ").strip()
            
            if choice == '1':
                print("\nDescribe your dream (press Enter twice to finish):")
                dream_lines = []
                while True:
                    line = input()
                    if not line:
                        break
                    dream_lines.append(line)
                
                dream_text = ' '.join(dream_lines)
                if dream_text:
                    interpretations = analyze_dream_symbols(dream_text)
                    panel = create_interpretation_panel(dream_text, interpretations)
                    console.print(panel)
                    
                    # Save to journal
                    save_dream(dream_text, '\n'.join(interpretations))
                    type_print("\n🌙 Dream vision has been recorded in the cosmic journal...", delay=0.03)
                
            elif choice == '2':
                view_dream_journal()
                input("\nPress Enter to return to the cosmic realm...")
                
            elif choice == '3':
                type_print("\n✨ Returning to the waking world...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("✨ Dream journey interrupted...", delay=0.05)
            break

if __name__ == "__main__":
    main() 