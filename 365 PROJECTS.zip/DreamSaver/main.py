from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table
from datetime import datetime
import json
import os
import re

class DreamSaver:
    def __init__(self):
        self.console = Console()
        self.dreams_file = "dream_journal.json"
        self.common_symbols = {
            "flying": "Freedom, transcendence, escape",
            "falling": "Loss of control, anxiety, insecurity",
            "water": "Emotions, unconscious mind, cleansing",
            "teeth": "Anxiety, transition, loss",
            "chase": "Avoiding issues, feeling threatened",
            "house": "Self, personality, personal space",
            "door": "Opportunities, transitions, choices",
            "mirror": "Self-reflection, identity, truth",
            "light": "Enlightenment, awareness, hope",
            "darkness": "Unknown, mystery, fear"
        }
        self.load_dreams()
        
    def load_dreams(self):
        """Load saved dreams"""
        if os.path.exists(self.dreams_file):
            with open(self.dreams_file, 'r') as f:
                self.dreams = json.load(f)
        else:
            self.dreams = []
            
    def save_dreams(self):
        """Save dreams to file"""
        with open(self.dreams_file, 'w') as f:
            json.dump(self.dreams, f, indent=2)
            
    def analyze_dream(self, dream_text):
        """Analyze dream content for common symbols"""
        analysis = []
        for symbol, meaning in self.common_symbols.items():
            if re.search(r'\b' + symbol + r'\b', dream_text.lower()):
                analysis.append({
                    "symbol": symbol,
                    "meaning": meaning
                })
        return analysis
        
    def get_dream_stats(self):
        """Calculate dream statistics"""
        if not self.dreams:
            return None
            
        total_dreams = len(self.dreams)
        symbols_count = {}
        emotions = []
        
        for dream in self.dreams:
            # Count symbols
            for symbol in dream["analysis"]:
                symbols_count[symbol["symbol"]] = symbols_count.get(symbol["symbol"], 0) + 1
            
            # Collect emotions
            if "emotion" in dream:
                emotions.append(dream["emotion"])
                
        # Find most common symbols and emotions
        common_symbols = sorted(
            symbols_count.items(),
            key=lambda x: x[1],
            reverse=True
        )[:3]
        
        common_emotions = {}
        for emotion in emotions:
            common_emotions[emotion] = common_emotions.get(emotion, 0) + 1
            
        return {
            "total_dreams": total_dreams,
            "common_symbols": common_symbols,
            "common_emotions": dict(sorted(
                common_emotions.items(),
                key=lambda x: x[1],
                reverse=True
            )[:3])
        }
        
    def display_dream(self, dream):
        """Display a single dream entry"""
        self.console.print(Panel(
            f"[bold blue]Date:[/] {dream['date']}\n"
            f"[bold green]Emotion:[/] {dream.get('emotion', 'Not specified')}\n\n"
            f"{dream['content']}\n\n"
            "[bold yellow]Analysis:[/]",
            title="🌙 Dream Entry",
            border_style="cyan"
        ))
        
        # Display symbol analysis
        if dream["analysis"]:
            table = Table()
            table.add_column("Symbol", style="cyan")
            table.add_column("Meaning", style="yellow")
            
            for symbol in dream["analysis"]:
                table.add_row(symbol["symbol"], symbol["meaning"])
                
            self.console.print(table)
            
    def run(self):
        while True:
            self.console.print("\n💫 DreamSaver - Dream Journal & Analysis", style="bold purple")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4", "5"],
                default="1"
            )
            
            if choice == "1":
                # Record new dream
                self.console.print(Panel("✍️ New Dream Entry", style="bold green"))
                content = Prompt.ask("Describe your dream")
                emotion = Prompt.ask("How did the dream make you feel?")
                
                dream = {
                    "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "content": content,
                    "emotion": emotion,
                    "analysis": self.analyze_dream(content)
                }
                
                self.dreams.append(dream)
                self.save_dreams()
                
                self.console.print("\n✨ Dream saved! Analysis:")
                self.display_dream(dream)
                
            elif choice == "2":
                # View all dreams
                if not self.dreams:
                    self.console.print("No dreams recorded yet.", style="bold yellow")
                    continue
                    
                for dream in self.dreams:
                    self.display_dream(dream)
                    self.console.print("\n")
                    
            elif choice == "3":
                # View statistics
                stats = self.get_dream_stats()
                if not stats:
                    self.console.print("No dreams to analyze.", style="bold yellow")
                    continue
                    
                self.console.print(Panel(
                    f"[bold blue]Total Dreams:[/] {stats['total_dreams']}\n\n"
                    "[bold yellow]Most Common Symbols:[/]\n" +
                    "\n".join(f"- {s[0]}: {s[1]} times" for s in stats["common_symbols"]) +
                    "\n\n[bold green]Common Emotions:[/]\n" +
                    "\n".join(f"- {e}: {c} times" for e, c in stats["common_emotions"].items()),
                    title="📊 Dream Statistics",
                    border_style="blue"
                ))
                
            elif choice == "4":
                # Delete last dream
                if self.dreams:
                    self.dreams.pop()
                    self.save_dreams()
                    self.console.print("Last dream entry removed.", style="bold yellow")
                else:
                    self.console.print("No dreams to remove.", style="bold red")
                    
            elif choice == "5":
                self.console.print("Sweet dreams! 👋", style="bold purple")
                break
                
if __name__ == "__main__":
    saver = DreamSaver()
    saver.run() 