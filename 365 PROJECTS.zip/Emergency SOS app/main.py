def send_alert():
    print("Sending emergency alerts to saved contacts...")
    # Simulate alert sending
    print("Alert sent!")

def main():
    print("=== Emergency SOS App ===")
    while True:
        choice = input("Press 's' to send SOS alert or 'q' to quit: ").lower()
        if choice == 's':
            send_alert()
        elif choice == 'q':
            print("Exiting SOS App...")
            break
        else:
            print("Invalid input.")

if __name__ == "__main__":
    main()
