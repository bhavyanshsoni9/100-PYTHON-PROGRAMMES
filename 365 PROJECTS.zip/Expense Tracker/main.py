import sqlite3
from datetime import datetime

# DB init
conn = sqlite3.connect('expenses.db')
c = conn.cursor()

c.execute('''
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        amount REAL NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        date TEXT NOT NULL
    )
''')
conn.commit()

# Add expense
def add_expense():
    amount = float(input("Enter amount: ₹ "))
    category = input("Enter category (Food, Travel, Bills, etc): ")
    description = input("Enter description (optional): ")
    date = input("Enter date (YYYY-MM-DD) or leave empty for today: ")

    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    c.execute("INSERT INTO expenses (amount, category, description, date) VALUES (?, ?, ?, ?)",
              (amount, category, description, date))
    conn.commit()
    print("✅ Expense added successfully!\n")

# View all expenses
def view_expenses():
    c.execute("SELECT * FROM expenses ORDER BY date DESC")
    rows = c.fetchall()

    print("\n=== Your Expenses ===")
    for row in rows:
        print(f"{row[4]} | ₹{row[1]} | {row[2]} | {row[3]}")
    print()

# Show monthly total
def monthly_total():
    month = input("Enter month (YYYY-MM): ")
    c.execute("SELECT SUM(amount) FROM expenses WHERE date LIKE ?", (month + "%",))
    total = c.fetchone()[0] or 0
    print(f"\n💸 Total expenses in {month}: ₹{total}\n")

# Menu
def menu():
    while True:
        print("==== Smart Expense Tracker ====")
        print("1. Add Expense")
        print("2. View Expenses")
        print("3. Monthly Total")
        print("4. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            add_expense()
        elif choice == '2':
            view_expenses()
        elif choice == '3':
            monthly_total()
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice! Try again.\n")

if __name__ == '__main__':
    menu()
