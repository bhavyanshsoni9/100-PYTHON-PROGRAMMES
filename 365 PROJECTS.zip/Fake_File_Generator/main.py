#!/usr/bin/env python3

"""
Fake File Generator
A utility to generate dummy files of specified sizes and types with progress tracking.

Features:
- Generate files of any size (KB, MB, GB)
- Support for any file extension
- Custom or random file names
- Progress bar with size tracking
- Colorful interface with emojis
- Command-line and interactive modes

Author: Bhavyansh Soni
"""

# Import required libraries
import os
import sys
import time
import random
import string
import argparse
from tqdm import tqdm
from colorama import Fore, Style, init

# Initialize colorama for cross-platform color support
init(autoreset=True)

# List of emojis for visual feedback
EMOJIS = ['😃', '🚀', '📁', '✨', '📝', '💾', '🎉', '🦄', '🐍', '🧊']

def random_filename(extension: str) -> str:
    """Generate a random filename with the specified extension
    
    Args:
        extension (str): File extension without dot (e.g., 'txt', 'bin')
    
    Returns:
        str: Random filename with extension (e.g., 'a1b2c3d4.txt')
    """
    name = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    return f"{name}.{extension}"

def generate_fake_file(filename: str, size_bytes: int, chunk_size: int = 1024*1024) -> None:
    """Generate a file with random content and specified size
    
    Args:
        filename (str): Name of the file to create
        size_bytes (int): Size of the file in bytes
        chunk_size (int, optional): Size of chunks to write at once. Defaults to 1MB.
    """
    emoji = random.choice(EMOJIS)
    print(f"{Fore.CYAN}{emoji} Creating file: {Fore.YELLOW}{filename}{Style.RESET_ALL}")
    
    written = 0
    with open(filename, 'wb') as f, tqdm(total=size_bytes, unit='B', unit_scale=True, colour='green') as pbar:
        while written < size_bytes:
            # Calculate remaining bytes to write
            to_write = min(chunk_size, size_bytes - written)
            
            # Write random bytes
            f.write(os.urandom(to_write))
            written += to_write
            
            # Update progress bar
            pbar.update(to_write)
            
            # Add small delay for visual effect
            time.sleep(0.05)
    
    print(f"{Fore.GREEN}✅ Done! File created: {Fore.YELLOW}{filename} {random.choice(EMOJIS)}{Style.RESET_ALL}\n")

def parse_size(size_str: str) -> int:
    """Parse size string with units into bytes
    
    Args:
        size_str (str): Size string (e.g., '10MB', '500KB', '1GB')
    
    Returns:
        int: Size in bytes
    
    Raises:
        ValueError: If size format is invalid
    """
    size_str = size_str.strip().upper()
    
    # Convert size string to bytes based on unit
    if size_str.endswith('GB'):
        return int(float(size_str[:-2]) * 1024 ** 3)
    elif size_str.endswith('MB'):
        return int(float(size_str[:-2]) * 1024 ** 2)
    elif size_str.endswith('KB'):
        return int(float(size_str[:-2]) * 1024)
    elif size_str.endswith('B'):
        return int(float(size_str[:-1]))
    else:
        raise ValueError('Invalid size format. Use e.g. 10MB, 500KB, 1GB, etc.')

def main():
    """Main program handling command-line arguments and file generation"""
    # Set up command-line argument parser
    parser = argparse.ArgumentParser(description='Generate fake files of any size and type!')
    parser.add_argument('-s', '--size', help='Size of the file (e.g. 10MB, 500KB, 1GB)')
    parser.add_argument('-t', '--type', help='File extension/type (e.g. txt, bin, jpg)')
    parser.add_argument('-n', '--name', help='Optional file name (without extension)')
    args = parser.parse_args()

    # Interactive prompts if required arguments are missing
    if not args.size:
        args.size = input(f"{Fore.YELLOW}Enter file size (e.g. 10MB, 500KB, 1GB): {Style.RESET_ALL}")
    if not args.type:
        args.type = input(f"{Fore.YELLOW}Enter file type/extension (e.g. txt, bin, jpg): {Style.RESET_ALL}")

    # Parse and validate file size
    try:
        size_bytes = parse_size(args.size)
    except ValueError as e:
        print(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")
        sys.exit(1)

    # Generate filename (custom or random)
    if args.name:
        filename = f"{args.name}.{args.type}"
    else:
        filename = random_filename(args.type)

    # Generate the file
    generate_fake_file(filename, size_bytes)

# Start the program if this file is run directly
if __name__ == '__main__':
    main() 