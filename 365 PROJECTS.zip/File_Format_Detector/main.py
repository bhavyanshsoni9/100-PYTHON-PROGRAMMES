import sys
import os
from typing import List

try:
    from colorama import init, Fore, Style
except ImportError:
    print('Installing colorama...')
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'colorama'])
    from colorama import init, Fore, Style

init(autoreset=True)

MAGIC_NUMBERS = [
    (b'\x89PNG\r\n\x1a\n', 'PNG', '🖼️', Fore.CYAN),
    (b'\xff\xd8\xff', 'JPEG', '🖼️', Fore.MAGENTA),
    (b'GIF87a', 'GIF', '🖼️', Fore.YELLOW),
    (b'GIF89a', 'GIF', '🖼️', Fore.YELLOW),
    (b'%PDF-', 'PDF', '📄', Fore.RED),
    (b'PK\x03\x04', 'ZIP', '🗜️', Fore.BLUE),
    (b'Rar!\x1a\x07\x00', 'RAR', '🗜️', Fore.LIGHTBLUE_EX),
    (b'7z\xBC\xAF\x27\x1C', '7Z', '🗜️', Fore.LIGHTCYAN_EX),
    (b'\x1f\x8b', 'GZIP', '🗜️', Fore.LIGHTGREEN_EX),
    (b'ID3', 'MP3', '🎵', Fore.GREEN),
    (b'OggS', 'OGG', '🎵', Fore.LIGHTYELLOW_EX),
    (b'fLaC', 'FLAC', '🎵', Fore.LIGHTWHITE_EX),
    (b'MZ', 'EXE', '💻', Fore.LIGHTRED_EX),
    (b'BM', 'BMP', '🖼️', Fore.LIGHTMAGENTA_EX),
    (b'II*\x00', 'TIFF', '🖼️', Fore.LIGHTCYAN_EX),
    (b'MM\x00*', 'TIFF', '🖼️', Fore.LIGHTCYAN_EX),
]

# Map file extensions to programming languages and emojis
LANGUAGE_EXTENSIONS = {
    '.py':   ('Python', '🐍', Fore.LIGHTGREEN_EX),
    '.js':   ('JavaScript', '🟨', Fore.YELLOW),
    '.ts':   ('TypeScript', '🟦', Fore.BLUE),
    '.java': ('Java', '☕', Fore.LIGHTRED_EX),
    '.cpp':  ('C++', '💠', Fore.CYAN),
    '.c':    ('C', '🔵', Fore.BLUE),
    '.cs':   ('C#', '🎯', Fore.LIGHTCYAN_EX),
    '.rb':   ('Ruby', '💎', Fore.LIGHTRED_EX),
    '.php':  ('PHP', '🐘', Fore.MAGENTA),
    '.go':   ('Go', '🐹', Fore.CYAN),
    '.rs':   ('Rust', '🦀', Fore.RED),
    '.swift':('Swift', '🦅', Fore.LIGHTYELLOW_EX),
    '.kt':   ('Kotlin', '🟣', Fore.MAGENTA),
    '.html': ('HTML', '🌐', Fore.LIGHTYELLOW_EX),
    '.css':  ('CSS', '🎨', Fore.LIGHTBLUE_EX),
    '.sh':   ('Shell', '💻', Fore.LIGHTBLACK_EX),
    '.bat':  ('Batch', '💻', Fore.LIGHTBLACK_EX),
    '.pl':   ('Perl', '🦪', Fore.LIGHTWHITE_EX),
    '.lua':  ('Lua', '🌙', Fore.LIGHTBLUE_EX),
    '.sql':  ('SQL', '🗄️', Fore.LIGHTCYAN_EX),
    '.json': ('JSON', '🔢', Fore.LIGHTYELLOW_EX),
    '.xml':  ('XML', '📰', Fore.LIGHTWHITE_EX),
    '.md':   ('Markdown', '📝', Fore.LIGHTWHITE_EX),
}

BANNER = f"""
{Fore.CYAN}{Style.BRIGHT}
╔══════════════════════════════════════════════╗
║      🗂️  File Format Detector  🗂️         ║
╚══════════════════════════════════════════════╝
{Style.RESET_ALL}
"""

SEPARATOR = f"{Fore.LIGHTBLACK_EX}{'-'*60}{Style.RESET_ALL}"

HEADER = f"{Style.BRIGHT}| {'File Name':<20} | {'Format':<12} | {'Result':<20} |{Style.RESET_ALL}"


def detect_format(filepath: str):
    """Detect and return the file format info as a tuple."""
    basename = os.path.basename(filepath)
    ext = os.path.splitext(basename)[1].lower()
    # Programming language detection by extension
    if ext in LANGUAGE_EXTENSIONS:
        lang, emoji, color = LANGUAGE_EXTENSIONS[ext]
        return (basename, lang, f"{emoji} {lang}", color)
    # Magic number detection
    try:
        with open(filepath, 'rb') as f:
            header = f.read(16)
    except Exception as e:
        return (basename, 'Error', f"❌ {str(e)}", Fore.RED)
    for magic, fmt, emoji, color in MAGIC_NUMBERS:
        if header.startswith(magic):
            return (basename, fmt, f"{emoji} {fmt}", color)
    # Try to check if it's plain text
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            f.read(256)
        return (basename, 'TXT', '📄 TXT (plain)', Fore.WHITE)
    except Exception:
        pass
    return (basename, 'Unknown', '❓ Unknown', Fore.LIGHTBLACK_EX)

def get_files_in_directory(directory: str) -> List[str]:
    return [os.path.join(directory, f) for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

def main():
    print(BANNER)
    print(f"{Fore.LIGHTYELLOW_EX}Do you want to scan the current folder? (Y/n){Style.RESET_ALL}")
    choice = input().strip().lower()
    if choice in ('n', 'no'):
        print(f"{Fore.LIGHTYELLOW_EX}Enter the full path to the folder you want to scan:{Style.RESET_ALL}")
        directory = input().strip()
        if not os.path.isdir(directory):
            print(f"{Fore.RED}❌ The path '{directory}' is not a valid directory.{Style.RESET_ALL}")
            return
    else:
        directory = os.getcwd()
    files = get_files_in_directory(directory)
    if not files:
        print(f"{Fore.LIGHTRED_EX}No files found in the selected directory.{Style.RESET_ALL}")
        return
    print(f"\n{Fore.LIGHTGREEN_EX}Scanning directory: {directory}{Style.RESET_ALL}\n")
    print(HEADER)
    print(SEPARATOR)
    for file in files:
        fname, fmt, result, color = detect_format(file)
        print(f"| {fname:<20} | {fmt:<12} | {color}{result:<20}{Style.RESET_ALL} |")
    print(SEPARATOR)
    print(f"{Fore.LIGHTBLACK_EX}Detection complete. {len(files)} file(s) scanned.{Style.RESET_ALL}\n")

if __name__ == "__main__":
    main()