import os
import shutil
import time
from datetime import datetime
from pathlib import Path
import json
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class FileOrganizer:
    def __init__(self):
        self.history = []
        self.HISTORY_FILE = "organize_history.json"
        self.load_history()
        
        # File categories and their extensions
        self.categories = {
            'Images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.ico'],
            'Documents': ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt', '.xlsx', '.csv'],
            'Audio': ['.mp3', '.wav', '.flac', '.m4a', '.aac', '.wma'],
            'Video': ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv'],
            'Archives': ['.zip', '.rar', '.7z', '.tar', '.gz'],
            'Code': ['.py', '.java', '.cpp', '.html', '.css', '.js', '.php'],
            'Executables': ['.exe', '.msi', '.app'],
            'Others': []  # For files that don't match any category
        }

    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║          File Organizer               ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def load_history(self):
        """Load organization history from file"""
        try:
            if os.path.exists(self.HISTORY_FILE):
                with open(self.HISTORY_FILE, 'r') as f:
                    self.history = json.load(f)
        except Exception as e:
            slow_print(f"{Fore.RED}Error loading history: {str(e)}{Style.RESET_ALL}")
            self.history = []

    def save_history(self):
        """Save organization history to file"""
        try:
            with open(self.HISTORY_FILE, 'w') as f:
                json.dump(self.history, f, indent=4)
        except Exception as e:
            slow_print(f"{Fore.RED}Error saving history: {str(e)}{Style.RESET_ALL}")

    def get_category(self, file_path):
        """Determine the category of a file based on its extension"""
        ext = Path(file_path).suffix.lower()
        for category, extensions in self.categories.items():
            if ext in extensions:
                return category
        return 'Others'

    def create_category_folders(self, base_path):
        """Create folders for each category if they don't exist"""
        created_folders = []
        for category in self.categories.keys():
            folder_path = os.path.join(base_path, category)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
                created_folders.append(category)
        return created_folders

    def organize_files(self, directory):
        """Organize files in the specified directory"""
        try:
            # Convert to absolute path
            directory = os.path.abspath(directory)
            if not os.path.exists(directory):
                raise ValueError(f"Directory not found: {directory}")

            # Create category folders
            created_folders = self.create_category_folders(directory)
            if created_folders:
                slow_print(f"\n{Fore.GREEN}Created folders: {', '.join(created_folders)}{Style.RESET_ALL}")

            # Track statistics
            stats = {category: 0 for category in self.categories}
            moved_files = []
            skipped_files = []
            errors = []

            # Process each file
            for item in os.listdir(directory):
                item_path = os.path.join(directory, item)
                
                # Skip if it's a directory or category folder
                if os.path.isdir(item_path) or item in self.categories:
                    continue

                try:
                    # Get category and destination
                    category = self.get_category(item)
                    dest_folder = os.path.join(directory, category)
                    dest_path = os.path.join(dest_folder, item)

                    # Handle file name conflicts
                    if os.path.exists(dest_path):
                        base, ext = os.path.splitext(item)
                        counter = 1
                        while os.path.exists(dest_path):
                            new_name = f"{base}_{counter}{ext}"
                            dest_path = os.path.join(dest_folder, new_name)
                            counter += 1

                    # Move the file
                    shutil.move(item_path, dest_path)
                    stats[category] += 1
                    moved_files.append((item, category))

                except Exception as e:
                    errors.append((item, str(e)))
                    skipped_files.append(item)

            # Add to history
            self.history.append({
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'directory': directory,
                'stats': stats,
                'moved_files': moved_files,
                'skipped_files': skipped_files,
                'errors': errors
            })
            self.save_history()

            # Display results
            self.display_organization_results(stats, moved_files, skipped_files, errors)

        except Exception as e:
            slow_print(f"\n{Fore.RED}Error organizing files: {str(e)}{Style.RESET_ALL}")

    def display_organization_results(self, stats, moved_files, skipped_files, errors):
        """Display the results of file organization"""
        print("\n" + "═" * 50)
        slow_print(f"{Fore.CYAN}Organization Results:{Style.RESET_ALL}")
        print("═" * 50)

        # Display statistics
        print(f"\n{Fore.YELLOW}Files Organized by Category:{Style.RESET_ALL}")
        for category, count in stats.items():
            if count > 0:
                print(f"{category}: {count} files")

        # Display moved files
        if moved_files:
            print(f"\n{Fore.GREEN}Successfully Moved Files:{Style.RESET_ALL}")
            for file, category in moved_files:
                print(f"→ {file} → {category}")

        # Display skipped files
        if skipped_files:
            print(f"\n{Fore.YELLOW}Skipped Files:{Style.RESET_ALL}")
            for file in skipped_files:
                print(f"• {file}")

        # Display errors
        if errors:
            print(f"\n{Fore.RED}Errors:{Style.RESET_ALL}")
            for file, error in errors:
                print(f"• {file}: {error}")

        print("\n" + "═" * 50)

    def view_history(self):
        """View organization history"""
        if not self.history:
            slow_print(f"\n{Fore.YELLOW}No organization history!{Style.RESET_ALL}")
            return

        print(f"\n{Fore.CYAN}Organization History:{Style.RESET_ALL}")
        print("═" * 50)

        for entry in reversed(self.history[-5:]):  # Show last 5 entries
            print(f"\n{Fore.GREEN}Time: {entry['timestamp']}{Style.RESET_ALL}")
            print(f"Directory: {entry['directory']}")
            
            # Show statistics
            print("\nFiles organized:")
            for category, count in entry['stats'].items():
                if count > 0:
                    print(f"  {category}: {count} files")
            
            # Show errors if any
            if entry['errors']:
                print(f"\n{Fore.RED}Errors occurred:{Style.RESET_ALL}")
                for file, error in entry['errors']:
                    print(f"  • {file}: {error}")
            
            print("─" * 50)

    def clear_history(self):
        """Clear organization history"""
        confirm = input(f"\n{Fore.RED}Are you sure you want to clear history? (y/n): {Style.RESET_ALL}")
        if confirm.lower() == 'y':
            self.history = []
            self.save_history()
            slow_print(f"{Fore.GREEN}History cleared successfully!{Style.RESET_ALL}")

    def customize_categories(self):
        """Customize file categories and extensions"""
        while True:
            print(f"\n{Fore.YELLOW}Current Categories:{Style.RESET_ALL}")
            for category, extensions in self.categories.items():
                print(f"\n{category}:")
                print(f"Extensions: {', '.join(extensions) if extensions else 'All other files'}")

            print(f"\n{Fore.CYAN}Options:{Style.RESET_ALL}")
            print("1. Add new category")
            print("2. Add extension to category")
            print("3. Remove extension from category")
            print("4. Back to main menu")

            choice = input(f"\n{Fore.GREEN}Enter your choice (1-4): {Style.RESET_ALL}")

            if choice == '1':
                category = input(f"\n{Fore.CYAN}Enter new category name: {Style.RESET_ALL}")
                if category not in self.categories:
                    self.categories[category] = []
                    slow_print(f"{Fore.GREEN}Category added successfully!{Style.RESET_ALL}")
                else:
                    slow_print(f"{Fore.RED}Category already exists!{Style.RESET_ALL}")

            elif choice == '2':
                category = input(f"\n{Fore.CYAN}Enter category name: {Style.RESET_ALL}")
                if category in self.categories:
                    ext = input(f"Enter extension (with dot, e.g., .pdf): {Style.RESET_ALL}").lower()
                    if ext not in self.categories[category]:
                        self.categories[category].append(ext)
                        slow_print(f"{Fore.GREEN}Extension added successfully!{Style.RESET_ALL}")
                    else:
                        slow_print(f"{Fore.RED}Extension already exists in category!{Style.RESET_ALL}")
                else:
                    slow_print(f"{Fore.RED}Category not found!{Style.RESET_ALL}")

            elif choice == '3':
                category = input(f"\n{Fore.CYAN}Enter category name: {Style.RESET_ALL}")
                if category in self.categories:
                    ext = input(f"Enter extension to remove: {Style.RESET_ALL}").lower()
                    if ext in self.categories[category]:
                        self.categories[category].remove(ext)
                        slow_print(f"{Fore.GREEN}Extension removed successfully!{Style.RESET_ALL}")
                    else:
                        slow_print(f"{Fore.RED}Extension not found in category!{Style.RESET_ALL}")
                else:
                    slow_print(f"{Fore.RED}Category not found!{Style.RESET_ALL}")

            elif choice == '4':
                break

            else:
                slow_print(f"{Fore.RED}Invalid choice!{Style.RESET_ALL}")

    def main_menu(self):
        """Main program loop"""
        while True:
            clear_screen()
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Options:{Style.RESET_ALL}")
            slow_print("1. Organize Files")
            slow_print("2. View History")
            slow_print("3. Clear History")
            slow_print("4. Customize Categories")
            slow_print("5. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-5): {Style.RESET_ALL}")
            
            if choice == '1':
                directory = input(f"\n{Fore.CYAN}Enter directory path to organize: {Style.RESET_ALL}")
                self.organize_files(directory)
            elif choice == '2':
                self.view_history()
            elif choice == '3':
                self.clear_history()
            elif choice == '4':
                self.customize_categories()
            elif choice == '5':
                slow_print(f"\n{Fore.YELLOW}Thank you for using File Organizer!{Style.RESET_ALL}")
                break
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
            
            if choice != '4':  # Don't prompt if we're going to customize categories
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")

if __name__ == "__main__":
    try:
        organizer = FileOrganizer()
        organizer.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Program terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}")