import random
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

# Emojis
TUNNEL_EMOJI = "🕳️"
PUPPY_EMOJI = "🐶"
CHECK_EMOJI = "✅"
CROSS_EMOJI = "❌"
STAR_EMOJI = "⭐"
HEART_EMOJI = "❤️"

# Game settings
TOTAL_CHANCES = 5
PUPPIES_TO_FIND = 3
TUNNELS = 3

def print_tunnels(puppy_pos=None, reveal=False):
    print("\nChoose a tunnel:")
    for i in range(1, TUNNELS + 1):
        if reveal and i == puppy_pos:
            print(Fore.YELLOW + f"[{i}] {TUNNEL_EMOJI} {PUPPY_EMOJI}", end="  ")
        else:
            print(Fore.CYAN + f"[{i}] {TUNNEL_EMOJI}", end="  ")
    print("\n")

def main():
    print(Fore.MAGENTA + Style.BRIGHT + "\n🐾 Welcome to 'Find The Puppy'! 🐾\n")
    print(f"There are {TUNNELS} tunnels. A {PUPPY_EMOJI} is hiding in one of them each round.")
    print(f"You have {HEART_EMOJI} {TOTAL_CHANCES} chances to find {STAR_EMOJI} {PUPPIES_TO_FIND} puppies!\n")

    chances = TOTAL_CHANCES
    puppies_found = 0

    while chances > 0 and puppies_found < PUPPIES_TO_FIND:
        puppy_pos = random.randint(1, TUNNELS)
        print_tunnels()
        try:
            guess = int(input(Fore.GREEN + "Enter the tunnel number (1-3): "))
        except ValueError:
            print(Fore.RED + "Invalid input! Please enter a number between 1 and 3.\n")
            continue
        if guess < 1 or guess > TUNNELS:
            print(Fore.RED + "Please choose a valid tunnel number!\n")
            continue
        if guess == puppy_pos:
            puppies_found += 1
            print(Fore.YELLOW + f"{CHECK_EMOJI} You found the {PUPPY_EMOJI}! Great job!\n")
        else:
            print(Fore.RED + f"{CROSS_EMOJI} No puppy in this tunnel.\n")
            print_tunnels(puppy_pos, reveal=True)
        chances -= 1
        print(Fore.BLUE + f"Puppies found: {puppies_found}/{PUPPIES_TO_FIND} | Chances left: {chances}\n")
        print("-" * 40)

    if puppies_found >= PUPPIES_TO_FIND:
        print(Fore.GREEN + Style.BRIGHT + f"\n🎉 Congratulations! You found all the puppies! {PUPPY_EMOJI * puppies_found}")
    else:
        print(Fore.RED + Style.BRIGHT + f"\nGame Over! You found {puppies_found} out of {PUPPIES_TO_FIND} puppies. Better luck next time! {PUPPY_EMOJI * puppies_found}")

if __name__ == "__main__":
    main() 