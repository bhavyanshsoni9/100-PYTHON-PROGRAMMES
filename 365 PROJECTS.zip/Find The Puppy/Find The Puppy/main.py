from find_the_puppy import main

if __name__ == "__main__":
    main() 