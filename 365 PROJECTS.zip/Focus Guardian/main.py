import time
import os

blocked_websites = ["www.youtube.com", "www.instagram.com", "www.facebook.com"]
hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
redirect = "127.0.0.1"

def block_websites(duration_minutes):
    end_time = time.time() + duration_minutes * 60
    print(f"Blocking {blocked_websites} for {duration_minutes} minutes...")

    while time.time() < end_time:
        with open(hosts_path, "r+") as file:
            content = file.read()
            for site in blocked_websites:
                if site not in content:
                    file.write(f"{redirect} {site}\n")
        print("Websites are blocked. Stay Focused!")
        time.sleep(5)

    with open(hosts_path, "r+") as file:
        content = file.readlines()
        file.seek(0)
        for line in content:
            if not any(site in line for site in blocked_websites):
                file.write(line)
        file.truncate()

    print("Websites are unblocked now!")

if __name__ == "__main__":
    mins = int(input("Enter focus time in minutes: "))
    block_websites(mins)
