import os
import sys
from colorama import init, Fore, Style

init(autoreset=True)

FOLDER_EMOJI = "📁"  # Top-level folder
SUBFOLDER_EMOJI = "📂"  # Subfolder
FILE_EMOJI = "📄"
SUMMARY_EMOJI = "🧮"
BRANCH = "├── "
LAST_BRANCH = "└── "
VERTICAL = "│   "
EMPTY = "    "

def get_directory():
    path = input(f"{Fore.CYAN}📁 Enter directory path (leave blank for current directory): {Style.RESET_ALL}").strip()
    if not path:
        path = os.getcwd()
    if not os.path.isdir(path):
        print(f"{Fore.RED}❌ The path '{path}' is not a valid directory.{Style.RESET_ALL}")
        sys.exit(1)
    return path

def count_immediate_contents(path):
    try:
        with os.scandir(path) as it:
            files = sum(1 for entry in it if entry.is_file())
        with os.scandir(path) as it:
            folders = sum(1 for entry in it if entry.is_dir())
        return files, folders
    except Exception:
        return 0, 0

def print_tree(path, prefix="", is_last=True, stats=None, level=0, show_self=True):
    if stats is None:
        stats = {"folders": 0, "subfolders": 0, "files": 0}
    try:
        entries = sorted(os.listdir(path))
    except Exception:
        print(f"{prefix}{Fore.RED}❌ [Access Denied]{Style.RESET_ALL}")
        return
    folders = [e for e in entries if os.path.isdir(os.path.join(path, e))]
    files = [e for e in entries if os.path.isfile(os.path.join(path, e))]
    if show_self:
        # Only print the folder if not the root (so root's children are top-level)
        if level == 0:
            # Don't print the root itself, just its children
            pass
        elif level == 1:
            stats["folders"] += 1
            emoji = FOLDER_EMOJI
            color = Fore.YELLOW
        else:
            stats["subfolders"] += 1
            emoji = SUBFOLDER_EMOJI
            color = Fore.LIGHTYELLOW_EX
        if level > 0:
            file_count, folder_count = count_immediate_contents(path)
            print(f"{prefix}{color}{emoji} {os.path.basename(path) or path}{Style.RESET_ALL} {Fore.BLUE}[{folder_count} subfolders, {file_count} files]{Style.RESET_ALL}")
    new_prefix = prefix + (EMPTY if is_last else VERTICAL)
    for idx, folder in enumerate(folders):
        is_last_folder = (idx == len(folders) - 1) and not files
        print_tree(os.path.join(path, folder), new_prefix, is_last_folder, stats, level + 1, show_self=True)
    for idx, file in enumerate(files):
        is_last_file = idx == len(files) - 1
        stats["files"] += 1
        file_branch = LAST_BRANCH if is_last_file else BRANCH
        if level > 0:
            print(f"{new_prefix}{Fore.GREEN}{file_branch}{FILE_EMOJI} {file}{Style.RESET_ALL}")

def main():
    print(f"{Fore.YELLOW}🗂️  Folder Tree Counter Script{Style.RESET_ALL}")
    directory = get_directory()
    print(f"{Fore.BLUE}🔍 Scanning: {directory}{Style.RESET_ALL}\n")
    stats = {"folders": 0, "subfolders": 0, "files": 0}
    print_tree(directory, "", True, stats, level=0, show_self=False)  # Don't print the root itself
    print(f"\n{Fore.YELLOW}{SUMMARY_EMOJI} Top-level folders: {Style.BRIGHT}{stats['folders']}{Style.RESET_ALL}")
    print(f"{Fore.LIGHTYELLOW_EX}{SUMMARY_EMOJI} Subfolders: {Style.BRIGHT}{stats['subfolders']}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{SUMMARY_EMOJI} Total files: {Style.BRIGHT}{stats['files']}{Style.RESET_ALL}")
    print(f"\n{Fore.YELLOW}✅ Done!{Style.RESET_ALL}")

if __name__ == "__main__":
    main() 