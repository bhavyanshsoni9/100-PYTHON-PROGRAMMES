"""
GOD Code Enhancer (Generate, Organize & Decorate)
Enhances Python scripts with emoji comments and colored print statements using Colorama.
Offline only — no external AI APIs used!
"""

import os
import sys
import ast
from colorama import Fore, Style, init

init(autoreset=True)

def friendly_message(msg, color=Fore.CYAN):
    print(color + msg + Style.RESET_ALL)

def get_input_file():
    path = input(Fore.YELLOW + "Enter the path of the Python file to enhance: " + Style.RESET_ALL).strip()
    if not os.path.isfile(path):
        friendly_message(f"❌ File not found: {path}", Fore.RED)
        sys.exit(1)
    if not path.endswith('.py'):
        friendly_message("❌ Please provide a Python (.py) file.", Fore.RED)
        sys.exit(1)
    return path

def colorize_print_args(args):
    new_args = []
    for arg in args:
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            s = arg.value
            new_args.append(f'f"{{Fore.GREEN}}{s}{{Style.RESET_ALL}}"')
        elif isinstance(arg, ast.JoinedStr):  # f-string
            fstr = ast.unparse(arg)
            # Find the opening and closing quote positions
            if fstr.startswith('f"') or fstr.startswith("f'"):
                quote = fstr[1]
                # Find the first and last quote positions
                first_quote = 2
                last_quote = len(fstr) - 1
                # Insert color codes after opening quote and before closing quote
                fstr = fstr[:first_quote+1] + '{Fore.GREEN}' + fstr[first_quote+1:last_quote] + '{Style.RESET_ALL}' + fstr[last_quote:]
            new_args.append(fstr)
        else:
            try:
                new_args.append(ast.unparse(arg))
            except Exception:
                new_args.append(repr(arg))
    return ', '.join(new_args)

def parse_and_enhance(lines):
    enhanced = []
    for line in lines:
        stripped = line.strip()
        indent = line[:len(line) - len(line.lstrip())]
        # Emoji comments only
        if stripped.startswith('def '):
            enhanced.append(f"{indent}# 🛠️ Function definition")
            enhanced.append(line.rstrip())
            continue
        elif stripped.startswith(('for ', 'while ')):
            enhanced.append(f"{indent}# 🔁 Loop starts here")
        elif stripped.startswith(('if ', 'elif ', 'else')):
            enhanced.append(f"{indent}# 🔍 Conditional branch")
        elif 'input(' in stripped:
            enhanced.append(f"{indent}# 📝 Taking user input")
        elif 'print(' in stripped:
            enhanced.append(f"{indent}# 📢 Displaying output")
        # Colorize print
        if 'print(' in stripped:
            try:
                node = ast.parse(stripped)
                if (
                    len(node.body) > 0 and
                    isinstance(node.body[0], ast.Expr) and
                    isinstance(node.body[0].value, ast.Call) and
                    isinstance(node.body[0].value.func, ast.Name) and
                    node.body[0].value.func.id == 'print'
                ):
                    call = node.body[0].value
                    new_args = colorize_print_args(call.args)
                    enhanced.append(f"{indent}print({new_args})")
                    continue
            except Exception:
                pass
            enhanced.append(line.rstrip())
        else:
            enhanced.append(line.rstrip())
    header = [
        "# Enhanced by GOD Code Enhancer",
        "from colorama import Fore, Style, init",
        "init(autoreset=True)",
        ""
    ]
    return header + enhanced

def main():
    friendly_message("\n===== 🚀 GOD Code Enhancer 🚀 =====\n", Fore.MAGENTA)
    path = get_input_file()
    try:
        with open(path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except Exception as e:
        friendly_message(f"❌ Failed to read file: {e}", Fore.RED)
        sys.exit(1)
    friendly_message("✨ Enhancing your code...\n", Fore.GREEN)
    enhanced_lines = parse_and_enhance(lines)
    out_path = f"enhanced_{os.path.basename(path)}"
    try:
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(enhanced_lines))
        friendly_message(f"\n✅ Enhanced code saved as: {out_path}\n", Fore.CYAN)
    except Exception as e:
        friendly_message(f"❌ Failed to write enhanced file: {e}", Fore.RED)
        sys.exit(1)
    friendly_message("🎉 Done! Enjoy your enhanced Python script! 🎉", Fore.MAGENTA)

if __name__ == "__main__":
    main()
