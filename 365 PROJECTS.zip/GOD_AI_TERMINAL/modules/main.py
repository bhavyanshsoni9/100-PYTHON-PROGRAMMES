def handle_command(cmd):
    print(f"Command '{cmd}' not recognized. Type 'help' for commands.")