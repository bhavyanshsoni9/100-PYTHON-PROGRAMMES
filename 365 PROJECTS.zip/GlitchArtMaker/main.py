import random
import time
from rich.console import Console
from rich.panel import Panel
from rich.live import Live
from rich.text import Text
import os
import math

# Initialize Rich console
console = Console()

# Glitch characters and effects
GLITCH_CHARS = '░▒▓█▀▄▌▐│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌'
COLORS = ['red', 'green', 'blue', 'magenta', 'cyan', 'yellow']
EFFECTS = ['bold', 'dim', 'italic', 'reverse']

def type_print(text, delay=0.03):
    """Print text with glitch effect"""
    for char in text:
        if random.random() < 0.1:  # 10% chance of glitch
            char = random.choice(GLITCH_CHARS)
        style = f"{random.choice(COLORS)} {random.choice(EFFECTS)}"
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def create_glitch_frame(width, height):
    """Create a single frame of glitch art"""
    frame = []
    for y in range(height):
        line = []
        glitch_line = random.random() < 0.2  # 20% chance of glitched line
        
        for x in range(width):
            if glitch_line:
                # Create wave pattern with glitch
                wave = math.sin(x/5 + time.time() * 2) * 3
                if abs(y - height/2 - wave) < 2:
                    char = random.choice(GLITCH_CHARS)
                else:
                    char = ' '
            else:
                # Normal pattern
                if random.random() < 0.1:
                    char = random.choice(GLITCH_CHARS)
                else:
                    char = '░' if (x + y) % 2 == 0 else '▒'
            line.append(char)
        frame.append(''.join(line))
    return frame

def apply_color_glitch(text):
    """Apply color glitch effects to text"""
    styled_text = Text()
    for char in text:
        if random.random() < 0.3:  # 30% chance of color glitch
            style = f"{random.choice(COLORS)} {random.choice(EFFECTS)}"
        else:
            style = "white"
        styled_text.append(char, style=style)
    return styled_text

def create_glitch_art(text="GLITCH"):
    """Create animated glitch art with text"""
    width = 60
    height = 20
    text_pos = height // 2
    
    with Live(refresh_per_second=10) as live:
        while True:
            try:
                # Create base frame
                frame = create_glitch_frame(width, height)
                
                # Insert text with glitch effect
                if text:
                    text_line = text.center(width)
                    if random.random() < 0.1:  # 10% chance of text glitch
                        text_line = ''.join(random.choice(GLITCH_CHARS) if random.random() < 0.3 else c 
                                          for c in text_line)
                    frame[text_pos] = text_line
                
                # Convert frame to styled text
                styled_frame = '\n'.join(frame)
                glitched_text = apply_color_glitch(styled_frame)
                
                # Create panel with glitch effects
                panel = Panel(
                    glitched_text,
                    title="[bold red]GLITCH[/] [bold blue]ART[/] [bold green]MAKER[/]",
                    border_style=random.choice(COLORS),
                    subtitle="[bold white]< Press Ctrl+C to stop >[/]"
                )
                
                live.update(panel)
                time.sleep(0.1)
                
            except KeyboardInterrupt:
                break

def main():
    """Main program with cyberpunk interface"""
    console.clear()
    type_print("⚡ Welcome to GlitchArtMaker", delay=0.05)
    type_print("   Digital Reality Distorter", delay=0.03)
    print()
    
    while True:
        try:
            type_print("Enter text to glitch (or press Enter for default):", delay=0.02)
            text = input("> ").strip()
            print("\nInitiating reality distortion...\n")
            create_glitch_art(text if text else "GLITCH")
            
            type_print("\nCreate another glitch? (y/n):", delay=0.02)
            if input().lower() != 'y':
                type_print("\n💀 System decompiling...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("💀 Emergency shutdown initiated...", delay=0.05)
            break

if __name__ == "__main__":
    main() 