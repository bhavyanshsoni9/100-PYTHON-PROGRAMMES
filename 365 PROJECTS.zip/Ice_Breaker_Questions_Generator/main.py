import random
import time
import os
import json
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class IceBreakerGenerator:
    def __init__(self):
        self.questions = {
            'Fun': [
                "If you could have any superpower, what would it be and why?",
                "What's the most interesting place you've ever visited?",
                "If you could have dinner with any historical figure, who would it be?",
                "What's your favorite childhood memory?",
                "If you could instantly become an expert in something, what would it be?"
            ],
            'Professional': [
                "What inspired you to choose your current career path?",
                "What's the best piece of professional advice you've ever received?",
                "What's one skill you'd like to develop this year?",
                "What's your ideal work environment like?",
                "What's the most challenging project you've worked on?"
            ],
            'Creative': [
                "If you could create anything without limitations, what would you make?",
                "What's your favorite way to express yourself creatively?",
                "If your life was a movie, what genre would it be?",
                "What's the most creative solution you've found to a problem?",
                "If you could master any art form instantly, what would you choose?"
            ],
            'Personal Growth': [
                "What's one thing you want to achieve in the next year?",
                "What's a valuable life lesson you've learned recently?",
                "What motivates you to keep growing and learning?",
                "What's one habit you're trying to build or break?",
                "What's the best advice you've ever received?"
            ]
        }
        self.custom_questions = []
        self.used_questions = set()
        self.CUSTOM_QUESTIONS_FILE = "custom_questions.json"
        self.load_custom_questions()

    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║    Ice Breaker Questions Generator    ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def load_custom_questions(self):
        """Load custom questions from file"""
        try:
            if os.path.exists(self.CUSTOM_QUESTIONS_FILE):
                with open(self.CUSTOM_QUESTIONS_FILE, 'r') as f:
                    self.custom_questions = json.load(f)
        except Exception as e:
            slow_print(f"{Fore.RED}Error loading custom questions: {str(e)}{Style.RESET_ALL}")
            self.custom_questions = []

    def save_custom_questions(self):
        """Save custom questions to file"""
        try:
            with open(self.CUSTOM_QUESTIONS_FILE, 'w') as f:
                json.dump(self.custom_questions, f, indent=4)
        except Exception as e:
            slow_print(f"{Fore.RED}Error saving custom questions: {str(e)}{Style.RESET_ALL}")

    def add_custom_question(self):
        """Add a custom question"""
        question = input(f"\n{Fore.CYAN}Enter your custom question: {Style.RESET_ALL}")
        if question and question not in self.custom_questions:
            self.custom_questions.append(question)
            self.save_custom_questions()
            slow_print(f"{Fore.GREEN}Question added successfully!{Style.RESET_ALL}")
        else:
            slow_print(f"{Fore.RED}Question already exists or is empty!{Style.RESET_ALL}")

    def view_custom_questions(self):
        """View all custom questions"""
        if not self.custom_questions:
            slow_print(f"\n{Fore.YELLOW}No custom questions added yet!{Style.RESET_ALL}")
            return

        print(f"\n{Fore.CYAN}Custom Questions:{Style.RESET_ALL}")
        for i, question in enumerate(self.custom_questions, 1):
            print(f"{i}. {question}")

    def remove_custom_question(self):
        """Remove a custom question"""
        if not self.custom_questions:
            slow_print(f"\n{Fore.YELLOW}No custom questions to remove!{Style.RESET_ALL}")
            return

        self.view_custom_questions()
        try:
            index = int(input(f"\n{Fore.CYAN}Enter the number of the question to remove: {Style.RESET_ALL}")) - 1
            if 0 <= index < len(self.custom_questions):
                removed = self.custom_questions.pop(index)
                self.save_custom_questions()
                slow_print(f"{Fore.GREEN}Removed: {removed}{Style.RESET_ALL}")
            else:
                slow_print(f"{Fore.RED}Invalid question number!{Style.RESET_ALL}")
        except ValueError:
            slow_print(f"{Fore.RED}Please enter a valid number!{Style.RESET_ALL}")

    def get_random_question(self, category=None):
        """Get a random question that hasn't been used recently"""
        if category == 'Custom':
            available = [q for q in self.custom_questions if q not in self.used_questions]
            if not available:
                self.used_questions.clear()
                available = self.custom_questions
        else:
            if category:
                pool = self.questions[category]
            else:
                pool = [q for questions in self.questions.values() for q in questions]
            
            available = [q for q in pool if q not in self.used_questions]
            if not available:
                self.used_questions.clear()
                available = pool

        if available:
            question = random.choice(available)
            self.used_questions.add(question)
            return question
        return None

    def generate_questions(self):
        """Generate ice breaker questions"""
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Choose a category:{Style.RESET_ALL}")
        categories = list(self.questions.keys()) + ['Custom', 'Random']
        
        for i, category in enumerate(categories, 1):
            slow_print(f"{i}. {category}")
        
        try:
            choice = int(input(f"\n{Fore.GREEN}Enter category number (1-{len(categories)}): {Style.RESET_ALL}"))
            if 1 <= choice <= len(categories):
                category = categories[choice - 1]
                category = None if category == 'Random' else category
                
                if category == 'Custom' and not self.custom_questions:
                    slow_print(f"\n{Fore.YELLOW}No custom questions available! Add some first.{Style.RESET_ALL}")
                    return
                
                question = self.get_random_question(category)
                if question:
                    print("\n" + "═" * 50)
                    slow_print(f"{Fore.CYAN}Q: {question}{Style.RESET_ALL}")
                    print("═" * 50)
                else:
                    slow_print(f"\n{Fore.RED}No questions available in this category!{Style.RESET_ALL}")
            else:
                slow_print(f"\n{Fore.RED}Invalid category number!{Style.RESET_ALL}")
        except ValueError:
            slow_print(f"\n{Fore.RED}Please enter a valid number!{Style.RESET_ALL}")

    def manage_custom_questions(self):
        """Manage custom questions menu"""
        while True:
            clear_screen()
            slow_print(f"\n{Fore.YELLOW}Custom Questions Management:{Style.RESET_ALL}")
            slow_print("1. Add Custom Question")
            slow_print("2. View Custom Questions")
            slow_print("3. Remove Custom Question")
            slow_print("4. Back to Main Menu")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-4): {Style.RESET_ALL}")
            
            if choice == '1':
                self.add_custom_question()
            elif choice == '2':
                self.view_custom_questions()
            elif choice == '3':
                self.remove_custom_question()
            elif choice == '4':
                break
            else:
                slow_print(f"{Fore.RED}Invalid choice!{Style.RESET_ALL}")
            
            input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")

    def main_menu(self):
        """Main program loop"""
        while True:
            clear_screen()
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Options:{Style.RESET_ALL}")
            slow_print("1. Generate Ice Breaker Question")
            slow_print("2. Manage Custom Questions")
            slow_print("3. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-3): {Style.RESET_ALL}")
            
            if choice == '1':
                self.generate_questions()
            elif choice == '2':
                self.manage_custom_questions()
            elif choice == '3':
                slow_print(f"\n{Fore.YELLOW}Thank you for using Ice Breaker Questions Generator!{Style.RESET_ALL}")
                break
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
            
            if choice != '2':  # Don't prompt if we're going to custom questions menu
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")

if __name__ == "__main__":
    try:
        generator = IceBreakerGenerator()
        generator.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Program terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}")