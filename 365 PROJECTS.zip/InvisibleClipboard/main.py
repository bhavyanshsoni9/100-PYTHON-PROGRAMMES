from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table
import pyperclip
from cryptography.fernet import Fernet
from datetime import datetime
import json
import os
import time
import threading

class InvisibleClipboard:
    def __init__(self):
        self.console = Console()
        self.key_file = "clipboard.key"
        self.history_file = "clipboard_history.enc"
        self.max_history = 50
        self.fernet = self._setup_encryption()
        self.history = []
        self.load_history()
        self.monitoring = False
        self.last_copied = ""
        
    def _setup_encryption(self):
        """Setup encryption key"""
        if not os.path.exists(self.key_file):
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
        else:
            with open(self.key_file, "rb") as f:
                key = f.read()
        return Fernet(key)
        
    def load_history(self):
        """Load clipboard history"""
        if os.path.exists(self.history_file):
            with open(self.history_file, "rb") as f:
                encrypted_data = f.read()
                try:
                    decrypted_data = self.fernet.decrypt(encrypted_data)
                    self.history = json.loads(decrypted_data)
                except:
                    self.history = []
                    
    def save_history(self):
        """Save clipboard history"""
        encrypted_data = self.fernet.encrypt(json.dumps(self.history).encode())
        with open(self.history_file, "wb") as f:
            f.write(encrypted_data)
            
    def add_to_history(self, content):
        """Add new item to clipboard history"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Add to front of list
        self.history.insert(0, {
            "timestamp": timestamp,
            "content": content,
            "preview": content[:50] + "..." if len(content) > 50 else content
        })
        
        # Maintain max size
        if len(self.history) > self.max_history:
            self.history.pop()
            
        self.save_history()
        
    def monitor_clipboard(self):
        """Monitor clipboard for changes"""
        self.monitoring = True
        self.last_copied = pyperclip.paste()
        
        while self.monitoring:
            try:
                current = pyperclip.paste()
                if current != self.last_copied:
                    self.last_copied = current
                    self.add_to_history(current)
                time.sleep(0.5)
            except:
                continue
                
    def display_history(self):
        """Display clipboard history"""
        if not self.history:
            self.console.print("No clipboard history.", style="bold yellow")
            return
            
        table = Table(title="📋 Clipboard History")
        table.add_column("Time", style="cyan")
        table.add_column("Content Preview", style="green")
        table.add_column("#", style="magenta")
        
        for i, item in enumerate(self.history):
            table.add_row(
                item["timestamp"],
                item["preview"],
                str(i + 1)
            )
            
        self.console.print(table)
        
    def copy_from_history(self, index):
        """Copy item from history to clipboard"""
        if 0 <= index < len(self.history):
            content = self.history[index]["content"]
            pyperclip.copy(content)
            self.console.print("✨ Copied to clipboard!", style="bold green")
        else:
            self.console.print("Invalid index!", style="bold red")
            
    def run(self):
        # Start monitoring thread
        monitor_thread = threading.Thread(target=self.monitor_clipboard)
        monitor_thread.daemon = True
        monitor_thread.start()
        
        while True:
            self.console.print("\n🔍 InvisibleClipboard - Hidden Clipboard Manager", style="bold blue")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4"],
                default="1"
            )
            
            if choice == "1":
                self.display_history()
                
            elif choice == "2":
                self.display_history()
                try:
                    index = int(Prompt.ask("\nEnter number of item to copy")) - 1
                    self.copy_from_history(index)
                except ValueError:
                    self.console.print("Invalid input!", style="bold red")
                    
            elif choice == "3":
                if self.history:
                    self.history.pop(0)  # Remove most recent
                    self.save_history()
                    self.console.print("Last clipboard item removed.", style="bold yellow")
                else:
                    self.console.print("No history to remove.", style="bold red")
                    
            elif choice == "4":
                self.monitoring = False
                self.console.print("Goodbye! 👋", style="bold blue")
                break
                
if __name__ == "__main__":
    clipboard = InvisibleClipboard()
    clipboard.run() 