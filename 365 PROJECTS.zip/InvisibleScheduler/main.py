from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
import threading
import json
import os
import time
from plyer import notification

class InvisibleScheduler:
    def __init__(self):
        self.console = Console()
        self.key_file = "scheduler.key"
        self.tasks_file = "scheduled_tasks.enc"
        self.fernet = self._setup_encryption()
        self.tasks = []
        self.load_tasks()
        self.running = False
        
    def _setup_encryption(self):
        """Setup encryption key"""
        if not os.path.exists(self.key_file):
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
        else:
            with open(self.key_file, "rb") as f:
                key = f.read()
        return Fernet(key)
        
    def load_tasks(self):
        """Load scheduled tasks"""
        if os.path.exists(self.tasks_file):
            with open(self.tasks_file, "rb") as f:
                encrypted_data = f.read()
                try:
                    decrypted_data = self.fernet.decrypt(encrypted_data)
                    self.tasks = json.loads(decrypted_data)
                except:
                    self.tasks = []
                    
    def save_tasks(self):
        """Save scheduled tasks"""
        encrypted_data = self.fernet.encrypt(json.dumps(self.tasks).encode())
        with open(self.tasks_file, "wb") as f:
            f.write(encrypted_data)
            
    def add_task(self, title, description, schedule_time, repeat_interval=None):
        """Add new scheduled task"""
        task = {
            "id": str(int(time.time())),
            "title": title,
            "description": description,
            "schedule_time": schedule_time,
            "repeat_interval": repeat_interval,
            "last_run": None,
            "active": True
        }
        
        self.tasks.append(task)
        self.save_tasks()
        
    def check_tasks(self):
        """Check and execute scheduled tasks"""
        while self.running:
            current_time = datetime.now()
            
            for task in self.tasks:
                if not task["active"]:
                    continue
                    
                schedule_time = datetime.strptime(
                    task["schedule_time"],
                    "%Y-%m-%d %H:%M:%S"
                )
                
                if current_time >= schedule_time:
                    if not task["last_run"] or task["repeat_interval"]:
                        # Execute task (show notification)
                        self.execute_task(task)
                        
                        # Update last run time
                        task["last_run"] = current_time.strftime("%Y-%m-%d %H:%M:%S")
                        
                        # If task repeats, update next schedule time
                        if task["repeat_interval"]:
                            while schedule_time <= current_time:
                                schedule_time += timedelta(minutes=task["repeat_interval"])
                            task["schedule_time"] = schedule_time.strftime("%Y-%m-%d %H:%M:%S")
                        else:
                            task["active"] = False
                            
                        self.save_tasks()
                        
            time.sleep(30)  # Check every 30 seconds
            
    def execute_task(self, task):
        """Execute a scheduled task"""
        try:
            notification.notify(
                title=task["title"],
                message=task["description"],
                app_icon=None,
                timeout=10,
            )
        except Exception as e:
            self.console.print(f"Failed to show notification: {str(e)}", style="bold red")
            
    def display_tasks(self):
        """Display all scheduled tasks"""
        if not self.tasks:
            self.console.print("No scheduled tasks.", style="bold yellow")
            return
            
        table = Table(title="📅 Scheduled Tasks")
        table.add_column("ID", style="cyan")
        table.add_column("Title", style="green")
        table.add_column("Description", style="blue")
        table.add_column("Schedule", style="magenta")
        table.add_column("Repeat", style="yellow")
        table.add_column("Status", style="red")
        
        for task in self.tasks:
            table.add_row(
                task["id"],
                task["title"],
                task["description"][:30] + "..." if len(task["description"]) > 30 else task["description"],
                task["schedule_time"],
                f"Every {task['repeat_interval']} min" if task["repeat_interval"] else "No",
                "Active" if task["active"] else "Inactive"
            )
            
        self.console.print(table)
        
    def run(self):
        # Start task checker thread
        self.running = True
        checker_thread = threading.Thread(target=self.check_tasks)
        checker_thread.daemon = True
        checker_thread.start()
        
        while True:
            self.console.print("\n⏰ InvisibleScheduler - Hidden Task Scheduler", style="bold cyan")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4", "5"],
                default="1"
            )
            
            if choice == "1":
                # Add new task
                title = Prompt.ask("Task title")
                description = Prompt.ask("Task description")
                
                # Get schedule time
                while True:
                    try:
                        schedule_str = Prompt.ask(
                            "Schedule time (YYYY-MM-DD HH:MM:SS)",
                            default=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        )
                        schedule_time = datetime.strptime(schedule_str, "%Y-%m-%d %H:%M:%S")
                        break
                    except ValueError:
                        self.console.print("Invalid date format!", style="bold red")
                        
                # Check for repeat interval
                repeat = Prompt.ask("Repeat interval in minutes (0 for no repeat)", default="0")
                repeat_interval = int(repeat) if repeat != "0" else None
                
                self.add_task(title, description, schedule_str, repeat_interval)
                self.console.print("✨ Task scheduled successfully!", style="bold green")
                
            elif choice == "2":
                self.display_tasks()
                
            elif choice == "3":
                # Toggle task status
                self.display_tasks()
                task_id = Prompt.ask("\nEnter task ID to toggle")
                
                for task in self.tasks:
                    if task["id"] == task_id:
                        task["active"] = not task["active"]
                        self.save_tasks()
                        status = "activated" if task["active"] else "deactivated"
                        self.console.print(f"Task {status}!", style="bold green")
                        break
                else:
                    self.console.print("Task not found!", style="bold red")
                    
            elif choice == "4":
                # Delete task
                self.display_tasks()
                task_id = Prompt.ask("\nEnter task ID to delete")
                
                self.tasks = [task for task in self.tasks if task["id"] != task_id]
                self.save_tasks()
                self.console.print("Task deleted!", style="bold yellow")
                
            elif choice == "5":
                self.running = False
                self.console.print("Goodbye! 👋", style="bold cyan")
                break
                
if __name__ == "__main__":
    scheduler = InvisibleScheduler()
    scheduler.run() 