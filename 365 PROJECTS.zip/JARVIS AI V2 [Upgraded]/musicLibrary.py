music = {
    "skyfall": "https://www.youtube.com/watch?v=DeumyOzKqgI&pp=ygUHc2t5ZmFsbA%3D%3D",
    "blue eyes": "https://www.youtube.com/watch?v=NbyHNASFi6U&pp=ygULaG9uZXkgc2luZ2g%3D",
    "brown":"https://www.youtube.com/watch?v=PqFMFVcCZgI&pp=ygULaG9uZXkgc2luZ2g%3D",
    "blue":"https://www.youtube.com/watch?v=IpFX2vq8HKw"
}