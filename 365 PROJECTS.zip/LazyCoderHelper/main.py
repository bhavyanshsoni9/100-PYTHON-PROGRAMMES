from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.syntax import Syntax
import os
import re
import json

class LazyCoderHelper:
    def __init__(self):
        self.console = Console()
        self.snippets_file = "code_snippets.json"
        self.templates = {
            "python_class": """class {name}:
    def __init__(self):
        {attributes}
        
    def {method}(self):
        pass""",
            
            "python_function": """def {name}({params}):
    \"""
    {docstring}
    \"""
    {body}""",
            
            "html_component": """<div class="{class_name}">
    <h{level}>{title}</h{level}>
    {content}
</div>""",
            
            "react_component": """import React from 'react';

interface {name}Props {
    {props}
}

const {name}: React.FC<{name}Props> = ({{{params}}}) => {
    return (
        <div className="{class_name}">
            {content}
        </div>
    );
};

export default {name};""",
            
            "api_endpoint": """@app.{method}("/{endpoint}")
async def {name}({params}):
    try:
        {body}
    except Exception as e:
        return {"error": str(e)}"""
        }
        
        self.load_snippets()
        
    def load_snippets(self):
        """Load saved code snippets"""
        if os.path.exists(self.snippets_file):
            with open(self.snippets_file, 'r') as f:
                self.snippets = json.load(f)
        else:
            self.snippets = {}
            
    def save_snippets(self):
        """Save code snippets"""
        with open(self.snippets_file, 'w') as f:
            json.dump(self.snippets, f, indent=2)
            
    def generate_code(self, template_name, **kwargs):
        """Generate code from template"""
        if template_name not in self.templates:
            raise ValueError("Template not found")
            
        return self.templates[template_name].format(**kwargs)
        
    def format_code(self, code, language):
        """Format code with syntax highlighting"""
        return Syntax(code, language, theme="monokai")
        
    def save_snippet(self, name, code, language):
        """Save a code snippet"""
        self.snippets[name] = {
            "code": code,
            "language": language
        }
        self.save_snippets()
        
    def generate_class(self):
        """Generate a Python class"""
        name = Prompt.ask("Class name")
        attributes = Prompt.ask("Attributes (comma-separated)", default="pass")
        method = Prompt.ask("Initial method name", default="run")
        
        if attributes != "pass":
            attributes = "\n        ".join(
                f"self.{attr.strip()} = None"
                for attr in attributes.split(",")
            )
            
        code = self.generate_code(
            "python_class",
            name=name,
            attributes=attributes,
            method=method
        )
        
        self.console.print(self.format_code(code, "python"))
        return code
        
    def generate_function(self):
        """Generate a Python function"""
        name = Prompt.ask("Function name")
        params = Prompt.ask("Parameters (comma-separated)", default="")
        docstring = Prompt.ask("Docstring", default="Function description")
        body = Prompt.ask("Function body", default="pass")
        
        code = self.generate_code(
            "python_function",
            name=name,
            params=params,
            docstring=docstring,
            body=body
        )
        
        self.console.print(self.format_code(code, "python"))
        return code
        
    def generate_html(self):
        """Generate an HTML component"""
        class_name = Prompt.ask("CSS class name")
        level = Prompt.ask("Heading level (1-6)", default="2")
        title = Prompt.ask("Title")
        content = Prompt.ask("Content")
        
        code = self.generate_code(
            "html_component",
            class_name=class_name,
            level=level,
            title=title,
            content=content
        )
        
        self.console.print(self.format_code(code, "html"))
        return code
        
    def generate_react(self):
        """Generate a React component"""
        name = Prompt.ask("Component name")
        props = Prompt.ask("Props (TypeScript interface)", default="")
        params = Prompt.ask("Component parameters", default="")
        class_name = Prompt.ask("CSS class name")
        content = Prompt.ask("JSX content")
        
        code = self.generate_code(
            "react_component",
            name=name,
            props=props,
            params=params,
            class_name=class_name,
            content=content
        )
        
        self.console.print(self.format_code(code, "typescript"))
        return code
        
    def generate_api(self):
        """Generate an API endpoint"""
        method = Prompt.ask("HTTP method", choices=["get", "post", "put", "delete"])
        endpoint = Prompt.ask("Endpoint path")
        name = Prompt.ask("Function name")
        params = Prompt.ask("Parameters", default="")
        body = Prompt.ask("Function body", default="return {}")
        
        code = self.generate_code(
            "api_endpoint",
            method=method,
            endpoint=endpoint,
            name=name,
            params=params,
            body=body
        )
        
        self.console.print(self.format_code(code, "python"))
        return code
        
    def run(self):
        while True:
            self.console.print("\n🦥 LazyCoderHelper - Code Generation Tool", style="bold green")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4", "5", "6", "7", "8"],
                default="1"
            )
            
            try:
                if choice == "1":
                    # Generate Python class
                    code = self.generate_class()
                    if Prompt.ask("Save this snippet?", choices=["y", "n"]) == "y":
                        name = Prompt.ask("Snippet name")
                        self.save_snippet(name, code, "python")
                        
                elif choice == "2":
                    # Generate Python function
                    code = self.generate_function()
                    if Prompt.ask("Save this snippet?", choices=["y", "n"]) == "y":
                        name = Prompt.ask("Snippet name")
                        self.save_snippet(name, code, "python")
                        
                elif choice == "3":
                    # Generate HTML component
                    code = self.generate_html()
                    if Prompt.ask("Save this snippet?", choices=["y", "n"]) == "y":
                        name = Prompt.ask("Snippet name")
                        self.save_snippet(name, code, "html")
                        
                elif choice == "4":
                    # Generate React component
                    code = self.generate_react()
                    if Prompt.ask("Save this snippet?", choices=["y", "n"]) == "y":
                        name = Prompt.ask("Snippet name")
                        self.save_snippet(name, code, "typescript")
                        
                elif choice == "5":
                    # Generate API endpoint
                    code = self.generate_api()
                    if Prompt.ask("Save this snippet?", choices=["y", "n"]) == "y":
                        name = Prompt.ask("Snippet name")
                        self.save_snippet(name, code, "python")
                        
                elif choice == "6":
                    # View saved snippets
                    if not self.snippets:
                        self.console.print("No saved snippets.", style="bold yellow")
                        continue
                        
                    self.console.print("\nSaved Snippets:")
                    for name, data in self.snippets.items():
                        self.console.print(f"\n[bold blue]{name}[/] ({data['language']})")
                        self.console.print(self.format_code(data['code'], data['language']))
                        
                elif choice == "7":
                    # Delete snippet
                    if not self.snippets:
                        self.console.print("No snippets to delete.", style="bold yellow")
                        continue
                        
                    name = Prompt.ask("Enter snippet name to delete")
                    if name in self.snippets:
                        del self.snippets[name]
                        self.save_snippets()
                        self.console.print("Snippet deleted!", style="bold yellow")
                    else:
                        self.console.print("Snippet not found!", style="bold red")
                        
                elif choice == "8":
                    self.console.print("Goodbye! 👋", style="bold green")
                    break
                    
            except Exception as e:
                self.console.print(f"Error: {str(e)}", style="bold red")
                
if __name__ == "__main__":
    helper = LazyCoderHelper()
    helper.run() 