def greet():
    print("Hello! This is a sample code file.")

greet()
