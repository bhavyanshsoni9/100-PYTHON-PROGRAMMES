from langchain.vectorstores import Chroma
from langchain.embeddings import SentenceTransformerEmbeddings
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI

def chat_with_ai():
    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    vectordb = Chroma(persist_directory="vector_db", embedding_function=embeddings)

    retriever = vectordb.as_retriever()
    qa = RetrievalQA.from_chain_type(llm=OpenAI(temperature=0), retriever=retriever)

    print("\n🤖 AI: Hello! I am your ULTIMATE AI. Ask me anything 🚀")
    while True:
        query = input("You: ")
        if query.lower() in ['exit', 'quit']:
            print("🤖 AI: Goodbye!")
            break
        result = qa.run(query)
        print(f"🤖 AI: {result}\n")

if __name__ == "__main__":
    chat_with_ai()
