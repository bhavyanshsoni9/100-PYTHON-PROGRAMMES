from langchain.document_loaders import PyPDFLoader, TextLoader, UnstructuredWordDocumentLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.embeddings import SentenceTransformerEmbeddings
import os

def train_documents():
    docs = []
    print("[INFO] Loading Documents...")

    for file in os.listdir('docs'):
        path = os.path.join('docs', file)
        if file.endswith('.pdf'):
            loader = PyPDFLoader(path)
        elif file.endswith('.txt'):
            loader = TextLoader(path)
        elif file.endswith('.docx'):
            loader = UnstructuredWordDocumentLoader(path)
        else:
            print(f"[WARNING] Unsupported file {file}")
            continue
        docs.extend(loader.load())

    print(f"[INFO] ✅ Loaded {len(docs)} documents.")

    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    docs = splitter.split_documents(docs)

    print(f"[INFO] ✅ Split into {len(docs)} chunks.")

    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

    vectordb = Chroma.from_documents(docs, embeddings, persist_directory="vector_db")

    vectordb.persist()

    print("[INFO] ✅ Documents trained and stored in vector DB successfully!")

if __name__ == "__main__":
    train_documents()
