import argparse
import sys
import time
from pathlib import Path
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel
from markdown import markdown

console = Console()

EMOJIS = {
    'start': '⏳',
    'success': '✅',
    'error': '❌',
    'processing': '🔄',
}

def print_status(message, emoji_key, delay=0.7):
    console.print(f"[bold]{EMOJIS.get(emoji_key, '')} {message}")
    time.sleep(delay)

def highlight_markdown(md_text):
    syntax = Syntax(md_text, "markdown", theme="monokai", line_numbers=True)
    console.print(Panel(syntax, title="Markdown Preview", border_style="cyan"))
    time.sleep(1)

def convert_markdown_to_html(md_path, output_dir):
    try:
        print_status(f"Reading file: {md_path}", 'start')
        with open(md_path, 'r', encoding='utf-8') as f:
            md_text = f.read()
        highlight_markdown(md_text)
        print_status("Converting to HTML...", 'processing')
        html = markdown(md_text)
        html_filename = Path(md_path).with_suffix('.html').name
        if output_dir:
            output_path = Path(output_dir) / html_filename
        else:
            output_path = Path(html_filename)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print_status(f"Conversion complete! HTML saved to: {output_path}", 'success')
    except Exception as e:
        print_status(f"Error: {e}", 'error')

def main():
    parser = argparse.ArgumentParser(description="Convert Markdown to HTML with colorful terminal output.")
    parser.add_argument('markdown_file', nargs='?', help="Path to the Markdown file.")
    args = parser.parse_args()
    if not args.markdown_file:
        console.print("[bold red]Error:[/bold red] No markdown file provided.")
        console.print("[bold]Usage:[/bold] python main.py [markdown_file.md]")
        sys.exit(1)
    console.print(
        "[bold yellow]Please enter the output directory for the HTML file.[/bold yellow]\n"
        "Leave blank and press Enter to save in the current directory."
    )
    output_dir = input("Output directory: ").strip()
    if output_dir and not Path(output_dir).exists():
        console.print(f"[bold red]Error:[/bold red] The directory '{output_dir}' does not exist.")
        sys.exit(1)
    convert_markdown_to_html(args.markdown_file, output_dir)

if __name__ == "__main__":
    main() 