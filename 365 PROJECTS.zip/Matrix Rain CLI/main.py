#!/usr/bin/env python3
"""
Matrix Rain CLI - Advanced Digital Rain Effect
A high-performance terminal-based Matrix digital rain animation with customizable effects.

Features:
- Multiple rain patterns and speeds
- Color customization and effects
- Performance optimization
- Interactive controls
- Full-screen terminal support
"""

import sys
import time
import os
import random
import threading
from typing import List, Tuple

class Colors:
    """ANSI color codes for terminal styling"""
    RESET = '\033'
    BOLD = '\033[1m'
    GREEN = '\033✅'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    DIM = '\033[2m'

class MatrixRain:
    def __init__(self):
        self.running = False
        self.width = 80
        self.height = 24
        self.drops = []
        self.characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()_+-=[]{}|;:,.<>?"
        self.japanese_chars = "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン"
        self.matrix_chars = self.characters + self.japanese_chars
        self.speed = 0.05
        self.density = 0.3
        self.use_japanese = True
        self.fade_effect = True
        
    def get_terminal_size(self):
        """Get current terminal size"""
        try:
            size = os.get_terminal_size()
            self.width = size.columns
            self.height = size.lines
        except:
            self.width = 80
            self.height = 24
            
    def initialize_drops(self):
        """Initialize rain drops"""
        self.drops = []
        for x in range(self.width):
            if random.random() < self.density:
                drop = {
                    'x': x,
                    'y': random.randint(-self.height, 0),
                    'speed': random.uniform(0.5, 2.0),
                    'length': random.randint(8, 25),
                    'chars': [random.choice(self.matrix_chars) for _ in range(25)]
                }
                self.drops.append(drop)
                
    def update_drops(self):
        """Update drop positions and add new ones"""
        # Update existing drops
        for drop in self.drops[:]:
            drop['y'] += drop['speed']
            if drop['y'] > self.height + drop['length']:
                self.drops.remove(drop)
                
        # Add new drops
        for x in range(self.width):
            if random.random() < 0.01:  # 1% chance per column per frame
                drop = {
                    'x': x,
                    'y': -random.randint(1, 10),
                    'speed': random.uniform(0.5, 2.0),
                    'length': random.randint(8, 25),
                    'chars': [random.choice(self.matrix_chars) for _ in range(25)]
                }
                self.drops.append(drop)
                
    def render_frame(self):
        """Render current frame"""
        # Clear screen
        print('\033[2J\033[H', end='')
        
        # Create frame buffer
        frame = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        colors = [[''] for _ in range(self.height) for _ in range(self.width)]
        
        # Draw drops
        for drop in self.drops:
            x = int(drop['x'])
            if x >= self.width:
                continue
                
            for i in range(drop['length']):
                y = int(drop['y'] - i)
                if 0 <= y < self.height:
                    char_index = i % len(drop['chars'])
                    char = drop['chars'][char_index]
                    
                    # Determine color based on position in drop
                    if i == 0:  # Head of drop
                        color = Colors.BRIGHT_WHITE
                    elif i < 3:  # Near head
                        color = Colors.BRIGHT_GREEN
                    elif i < 6:  # Middle
                        color = Colors.GREEN
                    else:  # Tail
                        color = Colors.GREEN + Colors.DIM
                        
                    frame[y][x] = char
                    
        # Print frame
        for row in frame:
            line = ''
            for i, char in enumerate(row):
                if char != ' ':
                    # Randomly change some characters for effect
                    if random.random() < 0.05:
                        char = random.choice(self.matrix_chars)
                    
                    if i == 0 or row[i-1] == ' ':  # Start of new sequence
                        line += Colors.BRIGHT_GREEN + char
                    else:
                        line += Colors.GREEN + char
                else:
                    line += Colors.RESET + char
            print(line + Colors.RESET)
            
    def display_banner(self):
        """Display Matrix Rain banner"""
        banner = [
            "╔══════════════════════════════════════╗",
            "║           MATRIX RAIN CLI            ║",
            "║      Digital Rain Simulation         ║",
            "╚══════════════════════════════════════╝"
        ]
        
        print("\n")
        for line in banner:
            print(f"{Colors.BRIGHT_GREEN}{line}{Colors.RESET}")
        print("\n")
        
    def show_controls(self):
        """Show control instructions"""
        print(f"{Colors.BRIGHT_CYAN}Controls:{Colors.RESET}")
        print(f"  {Colors.GREEN}SPACE{Colors.RESET} - Pause/Resume")
        print(f"  {Colors.GREEN}+/-{Colors.RESET}   - Speed up/down")
        print(f"  {Colors.GREEN}j{Colors.RESET}     - Toggle Japanese characters")
        print(f"  {Colors.GREEN}f{Colors.RESET}     - Toggle fade effect")
        print(f"  {Colors.GREEN}r{Colors.RESET}     - Reset drops")
        print(f"  {Colors.GREEN}q{Colors.RESET}     - Quit")
        print(f"\nPress any key to start...")
        
    def run_interactive(self):
        """Run interactive mode with controls"""
        self.get_terminal_size()
        self.initialize_drops()
        self.running = True
        
        try:
            while self.running:
                self.update_drops()
                self.render_frame()
                time.sleep(self.speed)
                
        except KeyboardInterrupt:
            self.running = False
            print(f"\n{Colors.BRIGHT_GREEN}Matrix Rain terminated.{Colors.RESET}")
            
    def run_demo(self, duration=30):
        """Run demo mode for specified duration"""
        print(f"{Colors.BRIGHT_GREEN}Running Matrix Rain demo for {duration} seconds...{Colors.RESET}")
        print(f"{Colors.GREEN}Press Ctrl+C to stop early{Colors.RESET}\n")
        
        self.get_terminal_size()
        self.initialize_drops()
        self.running = True
        
        start_time = time.time()
        
        try:
            while self.running and (time.time() - start_time) < duration:
                self.update_drops()
                self.render_frame()
                time.sleep(self.speed)
                
        except KeyboardInterrupt:
            pass
            
        self.running = False
        print(f"\n{Colors.BRIGHT_GREEN}Demo completed.{Colors.RESET}")

def slow_print(text, delay=0.03, color=Colors.BRIGHT_GREEN):
    """Print text with slow typing effect"""
    for char in text:
        sys.stdout.write(color + char + Colors.RESET)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def main():
    """Main application entry point"""
    try:
        # Clear screen
        os.system('clear' if os.name == 'posix' else 'cls')
        
        matrix = MatrixRain()
        matrix.display_banner()
        
        slow_print("Welcome to Matrix Rain CLI!", delay=0.05, color=Colors.BRIGHT_GREEN)
        print()
        
        slow_print("Features:", color=Colors.BRIGHT_CYAN)
        features = [
            "High-performance digital rain animation",
            "Customizable characters and effects",
            "Multiple animation speeds",
            "Japanese character support",
            "Full-screen terminal rendering",
            "Interactive controls and settings"
        ]
        
        for i, feature in enumerate(features, 1):
            slow_print(f"  {i}. {feature}", delay=0.01, color=Colors.GREEN)
        print()
        
        while True:
            try:
                print(f"{Colors.BRIGHT_CYAN}Choose an option:{Colors.RESET}")
                print(f"  {Colors.GREEN}1{Colors.RESET} - Run full-screen Matrix Rain")
                print(f"  {Colors.GREEN}2{Colors.RESET} - Run 30-second demo")
                print(f"  {Colors.GREEN}3{Colors.RESET} - Show controls")
                print(f"  {Colors.GREEN}4{Colors.RESET} - Settings")
                print(f"  {Colors.GREEN}q{Colors.RESET} - Quit")
                
                choice = input(f"\n{Colors.BRIGHT_CYAN}Enter choice: {Colors.RESET}").strip().lower()
                
                if choice == '1':
                    print(f"{Colors.BRIGHT_GREEN}Starting Matrix Rain... Press Ctrl+C to stop{Colors.RESET}")
                    time.sleep(1)
                    matrix.run_interactive()
                    
                elif choice == '2':
                    matrix.run_demo(30)
                    
                elif choice == '3':
                    matrix.show_controls()
                    input()
                    
                elif choice == '4':
                    print(f"{Colors.BRIGHT_CYAN}Settings:{Colors.RESET}")
                    print(f"  Current speed: {matrix.speed:.2f}")
                    print(f"  Japanese chars: {matrix.use_japanese}")
                    print(f"  Fade effect: {matrix.fade_effect}")
                    input("Press Enter to continue...")
                    
                elif choice == 'q':
                    slow_print("Goodbye!", color=Colors.BRIGHT_GREEN)
                    break
                    
                else:
                    print(f"{Colors.BRIGHT_GREEN}Invalid choice. Please try again.{Colors.RESET}")
                    
            except KeyboardInterrupt:
                print(f"\n{Colors.BRIGHT_GREEN}Goodbye!{Colors.RESET}")
                break
            except Exception as e:
                print(f"{Colors.BRIGHT_GREEN}Error: {e}{Colors.RESET}")
                
    except Exception as e:
        print(f"{Colors.BRIGHT_GREEN}Fatal error: {e}{Colors.RESET}")
        sys.exit(1)

if __name__ == "__main__":
    main()