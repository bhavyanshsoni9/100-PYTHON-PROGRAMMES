import datetime
import time

def mood_tracker():
    mood = input("How are you feeling today? 😄😢😡😎 : ")
    with open("mood_log.txt", "a") as file:
        file.write(f"{datetime.datetime.now()} - {mood}\n")
    print("✅ Mood saved!")

def breathing_exercise():
    print("🧘‍♂️ Breathe in... (4 sec)")
    time.sleep(4)
    print("Hold... (4 sec)")
    time.sleep(4)
    print("Breathe out... (4 sec)")
    time.sleep(4)
    print("✅ Done! Feeling better?")

def gratitude_journal():
    entry = input("🙏 What are you grateful for today? ")
    with open("gratitude_log.txt", "a") as file:
        file.write(f"{datetime.datetime.now()} - {entry}\n")
    print("✅ Saved!")

def main():
    print("🌟 Mental Health Assistant 🌟")
    print("1. Mood Tracker")
    print("2. Breathing Exercise")
    print("3. Gratitude Journal")
    choice = input("Choose (1/2/3): ")

    if choice == '1':
        mood_tracker()
    elif choice == '2':
        breathing_exercise()
    elif choice == '3':
        gratitude_journal()
    else:
        print("❌ Invalid choice!")

if __name__ == "__main__":
    main()