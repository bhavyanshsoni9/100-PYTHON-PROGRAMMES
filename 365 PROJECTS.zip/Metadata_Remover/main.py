import argparse
import os
import time
from PIL import Image
from PyPDF2 import PdfReader, PdfWriter
from docx import Document
from colorama import Fore, Style, init

init(autoreset=True)

EMOJIS = {
    'start': '🧹',
    'progress': '🔄',
    'done': '✅',
    'error': '❌',
}

COLORS = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.MAGENTA]

def print_progress_bar(step, total, emoji):
    percent = int((step / total) * 100)
    color = COLORS[step % len(COLORS)]
    bar = color + '█' * (percent // 10) + Style.RESET_ALL + '-' * (10 - percent // 10)
    print(f"\r{emoji} [{bar}] {percent}%", end='')


def clean_image_metadata(filepath, outpath):
    try:
        img = Image.open(filepath)
        img_no_exif = img.copy()
        img_no_exif.save(outpath, exif=None)
        return True
    except Exception as e:
        print(f"\n{EMOJIS['error']} Error cleaning image: {e}")
        return False


def clean_pdf_metadata(filepath, outpath):
    try:
        reader = PdfReader(filepath)
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        writer.add_metadata({})  # Remove all metadata
        with open(outpath, 'wb') as f:
            writer.write(f)
        return True
    except Exception as e:
        print(f"\n{EMOJIS['error']} Error cleaning PDF: {e}")
        return False


def clean_docx_metadata(filepath, outpath):
    try:
        doc = Document(filepath)
        # Remove core properties
        core_props = doc.core_properties
        core_props.author = ""
        core_props.title = ""
        core_props.subject = ""
        core_props.keywords = ""
        core_props.comments = ""
        core_props.last_modified_by = ""
        core_props.category = ""
        core_props.content_status = ""
        # core_props.created = None
        # core_props.last_printed = None
        # core_props.modified = None
        core_props.revision = 0
        core_props.version = ""
        doc.save(outpath)
        return True
    except Exception as e:
        print(f"\n{EMOJIS['error']} Error cleaning DOCX: {e}")
        return False


def simulate_processing():
    total = 10
    for i in range(total + 1):
        print_progress_bar(i, total, EMOJIS['progress'])
        time.sleep(0.15)
    print()


def get_output_path(filepath):
    base, ext = os.path.splitext(filepath)
    return f"{base}_cleaned{ext}"


def main():
    parser = argparse.ArgumentParser(description="Clean metadata from images, PDFs, and DOCX files.")
    parser.add_argument('file', help="Path to the file to clean")
    args = parser.parse_args()
    filepath = args.file
    if not os.path.isfile(filepath):
        print(f"{EMOJIS['error']} File not found: {filepath}")
        return
    ext = os.path.splitext(filepath)[1].lower()
    outpath = get_output_path(filepath)
    print(f"{EMOJIS['start']} Cleaning metadata from: {filepath}")
    simulate_processing()
    if ext in ['.jpg', '.jpeg', '.png']:
        success = clean_image_metadata(filepath, outpath)
    elif ext == '.pdf':
        success = clean_pdf_metadata(filepath, outpath)
    elif ext == '.docx':
        success = clean_docx_metadata(filepath, outpath)
    else:
        print(f"{EMOJIS['error']} Unsupported file type: {ext}")
        return
    if success:
        print(f"{EMOJIS['done']} Cleaned file saved as: {outpath}")
    else:
        print(f"{EMOJIS['error']} Failed to clean file.")

if __name__ == '__main__':
    main()
