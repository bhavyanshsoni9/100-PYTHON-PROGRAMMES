import streamlit as st
import json
from datetime import datetime
from utils import load_user_data, save_user_data, add_recent_activity

def show_notes():
    """Display notes application"""
    st.markdown("# 📝 Notes")
    
    # Load user notes
    user_data = load_user_data(st.session_state.username)
    notes = user_data.get('notes', {})
    
    # Notes interface
    tab1, tab2 = st.tabs(["Write Note", "My Notes"])
    
    with tab1:
        st.markdown("### Create or Edit Note")
        
        # Note selection
        note_options = ["New Note"] + list(notes.keys())
        selected_note = st.selectbox("Select Note:", note_options)
        
        # Initialize session state for note editing
        if 'current_note_title' not in st.session_state:
            st.session_state.current_note_title = ""
        if 'current_note_content' not in st.session_state:
            st.session_state.current_note_content = ""
        
        # Load selected note
        if selected_note != "New Note" and selected_note in notes:
            note_data = notes[selected_note]
            default_title = selected_note
            default_content = note_data.get('content', '')
        else:
            default_title = ""
            default_content = ""
        
        # Note editor
        with st.form("note_form", clear_on_submit=False):
            note_title = st.text_input("Note Title:", value=default_title)
            note_content = st.text_area("Note Content:", value=default_content, height=300)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                save_button = st.form_submit_button("💾 Save Note", type="primary")
            with col2:
                if selected_note != "New Note":
                    delete_button = st.form_submit_button("🗑️ Delete Note", type="secondary")
                else:
                    delete_button = False
            with col3:
                clear_button = st.form_submit_button("🗒️ New Note")
            
            # Handle form submissions
            if save_button and note_title and note_content:
                save_note(note_title, note_content, notes, user_data)
                st.success(f"Note '{note_title}' saved successfully!")
                st.rerun()
            elif save_button:
                st.error("Please provide both title and content.")
            
            if delete_button and selected_note != "New Note":
                delete_note(selected_note, notes, user_data)
                st.success(f"Note '{selected_note}' deleted!")
                st.rerun()
            
            if clear_button:
                st.rerun()
    
    with tab2:
        st.markdown("### My Notes")
        
        if not notes:
            st.info("No notes found. Create your first note!")
        else:
            # Search functionality
            search_term = st.text_input("🔍 Search notes:")
            
            # Filter notes based on search
            if search_term:
                filtered_notes = {title: content for title, content in notes.items() 
                                if search_term.lower() in title.lower() or 
                                   search_term.lower() in content.get('content', '').lower()}
            else:
                filtered_notes = notes
            
            # Display notes
            if not filtered_notes:
                st.info("No notes match your search.")
            else:
                # Sort notes by last modified
                sorted_notes = sorted(filtered_notes.items(), 
                                    key=lambda x: x[1].get('modified', ''), 
                                    reverse=True)
                
                for note_title, note_data in sorted_notes:
                    with st.expander(f"📄 {note_title}"):
                        st.markdown(f"**Created:** {note_data.get('created', 'Unknown')}")
                        st.markdown(f"**Modified:** {note_data.get('modified', 'Unknown')}")
                        st.markdown(f"**Words:** {count_words(note_data.get('content', ''))}")
                        st.markdown("---")
                        st.markdown("**Content:**")
                        st.text_area("", value=note_data.get('content', ''), 
                                   key=f"view_{note_title}", height=200, disabled=True)
                        
                        # Quick actions
                        col1, col2 = st.columns(2)
                        with col1:
                            if st.button(f"✏️ Edit", key=f"edit_{note_title}"):
                                # Switch to write tab with this note selected
                                st.session_state.selected_note_for_edit = note_title
                                st.info("Switch to 'Write Note' tab to edit this note.")
                        with col2:
                            if st.button(f"📋 Copy", key=f"copy_{note_title}"):
                                st.code(note_data.get('content', ''))
                                st.success(f"Content of '{note_title}' displayed for copying!")
    
    # Notes statistics
    st.markdown("---")
    st.markdown("### 📊 Statistics")
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Notes", len(notes))
    with col2:
        total_words = sum(count_words(note.get('content', '')) for note in notes.values())
        st.metric("Total Words", total_words)
    with col3:
        if notes:
            avg_words = total_words // len(notes)
            st.metric("Avg Words/Note", avg_words)
        else:
            st.metric("Avg Words/Note", 0)
    with col4:
        recent_notes = sum(1 for note in notes.values() 
                          if is_recent(note.get('modified', '')))
        st.metric("Recent Notes", recent_notes)

def save_note(title, content, notes, user_data):
    """Save a note"""
    current_time = datetime.now().isoformat()
    
    # Check if note exists
    is_new = title not in notes
    
    notes[title] = {
        'content': content,
        'created': notes.get(title, {}).get('created', current_time),
        'modified': current_time
    }
    
    user_data['notes'] = notes
    save_user_data(st.session_state.username, user_data)
    
    action = "Created" if is_new else "Updated"
    add_recent_activity(st.session_state.username, f"{action} note: {title}")

def delete_note(title, notes, user_data):
    """Delete a note"""
    if title in notes:
        del notes[title]
        user_data['notes'] = notes
        save_user_data(st.session_state.username, user_data)
        add_recent_activity(st.session_state.username, f"Deleted note: {title}")

def count_words(text):
    """Count words in text"""
    if not text:
        return 0
    return len(text.split())

def is_recent(date_string):
    """Check if date is within last 7 days"""
    try:
        note_date = datetime.fromisoformat(date_string)
        current_date = datetime.now()
        return (current_date - note_date).days <= 7
    except:
        return False
