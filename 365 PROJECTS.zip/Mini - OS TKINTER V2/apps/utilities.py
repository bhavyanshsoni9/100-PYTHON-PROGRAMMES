import streamlit as st
import json
import os
import sys
import platform
import subprocess
import datetime
import calendar
import random
import math
from utils import add_recent_activity, load_user_data, save_user_data

def show_utilities():
    """Display utilities interface"""
    st.markdown("# 🛠️ Utilities")
    
    # Utility categories
    utility_tabs = st.tabs([
        "📅 Calendar", "🌦️ Weather", "🔧 System Tools", 
        "🎨 Color Picker", "📐 Unit Converter", "⏰ Timer", 
        "📊 Charts", "🔤 Text Tools"
    ])
    
    with utility_tabs[0]:
        show_calendar()
    
    with utility_tabs[1]:
        show_weather_info()
    
    with utility_tabs[2]:
        show_system_tools()
    
    with utility_tabs[3]:
        show_color_picker()
    
    with utility_tabs[4]:
        show_unit_converter()
    
    with utility_tabs[5]:
        show_timer()
    
    with utility_tabs[6]:
        show_charts()
    
    with utility_tabs[7]:
        show_text_tools()

def show_calendar():
    """Calendar utility"""
    st.markdown("### 📅 Calendar")
    
    # Current date
    today = datetime.date.today()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Select Date:**")
        selected_date = st.date_input("Date:", value=today)
        
        # Date information
        st.markdown(f"**Selected:** {selected_date.strftime('%A, %B %d, %Y')}")
        st.markdown(f"**Day of year:** {selected_date.timetuple().tm_yday}")
        st.markdown(f"**Week number:** {selected_date.isocalendar()[1]}")
        
        # Calculate days until/since
        days_diff = (selected_date - today).days
        if days_diff > 0:
            st.markdown(f"**Days until:** {days_diff}")
        elif days_diff < 0:
            st.markdown(f"**Days ago:** {abs(days_diff)}")
        else:
            st.markdown("**Today!**")
    
    with col2:
        st.markdown("**Calendar View:**")
        
        # Display calendar for selected month
        year = selected_date.year
        month = selected_date.month
        
        cal = calendar.monthcalendar(year, month)
        month_name = calendar.month_name[month]
        
        st.markdown(f"**{month_name} {year}**")
        
        # Calendar header
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        header = " | ".join(f"{day:^3}" for day in days)
        st.markdown(f"`{header}`")
        
        # Calendar rows
        for week in cal:
            week_str = " | ".join(f"{day:^3}" if day != 0 else "   " for day in week)
            if selected_date.day in week and week[selected_date.weekday()] == selected_date.day:
                week_str = week_str.replace(f"{selected_date.day:^3}", f"[{selected_date.day}]")
            st.markdown(f"`{week_str}`")
    
    # Events/Notes for date
    st.markdown("---")
    st.markdown("### 📝 Date Notes")
    
    user_data = load_user_data(st.session_state.username)
    date_notes = user_data.get('date_notes', {})
    date_key = selected_date.isoformat()
    
    current_note = date_notes.get(date_key, "")
    
    with st.form("date_note_form"):
        note_text = st.text_area("Note for this date:", value=current_note, height=100)
        if st.form_submit_button("Save Note"):
            if note_text.strip():
                date_notes[date_key] = note_text.strip()
            elif date_key in date_notes:
                del date_notes[date_key]
            
            user_data['date_notes'] = date_notes
            save_user_data(st.session_state.username, user_data)
            st.success("Note saved!")
            add_recent_activity(st.session_state.username, f"Added note for {selected_date}")
            st.rerun()

def show_weather_info():
    """Weather information utility"""
    st.markdown("### 🌦️ Weather Information")
    
    st.info("🌍 This is a weather information display utility")
    
    # Mock weather data (in a real app, you'd use a weather API)
    cities = {
        "New York": {"temp": 22, "condition": "Sunny", "humidity": 65, "wind": 8},
        "London": {"temp": 15, "condition": "Cloudy", "humidity": 78, "wind": 12},
        "Tokyo": {"temp": 28, "condition": "Rainy", "humidity": 82, "wind": 6},
        "Sydney": {"temp": 25, "condition": "Partly Cloudy", "humidity": 60, "wind": 15},
        "Paris": {"temp": 18, "condition": "Overcast", "humidity": 72, "wind": 9}
    }
    
    selected_city = st.selectbox("Select a city:", list(cities.keys()))
    
    if selected_city:
        weather = cities[selected_city]
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("🌡️ Temperature", f"{weather['temp']}°C")
        with col2:
            st.metric("☁️ Condition", weather['condition'])
        with col3:
            st.metric("💧 Humidity", f"{weather['humidity']}%")
        with col4:
            st.metric("💨 Wind", f"{weather['wind']} km/h")
        
        # Weather icon based on condition
        condition_icons = {
            "Sunny": "☀️",
            "Cloudy": "☁️",
            "Rainy": "🌧️",
            "Partly Cloudy": "⛅",
            "Overcast": "☁️"
        }
        
        icon = condition_icons.get(weather['condition'], "🌤️")
        st.markdown(f"## {icon} {weather['condition']}")
        
        # 5-day forecast (mock data)
        st.markdown("### 📊 5-Day Forecast")
        
        forecast_data = []
        for i in range(5):
            date = datetime.date.today() + datetime.timedelta(days=i)
            temp = weather['temp'] + random.randint(-5, 5)
            condition = random.choice(list(condition_icons.keys()))
            forecast_data.append({
                'Date': date.strftime('%a %m/%d'),
                'High': f"{temp + 3}°",
                'Low': f"{temp - 2}°",
                'Condition': condition_icons[condition]
            })
        
        st.table(forecast_data)

def show_system_tools():
    """System tools utility"""
    st.markdown("### 🔧 System Tools")
    
    tool_tabs = st.tabs(["System Info", "Disk Usage", "Process Monitor", "Network"])
    
    with tool_tabs[0]:
        st.markdown("**System Information:**")
        
        info = {
            "OS": platform.system(),
            "OS Version": platform.release(),
            "Architecture": platform.machine(),
            "Processor": platform.processor(),
            "Python Version": platform.python_version(),
            "Host Name": platform.node(),
        }
        
        for key, value in info.items():
            st.text(f"{key}: {value}")
    
    with tool_tabs[1]:
        st.markdown("**Disk Usage:**")
        
        try:
            import shutil
            total, used, free = shutil.disk_usage("/")
            
            total_gb = total / (1024**3)
            used_gb = used / (1024**3)
            free_gb = free / (1024**3)
            used_percent = (used / total) * 100
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total", f"{total_gb:.1f} GB")
            with col2:
                st.metric("Used", f"{used_gb:.1f} GB")
            with col3:
                st.metric("Free", f"{free_gb:.1f} GB")
            
            st.progress(used_percent / 100)
            st.text(f"Usage: {used_percent:.1f}%")
            
        except Exception as e:
            st.error(f"Could not retrieve disk usage: {e}")
    
    with tool_tabs[2]:
        st.markdown("**Process Information:**")
        
        try:
            import psutil
            
            # Current process info
            process = psutil.Process()
            st.text(f"Current Process ID: {process.pid}")
            st.text(f"Memory Usage: {process.memory_info().rss / 1024 / 1024:.1f} MB")
            st.text(f"CPU Percent: {process.cpu_percent()}%")
            st.text(f"Process Status: {process.status()}")
            
            # System load
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            st.markdown("**System Load:**")
            st.text(f"CPU Usage: {cpu_percent}%")
            st.text(f"Memory Usage: {memory.percent}%")
            
        except ImportError:
            st.text("Process monitoring not available (psutil not installed)")
        except Exception as e:
            st.error(f"Error getting process info: {e}")
    
    with tool_tabs[3]:
        st.markdown("**Network Information:**")
        
        try:
            import socket
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            
            st.text(f"Hostname: {hostname}")
            st.text(f"Local IP: {local_ip}")
            
            # Test connectivity
            if st.button("Test Internet Connection"):
                try:
                    socket.create_connection(("8.8.8.8", 53), timeout=3)
                    st.success("✅ Internet connection is working")
                except OSError:
                    st.error("❌ No internet connection")
            
        except Exception as e:
            st.error(f"Network info unavailable: {e}")

def show_color_picker():
    """Color picker utility"""
    st.markdown("### 🎨 Color Picker")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Color Selection:**")
        selected_color = st.color_picker("Pick a color:", "#FF0000")
        
        st.markdown("**Color Information:**")
        
        # Convert hex to RGB
        hex_color = selected_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        st.text(f"Hex: {selected_color}")
        st.text(f"RGB: {rgb}")
        st.text(f"HSL: {rgb_to_hsl(rgb)}")
        
        # Color preview
        st.markdown(f"<div style='width: 100px; height: 100px; background-color: {selected_color}; border: 2px solid #ccc; border-radius: 8px;'></div>", unsafe_allow_html=True)
    
    with col2:
        st.markdown("**Color Palette Generator:**")
        
        if st.button("Generate Random Palette"):
            st.session_state.color_palette = [
                f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}"
                for _ in range(5)
            ]
        
        if 'color_palette' in st.session_state:
            st.markdown("**Generated Palette:**")
            for i, color in enumerate(st.session_state.color_palette):
                st.markdown(f"<div style='display: inline-block; width: 50px; height: 50px; background-color: {color}; border: 1px solid #ccc; margin: 2px;'></div> `{color}`", unsafe_allow_html=True)
        
        st.markdown("**Common Colors:**")
        common_colors = {
            "Red": "#FF0000", "Green": "#00FF00", "Blue": "#0000FF",
            "Yellow": "#FFFF00", "Purple": "#800080", "Orange": "#FFA500",
            "Pink": "#FFC0CB", "Brown": "#A52A2A", "Black": "#000000"
        }
        
        for name, color in common_colors.items():
            if st.button(f"{name}", key=f"color_{name}"):
                st.session_state.selected_common_color = color
        
        if 'selected_common_color' in st.session_state:
            color = st.session_state.selected_common_color
            st.markdown(f"<div style='width: 80px; height: 30px; background-color: {color}; border: 1px solid #ccc;'></div> `{color}`", unsafe_allow_html=True)

def show_unit_converter():
    """Unit converter utility"""
    st.markdown("### 📐 Unit Converter")
    
    converter_type = st.selectbox("Conversion Type:", [
        "Length", "Weight", "Temperature", "Volume", "Area", "Speed"
    ])
    
    if converter_type == "Length":
        units = {
            "Meters": 1, "Kilometers": 1000, "Centimeters": 0.01,
            "Millimeters": 0.001, "Inches": 0.0254, "Feet": 0.3048,
            "Yards": 0.9144, "Miles": 1609.34
        }
    elif converter_type == "Weight":
        units = {
            "Kilograms": 1, "Grams": 0.001, "Pounds": 0.453592,
            "Ounces": 0.0283495, "Tons": 1000, "Stones": 6.35029
        }
    elif converter_type == "Temperature":
        show_temperature_converter()
        return
    elif converter_type == "Volume":
        units = {
            "Liters": 1, "Milliliters": 0.001, "Gallons (US)": 3.78541,
            "Quarts": 0.946353, "Pints": 0.473176, "Cups": 0.236588,
            "Fluid Ounces": 0.0295735
        }
    elif converter_type == "Area":
        units = {
            "Square Meters": 1, "Square Kilometers": 1000000,
            "Square Feet": 0.092903, "Square Inches": 0.00064516,
            "Acres": 4046.86, "Hectares": 10000
        }
    elif converter_type == "Speed":
        units = {
            "Meters/Second": 1, "Kilometers/Hour": 0.277778,
            "Miles/Hour": 0.44704, "Feet/Second": 0.3048,
            "Knots": 0.514444
        }
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        from_unit = st.selectbox("From:", list(units.keys()))
        value = st.number_input("Value:", value=1.0)
    
    with col2:
        st.markdown("**=**")
    
    with col3:
        to_unit = st.selectbox("To:", list(units.keys()))
        
        # Perform conversion
        if from_unit != to_unit:
            # Convert to base unit first, then to target unit
            base_value = value * units[from_unit]
            result = base_value / units[to_unit]
            st.number_input("Result:", value=result, disabled=True)
        else:
            st.number_input("Result:", value=value, disabled=True)

def show_temperature_converter():
    """Temperature converter"""
    st.markdown("**Temperature Converter**")
    
    temp_value = st.number_input("Temperature:", value=0.0)
    from_scale = st.selectbox("From:", ["Celsius", "Fahrenheit", "Kelvin"])
    to_scale = st.selectbox("To:", ["Celsius", "Fahrenheit", "Kelvin"])
    
    # Convert temperature
    if from_scale == to_scale:
        result = temp_value
    else:
        # Convert to Celsius first
        if from_scale == "Fahrenheit":
            celsius = (temp_value - 32) * 5/9
        elif from_scale == "Kelvin":
            celsius = temp_value - 273.15
        else:
            celsius = temp_value
        
        # Convert from Celsius to target
        if to_scale == "Fahrenheit":
            result = celsius * 9/5 + 32
        elif to_scale == "Kelvin":
            result = celsius + 273.15
        else:
            result = celsius
    
    st.success(f"{temp_value}° {from_scale} = {result:.2f}° {to_scale}")

def show_timer():
    """Timer utility"""
    st.markdown("### ⏰ Timer & Stopwatch")
    
    timer_tab, stopwatch_tab = st.tabs(["Timer", "Stopwatch"])
    
    with timer_tab:
        st.markdown("**Set Timer:**")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            hours = st.number_input("Hours:", min_value=0, max_value=23, value=0)
        with col2:
            minutes = st.number_input("Minutes:", min_value=0, max_value=59, value=5)
        with col3:
            seconds = st.number_input("Seconds:", min_value=0, max_value=59, value=0)
        
        total_seconds = hours * 3600 + minutes * 60 + seconds
        
        if total_seconds > 0:
            st.text(f"Timer set for: {hours:02d}:{minutes:02d}:{seconds:02d}")
            
            if st.button("⏰ Start Timer"):
                st.session_state.timer_target = datetime.datetime.now() + datetime.timedelta(seconds=total_seconds)
                st.session_state.timer_running = True
                add_recent_activity(st.session_state.username, f"Started timer for {total_seconds} seconds")
                st.rerun()
        
        # Show running timer
        if st.session_state.get('timer_running', False):
            now = datetime.datetime.now()
            target = st.session_state.get('timer_target')
            
            if target and now < target:
                remaining = target - now
                remaining_seconds = int(remaining.total_seconds())
                
                hrs = remaining_seconds // 3600
                mins = (remaining_seconds % 3600) // 60
                secs = remaining_seconds % 60
                
                st.markdown(f"## ⏰ {hrs:02d}:{mins:02d}:{secs:02d}")
                st.progress(1 - (remaining_seconds / total_seconds))
                
                if st.button("Stop Timer"):
                    st.session_state.timer_running = False
                    st.rerun()
            else:
                st.success("⏰ Timer finished!")
                st.balloons()
                st.session_state.timer_running = False
                if st.button("Reset Timer"):
                    st.rerun()
    
    with stopwatch_tab:
        st.markdown("**Stopwatch:**")
        
        if 'stopwatch_start' not in st.session_state:
            st.session_state.stopwatch_start = None
            st.session_state.stopwatch_running = False
            st.session_state.stopwatch_elapsed = 0
        
        if not st.session_state.stopwatch_running:
            if st.button("▶️ Start"):
                st.session_state.stopwatch_start = datetime.datetime.now()
                st.session_state.stopwatch_running = True
                st.rerun()
        else:
            if st.button("⏸️ Stop"):
                if st.session_state.stopwatch_start:
                    elapsed = datetime.datetime.now() - st.session_state.stopwatch_start
                    st.session_state.stopwatch_elapsed += elapsed.total_seconds()
                st.session_state.stopwatch_running = False
                st.session_state.stopwatch_start = None
                st.rerun()
        
        if st.button("🔄 Reset"):
            st.session_state.stopwatch_elapsed = 0
            st.session_state.stopwatch_start = None
            st.session_state.stopwatch_running = False
            st.rerun()
        
        # Display stopwatch time
        current_elapsed = st.session_state.stopwatch_elapsed
        if st.session_state.stopwatch_running and st.session_state.stopwatch_start:
            current_elapsed += (datetime.datetime.now() - st.session_state.stopwatch_start).total_seconds()
        
        hrs = int(current_elapsed // 3600)
        mins = int((current_elapsed % 3600) // 60)
        secs = int(current_elapsed % 60)
        
        st.markdown(f"## ⏱️ {hrs:02d}:{mins:02d}:{secs:02d}")

def show_charts():
    """Charts utility"""
    st.markdown("### 📊 Chart Generator")
    
    chart_type = st.selectbox("Chart Type:", ["Line Chart", "Bar Chart", "Pie Chart", "Scatter Plot", "Area Chart"])
    
    # Sample data generator
    if st.button("Generate Sample Data"):
        if chart_type in ["Line Chart", "Area Chart"]:
            x_data = list(range(1, 11))
            y_data = [random.randint(10, 100) for _ in range(10)]
            
            chart_data = {"x": x_data, "y": y_data}
            
            if chart_type == "Line Chart":
                st.line_chart(y_data)
            else:  # Area Chart
                st.area_chart(y_data)
            
        elif chart_type == "Bar Chart":
            categories = ["A", "B", "C", "D", "E"]
            values = [random.randint(10, 100) for _ in range(5)]
            
            st.bar_chart(dict(zip(categories, values)))
            
        elif chart_type == "Pie Chart":
            labels = ["Category 1", "Category 2", "Category 3", "Category 4"]
            sizes = [random.randint(10, 50) for _ in range(4)]
            
            # Create pie chart data
            pie_data = dict(zip(labels, sizes))
            st.write("Pie Chart Data:")
            for label, size in pie_data.items():
                st.write(f"• {label}: {size}")
            
            # Display as bar chart (Streamlit doesn't have native pie charts)
            st.bar_chart(pie_data)
            
        elif chart_type == "Scatter Plot":
            import pandas as pd
            
            x_data = [random.randint(1, 100) for _ in range(20)]
            y_data = [random.randint(1, 100) for _ in range(20)]
            
            df = pd.DataFrame({"x": x_data, "y": y_data})
            st.scatter_chart(df, x="x", y="y")
    
    # Custom data input
    st.markdown("**Or enter your own data:**")
    
    with st.expander("Custom Data Input"):
        data_input = st.text_area("Enter data (one value per line):", height=100)
        
        if data_input and st.button("Generate Chart from Data"):
            try:
                values = [float(line.strip()) for line in data_input.split('\n') if line.strip()]
                
                if values:
                    if chart_type == "Line Chart":
                        st.line_chart(values)
                    elif chart_type == "Bar Chart":
                        st.bar_chart(values)
                    elif chart_type == "Area Chart":
                        st.area_chart(values)
                    
                    st.success(f"Generated {chart_type} with {len(values)} data points")
                else:
                    st.error("No valid data found")
            except ValueError:
                st.error("Please enter numeric values only")

def show_text_tools():
    """Text manipulation tools"""
    st.markdown("### 🔤 Text Tools")
    
    input_text = st.text_area("Enter text to manipulate:", height=150)
    
    if input_text:
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Text Statistics:**")
            st.text(f"Characters: {len(input_text)}")
            st.text(f"Characters (no spaces): {len(input_text.replace(' ', ''))}")
            st.text(f"Words: {len(input_text.split())}")
            st.text(f"Lines: {len(input_text.splitlines())}")
            st.text(f"Sentences: {input_text.count('.') + input_text.count('!') + input_text.count('?')}")
        
        with col2:
            st.markdown("**Text Transformations:**")
            
            transformations = {
                "UPPERCASE": input_text.upper(),
                "lowercase": input_text.lower(),
                "Title Case": input_text.title(),
                "Sentence case": input_text.capitalize(),
                "Reverse": input_text[::-1],
                "No Spaces": input_text.replace(" ", ""),
                "Sorted Words": " ".join(sorted(input_text.split())),
            }
            
            for name, result in transformations.items():
                if st.button(name, key=f"transform_{name}"):
                    st.session_state.transformed_text = result
        
        if 'transformed_text' in st.session_state:
            st.markdown("**Result:**")
            st.code(st.session_state.transformed_text, language=None)
        
        # Additional tools
        st.markdown("---")
        st.markdown("**Additional Tools:**")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🔤 Count Each Character"):
                char_count = {}
                for char in input_text.lower():
                    if char.isalpha():
                        char_count[char] = char_count.get(char, 0) + 1
                
                st.markdown("**Character Frequency:**")
                for char, count in sorted(char_count.items()):
                    st.text(f"{char}: {count}")
        
        with col2:
            if st.button("📝 Word Frequency"):
                words = input_text.lower().split()
                word_count = {}
                
                for word in words:
                    # Remove punctuation
                    clean_word = ''.join(c for c in word if c.isalnum())
                    if clean_word:
                        word_count[clean_word] = word_count.get(clean_word, 0) + 1
                
                st.markdown("**Word Frequency:**")
                for word, count in sorted(word_count.items(), key=lambda x: x[1], reverse=True)[:10]:
                    st.text(f"{word}: {count}")
        
        with col3:
            if st.button("🔍 Find & Replace"):
                st.session_state.show_find_replace = True
        
        if st.session_state.get('show_find_replace', False):
            st.markdown("**Find & Replace:**")
            col1, col2 = st.columns(2)
            
            with col1:
                find_text = st.text_input("Find:")
            with col2:
                replace_text = st.text_input("Replace with:")
            
            if find_text:
                replaced_text = input_text.replace(find_text, replace_text)
                count = input_text.count(find_text)
                
                st.text(f"Found {count} occurrences")
                if count > 0:
                    st.markdown("**Result:**")
                    st.code(replaced_text, language=None)

# Helper functions
def rgb_to_hsl(rgb):
    """Convert RGB to HSL"""
    r, g, b = [x/255.0 for x in rgb]
    max_val = max(r, g, b)
    min_val = min(r, g, b)
    diff = max_val - min_val
    
    # Lightness
    l = (max_val + min_val) / 2
    
    if diff == 0:
        h = s = 0
    else:
        # Saturation
        s = diff / (2 - max_val - min_val) if l > 0.5 else diff / (max_val + min_val)
        
        # Hue
        if max_val == r:
            h = (g - b) / diff + (6 if g < b else 0)
        elif max_val == g:
            h = (b - r) / diff + 2
        else:
            h = (r - g) / diff + 4
        h /= 6
    
    return f"({int(h*360)}, {int(s*100)}%, {int(l*100)}%)"
