import streamlit as st
from auth import logout_user
from apps.file_manager import show_file_manager
from apps.calculator import show_calculator
from apps.notes import show_notes
from apps.security import show_security
from apps.games import show_games
from apps.utilities import show_utilities

def show_desktop():
    """Display the main desktop interface"""
    
    # Top bar with user info and logout
    col1, col2, col3 = st.columns([2, 6, 2])
    with col1:
        st.markdown(f"**Welcome, {st.session_state.username}**")
    with col3:
        if st.button("Logout", type="secondary"):
            logout_user()
    
    st.markdown("---")
    
    # App launcher sidebar
    with st.sidebar:
        st.markdown("## 🚀 Applications")
        
        apps = {
            "🏠 Desktop": "desktop",
            "📁 File Manager": "file_manager",
            "🔢 Calculator": "calculator",
            "📝 Notes": "notes",
            "🔐 Security Tools": "security",
            "🎮 Games": "games",
            "🛠️ Utilities": "utilities"
        }
        
        for app_name, app_key in apps.items():
            if st.button(app_name, key=app_key, use_container_width=True):
                st.session_state.current_app = app_key
                st.rerun()
    
    # Main content area
    if st.session_state.current_app == "desktop":
        show_desktop_home()
    elif st.session_state.current_app == "file_manager":
        show_file_manager()
    elif st.session_state.current_app == "calculator":
        show_calculator()
    elif st.session_state.current_app == "notes":
        show_notes()
    elif st.session_state.current_app == "security":
        show_security()
    elif st.session_state.current_app == "games":
        show_games()
    elif st.session_state.current_app == "utilities":
        show_utilities()

def show_desktop_home():
    """Show desktop home screen with app icons"""
    st.markdown("# 🖥️ Desktop")
    
    # Quick stats
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Files", get_file_count())
    with col2:
        st.metric("Notes", get_notes_count())
    with col3:
        st.metric("Apps", "10+")
    with col4:
        st.metric("Status", "Online", delta="✓")
    
    st.markdown("---")
    
    # App grid
    st.markdown("## Quick Launch")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📁\n\nFile Manager", key="quick_files", help="Manage your files and folders"):
            st.session_state.current_app = "file_manager"
            st.rerun()
    
    with col2:
        if st.button("🔢\n\nCalculator", key="quick_calc", help="Perform calculations"):
            st.session_state.current_app = "calculator"
            st.rerun()
    
    with col3:
        if st.button("📝\n\nNotes", key="quick_notes", help="Write and save notes"):
            st.session_state.current_app = "notes"
            st.rerun()
    
    with col4:
        if st.button("🔐\n\nSecurity", key="quick_security", help="Security and privacy tools"):
            st.session_state.current_app = "security"
            st.rerun()
    
    col5, col6, col7, col8 = st.columns(4)
    
    with col5:
        if st.button("🎮\n\nGames", key="quick_games", help="Play games"):
            st.session_state.current_app = "games"
            st.rerun()
    
    with col6:
        if st.button("🛠️\n\nUtilities", key="quick_utils", help="System utilities"):
            st.session_state.current_app = "utilities"
            st.rerun()
    
    # Recent activity
    st.markdown("---")
    st.markdown("## Recent Activity")
    
    recent_items = get_recent_activity()
    if recent_items:
        for item in recent_items[:5]:
            st.text(f"• {item}")
    else:
        st.info("No recent activity")

def get_file_count():
    """Get user's file count"""
    import os
    user_dir = f"data/filesystem/{st.session_state.username}"
    count = 0
    for root, dirs, files in os.walk(user_dir):
        count += len(files)
    return count

def get_notes_count():
    """Get user's notes count"""
    from utils import load_user_data
    user_data = load_user_data(st.session_state.username)
    return len(user_data.get('notes', {}))

def get_recent_activity():
    """Get recent user activity"""
    from utils import load_user_data
    user_data = load_user_data(st.session_state.username)
    return user_data.get('recent_activity', [])
