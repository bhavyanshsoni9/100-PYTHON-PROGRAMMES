#!/usr/bin/env python3
"""
Web-based Desktop Simulation - Tkinter Version
A complete desktop environment simulation with user authentication and multiple applications.
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import json
import os
import hashlib
from datetime import datetime
import threading
import time

# Import application modules
from tkinter_apps.file_manager import FileManagerApp
from tkinter_apps.calculator import CalculatorApp
from tkinter_apps.notes import NotesApp
from tkinter_apps.security import SecurityApp
from tkinter_apps.games import GamesApp
from tkinter_apps.utilities import UtilitiesApp

class DesktopOS:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Desktop OS Simulation")
        self.root.geometry("1200x800")
        self.root.configure(bg="#7896FA")
        
        # User session
        self.current_user = None
        self.user_data = {}
        
        # Create data directories
        os.makedirs("data", exist_ok=True)
        os.makedirs("data/filesystem", exist_ok=True)
        
        # Initialize UI
        self.setup_styles()
        self.show_login_screen()
        
    def setup_styles(self):
        """Configure UI styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors matching Windows 10/11 theme
        style.configure('Title.TLabel', font=('Segoe UI', 16, 'bold'), background="#7896FA")
        style.configure('Header.TLabel', font=('Segoe UI', 12, 'bold'), background="#7896FA")
        style.configure('App.TButton', font=('Segoe UI', 10), padding=10)
        style.configure('Desktop.TFrame', background="#7896FA")
        
    def hash_password(self, password):
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def load_users(self):
        """Load users from JSON file"""
        try:
            with open("data/users.json", "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    def save_users(self, users):
        """Save users to JSON file"""
        with open("data/users.json", "w") as f:
            json.dump(users, f, indent=2)
    
    def register_user(self, username, password, email=""):
        """Register a new user"""
        users = self.load_users()
        
        if username in users:
            return False
        
        users[username] = {
            "password": self.hash_password(password),
            "email": email,
            "created_at": datetime.now().isoformat(),
            "last_login": None
        }
        
        self.save_users(users)
        
        # Create user's filesystem directory
        user_dir = f"data/filesystem/{username}"
        os.makedirs(user_dir, exist_ok=True)
        os.makedirs(f"{user_dir}/Documents", exist_ok=True)
        os.makedirs(f"{user_dir}/Desktop", exist_ok=True)
        os.makedirs(f"{user_dir}/Downloads", exist_ok=True)
        
        return True
    
    def authenticate_user(self, username, password):
        """Authenticate user login"""
        users = self.load_users()
        
        if username not in users:
            return False
        
        if users[username]["password"] == self.hash_password(password):
            # Update last login
            users[username]["last_login"] = datetime.now().isoformat()
            self.save_users(users)
            return True
        
        return False
    
    def show_login_screen(self):
        """Display login/register interface"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main login frame
        login_frame = ttk.Frame(self.root, style='Desktop.TFrame')
        login_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        # Title
        title_label = ttk.Label(login_frame, text="🖥️ Desktop OS Simulation", style='Title.TLabel')
        title_label.pack(pady=(0, 30))
        
        # Notebook for login/register tabs
        notebook = ttk.Notebook(login_frame)
        notebook.pack(expand=True, fill='both')
        
        # Login tab
        login_tab = ttk.Frame(notebook)
        notebook.add(login_tab, text="Login")
        
        ttk.Label(login_tab, text="Username:", font=('Segoe UI', 10)).pack(pady=5)
        self.login_username = ttk.Entry(login_tab, font=('Segoe UI', 10), width=30)
        self.login_username.pack(pady=5)
        
        ttk.Label(login_tab, text="Password:", font=('Segoe UI', 10)).pack(pady=5)
        self.login_password = ttk.Entry(login_tab, font=('Segoe UI', 10), width=30, show="*")
        self.login_password.pack(pady=5)
        
        ttk.Button(login_tab, text="Login", command=self.handle_login, style='App.TButton').pack(pady=20)
        
        # Register tab
        register_tab = ttk.Frame(notebook)
        notebook.add(register_tab, text="Register")
        
        ttk.Label(register_tab, text="Username:", font=('Segoe UI', 10)).pack(pady=5)
        self.register_username = ttk.Entry(register_tab, font=('Segoe UI', 10), width=30)
        self.register_username.pack(pady=5)
        
        ttk.Label(register_tab, text="Password:", font=('Segoe UI', 10)).pack(pady=5)
        self.register_password = ttk.Entry(register_tab, font=('Segoe UI', 10), width=30, show="*")
        self.register_password.pack(pady=5)
        
        ttk.Label(register_tab, text="Confirm Password:", font=('Segoe UI', 10)).pack(pady=5)
        self.register_confirm = ttk.Entry(register_tab, font=('Segoe UI', 10), width=30, show="*")
        self.register_confirm.pack(pady=5)
        
        ttk.Label(register_tab, text="Email (optional):", font=('Segoe UI', 10)).pack(pady=5)
        self.register_email = ttk.Entry(register_tab, font=('Segoe UI', 10), width=30)
        self.register_email.pack(pady=5)
        
        ttk.Button(register_tab, text="Register", command=self.handle_register, style='App.TButton').pack(pady=20)
        
        # Bind Enter key
        self.root.bind('<Return>', lambda e: self.handle_login())
    
    def handle_login(self):
        """Handle login attempt"""
        username = self.login_username.get().strip()
        password = self.login_password.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password")
            return
        
        if self.authenticate_user(username, password):
            self.current_user = username
            self.load_user_data()
            self.show_desktop()
        else:
            messagebox.showerror("Error", "Invalid username or password")
    
    def handle_register(self):
        """Handle registration attempt"""
        username = self.register_username.get().strip()
        password = self.register_password.get()
        confirm = self.register_confirm.get()
        email = self.register_email.get().strip()
        
        if not username or not password:
            messagebox.showerror("Error", "Username and password are required")
            return
        
        if password != confirm:
            messagebox.showerror("Error", "Passwords do not match")
            return
        
        if self.register_user(username, password, email):
            messagebox.showinfo("Success", "Account created successfully! Please login.")
            # Clear registration fields
            self.register_username.delete(0, tk.END)
            self.register_password.delete(0, tk.END)
            self.register_confirm.delete(0, tk.END)
            self.register_email.delete(0, tk.END)
        else:
            messagebox.showerror("Error", "Username already exists")
    
    def load_user_data(self):
        """Load user-specific data"""
        user_data_file = f"data/user_data_{self.current_user}.json"
        
        try:
            with open(user_data_file, "r") as f:
                self.user_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # Initialize default user data
            self.user_data = {
                "notes": {},
                "recent_activity": [],
                "game_stats": {},
                "date_notes": {},
                "settings": {
                    "theme": "light",
                    "created_at": datetime.now().isoformat()
                }
            }
            self.save_user_data()
    
    def save_user_data(self):
        """Save user data to file"""
        user_data_file = f"data/user_data_{self.current_user}.json"
        self.user_data["last_updated"] = datetime.now().isoformat()
        
        with open(user_data_file, "w") as f:
            json.dump(self.user_data, f, indent=2)
    
    def add_recent_activity(self, activity):
        """Add activity to user's recent activity log"""
        if "recent_activity" not in self.user_data:
            self.user_data["recent_activity"] = []
        
        timestamped_activity = f"{datetime.now().strftime('%H:%M')} - {activity}"
        self.user_data["recent_activity"].insert(0, timestamped_activity)
        self.user_data["recent_activity"] = self.user_data["recent_activity"][:20]
        
        self.save_user_data()
    
    def show_desktop(self):
        """Display the main desktop interface"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Create main layout
        self.create_taskbar()
        self.create_desktop_area()
        
        # Update window title
        self.root.title(f"Desktop OS - {self.current_user}")
    
    def create_taskbar(self):
        """Create the taskbar at the bottom"""
        taskbar = ttk.Frame(self.root, style='Desktop.TFrame', relief='raised')
        taskbar.pack(side='bottom', fill='x', padx=5, pady=5)
        
        # Start menu button
        start_btn = ttk.Button(taskbar, text="🏠 Start", command=self.show_start_menu, style='App.TButton')
        start_btn.pack(side='left', padx=5)
        
        # User info
        user_label = ttk.Label(taskbar, text=f"Welcome, {self.current_user}", style='Header.TLabel')
        user_label.pack(side='left', padx=20)
        
        # Clock
        self.clock_label = ttk.Label(taskbar, text="", style='Header.TLabel')
        self.clock_label.pack(side='right', padx=10)
        self.update_clock()
        
        # Logout button
        logout_btn = ttk.Button(taskbar, text="Logout", command=self.logout, style='App.TButton')
        logout_btn.pack(side='right', padx=5)
    
    def create_desktop_area(self):
        """Create the main desktop area"""
        self.desktop_frame = ttk.Frame(self.root, style='Desktop.TFrame')
        self.desktop_frame.pack(expand=True, fill='both', padx=10, pady=10)
        
        # Welcome message
        welcome_label = ttk.Label(self.desktop_frame, 
                                text=f"Welcome to your Desktop, {self.current_user}!", 
                                style='Title.TLabel')
        welcome_label.pack(pady=20)
        
        # Quick stats
        stats_frame = ttk.Frame(self.desktop_frame, style='Desktop.TFrame')
        stats_frame.pack(pady=10)
        
        file_count = self.get_file_count()
        notes_count = len(self.user_data.get('notes', {}))
        
        ttk.Label(stats_frame, text=f"Files: {file_count}", style='Header.TLabel').pack(side='left', padx=20)
        ttk.Label(stats_frame, text=f"Notes: {notes_count}", style='Header.TLabel').pack(side='left', padx=20)
        ttk.Label(stats_frame, text="Apps: 10+", style='Header.TLabel').pack(side='left', padx=20)
        ttk.Label(stats_frame, text="Status: Online ✓", style='Header.TLabel').pack(side='left', padx=20)
        
        # App grid
        self.create_app_grid()
        
        # Recent activity
        self.create_recent_activity()
    
    def create_app_grid(self):
        """Create the application grid"""
        apps_frame = ttk.LabelFrame(self.desktop_frame, text="Applications", padding=10)
        apps_frame.pack(pady=20, fill='x')
        
        # App buttons in grid layout
        apps = [
            ("📁 File Manager", self.open_file_manager),
            ("🔢 Calculator", self.open_calculator),
            ("📝 Notes", self.open_notes),
            ("🔐 Security Tools", self.open_security),
            ("🎮 Games", self.open_games),
            ("🛠️ Utilities", self.open_utilities)
        ]
        
        row = 0
        col = 0
        for app_name, command in apps:
            btn = ttk.Button(apps_frame, text=app_name, command=command, 
                           style='App.TButton', width=20)
            btn.grid(row=row, column=col, padx=10, pady=10)
            
            col += 1
            if col > 2:  # 3 columns
                col = 0
                row += 1
    
    def create_recent_activity(self):
        """Create recent activity display"""
        activity_frame = ttk.LabelFrame(self.desktop_frame, text="Recent Activity", padding=10)
        activity_frame.pack(pady=10, fill='both', expand=True)
        
        # Activity listbox with scrollbar
        activity_list_frame = ttk.Frame(activity_frame)
        activity_list_frame.pack(fill='both', expand=True)
        
        scrollbar = ttk.Scrollbar(activity_list_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.activity_listbox = tk.Listbox(activity_list_frame, yscrollcommand=scrollbar.set,
                                         font=('Segoe UI', 9))
        self.activity_listbox.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.activity_listbox.yview)
        
        # Load recent activities
        activities = self.user_data.get('recent_activity', [])
        for activity in activities[:10]:  # Show last 10
            self.activity_listbox.insert(tk.END, activity)
    
    def get_file_count(self):
        """Get user's file count"""
        user_dir = f"data/filesystem/{self.current_user}"
        count = 0
        for root, dirs, files in os.walk(user_dir):
            count += len(files)
        return count
    
    def update_clock(self):
        """Update the clock display"""
        current_time = datetime.now().strftime("%H:%M:%S")
        self.clock_label.config(text=current_time)
        self.root.after(1000, self.update_clock)
    
    def show_start_menu(self):
        """Show start menu popup"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="📁 File Manager", command=self.open_file_manager)
        menu.add_command(label="🔢 Calculator", command=self.open_calculator)
        menu.add_command(label="📝 Notes", command=self.open_notes)
        menu.add_command(label="🔐 Security Tools", command=self.open_security)
        menu.add_command(label="🎮 Games", command=self.open_games)
        menu.add_command(label="🛠️ Utilities", command=self.open_utilities)
        menu.add_separator()
        menu.add_command(label="⚙️ Settings", command=self.open_settings)
        menu.add_command(label="🚪 Logout", command=self.logout)
        
        # Show menu at cursor position
        menu.post(self.root.winfo_pointerx(), self.root.winfo_pointery())
    
    def open_file_manager(self):
        """Open file manager application"""
        FileManagerApp(self)
        self.add_recent_activity("Opened File Manager")
    
    def open_calculator(self):
        """Open calculator application"""
        CalculatorApp(self)
        self.add_recent_activity("Opened Calculator")
    
    def open_notes(self):
        """Open notes application"""
        NotesApp(self)
        self.add_recent_activity("Opened Notes")
    
    def open_security(self):
        """Open security tools"""
        SecurityApp(self)
        self.add_recent_activity("Opened Security Tools")
    
    def open_games(self):
        """Open games application"""
        GamesApp(self)
        self.add_recent_activity("Opened Games")
    
    def open_utilities(self):
        """Open utilities application"""
        UtilitiesApp(self)
        self.add_recent_activity("Opened Utilities")
    
    def open_settings(self):
        """Open settings dialog"""
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("400x300")
        settings_window.configure(bg="#7896FA")
        
        ttk.Label(settings_window, text="User Settings", style='Title.TLabel').pack(pady=20)
        
        # Theme selection
        ttk.Label(settings_window, text="Theme:", style='Header.TLabel').pack(pady=5)
        theme_var = tk.StringVar(value=self.user_data.get('settings', {}).get('theme', 'light'))
        theme_combo = ttk.Combobox(settings_window, textvariable=theme_var, 
                                 values=['light', 'dark'], state='readonly')
        theme_combo.pack(pady=5)
        
        def save_settings():
            if 'settings' not in self.user_data:
                self.user_data['settings'] = {}
            self.user_data['settings']['theme'] = theme_var.get()
            self.save_user_data()
            messagebox.showinfo("Settings", "Settings saved successfully!")
            settings_window.destroy()
        
        ttk.Button(settings_window, text="Save", command=save_settings).pack(pady=20)
    
    def logout(self):
        """Logout current user"""
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.current_user = None
            self.user_data = {}
            self.show_login_screen()
    
    def run(self):
        """Start the application"""
        self.root.mainloop()

if __name__ == "__main__":
    app = DesktopOS()
    app.run()