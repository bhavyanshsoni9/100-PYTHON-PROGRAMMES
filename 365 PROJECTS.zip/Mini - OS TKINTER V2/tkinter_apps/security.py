import tkinter as tk
from tkinter import ttk, messagebox
import random
import string
import hashlib
import secrets
import platform
import psutil
import os
from datetime import datetime

class SecurityApp:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        
        # Create window
        self.window = tk.Toplevel(parent_app.root)
        self.window.title("Security Tools")
        self.window.geometry("700x600")
        self.window.configure(bg="#F3F2F1")
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the security tools UI"""
        # Notebook for tabs
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Password Generator tab
        self.setup_password_tab(notebook)
        
        # Hash Generator tab
        self.setup_hash_tab(notebook)
        
        # System Info tab
        self.setup_system_tab(notebook)
        
        # Security Checker tab
        self.setup_checker_tab(notebook)
    
    def setup_password_tab(self, notebook):
        """Setup password generator tab"""
        password_frame = ttk.Frame(notebook)
        notebook.add(password_frame, text="Password Generator")
        
        # Settings frame
        settings_frame = ttk.LabelFrame(password_frame, text="Password Settings", padding=10)
        settings_frame.pack(fill='x', padx=10, pady=10)
        
        # Length
        ttk.Label(settings_frame, text="Length:").grid(row=0, column=0, sticky='w', pady=2)
        self.length_var = tk.IntVar(value=12)
        length_scale = ttk.Scale(settings_frame, from_=4, to=50, variable=self.length_var, orient='horizontal')
        length_scale.grid(row=0, column=1, sticky='ew', padx=(10, 0))
        self.length_label = ttk.Label(settings_frame, text="12")
        self.length_label.grid(row=0, column=2, padx=(10, 0))
        
        def update_length_label(*args):
            self.length_label.config(text=str(self.length_var.get()))
        self.length_var.trace('w', update_length_label)
        
        # Checkboxes
        self.uppercase_var = tk.BooleanVar(value=True)
        self.lowercase_var = tk.BooleanVar(value=True)
        self.numbers_var = tk.BooleanVar(value=True)
        self.symbols_var = tk.BooleanVar(value=True)
        self.exclude_ambiguous_var = tk.BooleanVar(value=False)
        
        ttk.Checkbutton(settings_frame, text="Uppercase Letters (A-Z)", 
                       variable=self.uppercase_var).grid(row=1, column=0, columnspan=3, sticky='w', pady=2)
        ttk.Checkbutton(settings_frame, text="Lowercase Letters (a-z)", 
                       variable=self.lowercase_var).grid(row=2, column=0, columnspan=3, sticky='w', pady=2)
        ttk.Checkbutton(settings_frame, text="Numbers (0-9)", 
                       variable=self.numbers_var).grid(row=3, column=0, columnspan=3, sticky='w', pady=2)
        ttk.Checkbutton(settings_frame, text="Symbols (!@#$%^&*)", 
                       variable=self.symbols_var).grid(row=4, column=0, columnspan=3, sticky='w', pady=2)
        ttk.Checkbutton(settings_frame, text="Exclude Ambiguous Characters (0, O, l, I)", 
                       variable=self.exclude_ambiguous_var).grid(row=5, column=0, columnspan=3, sticky='w', pady=2)
        
        settings_frame.columnconfigure(1, weight=1)
        
        # Generate button
        ttk.Button(settings_frame, text="Generate Password", 
                  command=self.generate_password).grid(row=6, column=0, columnspan=3, pady=10)
        
        # Result frame
        result_frame = ttk.LabelFrame(password_frame, text="Generated Password", padding=10)
        result_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.password_text = tk.Text(result_frame, height=3, font=('Courier', 12))
        self.password_text.pack(fill='x', pady=5)
        
        # Strength display
        self.strength_var = tk.StringVar(value="Click 'Generate Password' to start")
        ttk.Label(result_frame, textvariable=self.strength_var).pack(pady=5)
        
        # Multiple passwords button
        ttk.Button(result_frame, text="Generate 5 Passwords", 
                  command=self.generate_multiple_passwords).pack(pady=5)
    
    def setup_hash_tab(self, notebook):
        """Setup hash generator tab"""
        hash_frame = ttk.Frame(notebook)
        notebook.add(hash_frame, text="Hash Generator")
        
        # Input frame
        input_frame = ttk.LabelFrame(hash_frame, text="Input Text", padding=10)
        input_frame.pack(fill='x', padx=10, pady=10)
        
        self.hash_input = tk.Text(input_frame, height=4)
        self.hash_input.pack(fill='x')
        self.hash_input.bind('<KeyRelease>', self.update_hashes)
        
        # Hashes frame
        hashes_frame = ttk.LabelFrame(hash_frame, text="Hash Values", padding=10)
        hashes_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Hash displays
        hash_types = ['MD5', 'SHA-1', 'SHA-256', 'SHA-512']
        self.hash_vars = {}
        
        for i, hash_type in enumerate(hash_types):
            ttk.Label(hashes_frame, text=f"{hash_type}:", font=('Segoe UI', 10, 'bold')).grid(
                row=i, column=0, sticky='nw', pady=2)
            
            self.hash_vars[hash_type] = tk.StringVar()
            hash_text = tk.Text(hashes_frame, height=2, wrap='word', font=('Courier', 9))
            hash_text.grid(row=i, column=1, sticky='ew', padx=(10, 0), pady=2)
            
            # Store reference to text widget
            self.hash_vars[hash_type + '_widget'] = hash_text
        
        hashes_frame.columnconfigure(1, weight=1)
    
    def setup_system_tab(self, notebook):
        """Setup system info tab"""
        system_frame = ttk.Frame(notebook)
        notebook.add(system_frame, text="System Info")
        
        # Create scrollable text widget
        text_frame = ttk.Frame(system_frame)
        text_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.system_text = tk.Text(text_frame, wrap='word', font=('Courier', 10))
        system_scrollbar = ttk.Scrollbar(text_frame, orient='vertical', command=self.system_text.yview)
        self.system_text.configure(yscrollcommand=system_scrollbar.set)
        
        self.system_text.pack(side='left', fill='both', expand=True)
        system_scrollbar.pack(side='right', fill='y')
        
        # Refresh button
        ttk.Button(system_frame, text="Refresh System Info", 
                  command=self.refresh_system_info).pack(pady=5)
        
        # Load initial system info
        self.refresh_system_info()
    
    def setup_checker_tab(self, notebook):
        """Setup security checker tab"""
        checker_frame = ttk.Frame(notebook)
        notebook.add(checker_frame, text="Security Checker")
        
        # Password audit section
        audit_frame = ttk.LabelFrame(checker_frame, text="Password Audit", padding=10)
        audit_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(audit_frame, text="Enter password to audit:").pack(anchor='w')
        self.audit_password = ttk.Entry(audit_frame, show='*', width=50)
        self.audit_password.pack(fill='x', pady=5)
        self.audit_password.bind('<KeyRelease>', self.audit_password_strength)
        
        self.audit_result = ttk.Label(audit_frame, text="Enter a password to see strength analysis")
        self.audit_result.pack(anchor='w', pady=5)
        
        # Security tips section
        tips_frame = ttk.LabelFrame(checker_frame, text="Security Best Practices", padding=10)
        tips_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        tips_text = tk.Text(tips_frame, wrap='word', font=('Segoe UI', 10))
        tips_scrollbar = ttk.Scrollbar(tips_frame, orient='vertical', command=tips_text.yview)
        tips_text.configure(yscrollcommand=tips_scrollbar.set)
        
        tips_text.pack(side='left', fill='both', expand=True)
        tips_scrollbar.pack(side='right', fill='y')
        
        # Insert security tips
        security_tips = """
Security Best Practices:

• Use unique passwords for each account
• Enable two-factor authentication when available
• Keep your software updated
• Be cautious of phishing emails and links
• Regularly backup important data
• Use secure networks (avoid public Wi-Fi for sensitive tasks)
• Regularly review and clean up file permissions
• Monitor account activity for unusual behavior
• Consider using a password manager
• Use antivirus software and keep it updated
• Be careful about what information you share online
• Regularly review your privacy settings on social media
• Use encryption for sensitive files
• Keep your operating system updated
• Be cautious when downloading software from the internet
        """
        
        tips_text.insert('1.0', security_tips.strip())
        tips_text.configure(state='disabled')
    
    def generate_password(self):
        """Generate a secure password"""
        length = self.length_var.get()
        uppercase = self.uppercase_var.get()
        lowercase = self.lowercase_var.get()
        numbers = self.numbers_var.get()
        symbols = self.symbols_var.get()
        exclude_ambiguous = self.exclude_ambiguous_var.get()
        
        characters = ""
        
        if uppercase:
            chars = string.ascii_uppercase
            if exclude_ambiguous:
                chars = chars.replace('O', '').replace('I', '')
            characters += chars
        
        if lowercase:
            chars = string.ascii_lowercase
            if exclude_ambiguous:
                chars = chars.replace('l', '').replace('o', '')
            characters += chars
        
        if numbers:
            chars = string.digits
            if exclude_ambiguous:
                chars = chars.replace('0', '').replace('1', '')
            characters += chars
        
        if symbols:
            characters += "!@#$%^&*()_+-=[]{}|;:,.<>?"
        
        if not characters:
            messagebox.showerror("Error", "Please select at least one character type!")
            return
        
        password = ''.join(secrets.choice(characters) for _ in range(length))
        
        self.password_text.delete('1.0', tk.END)
        self.password_text.insert('1.0', password)
        
        # Analyze strength
        strength = self.analyze_password_strength(password)
        self.strength_var.set(f"Strength: {strength['level']} (Score: {strength['score']}/100)")
        
        self.parent_app.add_recent_activity("Generated a secure password")
    
    def generate_multiple_passwords(self):
        """Generate multiple passwords"""
        passwords = []
        for i in range(5):
            self.generate_password()
            password = self.password_text.get('1.0', tk.END).strip()
            passwords.append(f"{i+1}. {password}")
        
        self.password_text.delete('1.0', tk.END)
        self.password_text.insert('1.0', '\n'.join(passwords))
    
    def analyze_password_strength(self, password):
        """Analyze password strength"""
        score = 0
        tips = []
        
        # Length check
        if len(password) >= 12:
            score += 25
        elif len(password) >= 8:
            score += 15
            tips.append("Consider using at least 12 characters")
        else:
            tips.append("Use at least 8 characters (12+ recommended)")
        
        # Character variety
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_symbol = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
        
        variety_score = sum([has_upper, has_lower, has_digit, has_symbol])
        score += variety_score * 15
        
        if not has_upper:
            tips.append("Add uppercase letters")
        if not has_lower:
            tips.append("Add lowercase letters")
        if not has_digit:
            tips.append("Add numbers")
        if not has_symbol:
            tips.append("Add special characters")
        
        # Common patterns check
        common_patterns = ['123', 'abc', 'password', 'qwerty', '111', '000']
        has_common = any(pattern in password.lower() for pattern in common_patterns)
        if has_common:
            tips.append("Avoid common patterns or dictionary words")
        else:
            score += 10
        
        # Repetition check
        if len(set(password)) < len(password) * 0.6:
            tips.append("Avoid too many repeated characters")
        else:
            score += 10
        
        # Determine strength level
        if score >= 85:
            level = "Very Strong"
        elif score >= 70:
            level = "Strong"
        elif score >= 50:
            level = "Medium"
        elif score >= 30:
            level = "Weak"
        else:
            level = "Very Weak"
        
        if not tips:
            tips.append("Excellent password security!")
        
        return {
            'score': min(score, 100),
            'level': level,
            'tips': tips
        }
    
    def update_hashes(self, event=None):
        """Update hash values"""
        input_text = self.hash_input.get('1.0', tk.END).strip()
        
        if not input_text:
            # Clear all hash displays
            for hash_type in ['MD5', 'SHA-1', 'SHA-256', 'SHA-512']:
                widget = self.hash_vars[hash_type + '_widget']
                widget.delete('1.0', tk.END)
            return
        
        try:
            # Calculate hashes
            hashes = {
                'MD5': hashlib.md5(input_text.encode()).hexdigest(),
                'SHA-1': hashlib.sha1(input_text.encode()).hexdigest(),
                'SHA-256': hashlib.sha256(input_text.encode()).hexdigest(),
                'SHA-512': hashlib.sha512(input_text.encode()).hexdigest()
            }
            
            # Update displays
            for hash_type, hash_value in hashes.items():
                widget = self.hash_vars[hash_type + '_widget']
                widget.delete('1.0', tk.END)
                widget.insert('1.0', hash_value)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error calculating hashes: {e}")
    
    def refresh_system_info(self):
        """Refresh system information"""
        self.system_text.delete('1.0', tk.END)
        
        info_lines = []
        
        # Platform information
        info_lines.append("=== PLATFORM INFORMATION ===")
        info_lines.append(f"System: {platform.system()}")
        info_lines.append(f"Release: {platform.release()}")
        info_lines.append(f"Version: {platform.version()}")
        info_lines.append(f"Machine: {platform.machine()}")
        info_lines.append(f"Processor: {platform.processor()}")
        info_lines.append(f"Python Version: {platform.python_version()}")
        info_lines.append(f"Host Name: {platform.node()}")
        info_lines.append("")
        
        # System resources
        try:
            info_lines.append("=== SYSTEM RESOURCES ===")
            
            # CPU
            cpu_percent = psutil.cpu_percent(interval=1)
            info_lines.append(f"CPU Usage: {cpu_percent}%")
            info_lines.append(f"CPU Cores: {psutil.cpu_count()}")
            
            # Memory
            memory = psutil.virtual_memory()
            info_lines.append(f"Memory Usage: {memory.percent}%")
            info_lines.append(f"Total Memory: {memory.total / (1024**3):.1f} GB")
            info_lines.append(f"Available Memory: {memory.available / (1024**3):.1f} GB")
            
            # Disk
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            info_lines.append(f"Disk Usage: {disk_percent:.1f}%")
            info_lines.append(f"Total Disk: {disk.total / (1024**3):.1f} GB")
            info_lines.append(f"Free Disk: {disk.free / (1024**3):.1f} GB")
            
        except Exception as e:
            info_lines.append(f"System resource information unavailable: {e}")
        
        info_lines.append("")
        
        # Network information
        try:
            info_lines.append("=== NETWORK INFORMATION ===")
            import socket
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            info_lines.append(f"Hostname: {hostname}")
            info_lines.append(f"Local IP: {local_ip}")
            
        except Exception as e:
            info_lines.append(f"Network information unavailable: {e}")
        
        self.system_text.insert('1.0', '\n'.join(info_lines))
    
    def audit_password_strength(self, event=None):
        """Audit password strength in real-time"""
        password = self.audit_password.get()
        
        if not password:
            self.audit_result.config(text="Enter a password to see strength analysis")
            return
        
        strength = self.analyze_password_strength(password)
        
        result_text = f"Strength: {strength['level']} (Score: {strength['score']}/100)\n"
        result_text += "Recommendations: " + ", ".join(strength['tips'][:3])  # Show first 3 tips
        
        self.audit_result.config(text=result_text)