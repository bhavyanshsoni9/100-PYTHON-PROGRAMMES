from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress
import os
import shutil
import hashlib
import json
from datetime import datetime

console = Console()

class MirrorVault:
    def __init__(self):
        self.config_file = "mirror_config.json"
        self.config = self._load_config()

    def _load_config(self):
        """Load mirror configuration"""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                return json.load(f)
        return {'mirrors': {}}

    def _save_config(self):
        """Save mirror configuration"""
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)

    def _calculate_hash(self, file_path):
        """Calculate file hash"""
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hasher.update(chunk)
        return hasher.hexdigest()

    def create_mirror(self, source, destination, name):
        """Create a new mirror"""
        if not os.path.exists(source):
            return False, "Source path does not exist"
        
        os.makedirs(destination, exist_ok=True)
        
        self.config['mirrors'][name] = {
            'source': source,
            'destination': destination,
            'last_sync': None,
            'files': {}
        }
        self._save_config()
        return True, "Mirror created successfully"

    def sync_mirror(self, name):
        """Synchronize a mirror"""
        if name not in self.config['mirrors']:
            return False, "Mirror not found"

        mirror = self.config['mirrors'][name]
        source = mirror['source']
        destination = mirror['destination']
        
        if not os.path.exists(source):
            return False, "Source path no longer exists"

        with Progress() as progress:
            # Scan source files
            task1 = progress.add_task("[cyan]Scanning files...", total=None)
            source_files = {}
            for root, _, files in os.walk(source):
                for file in files:
                    src_path = os.path.join(root, file)
                    rel_path = os.path.relpath(src_path, source)
                    source_files[rel_path] = self._calculate_hash(src_path)
                    progress.update(task1, advance=1)

            # Sync files
            task2 = progress.add_task("[green]Syncing files...", total=len(source_files))
            for rel_path, src_hash in source_files.items():
                src_path = os.path.join(source, rel_path)
                dst_path = os.path.join(destination, rel_path)
                
                os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                
                if rel_path not in mirror['files'] or mirror['files'][rel_path] != src_hash:
                    shutil.copy2(src_path, dst_path)
                    mirror['files'][rel_path] = src_hash
                
                progress.update(task2, advance=1)

            # Clean up deleted files
            task3 = progress.add_task("[yellow]Cleaning up...", total=None)
            for rel_path in list(mirror['files'].keys()):
                if rel_path not in source_files:
                    dst_path = os.path.join(destination, rel_path)
                    if os.path.exists(dst_path):
                        os.remove(dst_path)
                    del mirror['files'][rel_path]
                progress.update(task3, advance=1)

        mirror['last_sync'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self._save_config()
        return True, "Mirror synchronized successfully"

def main():
    console.clear()
    console.print("[bold magenta]🪞 MirrorVault[/]")
    console.print("[magenta]Secure File Mirroring System[/]\n")

    vault = MirrorVault()

    while True:
        console.print("\n[bold magenta]Options:[/]")
        console.print("1. Create Mirror")
        console.print("2. Sync Mirror")
        console.print("3. List Mirrors")
        console.print("4. Exit")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == '4':
            console.print("\n[magenta]Your files are safely mirrored! 🪞[/]")
            break

        if choice == '1':
            name = input("\nMirror name: ").strip()
            source = input("Source path: ").strip()
            destination = input("Destination path: ").strip()
            
            success, message = vault.create_mirror(source, destination, name)
            if success:
                console.print(f"\n[green]{message}[/]")
            else:
                console.print(f"\n[red]{message}[/]")

        elif choice == '2':
            if vault.config['mirrors']:
                console.print("\n[bold]Available Mirrors:[/]")
                for name in vault.config['mirrors']:
                    console.print(f"- {name}")
                
                name = input("\nEnter mirror name to sync: ").strip()
                success, message = vault.sync_mirror(name)
                if success:
                    console.print(f"\n[green]{message}[/]")
                else:
                    console.print(f"\n[red]{message}[/]")
            else:
                console.print("\n[yellow]No mirrors configured![/]")

        elif choice == '3':
            if vault.config['mirrors']:
                for name, mirror in vault.config['mirrors'].items():
                    panel = Panel(
                        f"[bold]Source:[/] {mirror['source']}\n"
                        f"[bold]Destination:[/] {mirror['destination']}\n"
                        f"[bold]Last Sync:[/] {mirror['last_sync'] or 'Never'}\n"
                        f"[bold]Files:[/] {len(mirror['files'])}",
                        title=f"[bold magenta]{name}[/]",
                        border_style="magenta"
                    )
                    console.print(panel)
            else:
                console.print("\n[yellow]No mirrors configured![/]")

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 