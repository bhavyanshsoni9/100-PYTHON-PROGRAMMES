import random
import time
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress
from rich.text import Text
from rich.table import Table
import json
import os
from datetime import datetime

# Initialize Rich console
console = Console()

# Mood definitions with corresponding colors and music genres
MOODS = {
    "happy": {
        "color": "yellow",
        "emoji": "😊",
        "genres": ["pop", "dance", "upbeat"],
        "description": "Feeling joyful and energetic"
    },
    "calm": {
        "color": "cyan",
        "emoji": "😌",
        "genres": ["ambient", "classical", "lofi"],
        "description": "Peaceful and relaxed"
    },
    "energetic": {
        "color": "red",
        "emoji": "⚡",
        "genres": ["rock", "electronic", "dance"],
        "description": "Full of energy and excitement"
    },
    "melancholic": {
        "color": "blue",
        "emoji": "🌧️",
        "genres": ["blues", "jazz", "indie"],
        "description": "Reflective and thoughtful"
    },
    "focused": {
        "color": "green",
        "emoji": "🎯",
        "genres": ["instrumental", "classical", "ambient"],
        "description": "Concentrated and productive"
    }
}

class MoodPlayer:
    def __init__(self):
        self.playlist_file = "mood_playlists.json"
        self.history_file = "mood_history.json"
        self.playlists = self.load_playlists()
        self.history = self.load_history()

    def load_playlists(self):
        """Load saved playlists"""
        if os.path.exists(self.playlist_file):
            try:
                with open(self.playlist_file, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def load_history(self):
        """Load mood history"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def save_playlists(self):
        """Save playlists to file"""
        with open(self.playlist_file, 'w') as f:
            json.dump(self.playlists, f, indent=2)

    def save_history(self):
        """Save mood history"""
        with open(self.history_file, 'w') as f:
            json.dump(self.history, f, indent=2)

    def add_to_history(self, mood):
        """Add mood to history"""
        self.history.append({
            'mood': mood,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        self.save_history()

    def create_playlist(self, mood, songs):
        """Create a new playlist for a mood"""
        self.playlists[mood] = songs
        self.save_playlists()

    def get_playlist(self, mood):
        """Get playlist for a mood"""
        return self.playlists.get(mood, [])

def type_print(text, delay=0.03):
    """Print text with mood-based colors"""
    for char in text:
        style = random.choice(['bold cyan', 'bold blue', 'bold purple'])
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def display_mood_options():
    """Display available moods in a table"""
    table = Table(title="[bold]Available Moods[/]")
    table.add_column("Mood", style="cyan")
    table.add_column("Description", style="white")
    table.add_column("Genres", style="green")
    
    for mood, info in MOODS.items():
        table.add_row(
            f"{info['emoji']} {mood.title()}",
            info['description'],
            ", ".join(info['genres'])
        )
    
    console.print(table)

def simulate_music_playback(song, mood):
    """Simulate playing a song with visual effects"""
    mood_color = MOODS[mood]['color']
    
    with Progress() as progress:
        task = progress.add_task(
            f"[{mood_color}]Playing: {song}[/]",
            total=100
        )
        
        while not progress.finished:
            progress.update(task, advance=0.5)
            time.sleep(0.05)

def display_mood_history(history):
    """Display mood history with visualization"""
    if not history:
        console.print(Panel("No mood history found...",
                          style="dim",
                          title="Mood History"))
        return
    
    for entry in history[-5:]:  # Show last 5 entries
        mood = entry['mood']
        mood_info = MOODS[mood]
        
        panel = Panel(
            f"{mood_info['emoji']} {mood.title()}\n{entry['timestamp']}",
            title="[bold]Mood Entry[/]",
            border_style=mood_info['color']
        )
        console.print(panel)
        time.sleep(0.2)

def main():
    """Main program with mood-based interface"""
    player = MoodPlayer()
    console.clear()
    
    type_print("🎵 Welcome to MoodPlayer", delay=0.05)
    type_print("   Let the music match your mood", delay=0.03)
    print()
    
    while True:
        try:
            console.print("\n[bold cyan]Menu Options:[/]")
            console.print("1. [white]Set Current Mood[/]")
            console.print("2. [white]View Mood History[/]")
            console.print("3. [white]Create Playlist[/]")
            console.print("4. [white]Play Music[/]")
            console.print("5. [white]Exit[/]")
            
            choice = input("\nSelect option (1-5): ").strip()
            
            if choice == '1':
                console.clear()
                display_mood_options()
                mood = input("\nEnter your current mood: ").lower()
                
                if mood in MOODS:
                    player.add_to_history(mood)
                    type_print(f"\n{MOODS[mood]['emoji']} Mood set to {mood}!", delay=0.03)
                else:
                    console.print("[red]Invalid mood selected.[/]")
                
            elif choice == '2':
                console.clear()
                type_print("📊 Your Mood History", delay=0.03)
                display_mood_history(player.history)
                input("\nPress Enter to continue...")
                
            elif choice == '3':
                console.clear()
                display_mood_options()
                mood = input("\nEnter mood for playlist: ").lower()
                
                if mood in MOODS:
                    print("\nEnter songs (one per line, press Enter twice to finish):")
                    songs = []
                    while True:
                        song = input()
                        if not song:
                            break
                        songs.append(song)
                    
                    if songs:
                        player.create_playlist(mood, songs)
                        type_print(f"\n✨ Playlist created for {mood} mood!", delay=0.03)
                else:
                    console.print("[red]Invalid mood selected.[/]")
                
            elif choice == '4':
                if not player.history:
                    console.print("[red]Please set your mood first![/]")
                    continue
                
                current_mood = player.history[-1]['mood']
                playlist = player.get_playlist(current_mood)
                
                if not playlist:
                    console.print(f"[red]No songs in playlist for {current_mood} mood![/]")
                    continue
                
                console.clear()
                type_print(f"🎵 Playing music for {current_mood} mood", delay=0.03)
                print()
                
                for song in playlist:
                    simulate_music_playback(song, current_mood)
                
                input("\nPlaylist finished. Press Enter to continue...")
                
            elif choice == '5':
                type_print("\n🎵 Thanks for using MoodPlayer...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("🎵 Music fading out...", delay=0.05)
            break

if __name__ == "__main__":
    main() 