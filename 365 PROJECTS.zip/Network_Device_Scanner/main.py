import sys
import time
import socket
import netifaces
from scapy.all import ARP, Ether, srp
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

console = Console()

# Emojis for device types (by OUI or guess)
OUI_EMOJIS = {
    '00:1A:2B': '🖥️',  # Example PC
    'F4:5C:89': '📱',  # Example Phone
    '00:1B:63': '🖨️',  # Example Printer
    # Add more OUIs as needed
}
DEFAULT_EMOJI = '🔸'


def get_local_subnet():
    # Get the first non-loopback IPv4 address and subnet mask
    for iface in netifaces.interfaces():
        addrs = netifaces.ifaddresses(iface)
        if netifaces.AF_INET in addrs:
            for link in addrs[netifaces.AF_INET]:
                ip = link.get('addr')
                netmask = link.get('netmask')
                if ip and not ip.startswith('127.'):
                    return ip, netmask
    raise RuntimeError('No suitable network interface found.')


def cidr_notation(ip, netmask):
    # Convert netmask to CIDR
    bits = sum([bin(int(x)).count('1') for x in netmask.split('.')])
    return f"{ip}/{bits}"


def get_emoji_for_mac(mac):
    oui = mac.upper()[0:8]
    return OUI_EMOJIS.get(oui, DEFAULT_EMOJI)


def scan_network(target_cidr):
    # ARP scan
    arp = ARP(pdst=target_cidr)
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    packet = ether/arp
    result = srp(packet, timeout=2, verbose=0)[0]
    devices = []
    for sent, received in result:
        devices.append({'ip': received.psrc, 'mac': received.hwsrc})
    return devices


def main():
    console.print("[bold cyan]Network Device Scanner[/bold cyan]")
    try:
        ip, netmask = get_local_subnet()
        cidr = cidr_notation(ip, netmask)
    except Exception as e:
        console.print(f"[red]Error detecting local network: {e}[/red]")
        sys.exit(1)
    console.print(f"Scanning subnet: [yellow]{cidr}[/yellow]")

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), BarColumn(), TimeElapsedColumn(), console=console) as progress:
        task = progress.add_task("Scanning network...", total=None)
        time.sleep(0.5)
        devices = scan_network(cidr)
        time.sleep(0.5)
        progress.update(task, completed=1)

    if not devices:
        console.print("[red]No devices found.[/red]")
        return

    table = Table(title="Devices Found", show_lines=True)
    table.add_column("IP Address", style="cyan")
    table.add_column("MAC Address", style="magenta")
    table.add_column("Status", style="green")
    table.add_column("Type", style="yellow")

    for dev in devices:
        emoji = get_emoji_for_mac(dev['mac'])
        table.add_row(dev['ip'], dev['mac'], "[green]Online[/green]", emoji)

    console.print(table)

if __name__ == "__main__":
    main() 