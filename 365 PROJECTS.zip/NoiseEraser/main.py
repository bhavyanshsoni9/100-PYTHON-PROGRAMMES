from rich.console import Console
from rich.panel import Panel
import re
import string
import unicodedata

console = Console()

class NoiseEraser:
    def __init__(self):
        self.rules = {
            'whitespace': lambda x: ' '.join(x.split()),
            'punctuation': lambda x: x.translate(str.maketrans('', '', string.punctuation)),
            'numbers': lambda x: ''.join(c for c in x if not c.isdigit()),
            'unicode': lambda x: unicodedata.normalize('NFKD', x).encode('ascii', 'ignore').decode('ascii'),
            'lowercase': lambda x: x.lower(),
            'uppercase': lambda x: x.upper(),
            'email': lambda x: re.sub(r'[\w\.-]+@[\w\.-]+\.\w+', '[EMAIL]', x),
            'url': lambda x: re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '[URL]', x),
            'emoji': lambda x: re.sub(r'[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', '', x),
            'hashtags': lambda x: re.sub(r'#\w+', '[HASHTAG]', x)
        }

    def clean_text(self, text, rules):
        """Apply cleaning rules to text"""
        result = text
        for rule in rules:
            if rule in self.rules:
                result = self.rules[rule](result)
        return result

    def get_text_stats(self, text):
        """Get statistics about the text"""
        return {
            'length': len(text),
            'words': len(text.split()),
            'lines': len(text.splitlines()),
            'spaces': text.count(' '),
            'punctuation': sum(1 for c in text if c in string.punctuation),
            'numbers': sum(1 for c in text if c.isdigit()),
            'uppercase': sum(1 for c in text if c.isupper()),
            'lowercase': sum(1 for c in text if c.islower())
        }

def main():
    console.clear()
    console.print("[bold green]🧹 NoiseEraser[/]")
    console.print("[green]Text Cleaning Utility[/]\n")

    eraser = NoiseEraser()

    while True:
        console.print("\n[bold green]Options:[/]")
        console.print("1. Clean Text")
        console.print("2. Analyze Text")
        console.print("3. View Rules")
        console.print("4. Exit")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == '4':
            console.print("\n[green]Text cleaned and analyzed! 👋[/]")
            break

        if choice == '1':
            console.print("\n[bold]Available Rules:[/]")
            for rule in eraser.rules:
                console.print(f"- {rule}")
            
            text = input("\nEnter text to clean: ").strip()
            rules_input = input("Enter rules to apply (comma-separated): ").strip()
            rules = [r.strip() for r in rules_input.split(',')]
            
            cleaned = eraser.clean_text(text, rules)
            
            panel = Panel(
                f"[bold]Original:[/]\n{text}\n\n[bold]Cleaned:[/]\n{cleaned}",
                title="[bold green]Cleaned Text[/]",
                border_style="green"
            )
            console.print(panel)

        elif choice == '2':
            text = input("\nEnter text to analyze: ").strip()
            stats = eraser.get_text_stats(text)
            
            panel = Panel(
                "\n".join(f"[bold]{k}:[/] {v}" for k, v in stats.items()),
                title="[bold green]Text Statistics[/]",
                border_style="green"
            )
            console.print(panel)

        elif choice == '3':
            for rule, func in eraser.rules.items():
                sample = "This is a #sample text with 123 numbers and http://example.com URLs!"
                cleaned = func(sample)
                panel = Panel(
                    f"[bold]Before:[/] {sample}\n[bold]After:[/] {cleaned}",
                    title=f"[bold green]{rule}[/]",
                    border_style="green"
                )
                console.print(panel)

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 