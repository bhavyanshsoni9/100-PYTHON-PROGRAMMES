from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import nltk
import numpy as np

nltk.download('punkt')

# Load Knowledge Base
with open("knowledge_base.txt", "r", encoding="utf-8") as file:
    knowledge = file.readlines()

# Clean data
knowledge = [line.strip() for line in knowledge if line.strip()]

# Initialize TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(knowledge)

def chatbot(query):
    query_vec = vectorizer.transform([query])
    similarity = cosine_similarity(query_vec, X)
    best_match = np.argmax(similarity)

    if similarity[0][best_match] < 0.3:
        return "I'm not sure about that. Can you rephrase?"
    return knowledge[best_match]

# Chat Loop
print("💬 AI Chatbot Ready! (Type 'exit' to stop)\n")
while True:
    q = input("You: ")
    if q.lower() == "exit":
        print("Bot: Bye! 👋")
        break
    print("Bot:", chatbot(q))
