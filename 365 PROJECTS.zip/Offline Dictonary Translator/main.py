import json

# Sample dictionary data (expand as you want)
dictionary_data = {
    "hello": {"meaning": "A greeting", "translations": {"hindi": "नमस्ते", "spanish": "hola"}},
    "world": {"meaning": "The earth, or the realm of human existence", "translations": {"hindi": "दुनिया", "spanish": "mundo"}},
    "python": {"meaning": "A programming language", "translations": {"hindi": "पायथन", "spanish": "pitón"}}
}

def get_meaning(word):
    word = word.lower()
    if word in dictionary_data:
        return dictionary_data[word]["meaning"]
    else:
        return "Word not found in dictionary."

def translate(word, lang):
    word = word.lower()
    if word in dictionary_data:
        return dictionary_data[word]["translations"].get(lang.lower(), f"No translation available for {lang}")
    else:
        return "Word not found in dictionary."

def main():
    print("=== Offline Dictionary + Translator ===")
    while True:
        choice = input("Choose:\n1. Get Meaning\n2. Translate\n3. Exit\n> ")
        if choice == '1':
            w = input("Enter word: ")
            print("Meaning:", get_meaning(w))
        elif choice == '2':
            w = input("Enter word: ")
            l = input("Enter language (hindi/spanish): ")
            print("Translation:", translate(w, l))
        elif choice == '3':
            print("Exiting...")
            break
        else:
            print("Invalid choice, try again.")

if __name__ == "__main__":
    main()
