"""
Camera Handler Module
Handles webcam capture and ASCII art conversion for terminal display
"""

import cv2
import numpy as np
import threading
import time
from typing import Optional, Tuple

class CameraHandler:
    def __init__(self, camera_index=0):
        self.camera_index = camera_index
        self.cap = None
        self.is_initialized = False
        self.current_frame = None
        self.frame_lock = threading.Lock()
        self.running = False
        self.capture_thread = None
        
        # ASCII characters for different brightness levels
        self.ascii_chars = " .:-=+*#%@"
        
    def initialize(self) -> bool:
        """Initialize the camera"""
        try:
            self.cap = cv2.VideoCapture(self.camera_index)
            if not self.cap.isOpened():
                print(f"ERROR: Could not open camera at index {self.camera_index}")
                return False
            
            # Set camera properties
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_FPS, 30)
            
            # Start capture thread
            self.running = True
            self.capture_thread = threading.Thread(target=self._capture_loop)
            self.capture_thread.daemon = True
            self.capture_thread.start()
            
            self.is_initialized = True
            print(f"Camera initialized successfully (index: {self.camera_index})")
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to initialize camera: {e}")
            return False
    
    def _capture_loop(self):
        """Background thread for continuous frame capture"""
        while self.running:
            if self.cap and self.cap.isOpened():
                ret, frame = self.cap.read()
                if ret:
                    with self.frame_lock:
                        self.current_frame = frame.copy()
                else:
                    print("WARNING: Failed to capture frame")
            time.sleep(0.01)  # Small delay to prevent excessive CPU usage
    
    def capture_frame(self) -> Optional[np.ndarray]:
        """Get the current frame"""
        if not self.is_initialized:
            return None
        
        with self.frame_lock:
            if self.current_frame is not None:
                return self.current_frame.copy()
            return None
    
    def frame_to_ascii(self, frame: np.ndarray, width: int = 60, height: int = 20) -> str:
        """Convert frame to ASCII art"""
        if frame is None:
            return "No frame available"
        
        # Resize frame
        aspect_ratio = frame.shape[1] / frame.shape[0]
        new_width = width
        new_height = int(width / aspect_ratio * 0.5)  # Adjust for character aspect ratio
        
        if new_height > height:
            new_height = height
            new_width = int(height * aspect_ratio * 2)
        
        resized = cv2.resize(frame, (new_width, new_height))
        
        # Convert to grayscale
        gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
        
        # Convert to ASCII
        ascii_frame = ""
        for row in gray:
            for pixel in row:
                # Map pixel value (0-255) to ASCII character index
                char_index = int(pixel / 255 * (len(self.ascii_chars) - 1))
                ascii_frame += self.ascii_chars[char_index]
            ascii_frame += "\n"
        
        return ascii_frame
    
    def get_frame_info(self) -> Tuple[int, int, int]:
        """Get frame dimensions and FPS"""
        if not self.cap or not self.cap.isOpened():
            return 0, 0, 0
        
        width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(self.cap.get(cv2.CAP_PROP_FPS))
        
        return width, height, fps
    
    def save_frame(self, filename: str = None) -> bool:
        """Save current frame to file"""
        if not self.is_initialized:
            return False
        
        frame = self.capture_frame()
        if frame is None:
            return False
        
        if filename is None:
            timestamp = int(time.time())
            filename = f"frame_{timestamp}.jpg"
        
        try:
            cv2.imwrite(filename, frame)
            print(f"Frame saved as {filename}")
            return True
        except Exception as e:
            print(f"ERROR: Failed to save frame: {e}")
            return False
    
    def release(self):
        """Release camera resources"""
        self.running = False
        
        if self.capture_thread and self.capture_thread.is_alive():
            self.capture_thread.join(timeout=1.0)
        
        if self.cap and self.cap.isOpened():
            self.cap.release()
        
        self.is_initialized = False
        print("Camera released")
    
    def __del__(self):
        """Destructor to ensure camera is released"""
        self.release() 