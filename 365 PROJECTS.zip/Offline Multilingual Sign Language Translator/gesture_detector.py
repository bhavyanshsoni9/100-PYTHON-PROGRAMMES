"""
Gesture Detector Module
Handles machine learning model loading and inference for sign language recognition
"""

import cv2
import numpy as np
import os
import json
import time
from typing import Tuple, Optional, Dict, List
import mediapipe as mp

class GestureDetector:
    def __init__(self, language='asl', model_path=None):
        self.language = language.lower()
        self.model_path = model_path or f"models/{self.language}_model"
        self.model = None
        self.is_loaded = False
        
        # MediaPipe hands for hand detection
        self.mp_hands = mp.solutions.hands
        self.hands = None
        
        # Gesture mappings for different languages
        self.gesture_mappings = self._load_gesture_mappings()
        
        # Detection history for smoothing
        self.detection_history = []
        self.history_size = 5
        
        # Performance tracking
        self.inference_times = []
        self.max_inference_history = 10
        
    def _load_gesture_mappings(self) -> Dict[str, str]:
        """Load gesture mappings for the specified language"""
        mappings = {
            'asl': {
                'A': 'A', 'B': 'B', 'C': 'C', 'D': 'D', 'E': 'E', 'F': 'F', 'G': 'G', 'H': 'H',
                'I': 'I', 'J': 'J', 'K': 'K', 'L': 'L', 'M': 'M', 'N': 'N', 'O': 'O', 'P': 'P',
                'Q': 'Q', 'R': 'R', 'S': 'S', 'T': 'T', 'U': 'U', 'V': 'V', 'W': 'W', 'X': 'X',
                'Y': 'Y', 'Z': 'Z',
                'HELLO': 'Hello', 'THANK_YOU': 'Thank you', 'PLEASE': 'Please',
                'YES': 'Yes', 'NO': 'No', 'GOOD': 'Good', 'BAD': 'Bad'
            },
            'bsl': {
                'A': 'A', 'B': 'B', 'C': 'C', 'D': 'D', 'E': 'E', 'F': 'F', 'G': 'G', 'H': 'H',
                'I': 'I', 'J': 'J', 'K': 'K', 'L': 'L', 'M': 'M', 'N': 'N', 'O': 'O', 'P': 'P',
                'Q': 'Q', 'R': 'R', 'S': 'S', 'T': 'T', 'U': 'U', 'V': 'V', 'W': 'W', 'X': 'X',
                'Y': 'Y', 'Z': 'Z',
                'HELLO': 'Hello', 'THANK_YOU': 'Thank you', 'PLEASE': 'Please'
            },
            'isl': {
                'A': 'A', 'B': 'B', 'C': 'C', 'D': 'D', 'E': 'E', 'F': 'F', 'G': 'G', 'H': 'H',
                'I': 'I', 'J': 'J', 'K': 'K', 'L': 'L', 'M': 'M', 'N': 'N', 'O': 'O', 'P': 'P',
                'Q': 'Q', 'R': 'R', 'S': 'S', 'T': 'T', 'U': 'U', 'V': 'V', 'W': 'W', 'X': 'X',
                'Y': 'Y', 'Z': 'Z',
                'NAMASTE': 'Namaste', 'THANK_YOU': 'Thank you'
            },
            'jsl': {
                'A': 'あ', 'B': 'い', 'C': 'う', 'D': 'え', 'E': 'お', 'F': 'か', 'G': 'き', 'H': 'く',
                'I': 'け', 'J': 'こ', 'K': 'さ', 'L': 'し', 'M': 'す', 'N': 'せ', 'O': 'そ', 'P': 'た',
                'Q': 'ち', 'R': 'つ', 'S': 'て', 'T': 'と', 'U': 'な', 'V': 'に', 'W': 'ぬ', 'X': 'ね',
                'Y': 'の', 'Z': 'は',
                'KONNICHIWA': 'こんにちは', 'ARIGATO': 'ありがとう'
            }
        }
        
        return mappings.get(self.language, mappings['asl'])
    
    def load_model(self) -> bool:
        """Load the gesture recognition model"""
        try:
            # Initialize MediaPipe hands
            self.hands = self.mp_hands.Hands(
                static_image_mode=False,
                max_num_hands=2,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
            
            # For now, we'll use a simple rule-based approach
            # In a real implementation, you would load a trained ML model here
            print(f"Gesture detector initialized for {self.language.upper()}")
            self.is_loaded = True
            return True
            
        except Exception as e:
            print(f"ERROR: Failed to load gesture detection model: {e}")
            return False
    
    def preprocess_frame(self, frame: np.ndarray) -> np.ndarray:
        """Preprocess frame for gesture detection"""
        if frame is None:
            return None
        
        # Convert BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Flip horizontally for mirror effect
        rgb_frame = cv2.flip(rgb_frame, 1)
        
        return rgb_frame
    
    def extract_hand_features(self, frame: np.ndarray) -> Optional[List]:
        """Extract hand landmarks using MediaPipe"""
        if self.hands is None:
            return None
        
        results = self.hands.process(frame)
        
        if results.multi_hand_landmarks:
            # Get landmarks from the first detected hand
            landmarks = results.multi_hand_landmarks[0]
            
            # Convert landmarks to list of coordinates
            hand_features = []
            for landmark in landmarks.landmark:
                hand_features.extend([landmark.x, landmark.y, landmark.z])
            
            return hand_features
        
        return None
    
    def detect_gesture_simple(self, hand_features: List) -> Tuple[str, float]:
        """Simple rule-based gesture detection (placeholder)"""
        if hand_features is None:
            return "No gesture detected", 0.0
        
        # This is a simplified placeholder implementation
        # In a real system, you would use a trained ML model here
        
        # Extract some basic features
        if len(hand_features) >= 63:  # 21 landmarks * 3 coordinates
            # Get finger positions (simplified)
            thumb_tip = hand_features[3:6]  # Landmark 4
            index_tip = hand_features[6:9]  # Landmark 8
            middle_tip = hand_features[9:12]  # Landmark 12
            ring_tip = hand_features[12:15]  # Landmark 16
            pinky_tip = hand_features[15:18]  # Landmark 20
            
            # Simple gesture classification based on finger positions
            # This is just a demonstration - real implementation would be more sophisticated
            
            # Check for "A" gesture (fist with thumb on side)
            if (thumb_tip[1] < 0.3 and  # Thumb up
                index_tip[1] > 0.5 and   # Index down
                middle_tip[1] > 0.5 and  # Middle down
                ring_tip[1] > 0.5 and    # Ring down
                pinky_tip[1] > 0.5):     # Pinky down
                return "A", 0.85
            
            # Check for "B" gesture (flat hand)
            elif (thumb_tip[1] > 0.4 and  # Thumb down
                  index_tip[1] < 0.3 and  # Index up
                  middle_tip[1] < 0.3 and # Middle up
                  ring_tip[1] < 0.3 and   # Ring up
                  pinky_tip[1] < 0.3):    # Pinky up
                return "B", 0.80
            
            # Check for "C" gesture (curved hand)
            elif (thumb_tip[1] < 0.4 and  # Thumb up
                  index_tip[1] < 0.4 and  # Index up
                  middle_tip[1] < 0.4 and # Middle up
                  ring_tip[1] < 0.4 and   # Ring up
                  pinky_tip[1] < 0.4):    # Pinky up
                return "C", 0.75
        
        return "No gesture detected", 0.0
    
    def smooth_detection(self, gesture: str, confidence: float) -> Tuple[str, float]:
        """Apply temporal smoothing to detection results"""
        self.detection_history.append((gesture, confidence))
        
        if len(self.detection_history) > self.history_size:
            self.detection_history.pop(0)
        
        # Get most common gesture in recent history
        if len(self.detection_history) >= 3:
            recent_gestures = [g for g, _ in self.detection_history[-3:]]
            gesture_counts = {}
            for g in recent_gestures:
                gesture_counts[g] = gesture_counts.get(g, 0) + 1
            
            most_common = max(gesture_counts.items(), key=lambda x: x[1])
            if most_common[1] >= 2:  # At least 2 out of 3 recent detections
                # Calculate average confidence for the most common gesture
                confidences = [c for g, c in self.detection_history[-3:] if g == most_common[0]]
                avg_confidence = sum(confidences) / len(confidences)
                return most_common[0], avg_confidence
        
        return gesture, confidence
    
    def detect(self, frame: np.ndarray) -> Tuple[str, float]:
        """Main detection method"""
        if not self.is_loaded:
            return "Model not loaded", 0.0
        
        start_time = time.time()
        
        # Preprocess frame
        processed_frame = self.preprocess_frame(frame)
        if processed_frame is None:
            return "No frame available", 0.0
        
        # Extract hand features
        hand_features = self.extract_hand_features(processed_frame)
        
        # Detect gesture
        gesture, confidence = self.detect_gesture_simple(hand_features)
        
        # Apply smoothing
        smoothed_gesture, smoothed_confidence = self.smooth_detection(gesture, confidence)
        
        # Track inference time
        inference_time = time.time() - start_time
        self.inference_times.append(inference_time)
        if len(self.inference_times) > self.max_inference_history:
            self.inference_times.pop(0)
        
        return smoothed_gesture, smoothed_confidence
    
    def get_average_inference_time(self) -> float:
        """Get average inference time"""
        if not self.inference_times:
            return 0.0
        return sum(self.inference_times) / len(self.inference_times)
    
    def get_supported_gestures(self) -> List[str]:
        """Get list of supported gestures for current language"""
        return list(self.gesture_mappings.keys())
    
    def cleanup(self):
        """Clean up resources"""
        if self.hands:
            self.hands.close()
        self.is_loaded = False
    
    def __del__(self):
        """Destructor"""
        self.cleanup() 