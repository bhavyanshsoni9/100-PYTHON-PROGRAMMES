#!/usr/bin/env python3
"""
Offline Multilingual Sign Language Translator
Terminal-based application for real-time sign language detection and translation
"""

import argparse
import sys
import time
import signal
from camera_handler import CameraHandler
from gesture_detector import GestureDetector
from translator import Translator
from config import Config
from utils import clear_screen, print_banner, print_status

class SignLanguageTranslator:
    def __init__(self, language='asl', confidence=0.7, fps=30):
        self.config = Config()
        self.language = language
        self.confidence_threshold = confidence
        self.target_fps = fps
        self.running = False
        
        # Initialize components
        self.camera = CameraHandler()
        self.detector = GestureDetector(language=language)
        self.translator = Translator(language=language)
        
        # Statistics
        self.frame_count = 0
        self.start_time = time.time()
        self.current_gesture = "No gesture detected"
        self.current_confidence = 0.0
        
    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        print("\n\nShutting down gracefully...")
        self.running = False
    
    def print_help(self):
        """Print keyboard shortcuts help"""
        print("\n" + "="*50)
        print("KEYBOARD SHORTCUTS:")
        print("  Q - Quit application")
        print("  H - Show this help")
        print("  S - Save current frame")
        print("  L - Change language")
        print("  C - Change confidence threshold")
        print("="*50)
    
    def process_frame(self, frame):
        """Process a single frame and detect gestures"""
        if frame is None:
            return
            
        # Detect gesture in frame
        gesture, confidence = self.detector.detect(frame)
        
        if confidence >= self.confidence_threshold:
            self.current_gesture = gesture
            self.current_confidence = confidence
            # Translate gesture to text
            translated_text = self.translator.translate(gesture)
        else:
            self.current_gesture = "No gesture detected"
            self.current_confidence = 0.0
            translated_text = ""
        
        return translated_text
    
    def display_frame(self, frame, translated_text):
        """Display frame as ASCII art and show translation"""
        clear_screen()
        print_banner()
        
        # Display ASCII representation of frame
        ascii_frame = self.camera.frame_to_ascii(frame, width=60, height=20)
        print(ascii_frame)
        
        # Display translation and status
        print("\n" + "="*60)
        print(f"LANGUAGE: {self.language.upper()}")
        print(f"DETECTED: {self.current_gesture}")
        print(f"CONFIDENCE: {self.current_confidence:.2f}")
        if translated_text:
            print(f"TRANSLATION: {translated_text}")
        print("="*60)
        
        # Display statistics
        self.frame_count += 1
        elapsed_time = time.time() - self.start_time
        current_fps = self.frame_count / elapsed_time if elapsed_time > 0 else 0
        
        print_status(f"FPS: {current_fps:.1f} | Frames: {self.frame_count} | Time: {elapsed_time:.1f}s")
        print("\nPress 'Q' to quit, 'H' for help")
    
    def run(self):
        """Main application loop"""
        print_banner()
        print("Initializing camera and models...")
        
        if not self.camera.initialize():
            print("ERROR: Could not initialize camera!")
            return False
        
        if not self.detector.load_model():
            print("ERROR: Could not load gesture detection model!")
            return False
        
        print("Ready! Starting detection...")
        time.sleep(2)
        
        self.running = True
        self.setup_signal_handlers()
        
        try:
            while self.running:
                # Capture frame
                frame = self.camera.capture_frame()
                if frame is None:
                    continue
                
                # Process frame
                translated_text = self.process_frame(frame)
                
                # Display results
                self.display_frame(frame, translated_text)
                
                # Control frame rate
                time.sleep(1.0 / self.target_fps)
                
        except KeyboardInterrupt:
            print("\n\nShutting down...")
        finally:
            self.cleanup()
        
        return True
    
    def cleanup(self):
        """Clean up resources"""
        if self.camera:
            self.camera.release()
        print("Cleanup complete.")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Offline Multilingual Sign Language Translator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                    # Run with default settings (ASL)
  python main.py --language bsl     # Run with British Sign Language
  python main.py --confidence 0.8   # Set confidence threshold to 80%
  python main.py --fps 15          # Set target FPS to 15
        """
    )
    
    parser.add_argument(
        '--language', '-l',
        choices=['asl', 'bsl', 'isl', 'jsl'],
        default='asl',
        help='Sign language to detect (default: asl)'
    )
    
    parser.add_argument(
        '--confidence', '-c',
        type=float,
        default=0.7,
        help='Confidence threshold for detection (default: 0.7)'
    )
    
    parser.add_argument(
        '--fps', '-f',
        type=int,
        default=30,
        help='Target FPS for processing (default: 30)'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose output'
    )
    
    args = parser.parse_args()
    
    # Validate arguments
    if not 0.0 <= args.confidence <= 1.0:
        print("ERROR: Confidence must be between 0.0 and 1.0")
        sys.exit(1)
    
    if args.fps <= 0:
        print("ERROR: FPS must be positive")
        sys.exit(1)
    
    # Create and run translator
    translator = SignLanguageTranslator(
        language=args.language,
        confidence=args.confidence,
        fps=args.fps
    )
    
    success = translator.run()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
