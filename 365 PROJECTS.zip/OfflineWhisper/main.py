from rich.console import Console
from rich.panel import Panel
import json
import os
from datetime import datetime
from cryptography.fernet import Fernet
import base64

console = Console()

class OfflineWhisper:
    def __init__(self):
        self.data_file = "whispers.dat"
        self.key_file = "whisper.key"
        self._init_encryption()
        self.whispers = self._load_whispers()

    def _init_encryption(self):
        """Initialize or load encryption key"""
        if os.path.exists(self.key_file):
            with open(self.key_file, 'rb') as f:
                self.key = f.read()
        else:
            self.key = Fernet.generate_key()
            with open(self.key_file, 'wb') as f:
                f.write(self.key)
        self.cipher = Fernet(self.key)

    def _load_whispers(self):
        """Load encrypted whispers from file"""
        if not os.path.exists(self.data_file):
            return []
        try:
            with open(self.data_file, 'rb') as f:
                encrypted_data = f.read()
                if encrypted_data:
                    data = self.cipher.decrypt(encrypted_data)
                    return json.loads(data)
        except:
            return []
        return []

    def _save_whispers(self):
        """Save whispers to encrypted file"""
        encrypted_data = self.cipher.encrypt(json.dumps(self.whispers).encode())
        with open(self.data_file, 'wb') as f:
            f.write(encrypted_data)

    def add_whisper(self, message, recipient):
        """Add a new whisper"""
        whisper = {
            'message': message,
            'recipient': recipient,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'id': base64.urlsafe_b64encode(os.urandom(8)).decode()
        }
        self.whispers.append(whisper)
        self._save_whispers()
        return whisper['id']

    def get_whispers(self, recipient):
        """Get all whispers for a recipient"""
        return [w for w in self.whispers if w['recipient'] == recipient]

    def delete_whisper(self, whisper_id):
        """Delete a whisper by ID"""
        self.whispers = [w for w in self.whispers if w['id'] != whisper_id]
        self._save_whispers()

def main():
    console.clear()
    console.print("[bold blue]📨 OfflineWhisper[/]")
    console.print("[blue]Secure Offline Message Storage[/]\n")

    whisper = OfflineWhisper()

    while True:
        console.print("\n[bold blue]Options:[/]")
        console.print("1. Store new whisper")
        console.print("2. Read whispers")
        console.print("3. Delete whisper")
        console.print("4. Exit")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == '4':
            console.print("\n[blue]Your whispers are safe... 🤫[/]")
            break

        if choice == '1':
            recipient = input("\nRecipient name: ").strip()
            message = input("Your whisper: ").strip()
            whisper_id = whisper.add_whisper(message, recipient)
            console.print(f"\n[blue]Whisper stored with ID: {whisper_id}[/]")

        elif choice == '2':
            recipient = input("\nRecipient name: ").strip()
            messages = whisper.get_whispers(recipient)
            if messages:
                for msg in messages:
                    panel = Panel(
                        f"[bold]Message:[/] {msg['message']}\n[bold]Time:[/] {msg['timestamp']}\n[bold]ID:[/] {msg['id']}",
                        title="[bold blue]Whisper[/]",
                        border_style="blue"
                    )
                    console.print(panel)
            else:
                console.print("\n[blue]No whispers found for this recipient[/]")

        elif choice == '3':
            whisper_id = input("\nWhisper ID to delete: ").strip()
            whisper.delete_whisper(whisper_id)
            console.print("\n[blue]Whisper deleted if it existed[/]")

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 