import os
import time
from PyPDF2 import PdfReader, PdfWriter
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class PDFTool:
    def __init__(self):
        self.history = []
        
    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║       PDF Merger & Splitter           ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def get_pdf_info(self, pdf_path):
        """Get information about a PDF file"""
        try:
            reader = PdfReader(pdf_path)
            return {
                'pages': len(reader.pages),
                'filename': os.path.basename(pdf_path)
            }
        except Exception as e:
            return None

    def merge_pdfs(self):
        """Merge multiple PDF files"""
        pdf_files = []
        merger = PdfWriter()
        
        slow_print(f"\n{Fore.YELLOW}Enter PDF file paths (press Enter with empty input to finish):{Style.RESET_ALL}")
        while True:
            pdf_path = input(f"\n{Fore.GREEN}PDF path: {Style.RESET_ALL}").strip()
            if not pdf_path:
                break
                
            if not os.path.exists(pdf_path):
                slow_print(f"{Fore.RED}File not found: {pdf_path}{Style.RESET_ALL}")
                continue
                
            info = self.get_pdf_info(pdf_path)
            if info:
                pdf_files.append((pdf_path, info))
                slow_print(f"{Fore.CYAN}Added: {info['filename']} ({info['pages']} pages){Style.RESET_ALL}")
            else:
                slow_print(f"{Fore.RED}Invalid PDF file: {pdf_path}{Style.RESET_ALL}")

        if len(pdf_files) < 2:
            slow_print(f"\n{Fore.RED}At least 2 PDF files are required for merging!{Style.RESET_ALL}")
            return

        # Show summary
        print(f"\n{Fore.YELLOW}Files to merge:{Style.RESET_ALL}")
        for i, (path, info) in enumerate(pdf_files, 1):
            print(f"{i}. {info['filename']} ({info['pages']} pages)")

        output_path = input(f"\n{Fore.GREEN}Enter output PDF path: {Style.RESET_ALL}")
        if not output_path.lower().endswith('.pdf'):
            output_path += '.pdf'

        try:
            # Merge PDFs
            for pdf_path, _ in pdf_files:
                merger.append(pdf_path)

            # Save merged PDF
            with open(output_path, 'wb') as output_file:
                merger.write(output_file)

            self.history.append(('merge', [info['filename'] for _, info in pdf_files], output_path))
            slow_print(f"\n{Fore.GREEN}PDFs merged successfully! Saved as: {output_path}{Style.RESET_ALL}")
            
        except Exception as e:
            slow_print(f"\n{Fore.RED}Error merging PDFs: {str(e)}{Style.RESET_ALL}")

    def split_pdf(self):
        """Split a PDF file into individual pages or ranges"""
        pdf_path = input(f"\n{Fore.GREEN}Enter PDF file path: {Style.RESET_ALL}").strip()
        
        if not os.path.exists(pdf_path):
            slow_print(f"{Fore.RED}File not found: {pdf_path}{Style.RESET_ALL}")
            return
            
        info = self.get_pdf_info(pdf_path)
        if not info:
            slow_print(f"{Fore.RED}Invalid PDF file: {pdf_path}{Style.RESET_ALL}")
            return

        print(f"\n{Fore.CYAN}File: {info['filename']}")
        print(f"Total pages: {info['pages']}{Style.RESET_ALL}")

        print(f"\n{Fore.YELLOW}Split options:{Style.RESET_ALL}")
        print("1. Split into individual pages")
        print("2. Split by page range")
        
        choice = input(f"\n{Fore.GREEN}Enter your choice (1-2): {Style.RESET_ALL}")

        try:
            reader = PdfReader(pdf_path)
            base_name = os.path.splitext(info['filename'])[0]
            
            if choice == '1':
                # Split into individual pages
                for page_num in range(len(reader.pages)):
                    writer = PdfWriter()
                    writer.add_page(reader.pages[page_num])
                    
                    output_path = f"{base_name}_page_{page_num + 1}.pdf"
                    with open(output_path, 'wb') as output_file:
                        writer.write(output_file)
                    
                    print(f"{Fore.CYAN}Created: {output_path}{Style.RESET_ALL}")
                
                self.history.append(('split_pages', info['filename'], f"{base_name}_page_*.pdf"))
                
            elif choice == '2':
                # Split by range
                while True:
                    range_str = input(f"\n{Fore.CYAN}Enter page range (e.g., 1-3,5,7-9): {Style.RESET_ALL}")
                    
                    try:
                        pages = set()
                        for part in range_str.split(','):
                            if '-' in part:
                                start, end = map(int, part.split('-'))
                                pages.update(range(start - 1, end))
                            else:
                                pages.add(int(part) - 1)
                        
                        if not all(0 <= p < len(reader.pages) for p in pages):
                            raise ValueError("Page numbers out of range")
                        
                        writer = PdfWriter()
                        for page_num in sorted(pages):
                            writer.add_page(reader.pages[page_num])
                        
                        output_path = f"{base_name}_pages_{range_str}.pdf"
                        with open(output_path, 'wb') as output_file:
                            writer.write(output_file)
                        
                        self.history.append(('split_range', info['filename'], output_path))
                        slow_print(f"\n{Fore.GREEN}PDF split successfully! Saved as: {output_path}{Style.RESET_ALL}")
                        break
                        
                    except ValueError:
                        slow_print(f"{Fore.RED}Invalid page range! Please try again.{Style.RESET_ALL}")
            
            else:
                slow_print(f"{Fore.RED}Invalid choice!{Style.RESET_ALL}")
                
        except Exception as e:
            slow_print(f"\n{Fore.RED}Error splitting PDF: {str(e)}{Style.RESET_ALL}")

    def view_history(self):
        """View operation history"""
        if not self.history:
            slow_print(f"\n{Fore.YELLOW}No operations in history!{Style.RESET_ALL}")
            return
            
        print(f"\n{Fore.CYAN}Operation History:{Style.RESET_ALL}")
        print("═" * 50)
        
        for op_type, source, dest in self.history:
            if op_type == 'merge':
                print(f"{Fore.GREEN}Merged:{Style.RESET_ALL}")
                for src in source:
                    print(f"  - {src}")
                print(f"Into: {dest}")
            elif op_type == 'split_pages':
                print(f"{Fore.GREEN}Split into pages:{Style.RESET_ALL}")
                print(f"  Source: {source}")
                print(f"  Output: {dest}")
            elif op_type == 'split_range':
                print(f"{Fore.GREEN}Split by range:{Style.RESET_ALL}")
                print(f"  Source: {source}")
                print(f"  Output: {dest}")
            print("─" * 50)

    def main_menu(self):
        """Main program loop"""
        while True:
            clear_screen()
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Options:{Style.RESET_ALL}")
            slow_print("1. Merge PDFs")
            slow_print("2. Split PDF")
            slow_print("3. View History")
            slow_print("4. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-4): {Style.RESET_ALL}")
            
            if choice == '1':
                self.merge_pdfs()
            elif choice == '2':
                self.split_pdf()
            elif choice == '3':
                self.view_history()
            elif choice == '4':
                slow_print(f"\n{Fore.YELLOW}Thank you for using PDF Merger & Splitter!{Style.RESET_ALL}")
                break
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
            
            input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")

if __name__ == "__main__":
    try:
        pdf_tool = PDFTool()
        pdf_tool.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Program terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}")