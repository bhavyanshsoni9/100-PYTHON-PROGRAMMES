#!/usr/bin/env python3

"""
Python Teacher (Python Guru)
A bilingual (English/Hindi) interactive Python learning platform with progress tracking.

Features:
- Interactive lessons in Python programming
- Bilingual support (English and Hindi)
- Progress tracking
- Multiple topics (Variables, Loops, Conditions, etc.)
- Immediate feedback on answers
- Score tracking per topic

Author: Bhavyansh Soni
"""

# Import required libraries
import json
import os
import time

# Constants for file paths
USERS_FOLDER = "users"  # Folder to store user data
PROGRESS_FILE = os.path.join(USERS_FOLDER, "progress.json")  # File to store progress

# Create necessary directories and files if they don't exist
if not os.path.exists(USERS_FOLDER):
    os.makedirs(USERS_FOLDER)

if not os.path.exists(PROGRESS_FILE):
    with open(PROGRESS_FILE, "w") as f:
        json.dump({}, f)

def speak(text: str) -> None:
    """Display text with a delay for better readability
    
    Args:
        text (str): Text to display
    """
    print("\n" + text)
    time.sleep(1)

def get_progress() -> dict:
    """Load progress data from JSON file
    
    Returns:
        dict: Dictionary containing user progress data
    """
    with open(PROGRESS_FILE, "r") as f:
        return json.load(f)

def save_progress(progress: dict) -> None:
    """Save progress data to JSON file
    
    Args:
        progress (dict): Progress data to save
    """
    with open(PROGRESS_FILE, "w") as f:
        json.dump(progress, f, indent=4)

def ask_question(q: str, ans: str, lang: str) -> bool:
    """Ask a question and check the answer
    
    Args:
        q (str): Question to ask
        ans (str): Correct answer
        lang (str): Language code ('en' or 'hi')
    
    Returns:
        bool: True if answer is correct, False otherwise
    """
    user_input = input(f"\n{'❓' if lang=='en' else '❓ प्रश्न'} {q}\n> ").strip().lower()
    if user_input == ans.lower():
        speak("✅ Correct! Well done!" if lang == 'en' else "✅ सही उत्तर! शाबाश!")
        return True
    else:
        speak(f"❌ Wrong. Correct answer: {ans}" if lang == 'en' else f"❌ गलत। सही उत्तर: {ans}")
        return False

def lesson_variables(lang: str) -> int:
    """Teach the Variables lesson
    
    Args:
        lang (str): Language code ('en' or 'hi')
    
    Returns:
        int: Score achieved in this lesson (0-2)
    """
    if lang == 'en':
        speak("Lesson: Variables")
        speak("Variables store data. Example: x = 5")
        speak("You can print it: print(x)")
    else:
        speak("पाठ: वेरिएबल्स")
        speak("वेरिएबल्स डेटा को स्टोर करते हैं। उदाहरण: x = 5")
        speak("आप इसे प्रिंट कर सकते हैं: print(x)")

    score = 0
    score += ask_question("What will be output of print(2 + 3)?", "5", lang)
    score += ask_question("Is this valid: name = 'Rahul'? (yes/no)", "yes", lang)
    return score

def lesson_loops(lang: str) -> int:
    """Teach the Loops lesson
    
    Args:
        lang (str): Language code ('en' or 'hi')
    
    Returns:
        int: Score achieved in this lesson (0-2)
    """
    if lang == 'en':
        speak("Lesson: Loops")
        speak("Loops repeat actions. Example: for i in range(3): print(i)")
    else:
        speak("पाठ: लूप्स")
        speak("लूप्स कार्यों को दोहराते हैं। उदाहरण: for i in range(3): print(i)")

    score = 0
    score += ask_question("How many times will this loop run: for i in range(4)?", "4", lang)
    score += ask_question("Is while True an infinite loop? (yes/no)", "yes", lang)
    return score

def lesson_conditions(lang: str) -> int:
    """Teach the Conditions lesson
    
    Args:
        lang (str): Language code ('en' or 'hi')
    
    Returns:
        int: Score achieved in this lesson (0-2)
    """
    if lang == 'en':
        speak("Lesson: Conditions")
        speak("Use if/else to make decisions.")
        speak("Example: if x > 0: print('positive')")
    else:
        speak("पाठ: शर्तें")
        speak("निर्णय लेने के लिए if/else का उपयोग करते हैं।")
        speak("उदाहरण: if x > 0: print('सकारात्मक')")

    score = 0
    score += ask_question("What does if x == 5 check?", "x equals 5", lang)
    score += ask_question("Does else always run if if fails? (yes/no)", "yes", lang)
    return score

def lesson_functions(lang: str) -> int:
    """Teach the Functions lesson
    
    Args:
        lang (str): Language code ('en' or 'hi')
    
    Returns:
        int: Score achieved in this lesson (0-2)
    """
    if lang == 'en':
        speak("Lesson: Functions")
        speak("Functions group reusable code.")
        speak("Example: def greet(): print('Hi')")
    else:
        speak("पाठ: फंक्शन्स")
        speak("फंक्शन्स कोड को दोबारा उपयोग करने के लिए होते हैं।")
        speak("उदाहरण: def greet(): print('Hi')")

    score = 0
    score += ask_question("What keyword defines a function?", "def", lang)
    score += ask_question("Can a function return values? (yes/no)", "yes", lang)
    return score

def lesson_oop(lang: str) -> int:
    """Teach the Object-Oriented Programming lesson
    
    Args:
        lang (str): Language code ('en' or 'hi')
    
    Returns:
        int: Score achieved in this lesson (0-2)
    """
    if lang == 'en':
        speak("Lesson: OOP")
        speak("OOP stands for Object-Oriented Programming.")
        speak("Example: class Car: def __init__(self): self.color = 'red'")
    else:
        speak("पाठ: ऑब्जेक्ट ओरिएंटेड प्रोग्रामिंग")
        speak("OOP का मतलब होता है ऑब्जेक्ट ओरिएंटेड प्रोग्रामिंग।")
        speak("उदाहरण: class Car: def __init__(self): self.color = 'red'")

    score = 0
    score += ask_question("Which keyword is used to define a class?", "class", lang)
    score += ask_question("Does __init__ run automatically? (yes/no)", "yes", lang)
    return score

def view_progress(progress: dict, lang: str) -> None:
    """Display user's progress across all topics
    
    Args:
        progress (dict): Dictionary containing progress data
        lang (str): Language code ('en' or 'hi')
    """
    speak("📊 Your Progress:" if lang == 'en' else "📊 आपकी प्रगति:")
    for topic, data in progress.items():
        print(f"{topic}: {data['score']}/2")

def main():
    """Main program loop handling menu navigation and lesson flow"""
    # Display welcome banner
    print("""
██████╗ ██╗   ██╗████████╗██╗  ██╗ ██████╗ ███╗   ██╗
██╔══██╗██║   ██║╚══██╔══╝██║  ██║██╔═══██╗████╗  ██║
██████╔╝██║   ██║   ██║   ███████║██║   ██║██╔██╗ ██║
██╔═══╝ ██║   ██║   ██║   ██╔══██║██║   ██║██║╚██╗██║
██║     ╚██████╔╝   ██║   ██║  ██║╚██████╔╝██║ ╚████║
╚═╝      ╚═════╝    ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝

Welcome to PYTHON GURU - Learn Python Easily!
""")

    # Language selection
    lang_choice = input("Choose language / भाषा चुनें (1-English, 2-Hindi): ").strip()
    lang = 'en' if lang_choice == '1' else 'hi'
    
    # Load user progress
    progress = get_progress()

    # Main menu loop
    while True:
        # Display menu based on selected language
        if lang == 'en':
            print("\n📚 Topics:")
            print("1. Variables")
            print("2. Loops")
            print("3. Conditions")
            print("4. Functions")
            print("5. OOP")
            print("6. View Progress")
            print("7. Exit")
        else:
            print("\n📚 टॉपिक:")
            print("1. वेरिएबल्स")
            print("2. लूप्स")
            print("3. शर्तें")
            print("4. फंक्शन्स")
            print("5. क्लास और ऑब्जेक्ट्स")
            print("6. प्रगति देखें")
            print("7. बाहर जाएं")

        # Handle user choice
        choice = input("> ").strip()
        topic = None
        score = 0

        # Process user selection
        if choice == '1':
            topic = 'Variables'
            score = lesson_variables(lang)
        elif choice == '2':
            topic = 'Loops'
            score = lesson_loops(lang)
        elif choice == '3':
            topic = 'Conditions'
            score = lesson_conditions(lang)
        elif choice == '4':
            topic = 'Functions'
            score = lesson_functions(lang)
        elif choice == '5':
            topic = 'OOP'
            score = lesson_oop(lang)
        elif choice == '6':
            view_progress(progress, lang)
            continue
        elif choice == '7':
            speak("Goodbye! Keep learning!" if lang == 'en' else "अलविदा! सीखते रहो!")
            break
        else:
            speak("Invalid option." if lang == 'en' else "गलत विकल्प।")
            continue

        # Save progress if a lesson was completed
        if topic:
            progress[topic] = {'score': score}
            save_progress(progress)
            speak("Topic completed! Progress saved." if lang == 'en' else "पाठ पूरा हुआ! प्रगति सेव की गई।")

# Start the program if this file is run directly
if __name__ == "__main__":
    main()
