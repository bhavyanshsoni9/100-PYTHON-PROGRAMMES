import json
import os
import time
from datetime import datetime, timedelta

DATA_FILE = "health_data.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {"water": [], "medicines": [], "workouts": [], "sleep": [], "reminders": []}

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

def add_entry(data, category, entry):
    data[category].append(entry)
    save_data(data)

def log_water(data):
    amt = input("Kitna paani piya (ml)? ")
    try:
        amt = int(amt)
        add_entry(data, "water", {"date": str(datetime.today().date()), "amount": amt})
        print(f"Paani ka record add ho gaya: {amt} ml")
    except:
        print("Invalid input!")

def log_medicine(data):
    med = input("Dawai ka naam likho: ")
    time_taken = input("Dawai kab li (HH:MM)? ")
    try:
        datetime.strptime(time_taken, "%H:%M")
        add_entry(data, "medicines", {"date": str(datetime.today().date()), "medicine": med, "time": time_taken})
        print("Medicine record add ho gaya.")
    except:
        print("Time format galat hai! Use HH:MM.")

def log_workout(data):
    workout = input("Workout type batao: ")
    duration = input("Kitna time (minutes)? ")
    try:
        duration = int(duration)
        add_entry(data, "workouts", {"date": str(datetime.today().date()), "workout": workout, "duration": duration})
        print("Workout record add ho gaya.")
    except:
        print("Invalid input!")

def log_sleep(data):
    sleep_hours = input("Aaj kitne ghante sone? ")
    try:
        sleep_hours = float(sleep_hours)
        add_entry(data, "sleep", {"date": str(datetime.today().date()), "hours": sleep_hours})
        print("Sleep record add ho gaya.")
    except:
        print("Invalid input!")

def show_data(data):
    print("\n--- Aaj tak ka Data ---")
    for key in ["water", "medicines", "workouts", "sleep"]:
        print(f"\n{key.capitalize()}:")
        if data[key]:
            for entry in data[key][-5:]:
                print(entry)
        else:
            print("No records.")

def ascii_bar(value, max_value=1000, length=30):
    filled_length = int(length * value / max_value)
    bar = '█' * filled_length + '-' * (length - filled_length)
    return f"|{bar}| {value}"

def show_charts(data):
    print("\n--- Paani Peene ka Chart (Last 7 days) ---")
    water_data = {}
    for entry in data["water"]:
        date = entry["date"]
        water_data[date] = water_data.get(date, 0) + entry["amount"]
    last_7_days = [(datetime.today() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(6, -1, -1)]
    for day in last_7_days:
        amt = water_data.get(day, 0)
        print(f"{day}: {ascii_bar(amt, max_value=3000)}")  # max 3L water

def add_reminder(data):
    rem_text = input("Reminder likho (e.g. 'Drink water'): ")
    rem_time = input("Kab chahiye reminder (HH:MM 24hr format): ")
    try:
        dt = datetime.strptime(rem_time, "%H:%M").time()
        data["reminders"].append({"text": rem_text, "time": rem_time})
        save_data(data)
        print("Reminder add ho gaya.")
    except:
        print("Time format galat hai! Use HH:MM.")

def check_reminders(data):
    now = datetime.now().strftime("%H:%M")
    for rem in data.get("reminders", []):
        if rem["time"] == now:
            print(f"\n⏰ Reminder: {rem['text']}")
            # Optionally remove reminder after alert
            # data["reminders"].remove(rem)
            # save_data(data)

def show_menu():
    print("""
--- Personal Health Tracker ---
1. Paani peene ka record daalo
2. Medicine ka record daalo
3. Workout ka record daalo
4. Sleep ka record daalo
5. Data dekho
6. Paani peene ka chart dekho
7. Reminder add karo
8. Exit
""")

def main():
    data = load_data()
    print("Health Tracker shuru ho gaya! Reminder notifications har minute check hoti hain (jab tak app chal raha ho).")
    try:
        while True:
            check_reminders(data)
            show_menu()
            choice = input("Choose karo: ")
            if choice == "1":
                log_water(data)
            elif choice == "2":
                log_medicine(data)
            elif choice == "3":
                log_workout(data)
            elif choice == "4":
                log_sleep(data)
            elif choice == "5":
                show_data(data)
            elif choice == "6":
                show_charts(data)
            elif choice == "7":
                add_reminder(data)
            elif choice == "8":
                print("Chal, sehat ka khayal rakhna! Bye!")
                break
            else:
                print("Galat input! Dobara try karo.")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nApp band kar diya gaya.")

if __name__ == "__main__":
    main()
