# Pomodoro Timer

A feature-rich command-line Pomodoro Timer with customizable intervals, statistics tracking, and system notifications.

## Features

- Customizable work and break durations
- Short and long break support
- Statistics tracking
- System notifications
- Pause/Resume functionality
- Session history
- Colorful interface
- Keyboard controls

## Requirements

- Python 3.6+
- Required packages (install using `pip install -r requirements.txt`):
  - colorama
  - keyboard
  - plyer

## Installation

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the program:
   ```bash
   python main.py
   ```

## Usage

1. Start the program and choose from the following options:
   - Start Pomodoro: Begin a Pomodoro session
   - View Statistics: See your productivity stats
   - Configure Timer: Customize timer durations
   - Exit: Close the program

2. During a timer:
   - Press 'p' to pause/resume
   - Press 'q' to quit the current session

3. Default settings:
   - Work duration: 25 minutes
   - Short break: 5 minutes
   - Long break: 15 minutes
   - Long break interval: Every 4 Pomodoros

## Configuration

You can customize:
- Work duration
- Short break duration
- Long break duration
- Number of Pomodoros until long break

Settings are automatically saved between sessions.

## Statistics

The program tracks:
- Completed Pomodoros
- Short breaks taken
- Long breaks taken
- Total work time

## Author

Created by Bhavyansh Soni 