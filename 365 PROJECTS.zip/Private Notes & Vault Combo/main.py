import tkinter as tk
from tkinter import messagebox, filedialog, simpledialog
import os
import keyboard
import cv2
from cryptography.fernet import Fernet
import base64
import json
import numpy as np

# ========== Constants ==========
APP_THEME_BG = "#1e1e2f"
SIDEBAR_COLOR = "#2b2b40"
BTN_COLOR = "#3e3e55"
BTN_HOVER = "#505070"
TEXT_COLOR = "white"

VAULT_FILE = "vault_data.enc"
KEY_FILE = "vault.key"
FACE_FILE = "face_data.jpg"
PASSWORD_FILE = "passwords.enc"
LOCKER_STATE_FILE = "locker_state.txt"

# ========== Encryption Helpers ==========
def generate_key():
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as f:
        f.write(key)

def load_key():
    if not os.path.exists(KEY_FILE):
        generate_key()
    with open(KEY_FILE, "rb") as f:
        return f.read()

def encrypt_data(data):
    f = Fernet(load_key())
    return f.encrypt(data.encode())

def decrypt_data(data):
    f = Fernet(load_key())
    return f.decrypt(data).decode()

# ========== Face Helpers (OpenCV Version) ==========
def capture_face():
    cam = cv2.VideoCapture(0)
    while True:
        ret, frame = cam.read()
        if not ret:
            break
        cv2.imshow("Capture Face - Press S to Save", frame)
        if cv2.waitKey(1) & 0xFF == ord('s'):
            face = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            face = cv2.resize(face, (150, 150))
            cv2.imwrite(FACE_FILE, face)
            break
    cam.release()
    cv2.destroyAllWindows()

def verify_face():
    if not os.path.exists(FACE_FILE):
        return False
    known = cv2.imread(FACE_FILE, cv2.IMREAD_GRAYSCALE)
    known = cv2.resize(known, (150, 150))

    cam = cv2.VideoCapture(0)
    ret, frame = cam.read()
    cam.release()
    if not ret:
        return False
    cv2.destroyAllWindows()
    test_face = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    test_face = cv2.resize(test_face, (150, 150))

    diff = cv2.absdiff(known, test_face)
    score = np.mean(diff)
    return score < 50

# ========== Vault Logic ==========
def save_to_vault(note):
    data = encrypt_data(note)
    with open(VAULT_FILE, "wb") as f:
        f.write(data)

def load_from_vault():
    if not os.path.exists(VAULT_FILE):
        return ""
    with open(VAULT_FILE, "rb") as f:
        encrypted = f.read()
    return decrypt_data(encrypted)

# ========== Password Manager ==========
def save_passwords(pw_dict):
    encrypted = encrypt_data(json.dumps(pw_dict))
    with open(PASSWORD_FILE, "wb") as f:
        f.write(encrypted)

def load_passwords():
    if not os.path.exists(PASSWORD_FILE):
        return {}
    with open(PASSWORD_FILE, "rb") as f:
        data = f.read()
    return json.loads(decrypt_data(data))

# ========== Folder Locker ==========
def lock_folder(path):
    os.system(f"attrib +h +s {path}")
    with open(LOCKER_STATE_FILE, "w") as f:
        f.write(path)

def unlock_folder():
    if os.path.exists(LOCKER_STATE_FILE):
        with open(LOCKER_STATE_FILE, "r") as f:
            path = f.read()
        os.system(f"attrib -h -s {path}")
        os.remove(LOCKER_STATE_FILE)

# ========== SecretPad App ==========
class SecretPad(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SecretPad Pro")
        self.geometry("1000x600")
        self.configure(bg=APP_THEME_BG)
        self.resizable(False, False)

        self.sidebar = tk.Frame(self, bg=SIDEBAR_COLOR, width=180)
        self.sidebar.pack(side="left", fill="y")

        tk.Label(self.sidebar, text="SecretPad", bg=SIDEBAR_COLOR, fg="white", font=("Segoe UI", 16, "bold")).pack(pady=20)

        btns = [
            ("Private Notes", self.load_notes),
            ("Secure Vault", self.load_vault),
            ("Password Manager", self.load_passwords_ui),
            ("Folder Locker", self.lock_or_unlock),
            ("Set Face", capture_face),
            ("Lock Now", self.lock_screen)
        ]
        for name, cmd in btns:
            b = tk.Button(self.sidebar, text=name, bg=BTN_COLOR, fg="white", font=("Segoe UI", 12), bd=0, relief="flat",
                          activebackground=BTN_HOVER, command=cmd)
            b.pack(fill="x", padx=10, pady=5)

        self.text_area = tk.Text(self, bg=SIDEBAR_COLOR, fg=TEXT_COLOR, font=("Consolas", 12))
        self.text_area.pack(expand=True, fill="both", padx=10, pady=10)

        keyboard.add_hotkey("ctrl+shift+l", self.lock_screen)

        self.protocol("WM_DELETE_WINDOW", self.quit_app)

    def load_notes(self):
        if not verify_face():
            messagebox.showerror("Access Denied", "Face verification failed!")
            return
        self.text_area.delete("1.0", tk.END)
        if os.path.exists("notes.txt"):
            with open("notes.txt", "r", encoding="utf-8") as f:
                self.text_area.insert("1.0", f.read())

    def load_vault(self):
        self.text_area.delete("1.0", tk.END)
        try:
            data = load_from_vault()
            self.text_area.insert("1.0", data)
        except:
            messagebox.showerror("Error", "Vault locked or corrupted!")

    def load_passwords_ui(self):
        pwds = load_passwords()
        self.text_area.delete("1.0", tk.END)
        for k, v in pwds.items():
            self.text_area.insert(tk.END, f"{k}: {v}\n")

    def lock_or_unlock(self):
        if os.path.exists(LOCKER_STATE_FILE):
            if verify_face():
                unlock_folder()
                messagebox.showinfo("Unlocked", "Folder Unlocked!")
            else:
                messagebox.showerror("Failed", "Face not matched!")
        else:
            folder = filedialog.askdirectory(title="Select Folder to Lock")
            if folder:
                if verify_face():
                    lock_folder(folder)
                    messagebox.showinfo("Locked", "Folder Locked!")
                else:
                    messagebox.showerror("Failed", "Face not matched!")

    def lock_screen(self):
        self.withdraw()
        self.after(500, self.unlock_prompt)

    def unlock_prompt(self):
        method = simpledialog.askstring("Unlock", "Enter 'face' or password:")
        if method == "face":
            if verify_face():
                messagebox.showinfo("Unlocked", "Face matched. Access granted!")
                self.deiconify()
            else:
                messagebox.showerror("Failed", "Face not matched!")
                self.unlock_prompt()
        elif method == "admin":
            messagebox.showinfo("Unlocked", "Password correct.")
            self.deiconify()
        else:
            self.unlock_prompt()

    def quit_app(self):
        with open("notes.txt", "w", encoding="utf-8") as f:
            f.write(self.text_area.get("1.0", tk.END))
        try:
            save_to_vault(self.text_area.get("1.0", tk.END))
        except:
            pass
        self.destroy()

# ========== Launch ==========
if __name__ == "__main__":
    if not os.path.exists(KEY_FILE):
        generate_key()
    app = SecretPad()
    app.mainloop()
