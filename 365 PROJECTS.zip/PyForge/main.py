#!/usr/bin/env python3
"""
PyForge - Python Code Generator and Template Manager
Created by BHAVYANSH SONI
A retro-style terminal-based Python code generator
"""

import os
import sys
import time
from colorama import init, Fore, Back, Style
from datetime import datetime
import random

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.GREEN}{'='*60}
{Fore.CYAN}    ██████╗ ██╗   ██╗███████╗ ██████╗ ██████╗  ██████╗ ███████╗
{Fore.CYAN}    ██╔══██╗╚██╗ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝ ██╔════╝
{Fore.CYAN}    ██████╔╝ ╚████╔╝ █████╗  ██║   ██║██████╔╝██║  ███╗█████╗  
{Fore.CYAN}    ██╔═══╝   ╚██╔╝  ██╔══╝  ██║   ██║██╔══██╗██║   ██║██╔══╝  
{Fore.CYAN}    ██║        ██║   ██║     ╚██████╔╝██║  ██║╚██████╔╝███████╗
{Fore.CYAN}    ╚═╝        ╚═╝   ╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝
{Fore.GREEN}{'='*60}
{Fore.YELLOW}    🔨 Python Code Generator & Template Manager
{Fore.MAGENTA}    ⚡ Created by: BHAVYANSH SONI
{Fore.GREEN}{'='*60}
"""
    print(header)

def get_python_templates():
    """Get available Python templates"""
    templates = {
        '1': {
            'name': 'Basic Flask Web App',
            'description': 'Simple Flask web application with routes',
            'emoji': '🌐'
        },
        '2': {
            'name': 'CLI Tool Template',
            'description': 'Command-line interface tool with argparse',
            'emoji': '⚡'
        },
        '3': {
            'name': 'Data Analysis Script',
            'description': 'Data analysis with pandas and matplotlib',
            'emoji': '📊'
        },
        '4': {
            'name': 'Web Scraper',
            'description': 'Web scraping with requests and BeautifulSoup',
            'emoji': '🕷️'
        },
        '5': {
            'name': 'REST API Client',
            'description': 'RESTful API client with error handling',
            'emoji': '🔗'
        },
        '6': {
            'name': 'File Manager',
            'description': 'File operations and directory management',
            'emoji': '📁'
        },
        '7': {
            'name': 'Database ORM',
            'description': 'SQLAlchemy ORM model template',
            'emoji': '🗄️'
        },
        '8': {
            'name': 'Unit Test Suite',
            'description': 'Unit testing with pytest framework',
            'emoji': '🧪'
        }
    }
    return templates

def generate_flask_app(app_name):
    """Generate Flask application template"""
    template = f'''#!/usr/bin/env python3
"""
{app_name} - Flask Web Application
Created by BHAVYANSH SONI
"""

from flask import Flask, render_template, request, jsonify
import os
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html', 
                         title='{app_name}',
                         current_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

@app.route('/api/status')
def api_status():
    """API status endpoint"""
    return jsonify({{
        'status': 'active',
        'timestamp': datetime.now().isoformat(),
        'app_name': '{app_name}'
    }})

@app.route('/api/data', methods=['GET', 'POST'])
def api_data():
    """Data API endpoint"""
    if request.method == 'POST':
        data = request.get_json()
        return jsonify({{'message': 'Data received', 'data': data}})
    
    return jsonify({{'message': 'Hello from {app_name}!'}})

@app.errorhandler(404)
def not_found(error):
    """404 error handler"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """500 error handler"""
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
'''
    return template

def generate_cli_tool(tool_name):
    """Generate CLI tool template"""
    template = f'''#!/usr/bin/env python3
"""
{tool_name} - Command Line Interface Tool
Created by BHAVYANSH SONI
"""

import argparse
import sys
import os
from datetime import datetime
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_banner():
    """Print application banner"""
    banner = f"""
{Fore.CYAN}{'='*50}
{Fore.GREEN}    {tool_name.upper()}
{Fore.YELLOW}    Created by: BHAVYANSH SONI
{Fore.CYAN}{'='*50}
"""
    print(banner)

def process_input(input_data, verbose=False):
    """Process input data"""
    if verbose:
        slow_print(f"{{Fore.YELLOW}}🔄 Processing input: {{input_data}}")
    
    # Add your processing logic here
    result = input_data.upper()
    
    if verbose:
        slow_print(f"{{Fore.GREEN}}✅ Processing complete!")
    
    return result

def main():
    """Main function"""
    parser = argparse.ArgumentParser(
        description='{tool_name} - A powerful CLI tool',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        'input',
        help='Input data to process'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose output'
    )
    
    parser.add_argument(
        '-o', '--output',
        help='Output file path'
    )
    
    args = parser.parse_args()
    
    print_banner()
    
    try:
        result = process_input(args.input, args.verbose)
        
        if args.output:
            with open(args.output, 'w') as f:
                f.write(result)
            slow_print(f"{{Fore.GREEN}}💾 Output saved to: {{args.output}}")
        else:
            slow_print(f"{{Fore.CYAN}}📤 Result: {{result}}")
            
    except Exception as e:
        slow_print(f"{{Fore.RED}}❌ Error: {{str(e)}}")
        sys.exit(1)

if __name__ == '__main__':
    main()
'''
    return template

def generate_data_analysis(script_name):
    """Generate data analysis script template"""
    template = f'''#!/usr/bin/env python3
"""
{script_name} - Data Analysis Script
Created by BHAVYANSH SONI
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

def load_data(file_path):
    """Load data from CSV file"""
    try:
        df = pd.read_csv(file_path)
        print(f"✅ Data loaded successfully: {{df.shape[0]}} rows, {{df.shape[1]}} columns")
        return df
    except Exception as e:
        print(f"❌ Error loading data: {{str(e)}}")
        return None

def analyze_data(df):
    """Perform basic data analysis"""
    analysis = {{}}
    
    # Basic statistics
    analysis['shape'] = df.shape
    analysis['columns'] = df.columns.tolist()
    analysis['dtypes'] = df.dtypes.to_dict()
    analysis['missing_values'] = df.isnull().sum().to_dict()
    analysis['numeric_summary'] = df.describe()
    
    return analysis

def create_visualizations(df, output_dir='plots'):
    """Create data visualizations"""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Set style
    plt.style.use('seaborn-v0_8')
    
    # Correlation heatmap for numeric columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 1:
        plt.figure(figsize=(10, 8))
        sns.heatmap(df[numeric_cols].corr(), annot=True, cmap='coolwarm', center=0)
        plt.title('Correlation Matrix')
        plt.tight_layout()
        plt.savefig(f'{{output_dir}}/correlation_matrix.png', dpi=300, bbox_inches='tight')
        plt.show()
    
    # Distribution plots
    for col in numeric_cols[:4]:  # Plot first 4 numeric columns
        plt.figure(figsize=(8, 6))
        df[col].hist(bins=30, alpha=0.7, color='skyblue', edgecolor='black')
        plt.title(f'Distribution of {{col}}')
        plt.xlabel(col)
        plt.ylabel('Frequency')
        plt.tight_layout()
        plt.savefig(f'{{output_dir}}/dist_{{col}}.png', dpi=300, bbox_inches='tight')
        plt.show()

def generate_report(analysis, output_file='analysis_report.txt'):
    """Generate analysis report"""
    with open(output_file, 'w') as f:
        f.write(f"{script_name} Analysis Report\\n")
        f.write(f"Generated on: {{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}}\\n")
        f.write("="*50 + "\\n\\n")
        
        f.write(f"Dataset Shape: {{analysis['shape']}}\\n")
        f.write(f"Columns: {{', '.join(analysis['columns'])}}\\n\\n")
        
        f.write("Missing Values:\\n")
        for col, missing in analysis['missing_values'].items():
            if missing > 0:
                f.write(f"  {{col}}: {{missing}}\\n")
        
        f.write("\\nNumeric Summary:\\n")
        f.write(str(analysis['numeric_summary']))
    
    print(f"📊 Report generated: {{output_file}}")

def main():
    """Main function"""
    print("🔍 {script_name} - Data Analysis Tool")
    print("Created by: BHAVYANSH SONI")
    print("="*50)
    
    # Example usage
    file_path = input("📁 Enter CSV file path: ").strip()
    
    if not file_path:
        print("❌ No file path provided")
        return
    
    df = load_data(file_path)
    if df is None:
        return
    
    print("\\n📊 Analyzing data...")
    analysis = analyze_data(df)
    
    print("\\n📈 Creating visualizations...")
    create_visualizations(df)
    
    print("\\n📋 Generating report...")
    generate_report(analysis)
    
    print("\\n✅ Analysis complete!")

if __name__ == '__main__':
    main()
'''
    return template

def display_templates():
    """Display available templates"""
    templates = get_python_templates()
    
    slow_print(f"{Fore.CYAN}📋 Available Python Templates:", 0.02)
    print(f"{Fore.YELLOW}{'─' * 60}")
    
    for key, template in templates.items():
        slow_print(f"{Fore.GREEN}{key}. {template['emoji']} {template['name']}", 0.01)
        slow_print(f"   {Fore.WHITE}{template['description']}", 0.01)
        print()

def create_project_structure(project_name, template_type):
    """Create project directory structure"""
    if not os.path.exists(project_name):
        os.makedirs(project_name)
    
    if template_type == '1':  # Flask app
        os.makedirs(f"{project_name}/templates", exist_ok=True)
        os.makedirs(f"{project_name}/static", exist_ok=True)
        
        # Create basic HTML template
        html_template = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">{{ title }}</h1>
        <p class="text-center">Current Time: {{ current_time }}</p>
        <div class="alert alert-success" role="alert">
            🎉 Your Flask application is running successfully!
        </div>
    </div>
</body>
</html>'''
        
        with open(f"{project_name}/templates/index.html", 'w') as f:
            f.write(html_template)

def main():
    """Main function"""
    print_header()
    
    while True:
        display_templates()
        
        slow_print(f"\n{Fore.YELLOW}🎯 Select a template (1-8) or 'q' to quit:", 0.02)
        choice = input(f"{Fore.CYAN}>>> ").strip()
        
        if choice.lower() == 'q':
            slow_print(f"{Fore.YELLOW}👋 Thanks for using PyForge! Goodbye!", 0.03)
            break
        
        if choice not in ['1', '2', '3', '4', '5', '6', '7', '8']:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
            time.sleep(1)
            print_header()
            continue
        
        slow_print(f"\n{Fore.CYAN}📝 Enter project name:", 0.02)
        project_name = input(f"{Fore.CYAN}>>> ").strip()
        
        if not project_name:
            slow_print(f"{Fore.RED}❌ Project name cannot be empty.", 0.02)
            time.sleep(1)
            print_header()
            continue
        
        slow_print(f"\n{Fore.YELLOW}🔨 Generating project '{project_name}'...", 0.02)
        
        try:
            create_project_structure(project_name, choice)
            
            # Generate appropriate template
            if choice == '1':
                code = generate_flask_app(project_name)
                filename = f"{project_name}/app.py"
            elif choice == '2':
                code = generate_cli_tool(project_name)
                filename = f"{project_name}/cli.py"
            elif choice == '3':
                code = generate_data_analysis(project_name)
                filename = f"{project_name}/analyze.py"
            else:
                slow_print(f"{Fore.YELLOW}⚠️ Template coming soon!", 0.02)
                time.sleep(1)
                print_header()
                continue
            
            with open(filename, 'w') as f:
                f.write(code)
            
            slow_print(f"{Fore.GREEN}✅ Project '{project_name}' created successfully!", 0.02)
            slow_print(f"{Fore.CYAN}📁 Location: {os.path.abspath(project_name)}", 0.02)
            slow_print(f"{Fore.CYAN}📄 Main file: {filename}", 0.02)
            
        except Exception as e:
            slow_print(f"{Fore.RED}❌ Error creating project: {str(e)}", 0.02)
        
        slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
        input()
        print_header()

if __name__ == "__main__":
    main()
