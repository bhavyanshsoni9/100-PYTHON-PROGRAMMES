# Cryptocurrency Tracking Dashboard

A real-time cryptocurrency tracking dashboard that displays live prices, historical charts, and price predictions for popular cryptocurrencies.

## Features

- Live price tracking for Bitcoin, Ethereum, Cardano, and Dogecoin
- Interactive price charts with moving averages
- Simple machine learning-based price predictions
- Multiple timeframe options (24h, 7d, 30d, 90d)
- Real-time data updates from CoinGecko API

## Requirements

- Python 3.8+
- Required packages listed in `requirements.txt`

## Installation

1. Clone this repository or download the files
2. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Run the dashboard:
   ```bash
   python crypto_dashboard.py
   ```

2. Use the interface to:
   - Select a cryptocurrency from the dropdown menu
   - Choose a timeframe (24h, 7d, 30d, 90d)
   - Click "Refresh Data" to update the information
   - View current price, 24h change, and predicted price
   - Interact with the price chart in your default web browser

## Technical Details

- Data Source: CoinGecko API (free, no API key required)
- Charting: Plotly (interactive charts)
- Price Prediction: Simple Linear Regression model
- GUI: Tkinter

## Notes

- The price prediction is based on a simple linear regression model and should not be used for financial decisions
- Charts are displayed in your default web browser for better interactivity
- Data is fetched in real-time when refreshing 