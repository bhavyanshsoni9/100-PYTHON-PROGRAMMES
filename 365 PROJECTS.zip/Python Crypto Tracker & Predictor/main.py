import tkinter as tk
from tkinter import ttk
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
from pycoingecko import CoinGeckoAPI
from sklearn.linear_model import LinearRegression
import json
import os
from plotly.subplots import make_subplots
import webbrowser

class CryptoDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("Cryptocurrency Dashboard")
        self.root.geometry("1200x800")
        
        # Initialize CoinGecko API
        self.cg = CoinGeckoAPI()
        
        # Default cryptocurrencies to track
        self.cryptocurrencies = {
            'bitcoin': 'Bitcoin',
            'ethereum': 'Ethereum',
            'cardano': 'Cardano',
            'dogecoin': 'Dogecoin'
        }
        
        self.selected_crypto = tk.StringVar(value='bitcoin')
        self.timeframe = tk.StringVar(value='24h')
        
        self.setup_gui()
        self.create_data_directory()
        
        # Initial data load
        self.refresh_data()
    
    def create_data_directory(self):
        """Create a directory to store historical data"""
        if not os.path.exists('data'):
            os.makedirs('data')
    
    def setup_gui(self):
        """Set up the GUI layout"""
        # Control Frame
        control_frame = ttk.Frame(self.root)
        control_frame.pack(fill='x', padx=5, pady=5)
        
        # Cryptocurrency Selection
        ttk.Label(control_frame, text="Select Cryptocurrency:").pack(side='left', padx=5)
        crypto_menu = ttk.Combobox(control_frame, textvariable=self.selected_crypto,
                                 values=list(self.cryptocurrencies.values()))
        crypto_menu.pack(side='left', padx=5)
        
        # Timeframe Selection
        ttk.Label(control_frame, text="Timeframe:").pack(side='left', padx=5)
        timeframe_menu = ttk.Combobox(control_frame, textvariable=self.timeframe,
                                    values=['24h', '7d', '30d', '90d'])
        timeframe_menu.pack(side='left', padx=5)
        
        # Refresh Button
        refresh_btn = ttk.Button(control_frame, text="Refresh Data",
                               command=self.refresh_data)
        refresh_btn.pack(side='left', padx=5)
        
        # Price Display Frame
        self.price_frame = ttk.Frame(self.root)
        self.price_frame.pack(fill='x', padx=5, pady=5)
        
        # Create price labels
        self.current_price_label = ttk.Label(self.price_frame, text="Current Price: --")
        self.current_price_label.pack(side='left', padx=5)
        
        self.price_change_label = ttk.Label(self.price_frame, text="24h Change: --")
        self.price_change_label.pack(side='left', padx=5)
        
        self.predicted_price_label = ttk.Label(self.price_frame, text="Predicted Price: --")
        self.predicted_price_label.pack(side='left', padx=5)
        
        # Graph Frame
        self.graph_frame = ttk.Frame(self.root)
        self.graph_frame.pack(fill='both', expand=True, padx=5, pady=5)

        # Bind events
        self.selected_crypto.trace('w', lambda *args: self.refresh_data())
        self.timeframe.trace('w', lambda *args: self.refresh_data())

    def refresh_data(self):
        """Fetch and update cryptocurrency data"""
        try:
            # Get selected crypto ID
            selected_name = self.selected_crypto.get()
            coin_id = [k for k, v in self.cryptocurrencies.items() if v == selected_name][0]
            
            # Convert timeframe to days
            timeframe_days = {
                '24h': 1,
                '7d': 7,
                '30d': 30,
                '90d': 90
            }[self.timeframe.get()]
            
            # Fetch historical data
            historical_data = self.fetch_historical_data(coin_id, timeframe_days)
            
            # Update display
            self.update_price_display(historical_data)
            
            # Create chart
            self.create_price_chart(historical_data)
            
        except Exception as e:
            print(f"Error refreshing data: {e}")

    def fetch_historical_data(self, coin_id, days):
        """Fetch historical price data for a cryptocurrency"""
        # Fetch market data
        market_data = self.cg.get_coin_market_chart_by_id(
            id=coin_id,
            vs_currency='usd',
            days=days
        )
        
        # Convert to DataFrame
        df = pd.DataFrame(market_data['prices'], columns=['timestamp', 'price'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        
        return df

    def update_price_display(self, price_data):
        """Update the price display widgets"""
        if len(price_data) > 0:
            current_price = price_data['price'].iloc[-1]
            price_24h_ago = price_data['price'].iloc[-24] if len(price_data) >= 24 else price_data['price'].iloc[0]
            price_change = ((current_price - price_24h_ago) / price_24h_ago) * 100
            
            # Predict next day's price
            predicted_price = self.predict_price(price_data)
            
            # Update labels
            self.current_price_label.config(text=f"Current Price: ${current_price:.2f}")
            self.price_change_label.config(
                text=f"24h Change: {price_change:+.2f}%",
                foreground='green' if price_change >= 0 else 'red'
            )
            self.predicted_price_label.config(
                text=f"Predicted Price (24h): ${predicted_price:.2f}"
            )

    def create_price_chart(self, historical_data):
        """Create and display the price chart"""
        # Create figure with secondary y-axis
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        
        # Add price line
        fig.add_trace(
            go.Scatter(
                x=historical_data['timestamp'],
                y=historical_data['price'],
                name="Price",
                line=dict(color='blue')
            ),
            secondary_y=False
        )
        
        # Calculate and add moving averages
        historical_data['MA7'] = historical_data['price'].rolling(window=7).mean()
        historical_data['MA30'] = historical_data['price'].rolling(window=30).mean()
        
        fig.add_trace(
            go.Scatter(
                x=historical_data['timestamp'],
                y=historical_data['MA7'],
                name="7-day MA",
                line=dict(color='orange', dash='dash')
            ),
            secondary_y=False
        )
        
        fig.add_trace(
            go.Scatter(
                x=historical_data['timestamp'],
                y=historical_data['MA30'],
                name="30-day MA",
                line=dict(color='red', dash='dash')
            ),
            secondary_y=False
        )
        
        # Add predicted price point
        if len(historical_data) > 0:
            predicted_price = self.predict_price(historical_data)
            last_timestamp = historical_data['timestamp'].iloc[-1]
            next_timestamp = last_timestamp + timedelta(days=1)
            
            fig.add_trace(
                go.Scatter(
                    x=[next_timestamp],
                    y=[predicted_price],
                    name="Predicted",
                    mode='markers',
                    marker=dict(
                        color='green',
                        size=10,
                        symbol='star'
                    )
                ),
                secondary_y=False
            )
        
        # Update layout
        fig.update_layout(
            title=f"{self.selected_crypto.get()} Price Chart",
            xaxis_title="Date",
            yaxis_title="Price (USD)",
            hovermode='x unified',
            showlegend=True
        )
        
        # Save and open in browser
        fig.write_html("temp_chart.html")
        webbrowser.open('file://' + os.path.realpath("temp_chart.html"))

    def predict_price(self, historical_data):
        """Predict the next day's price using Linear Regression"""
        if len(historical_data) < 2:
            return historical_data['price'].iloc[-1]
        
        # Prepare data for prediction
        X = np.arange(len(historical_data)).reshape(-1, 1)
        y = historical_data['price'].values
        
        # Create and fit the model
        model = LinearRegression()
        model.fit(X, y)
        
        # Predict next day's price
        next_day = np.array([[len(historical_data)]])
        predicted_price = model.predict(next_day)[0]
        
        # Ensure prediction is not negative
        return max(0, predicted_price)

def main():
    root = tk.Tk()
    app = CryptoDashboard(root)
    root.mainloop()

if __name__ == "__main__":
    main() 