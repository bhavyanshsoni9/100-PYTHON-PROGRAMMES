import time
import random
import json
import os
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box
from datetime import datetime
import base64

# Initialize Rich console
console = Console()

# Quantum-inspired constants
QUANTUM_STATES = ['⟨0|', '⟨1|', '|0⟩', '|1⟩', '|+⟩', '|-⟩']
SUPERPOSITION_CHARS = '⚡☄️✨⭐🌟'

def type_print(text, delay=0.03):
    """Print text with quantum typing effect"""
    for char in text:
        style = random.choice(['bold blue', 'bold cyan', 'bold magenta'])
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def quantum_encrypt(text):
    """Encrypt text using a quantum-inspired algorithm"""
    # Simple encryption for demonstration
    encoded = base64.b64encode(text.encode()).decode()
    # Add quantum noise
    quantum_noise = ''.join(random.choice(QUANTUM_STATES) for _ in range(5))
    return f"{quantum_noise}{encoded}"

def quantum_decrypt(text):
    """Decrypt quantum-encrypted text"""
    # Remove quantum noise
    encoded = text[25:]  # Remove the 5 quantum states (5 chars each)
    try:
        return base64.b64decode(encoded).decode()
    except:
        return "⟨ERROR| Quantum decoherence detected |ERROR⟩"

class QuantumNote:
    def __init__(self):
        self.notes_file = "quantum_notes.json"
        self.notes = self.load_notes()

    def load_notes(self):
        """Load quantum notes from storage"""
        if os.path.exists(self.notes_file):
            try:
                with open(self.notes_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def save_notes(self):
        """Save notes with quantum encryption"""
        with open(self.notes_file, 'w') as f:
            json.dump(self.notes, f, indent=2)

    def add_note(self, content):
        """Add a new quantum note"""
        note = {
            'id': len(self.notes) + 1,
            'content': quantum_encrypt(content),
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'state': random.choice(QUANTUM_STATES)
        }
        self.notes.append(note)
        self.save_notes()

    def display_notes(self):
        """Display notes with quantum effects"""
        console.clear()
        type_print("📝 Quantum Notes Superposition", delay=0.05)
        print()

        if not self.notes:
            console.print(Panel("Quantum void detected - No notes in superposition",
                              style="cyan",
                              title="Quantum State"))
            return

        for note in self.notes:
            # Create quantum-styled note display
            decrypted_content = quantum_decrypt(note['content'])
            quantum_border = random.choice(SUPERPOSITION_CHARS) * 3
            
            note_text = Text()
            note_text.append(f"{quantum_border} ", style="bold blue")
            note_text.append(decrypted_content, style="cyan")
            note_text.append(f" {quantum_border}", style="bold blue")
            
            panel = Panel(
                note_text,
                title=f"[bold magenta]{note['state']} Note {note['id']} {note['state']}[/]",
                subtitle=f"[bold blue]{note['timestamp']}[/]",
                box=box.DOUBLE,
                border_style="blue"
            )
            console.print(panel)
            time.sleep(0.2)  # Quantum delay between notes

def main():
    """Main quantum note-taking interface"""
    quantum_notes = QuantumNote()
    
    console.clear()
    type_print("🌌 Welcome to QuantumNote", delay=0.05)
    type_print("    Where your notes exist in superposition", delay=0.03)
    print()

    while True:
        try:
            console.print("\n[bold cyan]Quantum Commands:[/]")
            console.print("1. [magenta]Add Note[/]")
            console.print("2. [magenta]View Notes[/]")
            console.print("3. [magenta]Exit[/]")
            
            choice = input("\nEnter command (1-3): ").strip()
            
            if choice == '1':
                print("\nEnter your note (press Enter twice to finish):")
                lines = []
                while True:
                    line = input()
                    if not line:
                        break
                    lines.append(line)
                note_content = '\n'.join(lines)
                quantum_notes.add_note(note_content)
                type_print("🌠 Note collapsed into quantum storage!", delay=0.03)
                
            elif choice == '2':
                quantum_notes.display_notes()
                input("\nPress Enter to continue...")
                
            elif choice == '3':
                type_print("\n🌌 Quantum state decoherence initiated...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("🌌 Emergency quantum collapse...", delay=0.05)
            break

if __name__ == "__main__":
    main() 