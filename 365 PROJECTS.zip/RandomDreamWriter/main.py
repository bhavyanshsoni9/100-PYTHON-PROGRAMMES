import random
import time
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
import json
import os
from datetime import datetime

# Initialize Rich console
console = Console()

# Dream elements for generation
DREAM_ELEMENTS = {
    "settings": [
        "misty forest", "floating city", "crystal cave", "endless ocean",
        "neon metropolis", "ancient temple", "cosmic void", "rainbow desert",
        "paper world", "mirror maze", "cloud kingdom", "underwater library"
    ],
    "characters": [
        "wise owl", "shadow figure", "glowing child", "ancient tree",
        "star being", "crystal guardian", "time traveler", "dream weaver",
        "cosmic dancer", "memory keeper", "rainbow serpent", "void walker"
    ],
    "objects": [
        "floating lantern", "singing crystal", "memory mirror", "dream compass",
        "starlight feather", "time spiral", "reality brush", "soul gem",
        "cosmic map", "infinity hourglass", "rainbow key", "void flower"
    ],
    "events": [
        "reality shifts", "colors merge", "time reverses", "memories dance",
        "stars sing", "shadows speak", "dreams collide", "worlds blend",
        "patterns fractal", "dimensions fold", "echoes ripple", "light bends"
    ],
    "emotions": [
        "ethereal wonder", "cosmic peace", "timeless joy", "infinite curiosity",
        "dream serenity", "starlit hope", "void calm", "rainbow excitement",
        "crystal clarity", "mirror reflection", "cloud lightness", "deep mystery"
    ]
}

# Dream themes with associated elements
DREAM_THEMES = {
    "cosmic": {
        "color": "blue",
        "emoji": "🌌",
        "description": "Journey through the cosmic consciousness",
        "elements": ["cosmic void", "star being", "infinity hourglass", "stars sing", "cosmic peace"]
    },
    "nature": {
        "color": "green",
        "emoji": "🌳",
        "description": "Explore the living dreamscape",
        "elements": ["misty forest", "ancient tree", "void flower", "reality shifts", "dream serenity"]
    },
    "mystic": {
        "color": "magenta",
        "emoji": "✨",
        "description": "Discover magical realms",
        "elements": ["ancient temple", "crystal guardian", "singing crystal", "memories dance", "ethereal wonder"]
    },
    "urban": {
        "color": "yellow",
        "emoji": "🌆",
        "description": "Navigate the city of dreams",
        "elements": ["neon metropolis", "shadow figure", "floating lantern", "worlds blend", "infinite curiosity"]
    }
}

class DreamWriter:
    def __init__(self):
        self.dreams_file = "dream_sequences.json"
        self.dreams = self.load_dreams()

    def load_dreams(self):
        """Load saved dream sequences"""
        if os.path.exists(self.dreams_file):
            try:
                with open(self.dreams_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def save_dreams(self):
        """Save dream sequences"""
        with open(self.dreams_file, 'w') as f:
            json.dump(self.dreams, f, indent=2)

    def generate_dream_sequence(self, theme=None):
        """Generate a creative dream sequence"""
        if theme:
            theme_info = DREAM_THEMES[theme]
            elements = theme_info['elements']
        else:
            elements = []
            for category in DREAM_ELEMENTS.values():
                elements.append(random.choice(category))
        
        # Create dream narrative
        narrative = self.create_narrative(elements)
        
        dream = {
            'id': len(self.dreams) + 1,
            'theme': theme,
            'narrative': narrative,
            'elements': elements,
            'created': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.dreams.append(dream)
        self.save_dreams()
        return dream

    def create_narrative(self, elements):
        """Create a surreal narrative from dream elements"""
        # Template sentences for variety
        templates = [
            "In a {setting}, a {character} discovers a {object} that {event}, filling them with {emotion}.",
            "As {event} in the {setting}, the {character} follows a {object}, experiencing {emotion}.",
            "The {character} wanders through a {setting}, where {object} creates {event}, leading to {emotion}.",
            "Within the {setting}, {event} reveals a {character} holding a {object}, radiating {emotion}.",
            "A {object} guides the {character} through a {setting} where {event}, awakening {emotion}."
        ]
        
        # Map elements to template placeholders
        element_map = {
            'setting': elements[0],
            'character': elements[1],
            'object': elements[2],
            'event': elements[3],
            'emotion': elements[4]
        }
        
        # Generate multiple sentences for a longer narrative
        narrative = []
        for _ in range(3):  # Create 3 connected sentences
            template = random.choice(templates)
            sentence = template.format(**element_map)
            narrative.append(sentence)
            
            # Shuffle some elements for variety in next sentence
            random.shuffle(elements)
            element_map = {
                'setting': elements[0],
                'character': elements[1],
                'object': elements[2],
                'event': elements[3],
                'emotion': elements[4]
            }
        
        return " ".join(narrative)

def type_print(text, delay=0.03):
    """Print text with dreamy effect"""
    for char in text:
        style = random.choice(['bold cyan', 'bold blue', 'bold magenta'])
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def create_dream_panel(dream):
    """Create a dreamy styled panel"""
    if dream['theme']:
        theme_info = DREAM_THEMES[dream['theme']]
        color = theme_info['color']
        emoji = theme_info['emoji']
    else:
        color = random.choice(['cyan', 'blue', 'magenta', 'green'])
        emoji = random.choice(['🌌', '✨', '🌙', '⭐'])
    
    text = Text()
    text.append(f"{emoji} Dream Sequence #{dream['id']}\n\n", style=f"bold {color}")
    text.append(dream['narrative'], style="white")
    
    return Panel(
        text,
        title=f"[{color}]Dream Vision[/]",
        subtitle=f"[dim]{dream['created']}[/]",
        border_style=color
    )

def display_dream_themes():
    """Display available dream themes"""
    table = Table(title="[bold]Dream Themes[/]")
    table.add_column("Theme", style="cyan")
    table.add_column("Description", style="white")
    
    for theme, info in DREAM_THEMES.items():
        table.add_row(
            f"{info['emoji']} {theme.title()}",
            info['description']
        )
    
    console.print(table)

def simulate_dream_generation():
    """Create a dream generation animation"""
    dream_symbols = '✨ 🌙 ⭐ 🌌 💫'
    
    with Progress() as progress:
        task = progress.add_task("[cyan]Weaving dream sequence...[/]", total=100)
        
        while not progress.finished:
            for symbol in dream_symbols:
                console.print(f"\r{symbol}", end='')
                progress.update(task, advance=5)
                time.sleep(0.1)
    print()

def main():
    """Main program with dreamy interface"""
    dream_writer = DreamWriter()
    console.clear()
    
    type_print("✨ Welcome to RandomDreamWriter", delay=0.05)
    type_print("   Where Dreams Come to Life", delay=0.03)
    print()
    
    while True:
        try:
            console.print("\n[bold cyan]Dream Operations:[/]")
            console.print("1. [white]Generate Dream Sequence[/]")
            console.print("2. [white]View Dream Collection[/]")
            console.print("3. [white]Generate Themed Dream[/]")
            console.print("4. [white]Exit[/]")
            
            choice = input("\nSelect operation (1-4): ").strip()
            
            if choice == '1':
                simulate_dream_generation()
                dream = dream_writer.generate_dream_sequence()
                console.print(create_dream_panel(dream))
                type_print("\n✨ Dream sequence has manifested!", delay=0.03)
                
            elif choice == '2':
                console.clear()
                type_print("✨ Entering the Dream Archive", delay=0.03)
                print()
                
                if not dream_writer.dreams:
                    console.print(Panel("No dreams have been recorded yet...",
                                      style="dim",
                                      title="Dream Archive"))
                else:
                    for dream in dream_writer.dreams:
                        console.print(create_dream_panel(dream))
                        time.sleep(0.5)  # Dreamy pause between sequences
                
                input("\nPress Enter to return to reality...")
                
            elif choice == '3':
                console.clear()
                display_dream_themes()
                theme = input("\nEnter dream theme: ").lower()
                
                if theme in DREAM_THEMES:
                    simulate_dream_generation()
                    dream = dream_writer.generate_dream_sequence(theme)
                    console.print(create_dream_panel(dream))
                    type_print("\n✨ Themed dream has materialized!", delay=0.03)
                else:
                    console.print("[red]Invalid dream theme.[/]")
                
            elif choice == '4':
                type_print("\n✨ Returning to waking reality...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("✨ Dream sequence interrupted...", delay=0.05)
            break

if __name__ == "__main__":
    main() 