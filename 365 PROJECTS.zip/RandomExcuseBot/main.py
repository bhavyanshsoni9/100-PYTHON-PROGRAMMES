import random
from rich.console import Console
from rich.panel import Panel
from datetime import datetime

console = Console()

EXCUSES = {
    "work": [
        "My code achieved sentience and needed emotional support",
        "Got stuck in a git merge conflict time loop",
        "My keyboard turned into a cat temporarily",
        "My rubber duck debugger went rogue",
        "Quantum entanglement affected my alarm clock"
    ],
    "social": [
        "Training my AI assistant to make better excuses",
        "Had to debug my coffee maker's firmware",
        "My clone called in sick so I had to fill in",
        "Accidentally entered the wrong timeline",
        "My virtual pet needed emergency attention"
    ],
    "deadline": [
        "The cloud was full",
        "Mercury was in retrograde in my database",
        "My neural network needed a mental health day",
        "The code compiled too successfully, seemed suspicious",
        "Had to recalibrate my procrastination algorithm"
    ]
}

def generate_excuse(category=None):
    """Generate a random creative excuse"""
    if not category:
        category = random.choice(list(EXCUSES.keys()))
    return random.choice(EXCUSES[category])

def main():
    console.clear()
    console.print("[bold cyan]🤖 RandomExcuseBot[/]")
    console.print("[cyan]Your AI-Powered Excuse Generator[/]\n")

    while True:
        console.print("\n[bold cyan]Categories:[/]")
        console.print("1. Work Excuses")
        console.print("2. Social Excuses")
        console.print("3. Deadline Excuses")
        console.print("4. Random Excuse")
        console.print("5. Exit")

        choice = input("\nSelect category (1-5): ").strip()

        if choice == '5':
            console.print("\n[cyan]Goodbye! Remember to use excuses responsibly! 😉[/]")
            break

        category = None
        if choice == '1': category = 'work'
        elif choice == '2': category = 'social'
        elif choice == '3': category = 'deadline'

        excuse = generate_excuse(category)
        panel = Panel(excuse, title="[bold cyan]Your Excuse[/]", border_style="cyan")
        console.print("\n", panel)
        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 