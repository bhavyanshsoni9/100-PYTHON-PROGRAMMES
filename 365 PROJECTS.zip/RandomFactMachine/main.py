from rich.console import Console
from rich.panel import Panel
import random
import time

console = Console()

FACTS = {
    "tech": [
        "The first computer mouse was made of wood",
        "The first computer virus was created in 1983",
        "The first tweet was sent in 2006",
        "The first YouTube video was uploaded in 2005",
        "The term 'bug' in computing came from an actual moth"
    ],
    "science": [
        "Honey never spoils",
        "A day on Venus is longer than its year",
        "Bananas are berries, but strawberries aren't",
        "Octopuses have three hearts",
        "A cloud can weigh over a million pounds"
    ],
    "random": [
        "Cows have best friends",
        "The shortest war in history lasted 38 minutes",
        "A group of flamingos is called a flamboyance",
        "The moon has moonquakes",
        "Sloths can hold their breath for 40 minutes underwater"
    ]
}

def get_random_fact(category=None):
    """Get a random fact from the specified category or any category"""
    if not category:
        category = random.choice(list(FACTS.keys()))
    return random.choice(FACTS[category])

def main():
    console.clear()
    console.print("[bold magenta]🎲 RandomFactMachine[/]")
    console.print("[magenta]Your Daily Dose of Random Knowledge[/]\n")

    while True:
        console.print("\n[bold magenta]Categories:[/]")
        console.print("1. Tech Facts")
        console.print("2. Science Facts")
        console.print("3. Random Facts")
        console.print("4. Surprise Me!")
        console.print("5. Exit")

        choice = input("\nSelect category (1-5): ").strip()

        if choice == '5':
            console.print("\n[magenta]Thanks for learning with RandomFactMachine! 🧠[/]")
            break

        category = None
        if choice == '1': category = 'tech'
        elif choice == '2': category = 'science'
        elif choice == '3': category = 'random'

        fact = get_random_fact(category)
        panel = Panel(f"[italic]{fact}[/]", title="[bold magenta]Did You Know?[/]", border_style="magenta")
        console.print("\n", panel)
        input("\nPress Enter for another fact...")

if __name__ == "__main__":
    main() 