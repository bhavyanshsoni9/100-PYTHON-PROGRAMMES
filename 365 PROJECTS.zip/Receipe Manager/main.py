recipes = {}

def add_recipe(name, ingredients):
    recipes[name] = ingredients
    print(f"Recipe '{name}' added.")

def search_recipe(name):
    if name in recipes:
        print(f"Ingredients for {name}: {recipes[name]}")
    else:
        print("Recipe not found.")

def main():
    print("=== Recipe Manager ===")
    while True:
        choice = input("1. Add Recipe\n2. Search Recipe\n3. Exit\n> ")
        if choice == '1':
            name = input("Recipe name: ")
            ingredients = input("Ingredients (comma separated): ").split(",")
            ingredients = [i.strip() for i in ingredients]
            add_recipe(name, ingredients)
        elif choice == '2':
            name = input("Recipe name to search: ")
            search_recipe(name)
        elif choice == '3':
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
