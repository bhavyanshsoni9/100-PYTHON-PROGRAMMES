import datetime
import os

def generate_receipt():
    shop_name = "🛒 Bhavyansh Mart"
    gst_rate = 0.18  # 18% GST
    items = []

    print(f"\nWelcome to {shop_name}")
    customer = input("Enter Customer Name: ")

    while True:
        name = input("Item Name: ")
        qty = int(input("Quantity: "))
        price = float(input("Price per unit: ₹"))

        items.append((name, qty, price))

        cont = input("Add more items? (y/n): ")
        if cont.lower() != 'y':
            break

    subtotal = sum(qty * price for name, qty, price in items)
    gst = subtotal * gst_rate
    grand_total = subtotal + gst

    # Generate receipt content
    now = datetime.datetime.now()
    invoice_no = now.strftime("%Y_%m_%d_%H_%M_%S")
    filename = f"receipt.txt"

    receipt_lines = []
    receipt_lines.append("="*40)
    receipt_lines.append(f"         {shop_name}")
    receipt_lines.append(f"Invoice No: {invoice_no}")
    receipt_lines.append(f"Customer: {customer}")
    receipt_lines.append(f"Date: {now.strftime('%Y-%m-%d %H:%M')}")
    receipt_lines.append("="*40)
    receipt_lines.append(f"{'Item':<15}{'Qty':<5}{'Price':<10}{'Total'}")
    receipt_lines.append("-"*40)

    for name, qty, price in items:
        total = qty * price
        receipt_lines.append(f"{name:<15}{qty:<5}{price:<10.2f}{total:.2f}")

    receipt_lines.append("-"*40)
    receipt_lines.append(f"{'Subtotal':<30}₹{subtotal:.2f}")
    receipt_lines.append(f"{'GST (18%)':<30}₹{gst:.2f}")
    receipt_lines.append(f"{'Grand Total':<30}₹{grand_total:.2f}")
    receipt_lines.append("="*40)
    receipt_lines.append("Thank you for shopping with us!")
    receipt_lines.append("="*40)

    # Show on terminal
    receipt = "\n".join(receipt_lines) + "\n"*4
    print("\n".join(receipt_lines))

    # Save to file
    with open(filename, 'a',encoding='utf-8') as f:
        f.write(receipt)

    print(f"\n✅ Receipt saved as: {filename}")

# Run the generator
generate_receipt()
