import datetime

def add_receipt():
    item = input("Item Name: ")
    date = input("Purchase Date (YYYY-MM-DD): ")
    warranty = int(input("Warranty period in months: "))
    expiry = datetime.datetime.strptime(date, "%Y-%m-%d") + datetime.timedelta(days=warranty*30)
    with open("receipts.txt", "a") as f:
        f.write(f"{item} | {date} | {expiry.date()}\n")
    print("Receipt added.")

def view_receipts():
    print("\nSaved Receipts:")
    try:
        with open("receipts.txt", "r") as f:
            print(f.read())
    except FileNotFoundError:
        print("No receipts found.")

def main():
    while True:
        choice = input("\n1. Add Receipt\n2. View Receipts\n3. Exit\nChoose: ")
        if choice == '1':
            add_receipt()
        elif choice == '2':
            view_receipts()
        elif choice == '3':
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()