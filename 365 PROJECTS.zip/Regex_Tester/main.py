import re
import time
import sys

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
CYAN = '\033[96m'
RESET = '\033'
BOLD = '\033[1m'

SUCCESS_EMOJI = '✅'
FAIL_EMOJI = '❌'
INFO_EMOJI = 'ℹ️'


def print_colored(text, color, emoji=None, end='\n'):
    prefix = f"{color}{BOLD}"
    suffix = RESET
    if emoji:
        print(f"{prefix}{emoji} {text}{suffix}", end=end)
    else:
        print(f"{prefix}{text}{suffix}", end=end)


def main():
    print_colored("Welcome to the Offline Regex Tester!", CYAN, INFO_EMOJI)
    time.sleep(0.7)
    while True:
        print_colored("\nEnter your regex pattern (or type 'exit' to quit):", YELLOW, INFO_EMOJI, end=' ')
        pattern = input()
        if pattern.lower() == 'exit':
            print_colored("Goodbye! Happy regexing!", CYAN, SUCCESS_EMOJI)
            break
        print_colored("Enter the test string:", YELLOW, INFO_EMOJI, end=' ')
        test_string = input()
        time.sleep(0.5)
        try:
            regex = re.compile(pattern)
            print_colored("Regex compiled successfully!", GREEN, SUCCESS_EMOJI)
            time.sleep(0.5)
        except re.error as e:
            print_colored(f"Regex compilation error: {e}", RED, FAIL_EMOJI)
            time.sleep(0.7)
            continue
        matches = list(regex.finditer(test_string))
        if matches:
            print_colored(f"{len(matches)} match(es) found:", GREEN, SUCCESS_EMOJI)
            for i, match in enumerate(matches, 1):
                span = match.span()
                print_colored(f"  {i}. '{match.group()}' at {span}", GREEN)
                time.sleep(0.2)
        else:
            print_colored("No matches found.", RED, FAIL_EMOJI)
        time.sleep(0.7)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0) 