import os
import shutil
import time
from datetime import datetime
from colorama import init, Fore, Style
import emoji

init(autoreset=True)

SCREENSHOTS_DIR = os.getcwd()  # Current directory
SCREENSHOT_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.bmp']


def is_screenshot(filename):
    return any(filename.lower().endswith(ext) for ext in SCREENSHOT_EXTENSIONS)


def organize_by_date():
    print(Fore.CYAN + emoji.emojize(':calendar: Organizing by date...'))
    time.sleep(1)
    for file in os.listdir(SCREENSHOTS_DIR):
        if is_screenshot(file):
            file_path = os.path.join(SCREENSHOTS_DIR, file)
            mod_time = os.path.getmtime(file_path)
            date_folder = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d')
            target_folder = os.path.join(SCREENSHOTS_DIR, date_folder)
            if not os.path.exists(target_folder):
                os.makedirs(target_folder)
                print(Fore.GREEN + emoji.emojize(':file_folder: Created folder: ') + date_folder)
                time.sleep(0.5)
            shutil.move(file_path, os.path.join(target_folder, file))
            print(Fore.YELLOW + emoji.emojize(':arrow_right: Moved') + f' {file} -> {date_folder}/')
            time.sleep(0.5)
    print(Fore.GREEN + emoji.emojize(':check_mark_button: Done organizing by date!'))


def organize_by_project():
    print(Fore.CYAN + emoji.emojize(':briefcase: Organizing by project...'))
    time.sleep(1)
    for file in os.listdir(SCREENSHOTS_DIR):
        if is_screenshot(file):
            print(Fore.MAGENTA + f"Enter project name for {file} (or leave blank to skip): ", end='')
            project = input()
            if not project:
                print(Fore.RED + emoji.emojize(':cross_mark: Skipped') + f' {file}')
                continue
            target_folder = os.path.join(SCREENSHOTS_DIR, project)
            if not os.path.exists(target_folder):
                os.makedirs(target_folder)
                print(Fore.GREEN + emoji.emojize(':file_folder: Created folder: ') + project)
                time.sleep(0.5)
            shutil.move(os.path.join(SCREENSHOTS_DIR, file), os.path.join(target_folder, file))
            print(Fore.YELLOW + emoji.emojize(':arrow_right: Moved') + f' {file} -> {project}/')
            time.sleep(0.5)
    print(Fore.GREEN + emoji.emojize(':check_mark_button: Done organizing by project!'))


def main():
    print(Fore.BLUE + Style.BRIGHT + emoji.emojize(':camera: Screenshot Organizer'))
    print(Fore.BLUE + '1. Organize by date')
    print(Fore.BLUE + '2. Organize by project')
    choice = input(Fore.CYAN + 'Choose an option (1/2): ')
    if choice == '1':
        organize_by_date()
    elif choice == '2':
        organize_by_project()
    else:
        print(Fore.RED + emoji.emojize(':cross_mark: Invalid choice!'))

if __name__ == '__main__':
    main() 