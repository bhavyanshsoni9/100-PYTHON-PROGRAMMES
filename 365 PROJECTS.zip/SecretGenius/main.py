from rich.console import Console
from rich.panel import Panel
import random
import string
import secrets

console = Console()

def generate_password(length=16, use_special=True):
    """Generate a secure password"""
    chars = string.ascii_letters + string.digits
    if use_special:
        chars += string.punctuation
    return ''.join(secrets.choice(chars) for _ in range(length))

def generate_codename():
    """Generate a cool codename"""
    adjectives = ["Shadow", "Quantum", "Cyber", "Stealth", "Ghost", "Echo", "Void", "Neon"]
    nouns = ["Phoenix", "Dragon", "Nexus", "Matrix", "Vector", "Cipher", "Pulse", "Nova"]
    return f"{random.choice(adjectives)}{random.choice(nouns)}"

def generate_secret_key():
    """Generate a secure secret key"""
    return secrets.token_urlsafe(32)

def main():
    console.clear()
    console.print("[bold green]🧠 SecretGenius[/]")
    console.print("[green]Your Secure Code Generator[/]\n")

    while True:
        console.print("\n[bold green]Generate:[/]")
        console.print("1. Secure Password")
        console.print("2. Cool Codename")
        console.print("3. Secret Key")
        console.print("4. Exit")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == '4':
            console.print("\n[green]Secrets safe! Goodbye! 🔒[/]")
            break

        if choice == '1':
            length = input("\nPassword length (default 16): ").strip()
            length = int(length) if length.isdigit() else 16
            special = input("Include special characters? (y/n): ").lower() == 'y'
            result = generate_password(length, special)
            title = "Secure Password"
        
        elif choice == '2':
            result = generate_codename()
            title = "Your Codename"
        
        elif choice == '3':
            result = generate_secret_key()
            title = "Secret Key"

        panel = Panel(result, title=f"[bold green]{title}[/]", border_style="green")
        console.print("\n", panel)
        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 