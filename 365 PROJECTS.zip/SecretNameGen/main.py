from rich.console import Console
from rich.panel import Panel
import random

console = Console()

class NameGenerator:
    def __init__(self):
        self.themes = {
            'cyber': {
                'prefixes': ['Cyber', 'Digital', 'Binary', 'Neural', 'Quantum', 'Vector', 'Pixel', 'Data'],
                'suffixes': ['Node', 'Core', 'Mind', 'Net', 'Pulse', 'Wave', 'Byte', 'Stream']
            },
            'nature': {
                'prefixes': ['Storm', 'Thunder', 'Shadow', 'Night', 'Frost', 'Wind', 'Star', 'Moon'],
                'suffixes': ['Wolf', 'Hawk', 'Phoenix', 'Dragon', 'Tiger', 'Eagle', 'Lion', 'Bear']
            },
            'mystic': {
                'prefixes': ['Mystic', 'Arcane', 'Astral', 'Ethereal', 'Crystal', 'Spirit', 'Dream', 'Soul'],
                'suffixes': ['Weaver', 'Walker', 'Seeker', 'Sage', 'Mage', 'Seer', 'Guard', 'Knight']
            },
            'stealth': {
                'prefixes': ['Silent', 'Hidden', 'Ghost', 'Phantom', 'Shadow', 'Void', 'Dark', 'Night'],
                'suffixes': ['Blade', 'Strike', 'Stalker', 'Hunter', 'Wraith', 'Shade', 'Watcher', 'Agent']
            }
        }
        
        self.titles = {
            'cyber': ['Protocol', 'Algorithm', 'Function', 'System', 'Program', 'Interface'],
            'nature': ['Guardian', 'Protector', 'Master', 'Keeper', 'Lord', 'Champion'],
            'mystic': ['Oracle', 'Prophet', 'Elder', 'Master', 'Keeper', 'Wielder'],
            'stealth': ['Operative', 'Agent', 'Assassin', 'Infiltrator', 'Spy', 'Scout']
        }

    def generate_name(self, theme=None, use_title=False):
        """Generate a random name based on theme"""
        if not theme:
            theme = random.choice(list(self.themes.keys()))
        
        prefix = random.choice(self.themes[theme]['prefixes'])
        suffix = random.choice(self.themes[theme]['suffixes'])
        name = f"{prefix}{suffix}"
        
        if use_title:
            title = random.choice(self.titles[theme])
            name = f"{name} the {title}"
        
        return name, theme

def main():
    console.clear()
    console.print("[bold yellow]🎭 SecretNameGen[/]")
    console.print("[yellow]Codename Generator Extraordinaire[/]\n")

    generator = NameGenerator()

    while True:
        console.print("\n[bold yellow]Themes:[/]")
        console.print("1. Cyberpunk")
        console.print("2. Nature")
        console.print("3. Mystic")
        console.print("4. Stealth")
        console.print("5. Random")
        console.print("6. Exit")

        choice = input("\nSelect theme (1-6): ").strip()

        if choice == '6':
            console.print("\n[yellow]Your secret identity is safe with me! 🎭[/]")
            break

        theme = None
        if choice == '1': theme = 'cyber'
        elif choice == '2': theme = 'nature'
        elif choice == '3': theme = 'mystic'
        elif choice == '4': theme = 'stealth'

        use_title = input("\nAdd a title? (y/n): ").lower() == 'y'
        count = input("How many names to generate? (1-5): ").strip()
        count = min(max(1, int(count) if count.isdigit() else 1), 5)

        console.print("\n[yellow]Generating your secret identities...[/]")
        for _ in range(count):
            name, used_theme = generator.generate_name(theme, use_title)
            panel = Panel(
                name,
                title=f"[bold yellow]{used_theme.title()} Theme[/]",
                border_style="yellow"
            )
            console.print(panel)

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 