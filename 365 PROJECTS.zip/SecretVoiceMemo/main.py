from rich.console import Console
from rich.panel import Panel
import os
import json
from datetime import datetime
from cryptography.fernet import Fernet
import base64
import pyttsx3

console = Console()

class SecretVoiceMemo:
    def __init__(self):
        self.data_file = "voice_memos.dat"
        self.key_file = "voice.key"
        self._init_encryption()
        self.memos = self._load_memos()
        self.engine = pyttsx3.init()

    def _init_encryption(self):
        """Initialize or load encryption key"""
        if os.path.exists(self.key_file):
            with open(self.key_file, 'rb') as f:
                self.key = f.read()
        else:
            self.key = Fernet.generate_key()
            with open(self.key_file, 'wb') as f:
                f.write(self.key)
        self.cipher = Fernet(self.key)

    def _load_memos(self):
        """Load encrypted memos from file"""
        if not os.path.exists(self.data_file):
            return []
        try:
            with open(self.data_file, 'rb') as f:
                encrypted_data = f.read()
                if encrypted_data:
                    data = self.cipher.decrypt(encrypted_data)
                    return json.loads(data)
        except:
            return []
        return []

    def _save_memos(self):
        """Save memos to encrypted file"""
        encrypted_data = self.cipher.encrypt(json.dumps(self.memos).encode())
        with open(self.data_file, 'wb') as f:
            f.write(encrypted_data)

    def add_memo(self, text, title):
        """Add a new voice memo"""
        memo = {
            'text': text,
            'title': title,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'id': base64.urlsafe_b64encode(os.urandom(8)).decode()
        }
        self.memos.append(memo)
        self._save_memos()
        return memo['id']

    def get_memos(self):
        """Get all memos"""
        return self.memos

    def delete_memo(self, memo_id):
        """Delete a memo by ID"""
        self.memos = [m for m in self.memos if m['id'] != memo_id]
        self._save_memos()

    def play_memo(self, text):
        """Play memo using text-to-speech"""
        self.engine.say(text)
        self.engine.runAndWait()

def main():
    console.clear()
    console.print("[bold red]🎙️ SecretVoiceMemo[/]")
    console.print("[red]Encrypted Voice Memo System[/]\n")

    memo = SecretVoiceMemo()

    while True:
        console.print("\n[bold red]Options:[/]")
        console.print("1. Create new memo")
        console.print("2. List all memos")
        console.print("3. Play memo")
        console.print("4. Delete memo")
        console.print("5. Exit")

        choice = input("\nSelect option (1-5): ").strip()

        if choice == '5':
            console.print("\n[red]Your voice memos are sealed... 🤫[/]")
            break

        if choice == '1':
            title = input("\nMemo title: ").strip()
            text = input("Memo text: ").strip()
            memo_id = memo.add_memo(text, title)
            console.print(f"\n[red]Memo stored with ID: {memo_id}[/]")

        elif choice == '2':
            messages = memo.get_memos()
            if messages:
                for msg in messages:
                    panel = Panel(
                        f"[bold]Title:[/] {msg['title']}\n[bold]Text:[/] {msg['text']}\n"
                        f"[bold]Time:[/] {msg['timestamp']}\n[bold]ID:[/] {msg['id']}",
                        title="[bold red]Voice Memo[/]",
                        border_style="red"
                    )
                    console.print(panel)
            else:
                console.print("\n[red]No memos found[/]")

        elif choice == '3':
            messages = memo.get_memos()
            if messages:
                for i, msg in enumerate(messages, 1):
                    console.print(f"{i}. {msg['title']}")
                try:
                    idx = int(input("\nSelect memo number to play: ")) - 1
                    if 0 <= idx < len(messages):
                        console.print("\n[red]Playing memo...[/]")
                        memo.play_memo(messages[idx]['text'])
                    else:
                        console.print("\n[red]Invalid selection[/]")
                except:
                    console.print("\n[red]Invalid input[/]")
            else:
                console.print("\n[red]No memos to play[/]")

        elif choice == '4':
            memo_id = input("\nMemo ID to delete: ").strip()
            memo.delete_memo(memo_id)
            console.print("\n[red]Memo deleted if it existed[/]")

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 