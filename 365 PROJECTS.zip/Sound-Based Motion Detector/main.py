import sounddevice as sd
import numpy as np
import os
import platform
import time

# Settings
duration = 3  # seconds to record each time
threshold = 0.3  # adjust clap detection threshold (0 to 1)

def detect_clap(indata, frames, time_info, status):
    volume_norm = np.linalg.norm(indata) * 10
    print(f"Volume: {volume_norm}")  # uncomment to debug volume levels

    if volume_norm > threshold:
        print("👏 Clap detected! Locking screen...")
        lock_screen()
        # To avoid multiple triggers
        time.sleep(2)

def lock_screen():
    system = platform.system()
    if system == "Windows":
        os.system("rundll32.exe user32.dll,LockWorkStation")
    elif system == "Linux":
        os.system("gnome-screensaver-command -l")
    elif system == "Darwin":  # macOS
        os.system("/System/Library/CoreServices/Menu\\ Extras/User.menu/Contents/Resources/CGSession -suspend")
    else:
        print("Screen lock not supported on this OS.")

print("🎙️ Clap Detector is ON. Clap near your mic to lock the screen.")

with sd.InputStream(callback=detect_clap, channels=1, samplerate=44100):
    while True:
        sd.sleep(1000)
