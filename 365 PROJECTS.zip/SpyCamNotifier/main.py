from rich.console import Console
from rich.panel import Panel
import cv2
import time
import threading
import json
import os
from datetime import datetime
from plyer import notification

console = Console()

class SpyCamNotifier:
    def __init__(self):
        self.config_file = "spycam_config.json"
        self.config = self._load_config()
        self._running = False
        self._camera = None
        self._thread = None

    def _load_config(self):
        """Load configuration"""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                return json.load(f)
        return {
            'notification_interval': 5,
            'sensitivity': 2500,
            'camera_index': 0,
            'history': []
        }

    def _save_config(self):
        """Save configuration"""
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)

    def _notify(self, title, message):
        """Send desktop notification"""
        try:
            notification.notify(
                title=title,
                message=message,
                app_icon=None,
                timeout=10,
            )
        except:
            pass

    def _detect_motion(self, frame1, frame2):
        """Detect motion between frames"""
        diff = cv2.absdiff(frame1, frame2)
        gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
        dilated = cv2.dilate(thresh, None, iterations=3)
        contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            if cv2.contourArea(contour) > self.config['sensitivity']:
                return True
        return False

    def start_monitoring(self):
        """Start camera monitoring"""
        if self._running:
            return False, "Already monitoring"

        try:
            self._camera = cv2.VideoCapture(self.config['camera_index'])
            if not self._camera.isOpened():
                return False, "Failed to open camera"

            self._running = True
            self._thread = threading.Thread(target=self._monitor_loop)
            self._thread.daemon = True
            self._thread.start()
            
            return True, "Monitoring started"
        except Exception as e:
            return False, f"Error: {str(e)}"

    def stop_monitoring(self):
        """Stop camera monitoring"""
        self._running = False
        if self._camera:
            self._camera.release()
        if self._thread:
            self._thread.join()
        return True, "Monitoring stopped"

    def _monitor_loop(self):
        """Main monitoring loop"""
        last_notification = 0
        _, frame1 = self._camera.read()
        
        while self._running:
            _, frame2 = self._camera.read()
            
            if frame2 is None:
                break

            if self._detect_motion(frame1, frame2):
                current_time = time.time()
                if current_time - last_notification > self.config['notification_interval']:
                    self._notify(
                        "Motion Detected!",
                        f"Activity detected at {datetime.now().strftime('%H:%M:%S')}"
                    )
                    last_notification = current_time
                    
                    self.config['history'].append({
                        'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'type': 'motion'
                    })
                    self._save_config()

            frame1 = frame2
            time.sleep(0.1)

    def update_settings(self, interval=None, sensitivity=None, camera_index=None):
        """Update monitor settings"""
        if interval is not None:
            self.config['notification_interval'] = interval
        if sensitivity is not None:
            self.config['sensitivity'] = sensitivity
        if camera_index is not None:
            self.config['camera_index'] = camera_index
        self._save_config()

def main():
    console.clear()
    console.print("[bold red]👁️ SpyCamNotifier[/]")
    console.print("[red]Webcam Activity Monitor[/]\n")

    monitor = SpyCamNotifier()

    while True:
        console.print("\n[bold red]Options:[/]")
        console.print("1. Start Monitoring")
        console.print("2. Stop Monitoring")
        console.print("3. Update Settings")
        console.print("4. View History")
        console.print("5. Exit")

        choice = input("\nSelect option (1-5): ").strip()

        if choice == '5':
            if monitor._running:
                monitor.stop_monitoring()
            console.print("\n[red]Monitoring system deactivated! 👋[/]")
            break

        if choice == '1':
            success, message = monitor.start_monitoring()
            if success:
                console.print(f"\n[green]{message}[/]")
            else:
                console.print(f"\n[red]{message}[/]")

        elif choice == '2':
            success, message = monitor.stop_monitoring()
            if success:
                console.print(f"\n[green]{message}[/]")
            else:
                console.print(f"\n[red]{message}[/]")

        elif choice == '3':
            console.print("\nCurrent settings:")
            for key, value in monitor.config.items():
                if key != 'history':
                    console.print(f"[bold]{key}:[/] {value}")
            
            try:
                interval = input("\nNotification interval (seconds, press Enter to skip): ").strip()
                interval = float(interval) if interval else None
                
                sensitivity = input("Motion sensitivity (press Enter to skip): ").strip()
                sensitivity = int(sensitivity) if sensitivity else None
                
                camera = input("Camera index (press Enter to skip): ").strip()
                camera = int(camera) if camera else None
                
                monitor.update_settings(interval, sensitivity, camera)
                console.print("\n[green]Settings updated![/]")
            except:
                console.print("\n[red]Invalid input![/]")

        elif choice == '4':
            if monitor.config['history']:
                for event in monitor.config['history']:
                    panel = Panel(
                        f"[bold]Type:[/] {event['type']}\n[bold]Time:[/] {event['time']}",
                        title="[bold red]Activity Event[/]",
                        border_style="red"
                    )
                    console.print(panel)
            else:
                console.print("\n[yellow]No activity history![/]")

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 