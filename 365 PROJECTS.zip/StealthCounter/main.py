from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import json
import os
from datetime import datetime, timedelta
import time
import threading

console = Console()

class StealthCounter:
    def __init__(self):
        self.data_file = "counter_data.json"
        self.data = self._load_data()
        self._running = False
        self._current_timer = None
        self._lock = threading.Lock()

    def _load_data(self):
        """Load counter data"""
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                return json.load(f)
        return {'counters': {}, 'timers': {}}

    def _save_data(self):
        """Save counter data"""
        with open(self.data_file, 'w') as f:
            json.dump(self.data, f, indent=2)

    def create_counter(self, name, description=""):
        """Create a new counter"""
        self.data['counters'][name] = {
            'count': 0,
            'description': description,
            'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'history': []
        }
        self._save_data()

    def increment_counter(self, name, amount=1):
        """Increment a counter"""
        if name in self.data['counters']:
            self.data['counters'][name]['count'] += amount
            self.data['counters'][name]['history'].append({
                'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'change': amount
            })
            self._save_data()
            return True
        return False

    def start_timer(self, name):
        """Start a stealth timer"""
        with self._lock:
            self.data['timers'][name] = {
                'start': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'end': None,
                'duration': 0
            }
            self._save_data()
            self._current_timer = name
            self._running = True
            
            def update_timer():
                while self._running and self._current_timer == name:
                    with self._lock:
                        start = datetime.strptime(self.data['timers'][name]['start'], '%Y-%m-%d %H:%M:%S')
                        self.data['timers'][name]['duration'] = (datetime.now() - start).total_seconds()
                        self._save_data()
                    time.sleep(1)
            
            thread = threading.Thread(target=update_timer)
            thread.daemon = True
            thread.start()

    def stop_timer(self, name):
        """Stop a stealth timer"""
        with self._lock:
            if name in self.data['timers'] and self.data['timers'][name]['end'] is None:
                self._running = False
                self.data['timers'][name]['end'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                self._save_data()
                return True
        return False

    def get_stats(self):
        """Get counter and timer statistics"""
        stats = {
            'counters': len(self.data['counters']),
            'timers': len(self.data['timers']),
            'total_counts': sum(c['count'] for c in self.data['counters'].values()),
            'active_timers': sum(1 for t in self.data['timers'].values() if t['end'] is None)
        }
        return stats

def format_duration(seconds):
    """Format duration in seconds to readable string"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

def main():
    console.clear()
    console.print("[bold red]🕵️ StealthCounter[/]")
    console.print("[red]Silent Activity Tracking System[/]\n")

    counter = StealthCounter()

    while True:
        console.print("\n[bold red]Options:[/]")
        console.print("1. Create Counter")
        console.print("2. Increment Counter")
        console.print("3. Start Timer")
        console.print("4. Stop Timer")
        console.print("5. View Statistics")
        console.print("6. Exit")

        choice = input("\nSelect option (1-6): ").strip()

        if choice == '6':
            console.print("\n[red]Counters hidden... 🤫[/]")
            break

        if choice == '1':
            name = input("\nCounter name: ").strip()
            desc = input("Description (optional): ").strip()
            counter.create_counter(name, desc)
            console.print("\n[green]Counter created![/]")

        elif choice == '2':
            if counter.data['counters']:
                console.print("\n[bold]Available Counters:[/]")
                for name in counter.data['counters']:
                    count = counter.data['counters'][name]['count']
                    console.print(f"- {name}: {count}")
                
                name = input("\nEnter counter name: ").strip()
                try:
                    amount = int(input("Increment by (default 1): ").strip() or 1)
                    if counter.increment_counter(name, amount):
                        console.print("\n[green]Counter updated![/]")
                    else:
                        console.print("\n[red]Counter not found![/]")
                except:
                    console.print("\n[red]Invalid amount![/]")
            else:
                console.print("\n[yellow]No counters available![/]")

        elif choice == '3':
            name = input("\nTimer name: ").strip()
            counter.start_timer(name)
            console.print("\n[green]Timer started![/]")

        elif choice == '4':
            if counter.data['timers']:
                console.print("\n[bold]Active Timers:[/]")
                for name, timer in counter.data['timers'].items():
                    if timer['end'] is None:
                        duration = format_duration(timer['duration'])
                        console.print(f"- {name}: {duration}")
                
                name = input("\nEnter timer name to stop: ").strip()
                if counter.stop_timer(name):
                    console.print("\n[green]Timer stopped![/]")
                else:
                    console.print("\n[red]Timer not found or already stopped![/]")
            else:
                console.print("\n[yellow]No active timers![/]")

        elif choice == '5':
            stats = counter.get_stats()
            
            # General stats
            panel = Panel(
                "\n".join(f"[bold]{k}:[/] {v}" for k, v in stats.items()),
                title="[bold red]Overall Statistics[/]",
                border_style="red"
            )
            console.print(panel)
            
            # Counter details
            if counter.data['counters']:
                table = Table(title="Counter Details")
                table.add_column("Name")
                table.add_column("Count")
                table.add_column("Description")
                table.add_column("Created")
                
                for name, data in counter.data['counters'].items():
                    table.add_row(
                        name,
                        str(data['count']),
                        data['description'] or "N/A",
                        data['created']
                    )
                console.print(table)
            
            # Timer details
            if counter.data['timers']:
                table = Table(title="Timer Details")
                table.add_column("Name")
                table.add_column("Status")
                table.add_column("Duration")
                table.add_column("Started")
                
                for name, timer in counter.data['timers'].items():
                    status = "Active" if timer['end'] is None else "Stopped"
                    duration = format_duration(timer['duration'])
                    table.add_row(
                        name,
                        status,
                        duration,
                        timer['start']
                    )
                console.print(table)

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 