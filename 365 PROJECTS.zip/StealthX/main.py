#!/usr/bin/env python3
"""
StealthX - Network Stealth Scanner
Created by BHAVYANSH SONI
A retro-style terminal-based network reconnaissance tool
"""

import socket
import sys
import time
import threading
from datetime import datetime
from colorama import init, Fore, Back, Style
import random
import subprocess
import os

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.RED}{'='*60}
{Fore.GREEN}    ███████╗████████╗███████╗ █████╗ ██╗  ████████╗██╗  ██╗██╗  ██╗
{Fore.GREEN}    ██╔════╝╚══██╔══╝██╔════╝██╔══██╗██║  ╚══██╔══╝██║  ██║╚██╗██╔╝
{Fore.GREEN}    ███████╗   ██║   █████╗  ███████║██║     ██║   ███████║ ╚███╔╝ 
{Fore.GREEN}    ╚════██║   ██║   ██╔══╝  ██╔══██║██║     ██║   ██╔══██║ ██╔██╗ 
{Fore.GREEN}    ███████║   ██║   ███████╗██║  ██║███████╗██║   ██║  ██║██╔╝ ██╗
{Fore.GREEN}    ╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝
{Fore.RED}{'='*60}
{Fore.YELLOW}    🕵️  Network Stealth Scanner - Advanced Reconnaissance
{Fore.MAGENTA}    👤 Created by: BHAVYANSH SONI
{Fore.RED}{'='*60}
{Fore.CYAN}    ⚠️  FOR EDUCATIONAL PURPOSES ONLY
{Fore.RED}{'='*60}
"""
    print(header)

def get_local_ip():
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def port_scan(host, port, timeout=1):
    """Scan a single port"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except:
        return False

def stealth_scan(host, ports, threads=100):
    """Perform stealth port scan"""
    open_ports = []
    
    def scan_port(port):
        if port_scan(host, port):
            open_ports.append(port)
            print(f"{Fore.GREEN}   ✅ Port {port}: OPEN")
        else:
            print(f"{Fore.RED}   ❌ Port {port}: CLOSED", end='\r')
    
    slow_print(f"{Fore.YELLOW}🔍 Scanning {host} for open ports...", 0.02)
    
    thread_list = []
    for port in ports:
        thread = threading.Thread(target=scan_port, args=(port,))
        thread.daemon = True
        thread.start()
        thread_list.append(thread)
        
        if len(thread_list) >= threads:
            for t in thread_list:
                t.join()
            thread_list = []
    
    for t in thread_list:
        t.join()
    
    return open_ports

def service_detection(host, port):
    """Basic service detection"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)
        sock.connect((host, port))
        
        # Try to grab banner
        sock.send(b"HEAD / HTTP/1.0\r\n\r\n")
        banner = sock.recv(1024).decode('utf-8', errors='ignore')
        sock.close()
        
        if banner:
            return banner.split('\n')[0][:100]
        return "Unknown service"
    except:
        return "Unknown service"

def os_detection(host):
    """Basic OS detection using TTL"""
    try:
        if os.name == 'nt':
            result = subprocess.run(['ping', '-n', '1', host], 
                                  capture_output=True, text=True)
        else:
            result = subprocess.run(['ping', '-c', '1', host], 
                                  capture_output=True, text=True)
        
        output = result.stdout
        if 'ttl=64' in output.lower():
            return "Linux/Unix"
        elif 'ttl=128' in output.lower():
            return "Windows"
        elif 'ttl=255' in output.lower():
            return "Cisco/Network Device"
        else:
            return "Unknown OS"
    except:
        return "Unknown OS"

def get_common_ports():
    """Get list of common ports to scan"""
    return [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 993, 995, 1723, 3306, 3389, 5432, 5900, 8080]

def advanced_scan(host):
    """Perform advanced scan"""
    slow_print(f"{Fore.CYAN}🎯 Target: {host}", 0.02)
    
    # OS Detection
    slow_print(f"\n{Fore.YELLOW}🖥️  OS Detection:", 0.02)
    os_info = os_detection(host)
    slow_print(f"   {Fore.GREEN}Detected OS: {Fore.WHITE}{os_info}", 0.02)
    
    # Port Scanning
    slow_print(f"\n{Fore.YELLOW}🔍 Port Scanning:", 0.02)
    common_ports = get_common_ports()
    open_ports = stealth_scan(host, common_ports)
    
    if open_ports:
        slow_print(f"\n{Fore.GREEN}✅ Open Ports Found:", 0.02)
        for port in open_ports:
            service = service_detection(host, port)
            slow_print(f"   {Fore.CYAN}Port {port}: {Fore.WHITE}{service}", 0.02)
    else:
        slow_print(f"\n{Fore.RED}❌ No open ports found in common range", 0.02)

def network_discovery():
    """Discover devices on local network"""
    local_ip = get_local_ip()
    network = ".".join(local_ip.split(".")[:-1]) + "."
    
    slow_print(f"{Fore.YELLOW}🌐 Discovering devices on {network}0/24...", 0.02)
    
    active_hosts = []
    
    def ping_host(ip):
        try:
            if os.name == 'nt':
                result = subprocess.run(['ping', '-n', '1', '-w', '1000', ip], 
                                      capture_output=True, text=True)
            else:
                result = subprocess.run(['ping', '-c', '1', '-W', '1', ip], 
                                      capture_output=True, text=True)
            
            if result.returncode == 0:
                active_hosts.append(ip)
                print(f"{Fore.GREEN}   ✅ {ip}: ACTIVE")
        except:
            pass
    
    threads = []
    for i in range(1, 255):
        ip = network + str(i)
        thread = threading.Thread(target=ping_host, args=(ip,))
        thread.daemon = True
        thread.start()
        threads.append(thread)
        
        if len(threads) >= 50:
            for t in threads:
                t.join()
            threads = []
    
    for t in threads:
        t.join()
    
    return active_hosts

def main():
    """Main function"""
    print_header()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🎯 StealthX Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Single Host Scan", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Network Discovery", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Custom Port Range Scan", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Service Detection", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-5): ").strip()
        
        if choice == '1':
            host = input(f"{Fore.CYAN}Enter target host/IP: ").strip()
            if host:
                print(f"\n{Fore.YELLOW}{'─' * 60}")
                advanced_scan(host)
                print(f"{Fore.YELLOW}{'─' * 60}")
        
        elif choice == '2':
            print(f"\n{Fore.YELLOW}{'─' * 60}")
            active_hosts = network_discovery()
            if active_hosts:
                slow_print(f"\n{Fore.GREEN}📡 Active Hosts Found:", 0.02)
                for host in active_hosts:
                    slow_print(f"   {Fore.CYAN}• {host}", 0.02)
            else:
                slow_print(f"\n{Fore.RED}❌ No active hosts found", 0.02)
            print(f"{Fore.YELLOW}{'─' * 60}")
        
        elif choice == '3':
            host = input(f"{Fore.CYAN}Enter target host/IP: ").strip()
            start_port = int(input(f"{Fore.CYAN}Start port: ").strip())
            end_port = int(input(f"{Fore.CYAN}End port: ").strip())
            
            if host and start_port and end_port:
                print(f"\n{Fore.YELLOW}{'─' * 60}")
                ports = range(start_port, end_port + 1)
                open_ports = stealth_scan(host, ports)
                
                if open_ports:
                    slow_print(f"\n{Fore.GREEN}✅ Open Ports:", 0.02)
                    for port in open_ports:
                        slow_print(f"   {Fore.CYAN}Port {port}", 0.02)
                print(f"{Fore.YELLOW}{'─' * 60}")
        
        elif choice == '4':
            host = input(f"{Fore.CYAN}Enter target host/IP: ").strip()
            port = int(input(f"{Fore.CYAN}Enter port: ").strip())
            
            if host and port:
                print(f"\n{Fore.YELLOW}{'─' * 60}")
                slow_print(f"{Fore.YELLOW}🔍 Detecting service on {host}:{port}...", 0.02)
                service = service_detection(host, port)
                slow_print(f"{Fore.GREEN}Service: {Fore.WHITE}{service}", 0.02)
                print(f"{Fore.YELLOW}{'─' * 60}")
        
        elif choice == '5':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using StealthX! Stay ethical!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
        input()
        print_header()

if __name__ == "__main__":
    main()
