"""
Steganography Tool - Colorful GUI Version

Author: Bhavyansh Coder
"""

import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image


def encode(image_path, file_path, output_path):
    try:
        with open(file_path, "rb") as f:
            data = f.read()

        image = Image.open(image_path)
        encoded = image.copy()
        width, height = image.size
        max_bytes = width * height * 3 // 8

        if len(data) > max_bytes:
            raise ValueError("File too large to hide in this image.")

        data += b"::END"
        bin_data = ''.join(format(byte, '08b') for byte in data)

        pixels = list(encoded.getdata())
        new_pixels = []

        data_index = 0
        for pixel in pixels:
            r, g, b = pixel
            if data_index < len(bin_data):
                r = (r & ~1) | int(bin_data[data_index])
                data_index += 1
            if data_index < len(bin_data):
                g = (g & ~1) | int(bin_data[data_index])
                data_index += 1
            if data_index < len(bin_data):
                b = (b & ~1) | int(bin_data[data_index])
                data_index += 1
            new_pixels.append((r, g, b))

        encoded.putdata(new_pixels)
        encoded.save(output_path)
        messagebox.showinfo("Success", "File hidden successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


def decode(image_path, output_path):
    try:
        image = Image.open(image_path)
        pixels = list(image.getdata())

        bin_data = ''
        for pixel in pixels:
            for color in pixel:
                bin_data += str(color & 1)

        all_bytes = [bin_data[i:i + 8] for i in range(0, len(bin_data), 8)]
        data = bytearray()
        for byte in all_bytes:
            byte = int(byte, 2)
            data.append(byte)
            if data[-5:] == b"::END":
                data = data[:-5]
                break

        with open(output_path, "wb") as f:
            f.write(data)

        messagebox.showinfo("Success", "File extracted successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


def gui():
    root = tk.Tk()
    root.title("Steganography Tool")
    root.geometry("500x350")
    root.config(bg="#1e1e2f")

    title = tk.Label(
        root,
        text="🖼️ Steganography Tool",
        font=("Arial", 20, "bold"),
        bg="#1e1e2f",
        fg="#00ffcc"
    )
    title.pack(pady=20)

    def encode_file():
        img = filedialog.askopenfilename(title="Select Image")
        file = filedialog.askopenfilename(title="Select File to Hide")
        output = filedialog.asksaveasfilename(defaultextension=".png", title="Save as")
        if img and file and output:
            encode(img, file, output)

    def decode_file():
        img = filedialog.askopenfilename(title="Select Image to Decode")
        output = filedialog.asksaveasfilename(title="Save Extracted File As")
        if img and output:
            decode(img, output)

    button_style = {
        "font": ("Arial", 12, "bold"),
        "bg": "#00ffcc",
        "fg": "#000000",
        "activebackground": "#00bfa6",
        "activeforeground": "#ffffff",
        "bd": 0,
        "relief": "flat",
        "width": 25,
        "height": 2
    }

    tk.Button(root, text="🗂️ Hide File in Image", command=encode_file, **button_style).pack(pady=10)
    tk.Button(root, text="🔍 Extract File from Image", command=decode_file, **button_style).pack(pady=10)
    tk.Button(root, text="❌ Exit", command=root.destroy, **button_style).pack(pady=10)

    root.mainloop()


if __name__ == "__main__":
    gui()
