# 🎵 Color Symphony

**Created by Bhavyansh Soni**

## Description
A groundbreaking synesthetic music game where players compose melodies through terminal colors! Experience the magical fusion of visual art and musical harmony as each painted color represents a musical note. Paint patterns on your canvas to create beautiful symphonies that blend sight and sound in perfect unity.

## Synesthetic Concept
Based on the neurological phenomenon of synesthesia, where stimulation of one sensory pathway leads to involuntary experiences in another. In this game, colors have inherent musical qualities, and painting becomes composition.

## Color-Note Mapping System

### 🔴 **Red = C Note (261.63 Hz)**
- **Mood**: Passionate and powerful
- **Instrument**: Strings (violin, cello)
- **Emotional Quality**: Foundation, strength, grounding

### 🟡 **Yellow = D Note (293.66 Hz)**
- **Mood**: Joyful and bright
- **Instrument**: Brass (trumpet, horn)
- **Emotional Quality**: Optimism, energy, warmth

### 🟢 **Green = E Note (329.63 Hz)**
- **Mood**: Natural and growing
- **Instrument**: Woodwind (flute, clarinet)
- **Emotional Quality**: Balance, life, harmony

### 🔵 **Cyan = F Note (349.23 Hz)**
- **Mood**: Flowing and smooth
- **Instrument**: Piano (crystalline keys)
- **Emotional Quality**: Transition, movement, grace

### 🔵 **Blue = G Note (392.00 Hz)**
- **Mood**: Deep and contemplative
- **Instrument**: Bass (double bass, cello)
- **Emotional Quality**: Depth, stability, wisdom

### 🟣 **Magenta = A Note (440.00 Hz)**
- **Mood**: Mystical and ethereal
- **Instrument**: Harp (celestial strings)
- **Emotional Quality**: Magic, mystery, transcendence

### ⚪ **White = B Note (493.88 Hz)**
- **Mood**: Pure and ascending
- **Instrument**: Choir (human voices)
- **Emotional Quality**: Clarity, resolution, spirituality

## The Eight Movements

### 🌅 **Movement 1: Dawn Prelude**
- **Theme**: Gentle awakening
- **Target Harmony**: Pastel (white, cyan, magenta)
- **Tempo**: Slow and contemplative
- **Goal**: Create soft, awakening melodies

### 🌸 **Movement 2: Spring Waltz**
- **Theme**: Blooming nature
- **Target Harmony**: Major Triad (red, green, blue)
- **Tempo**: Moderate and dancing
- **Goal**: Capture the joy of new growth

### ☀️ **Movement 3: Summer Dance**
- **Theme**: Vibrant energy
- **Target Harmony**: Warm Colors (red, yellow, magenta)
- **Tempo**: Fast and energetic
- **Goal**: Express peak vitality and celebration

### 🍂 **Movement 4: Autumn Reflection**
- **Theme**: Nostalgic beauty
- **Target Harmony**: Minor Triad (red, cyan, blue)
- **Tempo**: Slow and reflective
- **Goal**: Evoke bittersweet memories

### ❄️ **Movement 5: Winter Nocturne**
- **Theme**: Crystalline stillness
- **Target Harmony**: Cool Colors (green, cyan, blue)
- **Tempo**: Very slow and peaceful
- **Goal**: Create crystalline, frozen beauty

### 🌈 **Movement 6: Rainbow Rhapsody**
- **Theme**: Spectrum of emotions
- **Target Harmony**: All Colors (full spectrum)
- **Tempo**: Variable and expressive
- **Goal**: Showcase complete emotional range

### ⚡ **Movement 7: Storm Symphony**
- **Theme**: Dramatic tension
- **Target Harmony**: Dominant (blue, white, yellow)
- **Tempo**: Intense and powerful
- **Goal**: Build dramatic climaxes

### 🌟 **Movement 8: Cosmic Finale**
- **Theme**: Transcendent unity
- **Target Harmony**: All harmonies combined
- **Tempo**: Epic and all-encompassing
- **Goal**: Create the ultimate musical expression

## Painting Tools & Techniques

### **Brush Sizes**
- **Fine Brush**: Single pixel precision for detailed melodies
- **Medium Brush**: 2x2 area for small chords and harmonies
- **Broad Brush**: 3x3 area for rich, full harmonies

### **Composition Commands**
- `paint <x> <y> <color_num>`: Place color at coordinates
- `brush <size>`: Change brush size (fine/medium/broad)
- `play`: Hear your composition as music
- `analyze`: Get detailed musical analysis
- `clear`: Start over with blank canvas
- `complete`: Finish current movement

## Musical Theory Integration

### **Harmony Recognition**
The game recognizes classical harmonic structures:
- **Major Triads**: Uplifting, positive sound
- **Minor Triads**: Melancholic, emotional depth
- **Dominant Chords**: Tension and resolution
- **Color Families**: Warm vs cool tonal palettes

### **Rhythm Patterns**
- **Horizontal Lines**: Create melodic sequences
- **Vertical Columns**: Form harmonic chords
- **Diagonal Patterns**: Generate flowing arpeggios
- **Clustered Colors**: Build rich chord progressions

## Scoring System

### **Movement Scoring**
- **Harmony Quality (0-100)**: Based on color relationships and chord structures
- **Rhythm Flow (0-100)**: Measured by pattern organization and musical logic
- **Inspiration Bonus (0-50)**: Remaining creative energy adds to score
- **Target Harmony Match**: Bonus for using movement's target colors

### **Symphony Evaluation**
- **Total Score**: Sum of all movement scores
- **Average Quality**: Consistency across movements
- **Completion Rate**: Percentage of movements finished
- **Artistic Innovation**: Creativity in color usage

## Achievement Levels
- 🌟 **Synesthetic Maestro**: Complete all 8 movements with high scores
- 🎵 **Color Symphony Virtuoso**: Complete 6+ movements excellently
- 🎨 **Artistic Composer**: Complete 4+ movements with good quality
- 🌈 **Creative Explorer**: Complete 2+ movements with experimentation
- 🌱 **Aspiring Artist**: Beginning the journey of synesthetic composition

## Educational Benefits
- **Music Theory**: Learn about notes, harmonies, and chord progressions
- **Color Theory**: Understand color relationships and emotional associations
- **Synesthesia Awareness**: Experience cross-sensory perception
- **Pattern Recognition**: Develop visual-musical pattern skills
- **Creative Expression**: Blend multiple art forms harmoniously
- **Spatial Reasoning**: Translate 2D visual patterns into temporal music

## Advanced Techniques
1. **Chord Painting**: Use medium/broad brushes for instant harmonies
2. **Melodic Lines**: Create horizontal color sequences for melodies
3. **Harmonic Columns**: Stack colors vertically for rich chords
4. **Color Gradients**: Transition smoothly between related notes
5. **Rhythmic Spacing**: Use empty space to create musical rests
6. **Theme Development**: Repeat and vary color patterns across movements

## Tips for Musical Success
1. **Study Target Harmonies**: Each movement has optimal color combinations
2. **Balance Colors**: Use variety while maintaining harmonic coherence
3. **Create Patterns**: Repetition and variation create musical structure
4. **Manage Inspiration**: Paint strategically to maintain creative energy
5. **Listen Actively**: Use the play function to hear your visual creations
6. **Analyze Regularly**: Learn from the harmonic analysis feedback

## The Philosophy of Color Music
"Music is the hidden arithmetic of the soul, and color is the visible music of the eye. In Color Symphony, these two languages of emotion unite to create something greater than the sum of their parts - a synesthetic experience that speaks directly to the heart."

## Technical Innovation
- Real-time translation of visual patterns into musical concepts
- Dynamic harmony analysis based on color theory and music theory
- Progressive difficulty through increasingly complex harmonic targets
- Multi-sensory feedback combining visual, textual, and conceptual audio
- Canvas-based composition interface with musical interpretation

Color Symphony represents a unique fusion of visual art and musical composition, offering players the chance to literally paint music and hear colors in a completely original gaming experience.

