#!/usr/bin/env python3
"""
🎵 COLOR SYMPHONY 🎵
Created by Bhavyansh Soni

An original synesthetic music game where players compose melodies through terminal colors!
Each color represents musical notes, and combinations create harmonious symphonies.
Paint with sound and hear with colors in this unique audio-visual experience!
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class ColorSymphony:
    def __init__(self):
        self.canvas_width = 20
        self.canvas_height = 12
        self.canvas = []
        self.composition = []
        self.current_instrument = "piano"
        self.harmony_score = 0
        self.movement = 1
        self.max_movements = 8
        self.inspiration = 100
        self.rhythm_energy = 100
        
        # Color-to-note mapping (using synesthetic associations)
        self.color_notes = {
            Fore.RED: {"note": "C", "frequency": 261.63, "emoji": "🔴", "mood": "passionate", "instrument": "strings"},
            Fore.YELLOW: {"note": "D", "frequency": 293.66, "emoji": "🟡", "mood": "joyful", "instrument": "brass"},
            Fore.GREEN: {"note": "E", "frequency": 329.63, "emoji": "🟢", "mood": "natural", "instrument": "woodwind"},
            Fore.CYAN: {"note": "F", "frequency": 349.23, "emoji": "🔵", "mood": "flowing", "instrument": "piano"},
            Fore.BLUE: {"note": "G", "frequency": 392.00, "emoji": "🔵", "mood": "deep", "instrument": "bass"},
            Fore.MAGENTA: {"note": "A", "frequency": 440.00, "emoji": "🟣", "mood": "mystical", "instrument": "harp"},
            Fore.WHITE: {"note": "B", "frequency": 493.88, "emoji": "⚪", "mood": "pure", "instrument": "choir"}
        }
        
        # Harmonic relationships and chord progressions
        self.harmonies = {
            "major_triad": [Fore.RED, Fore.GREEN, Fore.BLUE],        # C-E-G
            "minor_triad": [Fore.RED, Fore.CYAN, Fore.BLUE],         # C-F-G
            "dominant": [Fore.BLUE, Fore.WHITE, Fore.YELLOW],        # G-B-D
            "rainbow": [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA],
            "warm": [Fore.RED, Fore.YELLOW, Fore.MAGENTA],
            "cool": [Fore.GREEN, Fore.CYAN, Fore.BLUE],
            "pastel": [Fore.WHITE, Fore.CYAN, Fore.MAGENTA]
        }
        
        # Musical movements with themes
        self.movements = {
            1: {"name": "🌅 Dawn Prelude", "theme": "gentle awakening", "target_harmony": "pastel", "tempo": "slow"},
            2: {"name": "🌸 Spring Waltz", "theme": "blooming nature", "target_harmony": "major_triad", "tempo": "moderate"},
            3: {"name": "☀️ Summer Dance", "theme": "vibrant energy", "target_harmony": "warm", "tempo": "fast"},
            4: {"name": "🍂 Autumn Reflection", "theme": "nostalgic beauty", "target_harmony": "minor_triad", "tempo": "slow"},
            5: {"name": "❄️ Winter Nocturne", "theme": "crystalline stillness", "target_harmony": "cool", "tempo": "very_slow"},
            6: {"name": "🌈 Rainbow Rhapsody", "theme": "spectrum of emotions", "target_harmony": "rainbow", "tempo": "variable"},
            7: {"name": "⚡ Storm Symphony", "theme": "dramatic tension", "target_harmony": "dominant", "tempo": "intense"},
            8: {"name": "🌟 Cosmic Finale", "theme": "transcendent unity", "target_harmony": "all", "tempo": "epic"}
        }
        
        # Color painting tools
        self.brush_sizes = {
            "fine": [(0, 0)],
            "medium": [(0, 0), (0, 1), (1, 0), (1, 1)],
            "broad": [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 0), (0, 1), (1, -1), (1, 0), (1, 1)]
        }
        self.current_brush = "fine"
        
    def show_intro(self):
        """Display game introduction and synesthetic concepts"""
        clear_screen()
        
        intro_banner = create_banner("COLOR SYMPHONY", color=Fore.MAGENTA)
        print(intro_banner)
        
        slow_print(rainbow_text("🎵 Welcome to the magical realm where colors sing and music paints! 🎵"), delay=0.03)
        time.sleep(1)
        
        synesthetic_intro = [
            "\n🌈 SYNESTHETIC MUSIC THEORY:",
            "Each color corresponds to a musical note and emotional mood.",
            "Paint patterns on the canvas to create beautiful melodies.",
            "Harmonious color combinations produce pleasing musical chords.",
            "Your artistic vision becomes an audible symphony!",
            "",
            "🎨 COLOR-NOTE MAPPING:",
        ]
        
        for text in synesthetic_intro:
            if text.startswith("🌈") or text.startswith("🎨"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        # Show color-note mappings
        for color, data in self.color_notes.items():
            note_display = f"{color}🎵 {data['emoji']} = {data['note']} note ({data['mood']} mood, {data['instrument']})"
            slow_print(note_display, delay=0.02)
            time.sleep(0.3)
        
        how_to_play = [
            "",
            "🎼 HOW TO COMPOSE:",
            "🖌️ Paint colors on the canvas to place musical notes",
            "🎵 Each painted cell plays its corresponding note",
            "🎶 Color patterns create chord progressions and melodies",
            "🎯 Match the movement's target harmony for bonus points",
            "🌟 Complete 8 movements to become a Synesthetic Maestro!",
        ]
        
        for text in how_to_play:
            if text.startswith("🎼"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.CYAN + "\n🎨 Ready to paint your first symphony? Press ENTER to begin!", delay=0.03)
        input()
    
    def initialize_canvas(self):
        """Initialize a blank canvas for the current movement"""
        self.canvas = [[Fore.BLACK for _ in range(self.canvas_width)] for _ in range(self.canvas_height)]
    
    def show_movement_intro(self):
        """Display introduction for current movement"""
        clear_screen()
        
        movement_info = self.movements[self.movement]
        
        movement_banner = create_banner(f"MOVEMENT {self.movement}", color=Fore.YELLOW)
        print(movement_banner)
        
        slow_print(f"{Fore.CYAN}🎼 {movement_info['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}🎭 Theme: {movement_info['theme']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🎵 Target Harmony: {movement_info['target_harmony']}", delay=0.02)
        slow_print(f"{Fore.WHITE}⏱️ Tempo: {movement_info['tempo']}", delay=0.02)
        slow_print(f"{Fore.WHITE}💫 Inspiration: {self.inspiration}%", delay=0.02)
        slow_print(f"{Fore.WHITE}🎶 Rhythm Energy: {self.rhythm_energy}%", delay=0.02)
        
        # Show target harmony colors
        if movement_info['target_harmony'] in self.harmonies:
            target_colors = self.harmonies[movement_info['target_harmony']]
            slow_print(f"\n{Fore.YELLOW}🎯 Target Colors:", delay=0.02)
            color_display = ""
            for color in target_colors:
                color_display += f"{color}●● "
            slow_print(color_display, delay=0.05)
        
        time.sleep(2)
        slow_print(Fore.GREEN + "\n🎨 Begin composing! Press ENTER...", delay=0.03)
        input()
    
    def draw_canvas(self):
        """Draw the current composition canvas"""
        clear_screen()
        
        # Header
        movement_info = self.movements[self.movement]
        header = f"🎵 COLOR SYMPHONY | Movement {self.movement}: {movement_info['name']} | Harmony: {self.harmony_score} | Inspiration: {self.inspiration}%"
        print(Fore.CYAN + header)
        print(Fore.WHITE + "─" * 80)
        
        # Color palette
        print(Fore.YELLOW + "🎨 Color Palette:")
        palette_line = ""
        for i, (color, data) in enumerate(self.color_notes.items(), 1):
            palette_line += f"{color}[{i}]{data['emoji']}{data['note']} "
        print(palette_line)
        print()
        
        # Canvas with coordinates
        print(Fore.WHITE + "   " + "".join([f"{i:2}" for i in range(self.canvas_width)]))
        
        for y in range(self.canvas_height):
            row = f"{y:2} "
            for x in range(self.canvas_width):
                cell_color = self.canvas[y][x]
                if cell_color == Fore.BLACK:
                    row += "⬛"
                else:
                    # Find corresponding emoji
                    for color, data in self.color_notes.items():
                        if color == cell_color:
                            row += f"{color}{data['emoji']}"
                            break
                    else:
                        row += "◼️"
            print(row)
        
        print(Fore.WHITE + "─" * 80)
    
    def show_composition_menu(self):
        """Show composition interface"""
        print(Fore.GREEN + "\n🎼 Composition Commands:")
        print(Fore.WHITE + "paint <x> <y> <color_num> - Paint a color at coordinates")
        print(Fore.WHITE + "brush <size> - Change brush size (fine/medium/broad)")
        print(Fore.WHITE + "play - Play current composition")
        print(Fore.WHITE + "analyze - Analyze harmony and patterns")
        print(Fore.WHITE + "clear - Clear the canvas")
        print(Fore.WHITE + "complete - Complete this movement")
        print(Fore.WHITE + "quit - Exit to main menu")
        
        slow_print(Fore.CYAN + "\n🎨 Your command: ", delay=0.02, end="")
        
        try:
            command = input().strip().lower()
            return self.process_composition_command(command)
        except Exception as e:
            slow_print(Fore.RED + f"❌ Error: {e}", delay=0.02)
            time.sleep(1.5)
            return True
    
    def process_composition_command(self, command):
        """Process composition commands"""
        parts = command.split()
        
        if not parts:
            return True
        
        action = parts[0]
        
        if action == "paint" and len(parts) >= 4:
            try:
                x, y, color_num = int(parts[1]), int(parts[2]), int(parts[3])
                return self.paint_color(x, y, color_num)
            except ValueError:
                slow_print(Fore.RED + "❌ Please use: paint <x> <y> <color_number>", delay=0.02)
                time.sleep(1.5)
                return True
        
        elif action == "brush" and len(parts) >= 2:
            brush_size = parts[1]
            if brush_size in self.brush_sizes:
                self.current_brush = brush_size
                slow_print(Fore.GREEN + f"🖌️ Brush set to {brush_size}", delay=0.02)
            else:
                slow_print(Fore.RED + "❌ Available brushes: fine, medium, broad", delay=0.02)
            time.sleep(1)
            return True
        
        elif action == "play":
            return self.play_composition()
        
        elif action == "analyze":
            return self.analyze_composition()
        
        elif action == "clear":
            self.initialize_canvas()
            slow_print(Fore.YELLOW + "🎨 Canvas cleared!", delay=0.02)
            time.sleep(1)
            return True
        
        elif action == "complete":
            return self.complete_movement()
        
        elif action == "quit":
            return False
        
        else:
            slow_print(Fore.RED + "❌ Unknown command! See menu above.", delay=0.02)
            time.sleep(1.5)
            return True
    
    def paint_color(self, x, y, color_num):
        """Paint a color at specified coordinates"""
        if not (1 <= color_num <= len(self.color_notes)):
            slow_print(Fore.RED + f"❌ Color number must be 1-{len(self.color_notes)}", delay=0.02)
            time.sleep(1.5)
            return True
        
        if self.inspiration < 5:
            slow_print(Fore.RED + "❌ Not enough inspiration to paint!", delay=0.02)
            time.sleep(1.5)
            return True
        
        # Get color from mapping
        colors = list(self.color_notes.keys())
        selected_color = colors[color_num - 1]
        
        # Paint with current brush
        brush_pattern = self.brush_sizes[self.current_brush]
        painted_count = 0
        
        for dx, dy in brush_pattern:
            paint_x, paint_y = x + dx, y + dy
            
            if 0 <= paint_x < self.canvas_width and 0 <= paint_y < self.canvas_height:
                self.canvas[paint_y][paint_x] = selected_color
                painted_count += 1
        
        if painted_count > 0:
            self.inspiration = max(0, self.inspiration - 5)
            note_data = self.color_notes[selected_color]
            slow_print(f"{selected_color}🎵 Painted {note_data['note']} note ({note_data['mood']}) at ({x}, {y})", delay=0.02)
            
            # Play the note sound effect (simulated)
            slow_print(f"{Fore.CYAN}♪ {note_data['note']} ♪", delay=0.01)
        else:
            slow_print(Fore.RED + "❌ Invalid coordinates!", delay=0.02)
        
        time.sleep(0.5)
        return True
    
    def play_composition(self):
        """Play the current composition as music"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "🎵 PLAYING YOUR COMPOSITION 🎵", delay=0.03)
        time.sleep(1)
        
        # Analyze composition for playback
        notes_played = []
        
        for y in range(self.canvas_height):
            for x in range(self.canvas_width):
                cell_color = self.canvas[y][x]
                if cell_color != Fore.BLACK:
                    note_data = self.color_notes[cell_color]
                    notes_played.append((x, y, note_data))
        
        if not notes_played:
            slow_print(Fore.YELLOW + "🎼 Canvas is empty - no music to play!", delay=0.02)
            time.sleep(1.5)
            return True
        
        # Sort notes by position for playback (left to right, top to bottom)
        notes_played.sort(key=lambda n: (n[1], n[0]))
        
        # Play sequence
        slow_print(Fore.WHITE + "🎼 Musical sequence:", delay=0.02)
        
        chord_patterns = []
        current_chord = []
        last_y = -1
        
        for x, y, note_data in notes_played:
            if y != last_y and current_chord:
                # New row - process previous chord
                chord_patterns.append(current_chord)
                current_chord = []
            
            current_chord.append(note_data)
            last_y = y
        
        if current_chord:
            chord_patterns.append(current_chord)
        
        # Play chord patterns
        for i, chord in enumerate(chord_patterns):
            if len(chord) == 1:
                note = chord[0]
                slow_print(f"{Fore.WHITE}  {note['emoji']} {note['note']} ({note['mood']})", delay=0.02)
                slow_print(f"{Fore.CYAN}     ♪ {note['note']} ♪", delay=0.3)
            else:
                # Multiple notes = chord
                chord_display = " ".join([f"{n['emoji']}{n['note']}" for n in chord])
                slow_print(f"{Fore.YELLOW}  Chord: {chord_display}", delay=0.02)
                chord_sound = " ".join([f"♪{n['note']}♪" for n in chord])
                slow_print(f"{Fore.MAGENTA}     {chord_sound}", delay=0.5)
            
            time.sleep(0.8)
        
        # Calculate musical quality
        harmony_bonus = self.calculate_harmony_bonus()
        rhythm_bonus = self.calculate_rhythm_bonus()
        
        slow_print(f"\n{Fore.GREEN}🎼 Musical Analysis:", delay=0.02)
        slow_print(f"{Fore.CYAN}   Harmony Quality: {harmony_bonus}%", delay=0.02)
        slow_print(f"{Fore.CYAN}   Rhythm Flow: {rhythm_bonus}%", delay=0.02)
        
        time.sleep(2)
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
        return True
    
    def analyze_composition(self):
        """Analyze the current composition for musical properties"""
        clear_screen()
        
        slow_print(Fore.YELLOW + "🔍 COMPOSITION ANALYSIS", delay=0.03)
        time.sleep(1)
        
        # Count colors used
        color_counts = {}
        total_notes = 0
        
        for y in range(self.canvas_height):
            for x in range(self.canvas_width):
                cell_color = self.canvas[y][x]
                if cell_color != Fore.BLACK:
                    total_notes += 1
                    if cell_color in color_counts:
                        color_counts[cell_color] += 1
                    else:
                        color_counts[cell_color] = 1
        
        if total_notes == 0:
            slow_print(Fore.YELLOW + "📝 Canvas is empty - paint some colors first!", delay=0.02)
            time.sleep(1.5)
            return True
        
        # Show color distribution
        slow_print(f"{Fore.WHITE}🎨 Color Distribution (Total notes: {total_notes}):", delay=0.02)
        
        for color, count in color_counts.items():
            note_data = self.color_notes[color]
            percentage = (count / total_notes) * 100
            slow_print(f"{color}  {note_data['emoji']} {note_data['note']}: {count} notes ({percentage:.1f}%)", delay=0.02)
            time.sleep(0.3)
        
        # Harmony analysis
        harmony_score = self.calculate_harmony_bonus()
        rhythm_score = self.calculate_rhythm_bonus()
        
        slow_print(f"\n{Fore.CYAN}🎵 Musical Properties:", delay=0.02)
        slow_print(f"{Fore.WHITE}   Harmony Score: {harmony_score}%", delay=0.02)
        slow_print(f"{Fore.WHITE}   Rhythm Score: {rhythm_score}%", delay=0.02)
        
        # Target harmony check
        movement_info = self.movements[self.movement]
        target_harmony = movement_info['target_harmony']
        
        if target_harmony in self.harmonies:
            target_colors = set(self.harmonies[target_harmony])
            used_colors = set(color_counts.keys())
            
            matching_colors = target_colors.intersection(used_colors)
            match_percentage = (len(matching_colors) / len(target_colors)) * 100
            
            slow_print(f"\n{Fore.YELLOW}🎯 Target Harmony Match: {match_percentage:.1f}%", delay=0.02)
            
            if match_percentage >= 70:
                slow_print(f"{Fore.GREEN}   ✅ Excellent harmony alignment!", delay=0.02)
            elif match_percentage >= 40:
                slow_print(f"{Fore.YELLOW}   👍 Good harmony foundation!", delay=0.02)
            else:
                slow_print(f"{Fore.BLUE}   🎨 Creative interpretation!", delay=0.02)
        
        time.sleep(2)
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
        return True
    
    def calculate_harmony_bonus(self):
        """Calculate harmony bonus based on color relationships"""
        color_counts = {}
        
        for y in range(self.canvas_height):
            for x in range(self.canvas_width):
                cell_color = self.canvas[y][x]
                if cell_color != Fore.BLACK:
                    if cell_color in color_counts:
                        color_counts[cell_color] += 1
                    else:
                        color_counts[cell_color] = 1
        
        if not color_counts:
            return 0
        
        # Check for known harmonious combinations
        used_colors = set(color_counts.keys())
        harmony_bonus = 0
        
        for harmony_name, harmony_colors in self.harmonies.items():
            harmony_set = set(harmony_colors)
            if harmony_set.issubset(used_colors):
                harmony_bonus += 30  # Bonus for complete harmony
            elif len(harmony_set.intersection(used_colors)) >= len(harmony_set) * 0.6:
                harmony_bonus += 15  # Partial harmony bonus
        
        # Bonus for color balance
        if len(color_counts) >= 3:
            balance_bonus = min(20, len(color_counts) * 3)
            harmony_bonus += balance_bonus
        
        return min(100, harmony_bonus)
    
    def calculate_rhythm_bonus(self):
        """Calculate rhythm bonus based on pattern structure"""
        # Simple rhythm analysis based on distribution patterns
        pattern_score = 0
        
        # Check for horizontal patterns (melodies)
        for y in range(self.canvas_height):
            row_notes = [self.canvas[y][x] for x in range(self.canvas_width) if self.canvas[y][x] != Fore.BLACK]
            if len(row_notes) >= 3:
                pattern_score += 10
        
        # Check for vertical patterns (harmonies)
        for x in range(self.canvas_width):
            col_notes = [self.canvas[y][x] for y in range(self.canvas_height) if self.canvas[y][x] != Fore.BLACK]
            if len(col_notes) >= 2:
                pattern_score += 5
        
        return min(100, pattern_score)
    
    def complete_movement(self):
        """Complete the current movement and score it"""
        clear_screen()
        
        movement_info = self.movements[self.movement]
        
        # Calculate final scores
        harmony_score = self.calculate_harmony_bonus()
        rhythm_score = self.calculate_rhythm_bonus()
        inspiration_bonus = self.inspiration // 2
        
        total_score = harmony_score + rhythm_score + inspiration_bonus
        self.harmony_score += total_score
        
        completion_banner = create_banner("MOVEMENT COMPLETE", color=Fore.YELLOW)
        print(completion_banner)
        
        slow_print(f"{Fore.CYAN}🎼 {movement_info['name']} completed!", delay=0.03)
        time.sleep(1)
        
        # Show scoring breakdown
        score_info = [
            f"\n📊 MUSICAL SCORING:",
            f"🎵 Harmony Quality: {harmony_score} points",
            f"🎶 Rhythm Flow: {rhythm_score} points", 
            f"💫 Inspiration Bonus: {inspiration_bonus} points",
            f"🏆 Movement Total: {total_score} points",
            f"🌟 Symphony Score: {self.harmony_score} points",
        ]
        
        for info in score_info:
            slow_print(Fore.WHITE + info, delay=0.02)
            time.sleep(0.5)
        
        # Movement evaluation
        if total_score >= 180:
            slow_print(Fore.MAGENTA + "\n🌟 MASTERFUL COMPOSITION! 🌟", delay=0.03)
            evaluation = "A symphonic masterpiece of color and sound!"
        elif total_score >= 140:
            slow_print(Fore.GREEN + "\n🎵 Excellent Musical Flow! 🎵", delay=0.03)
            evaluation = "Beautiful harmonies dance through your canvas!"
        elif total_score >= 100:
            slow_print(Fore.YELLOW + "\n🎨 Creative Expression! 🎨", delay=0.03)
            evaluation = "Your artistic vision creates lovely music!"
        else:
            slow_print(Fore.BLUE + "\n🌱 Budding Composer! 🌱", delay=0.03)
            evaluation = "Every maestro starts with experimentation!"
        
        slow_print(f"{Fore.WHITE}💝 {evaluation}", delay=0.03)
        
        # Restore some inspiration
        self.inspiration = min(100, self.inspiration + 30)
        
        time.sleep(3)
        
        if self.movement < self.max_movements:
            slow_print(f"\n{Fore.CYAN}🎼 Preparing movement {self.movement + 1}...", delay=0.03)
            self.movement += 1
            time.sleep(2)
            return True
        else:
            return False  # Symphony complete
    
    def show_final_symphony(self):
        """Show the completed symphony results"""
        clear_screen()
        
        symphony_banner = create_banner("SYMPHONY COMPLETE", color=Fore.MAGENTA)
        print(symphony_banner)
        
        slow_print(rainbow_text("🎵 Your Color Symphony has reached its grand finale! 🎵"), delay=0.05)
        time.sleep(2)
        
        # Show all completed movements
        slow_print(f"\n{Fore.YELLOW}🎼 YOUR SYMPHONIC JOURNEY:", delay=0.03)
        
        for i in range(1, self.movement):
            movement_info = self.movements[i]
            slow_print(f"{Fore.CYAN}   {i}. {movement_info['name']}", delay=0.02)
            time.sleep(0.3)
        
        # Final statistics
        avg_score = self.harmony_score / (self.movement - 1) if self.movement > 1 else 0
        
        stats = [
            f"\n📊 SYMPHONY STATISTICS:",
            f"🎼 Movements Completed: {self.movement - 1}/{self.max_movements}",
            f"🏆 Total Harmony Score: {self.harmony_score}",
            f"🎵 Average Movement Score: {avg_score:.1f}",
            f"💫 Final Inspiration: {self.inspiration}%",
        ]
        
        for stat in stats:
            slow_print(Fore.WHITE + stat, delay=0.02)
            time.sleep(0.5)
        
        # Symphony mastery evaluation
        completion_rate = ((self.movement - 1) / self.max_movements) * 100
        
        if completion_rate == 100 and avg_score >= 150:
            slow_print(rainbow_text("🌟 SYNESTHETIC MAESTRO! 🌟"), delay=0.05)
            evaluation = "You have mastered the art of painting with sound!"
        elif completion_rate >= 75:
            slow_print(Fore.MAGENTA + "🎵 Color Symphony Virtuoso! 🎵", delay=0.03)
            evaluation = "Your musical paintings inspire the soul!"
        elif completion_rate >= 50:
            slow_print(Fore.YELLOW + "🎨 Artistic Composer! 🎨", delay=0.03)
            evaluation = "You've learned to blend colors and music beautifully!"
        elif completion_rate >= 25:
            slow_print(Fore.GREEN + "🌈 Creative Explorer! 🌈", delay=0.03)
            evaluation = "Your journey into synesthetic art has begun!"
        else:
            slow_print(Fore.BLUE + "🌱 Aspiring Artist! 🌱", delay=0.03)
            evaluation = "Every great symphony starts with a single note!"
        
        slow_print(f"\n{Fore.CYAN}🎼 {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def regenerate_inspiration(self):
        """Slowly regenerate inspiration"""
        if self.inspiration < 100:
            self.inspiration = min(100, self.inspiration + 1)
    
    def game_loop(self):
        """Main game loop"""
        while self.movement <= self.max_movements:
            # Initialize new canvas
            self.initialize_canvas()
            
            # Show movement introduction
            self.show_movement_intro()
            
            # Composition loop
            while True:
                # Regenerate inspiration slowly
                self.regenerate_inspiration()
                
                # Draw and interact
                self.draw_canvas()
                continue_composing = self.show_composition_menu()
                
                if not continue_composing:
                    if self.movement > self.max_movements:
                        # Symphony complete
                        self.show_final_symphony()
                    return
                elif self.movement > len(self.movements):
                    # All movements completed
                    self.show_final_symphony()
                    return
                else:
                    # Continue to next movement
                    break
        
        # Show final results
        self.show_final_symphony()

def main():
    """Main game entry point"""
    try:
        game = ColorSymphony()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your symphony awaits completion, maestro!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Symphony error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
