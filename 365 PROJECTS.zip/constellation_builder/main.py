#!/usr/bin/env python3
"""
⭐ CONSTELLATION BUILDER ⭐
Created by Bhavyansh Soni

An original celestial puzzle game where players create star patterns with ASCII magic!
Connect stars to form constellations, unlock mythical stories, and paint the night sky
with your imagination. Each constellation tells a tale of wonder and discovery!
"""

import random
import time
import sys
import os
import math
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class ConstellationBuilder:
    def __init__(self):
        self.sky_width = 25
        self.sky_height = 15
        self.stars = []
        self.connections = []
        self.current_constellation = []
        self.completed_constellations = []
        self.level = 1
        self.max_levels = 10
        self.cosmic_energy = 100
        self.legend_points = 0
        
        # Constellation patterns to discover
        self.constellation_patterns = {
            1: {
                "name": "✨ The Dreamer",
                "pattern": [(2, 2), (4, 1), (6, 3), (8, 2), (10, 4)],
                "story": "A wandering soul who maps the paths between dreams and reality.",
                "power": "Grants ability to see hidden connections",
                "points": 50
            },
            2: {
                "name": "🦋 The Butterfly",
                "pattern": [(3, 3), (5, 1), (7, 2), (9, 1), (11, 3), (7, 4), (9, 5)],
                "story": "Born from cosmic chrysalis, it carries wishes across the galaxy.",
                "power": "Transforms obstacles into opportunities",
                "points": 75
            },
            3: {
                "name": "🌊 The Wave",
                "pattern": [(1, 5), (3, 3), (5, 4), (7, 2), (9, 3), (11, 1), (13, 2)],
                "story": "An eternal tide that flows through space and time.",
                "power": "Brings flow and rhythm to chaotic energies",
                "points": 100
            },
            4: {
                "name": "🗝️ The Key",
                "pattern": [(4, 2), (6, 2), (8, 2), (8, 4), (10, 3), (10, 5)],
                "story": "Unlocks the secrets hidden in stellar vaults.",
                "power": "Opens doors to forbidden knowledge",
                "points": 125
            },
            5: {
                "name": "🌺 The Bloom",
                "pattern": [(6, 6), (5, 4), (7, 4), (4, 5), (8, 5), (5, 7), (7, 7)],
                "story": "A cosmic flower that blooms once every thousand years.",
                "power": "Nurtures growth in barren cosmic soil",
                "points": 150
            },
            6: {
                "name": "⚖️ The Balance",
                "pattern": [(2, 3), (4, 1), (6, 2), (8, 1), (10, 3), (6, 5), (4, 6), (8, 6)],
                "story": "Maintains equilibrium between order and chaos.",
                "power": "Harmonizes opposing forces",
                "points": 175
            },
            7: {
                "name": "🎭 The Mirror",
                "pattern": [(3, 2), (5, 1), (7, 1), (9, 2), (3, 6), (5, 7), (7, 7), (9, 6)],
                "story": "Reflects the true nature of all who gaze upon it.",
                "power": "Reveals hidden truths and illusions",
                "points": 200
            },
            8: {
                "name": "🌀 The Spiral",
                "pattern": [(6, 4), (7, 3), (8, 4), (7, 5), (6, 5), (5, 4), (5, 3), (6, 2), (8, 3)],
                "story": "An infinite spiral that connects all dimensions.",
                "power": "Creates pathways between worlds",
                "points": 225
            },
            9: {
                "name": "👁️ The Watcher",
                "pattern": [(5, 4), (3, 3), (7, 3), (2, 4), (8, 4), (3, 5), (7, 5), (5, 2), (5, 6)],
                "story": "The eternal guardian that sees all across time and space.",
                "power": "Grants cosmic wisdom and foresight",
                "points": 250
            },
            10: {
                "name": "♾️ The Infinite",
                "pattern": [(4, 4), (6, 2), (8, 4), (10, 2), (12, 4), (10, 6), (8, 4), (6, 6)],
                "story": "The symbol of endless possibility and eternal existence.",
                "power": "Transcends all limitations and boundaries",
                "points": 300
            }
        }
        
        # Star brightness levels
        self.star_brightness = [".", "·", "∘", "○", "●", "✦", "✧", "✨", "⭐", "🌟"]
        
    def show_intro(self):
        """Display game introduction and stellar lore"""
        clear_screen()
        
        intro_banner = create_banner("CONSTELLATION BUILDER", color=Fore.YELLOW)
        print(intro_banner)
        
        slow_print(rainbow_text("⭐ Welcome to the cosmic canvas of infinite starlight! ⭐"), delay=0.03)
        time.sleep(1)
        
        lore = [
            "\n🌌 STELLAR LORE:",
            "Long ago, cosmic architects scattered stars across the void.",
            "Each constellation holds ancient power and forgotten wisdom.",
            "As a Starweaver, you can connect these celestial dots",
            "to unlock the stories hidden in the night sky.",
            "",
            "🔭 CONSTELLATION CRAFTING:",
            "⭐ Click on stars to begin forming connections",
            "✨ Follow the pattern hints to complete constellations",
            "🌟 Each completed pattern unlocks its mythical power",
            "💫 Cosmic energy flows through your stellar creations",
            "🎆 Discover all 10 legendary constellations!",
            "",
            "🌠 POWERS AWAIT:",
            "Each constellation grants unique cosmic abilities",
            "that will aid you in your celestial journey!",
        ]
        
        for text in lore:
            if text.startswith("🌌") or text.startswith("🔭") or text.startswith("🌠"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.CYAN + "\n⭐ Ready to weave the stars? Press ENTER to begin!", delay=0.03)
        input()
    
    def generate_star_field(self):
        """Generate a random star field for the current level"""
        self.stars = []
        self.connections = []
        self.current_constellation = []
        
        # Get pattern for current level
        if self.level in self.constellation_patterns:
            target_pattern = self.constellation_patterns[self.level]["pattern"]
            
            # Place target stars
            for x, y in target_pattern:
                brightness = random.choice([6, 7, 8])  # Bright stars for patterns
                self.stars.append({"x": x, "y": y, "brightness": brightness, "is_target": True})
            
            # Add random background stars
            for _ in range(15 + self.level * 2):
                x = random.randint(0, self.sky_width - 1)
                y = random.randint(0, self.sky_height - 1)
                
                # Avoid placing on target positions
                if not any(star["x"] == x and star["y"] == y for star in self.stars):
                    brightness = random.randint(0, 5)
                    self.stars.append({"x": x, "y": y, "brightness": brightness, "is_target": False})
    
    def draw_sky(self):
        """Draw the current star field and connections"""
        clear_screen()
        
        # Header info
        energy_color = Fore.YELLOW if self.cosmic_energy > 50 else Fore.RED
        info = f"⭐ CONSTELLATION BUILDER | Level: {self.level}/10 | Energy: {energy_color}{self.cosmic_energy}% | Legend Points: {self.legend_points}"
        print(Fore.CYAN + info)
        print(Fore.WHITE + "─" * 80)
        
        # Create sky canvas
        sky = [[" " for _ in range(self.sky_width)] for _ in range(self.sky_height)]
        
        # Place stars
        for i, star in enumerate(self.stars):
            x, y = star["x"], star["y"]
            if 0 <= x < self.sky_width and 0 <= y < self.sky_height:
                brightness_char = self.star_brightness[min(star["brightness"], len(self.star_brightness) - 1)]
                
                # Color based on whether it's selected or target
                if i in self.current_constellation:
                    color = Fore.YELLOW + Style.BRIGHT
                elif star["is_target"]:
                    color = Fore.CYAN
                else:
                    color = Fore.WHITE
                
                sky[y][x] = color + brightness_char
        
        # Draw connections
        connection_points = set()
        for start_idx, end_idx in self.connections:
            start_star = self.stars[start_idx]
            end_star = self.stars[end_idx]
            
            # Simple line drawing between stars
            connection_points.update(self.get_line_points(
                start_star["x"], start_star["y"], 
                end_star["x"], end_star["y"]
            ))
        
        # Add connection lines
        for x, y in connection_points:
            if (0 <= x < self.sky_width and 0 <= y < self.sky_height and 
                sky[y][x] == " "):
                sky[y][x] = Fore.MAGENTA + "─"
        
        # Display sky
        for row in sky:
            print("  " + "".join(row))
        
        print(Fore.WHITE + "─" * 80)
        
        # Show current constellation info
        if self.level in self.constellation_patterns:
            pattern_info = self.constellation_patterns[self.level]
            print(f"{Fore.YELLOW}🎯 Target: {pattern_info['name']}")
            print(f"{Fore.WHITE}📜 {pattern_info['story']}")
            print(f"{Fore.MAGENTA}⚡ Power: {pattern_info['power']}")
            
            progress = len(self.current_constellation)
            total = len(pattern_info["pattern"])
            print(f"{Fore.CYAN}⭐ Progress: {progress}/{total} stars connected")
    
    def get_line_points(self, x1, y1, x2, y2):
        """Get points for drawing a line between two coordinates"""
        points = []
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        
        if dx == 0 and dy == 0:
            return points
        
        steps = max(dx, dy)
        x_step = (x2 - x1) / steps if steps > 0 else 0
        y_step = (y2 - y1) / steps if steps > 0 else 0
        
        for i in range(1, steps):
            x = int(x1 + i * x_step)
            y = int(y1 + i * y_step)
            points.append((x, y))
        
        return points
    
    def find_star_at_position(self, x, y):
        """Find star index at given position"""
        for i, star in enumerate(self.stars):
            if star["x"] == x and star["y"] == y:
                return i
        return None
    
    def select_star(self, star_index):
        """Select a star for constellation building"""
        if star_index in self.current_constellation:
            # Deselect star
            self.current_constellation.remove(star_index)
            # Remove connections involving this star
            self.connections = [(s, e) for s, e in self.connections 
                              if s != star_index and e != star_index]
        else:
            # Select star
            self.current_constellation.append(star_index)
            
            # Connect to previous star if any
            if len(self.current_constellation) > 1:
                prev_star = self.current_constellation[-2]
                self.connections.append((prev_star, star_index))
        
        # Use cosmic energy
        self.cosmic_energy = max(0, self.cosmic_energy - 2)
    
    def check_constellation_complete(self):
        """Check if current constellation matches the target pattern"""
        if self.level not in self.constellation_patterns:
            return False
        
        target_pattern = self.constellation_patterns[self.level]["pattern"]
        
        if len(self.current_constellation) != len(target_pattern):
            return False
        
        # Check if selected stars match target positions (order doesn't matter)
        selected_positions = set()
        for star_idx in self.current_constellation:
            star = self.stars[star_idx]
            selected_positions.add((star["x"], star["y"]))
        
        target_positions = set(target_pattern)
        
        return selected_positions == target_positions
    
    def complete_constellation(self):
        """Handle constellation completion"""
        pattern_info = self.constellation_patterns[self.level]
        
        # Award points
        points = pattern_info["points"]
        energy_bonus = self.cosmic_energy // 2
        total_points = points + energy_bonus
        
        self.legend_points += total_points
        
        clear_screen()
        
        # Completion animation
        completion_banner = create_banner("CONSTELLATION COMPLETE!", color=Fore.YELLOW)
        print(completion_banner)
        
        slow_print(rainbow_text(f"✨ {pattern_info['name']} has awakened! ✨"), delay=0.05)
        time.sleep(1)
        
        # Show constellation story
        slow_print(f"\n{Fore.CYAN}📜 Legend:", delay=0.02)
        slow_print(f"{Fore.WHITE}   {pattern_info['story']}", delay=0.02)
        time.sleep(1)
        
        slow_print(f"\n{Fore.MAGENTA}⚡ Power Gained:", delay=0.02)
        slow_print(f"{Fore.YELLOW}   {pattern_info['power']}", delay=0.02)
        time.sleep(1)
        
        # Show points
        slow_print(f"\n{Fore.GREEN}🏆 Constellation Points: +{points}", delay=0.02)
        slow_print(f"{Fore.CYAN}⚡ Energy Bonus: +{energy_bonus}", delay=0.02)
        slow_print(f"{Fore.YELLOW}✨ Total Earned: +{total_points}", delay=0.02)
        slow_print(f"{Fore.WHITE}🌟 Legend Points: {self.legend_points}", delay=0.02)
        
        # Add to completed constellations
        self.completed_constellations.append(pattern_info["name"])
        
        # Restore some cosmic energy
        self.cosmic_energy = min(100, self.cosmic_energy + 25)
        
        time.sleep(3)
        
        if self.level < self.max_levels:
            slow_print(Fore.CYAN + f"\n🌌 Preparing stellar map {self.level + 1}...", delay=0.03)
            self.level += 1
            time.sleep(2)
            return True
        else:
            return False  # Game complete
    
    def show_star_map(self):
        """Show interactive star selection interface"""
        print(f"\n{Fore.GREEN}🔭 Select stars to form constellation:")
        print(f"{Fore.WHITE}   Enter coordinates as 'x y' (0-{self.sky_width-1}, 0-{self.sky_height-1})")
        print(f"{Fore.WHITE}   Type 'done' to complete constellation")
        print(f"{Fore.WHITE}   Type 'clear' to start over")
        print(f"{Fore.WHITE}   Type 'hint' for guidance")
        
        slow_print(Fore.CYAN + "\n⭐ Your command: ", delay=0.02, end="")
        
        try:
            command = input().strip().lower()
            
            if command == "done":
                if self.check_constellation_complete():
                    return self.complete_constellation()
                else:
                    slow_print(Fore.RED + "❌ Constellation pattern incomplete! Keep connecting stars.", delay=0.02)
                    time.sleep(1.5)
            
            elif command == "clear":
                self.current_constellation = []
                self.connections = []
                slow_print(Fore.YELLOW + "🌌 Constellation cleared!", delay=0.02)
                time.sleep(1)
            
            elif command == "hint":
                self.show_constellation_hint()
                time.sleep(2)
            
            elif command == "quit":
                return False
            
            else:
                # Try to parse coordinates
                parts = command.split()
                if len(parts) == 2:
                    x, y = int(parts[0]), int(parts[1])
                    
                    if 0 <= x < self.sky_width and 0 <= y < self.sky_height:
                        star_idx = self.find_star_at_position(x, y)
                        
                        if star_idx is not None:
                            self.select_star(star_idx)
                            star = self.stars[star_idx]
                            if star_idx in self.current_constellation:
                                slow_print(f"{Fore.GREEN}✨ Selected star at ({x}, {y})", delay=0.02)
                            else:
                                slow_print(f"{Fore.YELLOW}⭐ Deselected star at ({x}, {y})", delay=0.02)
                        else:
                            slow_print(Fore.RED + f"❌ No star found at ({x}, {y})", delay=0.02)
                    else:
                        slow_print(Fore.RED + f"❌ Coordinates out of bounds! Use 0-{self.sky_width-1}, 0-{self.sky_height-1}", delay=0.02)
                else:
                    slow_print(Fore.RED + "❌ Invalid command! Use 'x y', 'done', 'clear', or 'hint'", delay=0.02)
                
                time.sleep(1)
        
        except ValueError:
            slow_print(Fore.RED + "❌ Please enter valid numbers for coordinates!", delay=0.02)
            time.sleep(1)
        except Exception as e:
            slow_print(Fore.RED + f"❌ Error: {e}", delay=0.02)
            time.sleep(1)
        
        return True
    
    def show_constellation_hint(self):
        """Show hint for current constellation"""
        if self.level in self.constellation_patterns:
            pattern = self.constellation_patterns[self.level]["pattern"]
            slow_print(Fore.YELLOW + "💡 Constellation Hint:", delay=0.02)
            slow_print(Fore.CYAN + f"   Connect stars at these positions:", delay=0.02)
            
            for i, (x, y) in enumerate(pattern):
                slow_print(f"{Fore.WHITE}   {i+1}. ({x}, {y})", delay=0.01)
    
    def regenerate_energy(self):
        """Slowly regenerate cosmic energy"""
        if self.cosmic_energy < 100:
            self.cosmic_energy = min(100, self.cosmic_energy + 1)
    
    def show_final_legend(self):
        """Show the final legend of completed constellations"""
        clear_screen()
        
        legend_banner = create_banner("STELLAR LEGEND COMPLETE", color=Fore.MAGENTA)
        print(legend_banner)
        
        slow_print(rainbow_text("⭐ You have become a true Master of the Stars! ⭐"), delay=0.05)
        time.sleep(2)
        
        # Show completed constellations
        slow_print(f"\n{Fore.YELLOW}🌟 YOUR STELLAR LEGACY:", delay=0.03)
        for constellation in self.completed_constellations:
            slow_print(f"{Fore.CYAN}   ✨ {constellation}", delay=0.02)
            time.sleep(0.3)
        
        # Final statistics
        stats = [
            f"\n📊 COSMIC STATISTICS:",
            f"🏆 Legend Points: {self.legend_points}",
            f"⭐ Constellations: {len(self.completed_constellations)}/10",
            f"⚡ Final Energy: {self.cosmic_energy}%",
        ]
        
        for stat in stats:
            slow_print(Fore.WHITE + stat, delay=0.02)
            time.sleep(0.5)
        
        # Cosmic mastery evaluation
        if len(self.completed_constellations) == 10:
            slow_print(rainbow_text("🌌 COSMIC ARCHITECT! 🌌"), delay=0.05)
            evaluation = "You have mastered the ancient art of stellar weaving!"
        elif len(self.completed_constellations) >= 7:
            slow_print(Fore.YELLOW + "⭐ Stellar Master! ⭐", delay=0.03)
            evaluation = "Your constellations shine brightly across the cosmos!"
        elif len(self.completed_constellations) >= 5:
            slow_print(Fore.CYAN + "🌟 Star Weaver! 🌟", delay=0.03)
            evaluation = "You've learned to read the language of stars!"
        elif len(self.completed_constellations) >= 3:
            slow_print(Fore.BLUE + "✨ Cosmic Student! ✨", delay=0.03)
            evaluation = "Your journey into the stars has begun!"
        else:
            slow_print(Fore.WHITE + "🌱 Stargazer Apprentice! 🌱", delay=0.03)
            evaluation = "The stars await your return, young astronomer!"
        
        slow_print(f"\n{Fore.MAGENTA}💫 {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.level <= self.max_levels and self.cosmic_energy > 0:
            # Generate new star field for current level
            self.generate_star_field()
            
            # Level loop
            while True:
                # Regenerate energy slowly
                self.regenerate_energy()
                
                # Draw current state
                self.draw_sky()
                
                # Get player input
                continue_game = self.show_star_map()
                
                if not continue_game:
                    if self.level > self.max_levels:
                        # All levels completed
                        self.show_final_legend()
                    return
                elif self.level > len(self.constellation_patterns):
                    # Completed all constellations
                    self.show_final_legend()
                    return
                else:
                    # Continue to next level
                    break
                
                # Check if out of energy
                if self.cosmic_energy <= 0:
                    slow_print(Fore.RED + "💫 Your cosmic energy has been depleted!", delay=0.03)
                    time.sleep(2)
                    self.show_final_legend()
                    return
        
        # Show final results
        self.show_final_legend()

def main():
    """Main game entry point"""
    try:
        game = ConstellationBuilder()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 The stars await your return, cosmic architect!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Cosmic error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
