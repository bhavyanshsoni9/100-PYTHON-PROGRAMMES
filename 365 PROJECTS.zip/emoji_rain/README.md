# 🌧️ Emoji Rain

**Created by Bhavyansh Soni**

## Description
An exciting terminal-based game where players catch falling emojis in a colorful storm! Navigate your catcher left and right to collect various emojis, each with different point values and rarities. Avoid lightning bolts and try to survive as long as possible!

## Gameplay Features
- 🎯 **Dynamic Movement**: Use A/D or arrow keys to move your catcher
- 🌟 **Multiple Emoji Types**: Different emojis with varying point values and rarities
- ⚡ **Penalty System**: Lightning bolts reduce your score
- ❤️ **Life System**: 3 lives - don't let valuable emojis hit the ground
- 🚀 **Progressive Difficulty**: Speed increases with each level
- 🏆 **Scoring System**: Rare emojis give more points

## Emoji Values
- 💎 Diamond: 50 points (very rare)
- 🌟 Star: 30 points (rare)
- 💰 Money: 25 points 
- 🎁 Gift: 20 points
- 🍕 Pizza: 15 points
- 🎈 Balloon: 10 points
- ☁️ Cloud: 5 points
- ⚡ Lightning: -10 points (avoid!)

## Controls
- **A** or **←**: Move left
- **D** or **→**: Move right
- **Q**: Quit game

## How to Play
1. Run the game from the main launcher
2. Use movement keys to position your catcher (🎯)
3. Catch falling emojis to score points
4. Avoid lightning bolts that reduce your score
5. Don't let valuable emojis hit the ground or you'll lose a life
6. Survive as long as possible and achieve the highest score!

## Scoring Tiers
- 🌟 **500+ points**: Legendary Emoji Catcher
- 🎯 **300+ points**: Excellent Storm Survivor
- 👍 **150+ points**: Good Emoji Hunter
- 🌱 **Below 150**: Keep practicing!

## Technical Features
- Colorful terminal output with emoji animations
- Real-time input handling
- Progressive difficulty scaling
- Visual effects for catching and losing lives
- Score-based level progression
