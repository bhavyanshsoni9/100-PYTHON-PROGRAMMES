#!/usr/bin/env python3
"""
🌸 EMOTION GARDEN 🌸
Created by Bhavyansh Soni

An original nurturing game where players grow emotions into beautiful emoji flowers.
Tend to your garden with care, water feelings with experiences, and watch your
emotional landscape bloom into a stunning display of human complexity!
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class EmotionGarden:
    def __init__(self):
        self.garden_width = 12
        self.garden_height = 8
        self.garden = {}
        self.day = 1
        self.max_days = 21  # 3 weeks of emotional growth
        self.harmony_score = 0
        self.total_flowers = 0
        self.garden_health = 100
        
        # Emotion types with growth requirements and appearances
        self.emotion_types = {
            "joy": {
                "seed": "😊", "sprout": "🌱", "bloom": "🌻", "mature": "🌟",
                "color": Fore.YELLOW, "water_need": "laughter", "sunlight_need": "friendship",
                "growth_days": 3, "harmony_value": 10
            },
            "love": {
                "seed": "💕", "sprout": "💗", "bloom": "🌹", "mature": "💖",
                "color": Fore.RED, "water_need": "compassion", "sunlight_need": "connection",
                "growth_days": 4, "harmony_value": 15
            },
            "peace": {
                "seed": "😌", "sprout": "🕊️", "bloom": "🌸", "mature": "☮️",
                "color": Fore.BLUE, "water_need": "meditation", "sunlight_need": "solitude",
                "growth_days": 5, "harmony_value": 12
            },
            "courage": {
                "seed": "😤", "sprout": "🔥", "bloom": "🦁", "mature": "⚔️",
                "color": Fore.RED, "water_need": "challenge", "sunlight_need": "confidence",
                "growth_days": 3, "harmony_value": 8
            },
            "wisdom": {
                "seed": "🤔", "sprout": "📚", "bloom": "🦉", "mature": "🧠",
                "color": Fore.CYAN, "water_need": "reflection", "sunlight_need": "experience",
                "growth_days": 6, "harmony_value": 20
            },
            "creativity": {
                "seed": "💡", "sprout": "🎨", "bloom": "🌈", "mature": "✨",
                "color": Fore.MAGENTA, "water_need": "inspiration", "sunlight_need": "freedom",
                "growth_days": 4, "harmony_value": 14
            },
            "gratitude": {
                "seed": "🙏", "sprout": "🌿", "bloom": "🌺", "mature": "🙌",
                "color": Fore.GREEN, "water_need": "appreciation", "sunlight_need": "awareness",
                "growth_days": 3, "harmony_value": 16
            },
            "hope": {
                "seed": "🌱", "sprout": "🌾", "bloom": "🌟", "mature": "🌅",
                "color": Fore.YELLOW, "water_need": "belief", "sunlight_need": "optimism",
                "growth_days": 5, "harmony_value": 18
            },
            "serenity": {
                "seed": "😊", "sprout": "🍃", "bloom": "💙", "mature": "🌊",
                "color": Fore.BLUE, "water_need": "calm", "sunlight_need": "balance",
                "growth_days": 7, "harmony_value": 22
            },
            "wonder": {
                "seed": "😯", "sprout": "👀", "bloom": "🔮", "mature": "🌌",
                "color": Fore.MAGENTA, "water_need": "curiosity", "sunlight_need": "discovery",
                "growth_days": 4, "harmony_value": 13
            }
        }
        
        # Available experiences for watering emotions
        self.experiences = {
            "laughter": ["😂", "🎭", "🤡", "😹", "🎪"],
            "compassion": ["🤗", "❤️", "🫂", "💝", "🤲"],
            "meditation": ["🧘", "🕯️", "🔮", "🎋", "🌙"],
            "challenge": ["🏔️", "🏃", "💪", "🎯", "⚡"],
            "reflection": ["🪞", "📖", "🌅", "🤲", "💭"],
            "inspiration": ["🎶", "🎨", "📝", "🌈", "💫"],
            "appreciation": ["🙏", "💐", "🌹", "✨", "💝"],
            "belief": ["🕯️", "🌟", "🔥", "💫", "🌅"],
            "calm": ["🌊", "🍃", "☁️", "🕊️", "💙"],
            "curiosity": ["🔍", "❓", "🧐", "🔬", "🗝️"],
            "friendship": ["👥", "🤝", "💌", "🎈", "🎉"],
            "connection": ["💕", "🌉", "🔗", "💞", "🤝"],
            "solitude": ["🌙", "🏔️", "🌲", "🕯️", "📚"],
            "confidence": ["💪", "👑", "⭐", "🦋", "🌟"],
            "experience": ["🎓", "🌍", "📚", "🗺️", "⏳"],
            "freedom": ["🦋", "🕊️", "🌈", "🌊", "🌅"],
            "awareness": ["👁️", "🌅", "🧘", "💎", "🔮"],
            "optimism": ["☀️", "🌈", "😊", "🌱", "⭐"],
            "balance": ["⚖️", "☯️", "🌊", "🌸", "🕊️"],
            "discovery": ["🔍", "🗺️", "💎", "🌟", "🚪"]
        }
        
    def show_intro(self):
        """Display game introduction and garden philosophy"""
        clear_screen()
        
        intro_banner = create_banner("EMOTION GARDEN", color=Fore.GREEN)
        print(intro_banner)
        
        slow_print(rainbow_text("🌸 Welcome to the most beautiful garden of human feelings! 🌸"), delay=0.03)
        time.sleep(1)
        
        philosophy = [
            "\n🌱 GARDEN PHILOSOPHY:",
            "Every emotion is a seed waiting to bloom into something beautiful.",
            "Nurture your feelings with experiences and watch them grow.",
            "A balanced garden creates harmony within the soul.",
            "",
            "🌻 HOW TO TEND YOUR GARDEN:",
            "🌱 Plant emotion seeds in your garden plots",
            "💧 Water them with appropriate experiences",
            "☀️ Provide sunlight through matching activities",
            "⏰ Wait patiently for growth - emotions take time",
            "🌸 Harvest mature flowers for harmony points",
            "🌿 Maintain garden health through balance",
            "",
            "🎯 GOAL: Create a harmonious emotional landscape over 21 days!",
        ]
        
        for text in philosophy:
            if text.startswith("🌱") or text.startswith("🌻") or text.startswith("🎯"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.GREEN + "\n🌸 Ready to plant your first emotions? Press ENTER!", delay=0.03)
        input()
    
    def show_garden(self):
        """Display the current garden state"""
        clear_screen()
        
        # Garden info header
        health_color = Fore.GREEN if self.garden_health > 70 else Fore.YELLOW if self.garden_health > 40 else Fore.RED
        season = "🌱 Spring" if self.day <= 7 else "☀️ Summer" if self.day <= 14 else "🍂 Autumn"
        
        info = f"🌸 EMOTION GARDEN | Day {self.day}/21 | {season} | Harmony: {self.harmony_score} | Health: {health_color}{self.garden_health}%"
        print(Fore.GREEN + info)
        print(Fore.WHITE + "─" * 80)
        
        # Draw garden grid
        print(Fore.WHITE + "   " + " ".join([f"{i:2}" for i in range(self.garden_width)]))
        
        for y in range(self.garden_height):
            row = f"{y:2} "
            for x in range(self.garden_width):
                if (x, y) in self.garden:
                    plant = self.garden[(x, y)]
                    emotion_data = self.emotion_types[plant["type"]]
                    
                    # Determine growth stage
                    if plant["days_planted"] >= emotion_data["growth_days"]:
                        emoji = emotion_data["mature"]
                    elif plant["days_planted"] >= emotion_data["growth_days"] - 1:
                        emoji = emotion_data["bloom"]
                    elif plant["days_planted"] >= 1:
                        emoji = emotion_data["sprout"]
                    else:
                        emoji = emotion_data["seed"]
                    
                    # Color based on health
                    if plant["health"] > 80:
                        color = emotion_data["color"]
                    elif plant["health"] > 50:
                        color = Fore.YELLOW
                    else:
                        color = Fore.RED
                    
                    row += color + emoji + " "
                else:
                    row += Fore.BLACK + "🟫 "  # Empty soil
            
            print(row)
        
        print(Fore.WHITE + "─" * 80)
    
    def show_daily_menu(self):
        """Show daily gardening options"""
        print(Fore.CYAN + f"\n🌅 Day {self.day} - What would you like to do?")
        print(Fore.WHITE + "[1] 🌱 Plant new emotion")
        print(Fore.WHITE + "[2] 💧 Water existing plants")
        print(Fore.WHITE + "[3] ☀️ Provide sunlight")
        print(Fore.WHITE + "[4] 🌸 Harvest mature flowers")
        print(Fore.WHITE + "[5] 📊 Check garden status")
        print(Fore.WHITE + "[6] ⏰ End day")
        print(Fore.WHITE + "[0] 🚪 Quit garden")
        
        slow_print(Fore.GREEN + "\n🌻 Your choice: ", delay=0.02, end="")
        
        try:
            choice = input().strip()
            return choice
        except:
            return "0"
    
    def plant_emotion(self):
        """Plant a new emotion in the garden"""
        clear_screen()
        self.show_garden()
        
        slow_print(Fore.YELLOW + "\n🌱 PLANTING NEW EMOTION", delay=0.03)
        
        # Show available emotions
        emotions = list(self.emotion_types.keys())
        print(Fore.WHITE + "\nAvailable emotions to plant:")
        
        for i, emotion in enumerate(emotions, 1):
            data = self.emotion_types[emotion]
            color = data["color"]
            print(f"{color}[{i}] {emotion.title()} {data['seed']} (grows in {data['growth_days']} days)")
        
        try:
            slow_print(Fore.GREEN + "\nChoose emotion (1-{}): ".format(len(emotions)), delay=0.02, end="")
            choice = int(input().strip())
            
            if 1 <= choice <= len(emotions):
                emotion_type = emotions[choice - 1]
                
                # Get planting location
                slow_print(Fore.GREEN + "Enter location (x y): ", delay=0.02, end="")
                location = input().strip().split()
                
                if len(location) == 2:
                    x, y = int(location[0]), int(location[1])
                    
                    if (0 <= x < self.garden_width and 0 <= y < self.garden_height and 
                        (x, y) not in self.garden):
                        
                        # Plant the emotion
                        self.garden[(x, y)] = {
                            "type": emotion_type,
                            "days_planted": 0,
                            "health": 100,
                            "last_watered": 0,
                            "last_sunlight": 0
                        }
                        
                        data = self.emotion_types[emotion_type]
                        slow_print(f"{data['color']}🌱 Planted {emotion_type} {data['seed']} at ({x}, {y})!", delay=0.03)
                        time.sleep(1.5)
                        return
                    else:
                        slow_print(Fore.RED + "❌ Invalid location or spot already occupied!", delay=0.02)
                else:
                    slow_print(Fore.RED + "❌ Please enter x and y coordinates!", delay=0.02)
            else:
                slow_print(Fore.RED + "❌ Invalid emotion choice!", delay=0.02)
        except ValueError:
            slow_print(Fore.RED + "❌ Please enter valid numbers!", delay=0.02)
        except Exception as e:
            slow_print(Fore.RED + f"❌ Error: {e}", delay=0.02)
        
        time.sleep(1.5)
    
    def water_plants(self):
        """Water plants with experiences"""
        if not self.garden:
            slow_print(Fore.YELLOW + "🌱 No plants to water yet! Plant some emotions first.", delay=0.03)
            time.sleep(1.5)
            return
        
        clear_screen()
        self.show_garden()
        
        slow_print(Fore.BLUE + "\n💧 WATERING PLANTS WITH EXPERIENCES", delay=0.03)
        
        # Show plants that need watering
        plants_to_water = [(pos, plant) for pos, plant in self.garden.items() 
                          if plant["last_watered"] < self.day]
        
        if not plants_to_water:
            slow_print(Fore.GREEN + "✅ All plants are well-watered today!", delay=0.03)
            time.sleep(1.5)
            return
        
        print(Fore.WHITE + "\nPlants that need watering:")
        for i, (pos, plant) in enumerate(plants_to_water, 1):
            data = self.emotion_types[plant["type"]]
            needed_experience = data["water_need"]
            print(f"{data['color']}[{i}] {plant['type'].title()} at {pos} - needs: {needed_experience}")
        
        try:
            slow_print(Fore.GREEN + f"\nChoose plant to water (1-{len(plants_to_water)}): ", delay=0.02, end="")
            choice = int(input().strip())
            
            if 1 <= choice <= len(plants_to_water):
                pos, plant = plants_to_water[choice - 1]
                emotion_data = self.emotion_types[plant["type"]]
                needed_experience = emotion_data["water_need"]
                
                # Show available experiences
                available_experiences = self.experiences[needed_experience]
                
                print(f"\n{emotion_data['color']}💧 Watering {plant['type']} with {needed_experience}:")
                for i, exp in enumerate(available_experiences, 1):
                    print(f"{Fore.CYAN}[{i}] {exp}")
                
                slow_print(Fore.GREEN + f"Choose experience (1-{len(available_experiences)}): ", delay=0.02, end="")
                exp_choice = int(input().strip())
                
                if 1 <= exp_choice <= len(available_experiences):
                    chosen_exp = available_experiences[exp_choice - 1]
                    
                    # Apply watering
                    plant["last_watered"] = self.day
                    plant["health"] = min(100, plant["health"] + 20)
                    
                    slow_print(f"{emotion_data['color']}💧 Watered {plant['type']} with {chosen_exp}! Health: {plant['health']}%", delay=0.03)
                    time.sleep(1.5)
                    return
            
            slow_print(Fore.RED + "❌ Invalid choice!", delay=0.02)
        except ValueError:
            slow_print(Fore.RED + "❌ Please enter valid numbers!", delay=0.02)
        
        time.sleep(1.5)
    
    def provide_sunlight(self):
        """Provide sunlight activities to plants"""
        if not self.garden:
            slow_print(Fore.YELLOW + "🌱 No plants to give sunlight yet!", delay=0.03)
            time.sleep(1.5)
            return
        
        clear_screen()
        self.show_garden()
        
        slow_print(Fore.YELLOW + "\n☀️ PROVIDING SUNLIGHT ACTIVITIES", delay=0.03)
        
        # Show plants that need sunlight
        plants_for_sun = [(pos, plant) for pos, plant in self.garden.items() 
                         if plant["last_sunlight"] < self.day]
        
        if not plants_for_sun:
            slow_print(Fore.GREEN + "✅ All plants have received sunlight today!", delay=0.03)
            time.sleep(1.5)
            return
        
        print(Fore.WHITE + "\nPlants that need sunlight:")
        for i, (pos, plant) in enumerate(plants_for_sun, 1):
            data = self.emotion_types[plant["type"]]
            needed_activity = data["sunlight_need"]
            print(f"{data['color']}[{i}] {plant['type'].title()} at {pos} - needs: {needed_activity}")
        
        try:
            slow_print(Fore.GREEN + f"\nChoose plant for sunlight (1-{len(plants_for_sun)}): ", delay=0.02, end="")
            choice = int(input().strip())
            
            if 1 <= choice <= len(plants_for_sun):
                pos, plant = plants_for_sun[choice - 1]
                emotion_data = self.emotion_types[plant["type"]]
                needed_activity = emotion_data["sunlight_need"]
                
                # Show available activities
                available_activities = self.experiences[needed_activity]
                
                print(f"\n{emotion_data['color']}☀️ Giving {plant['type']} {needed_activity}:")
                for i, activity in enumerate(available_activities, 1):
                    print(f"{Fore.YELLOW}[{i}] {activity}")
                
                slow_print(Fore.GREEN + f"Choose activity (1-{len(available_activities)}): ", delay=0.02, end="")
                act_choice = int(input().strip())
                
                if 1 <= act_choice <= len(available_activities):
                    chosen_activity = available_activities[act_choice - 1]
                    
                    # Apply sunlight
                    plant["last_sunlight"] = self.day
                    plant["health"] = min(100, plant["health"] + 15)
                    
                    slow_print(f"{emotion_data['color']}☀️ Gave {plant['type']} {chosen_activity}! Health: {plant['health']}%", delay=0.03)
                    time.sleep(1.5)
                    return
            
            slow_print(Fore.RED + "❌ Invalid choice!", delay=0.02)
        except ValueError:
            slow_print(Fore.RED + "❌ Please enter valid numbers!", delay=0.02)
        
        time.sleep(1.5)
    
    def harvest_flowers(self):
        """Harvest mature flowers for harmony points"""
        mature_plants = []
        
        for pos, plant in self.garden.items():
            emotion_data = self.emotion_types[plant["type"]]
            if plant["days_planted"] >= emotion_data["growth_days"]:
                mature_plants.append((pos, plant))
        
        if not mature_plants:
            slow_print(Fore.YELLOW + "🌱 No mature flowers ready for harvest yet!", delay=0.03)
            time.sleep(1.5)
            return
        
        clear_screen()
        self.show_garden()
        
        slow_print(Fore.MAGENTA + "\n🌸 HARVESTING MATURE FLOWERS", delay=0.03)
        
        total_harmony = 0
        for pos, plant in mature_plants:
            emotion_data = self.emotion_types[plant["type"]]
            harmony_value = emotion_data["harmony_value"]
            
            # Health affects harvest value
            health_multiplier = plant["health"] / 100
            actual_harmony = int(harmony_value * health_multiplier)
            
            total_harmony += actual_harmony
            
            slow_print(f"{emotion_data['color']}🌸 Harvested {plant['type']} {emotion_data['mature']} (+{actual_harmony} harmony)", delay=0.02)
            
            # Remove harvested plant
            del self.garden[pos]
        
        self.harmony_score += total_harmony
        self.total_flowers += len(mature_plants)
        
        slow_print(f"\n{Fore.YELLOW}✨ Total harmony gained: {total_harmony}", delay=0.03)
        slow_print(f"{Fore.CYAN}🏆 Total harmony score: {self.harmony_score}", delay=0.03)
        
        time.sleep(2)
    
    def show_garden_status(self):
        """Show detailed garden statistics"""
        clear_screen()
        
        status_banner = create_banner("GARDEN STATUS", color=Fore.GREEN)
        print(status_banner)
        
        # Calculate statistics
        total_plants = len(self.garden)
        healthy_plants = len([p for p in self.garden.values() if p["health"] > 70])
        emotion_counts = {}
        
        for plant in self.garden.values():
            emotion_type = plant["type"]
            if emotion_type in emotion_counts:
                emotion_counts[emotion_type] += 1
            else:
                emotion_counts[emotion_type] = 1
        
        # Display statistics
        stats = [
            f"🌱 Total plants: {total_plants}",
            f"💚 Healthy plants: {healthy_plants}",
            f"🌸 Flowers harvested: {self.total_flowers}",
            f"✨ Harmony score: {self.harmony_score}",
            f"🌿 Garden health: {self.garden_health}%",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.3)
        
        if emotion_counts:
            slow_print(Fore.WHITE + "\n🎭 Emotion distribution:", delay=0.02)
            for emotion, count in emotion_counts.items():
                data = self.emotion_types[emotion]
                slow_print(f"{data['color']}  {emotion.title()}: {count} plants", delay=0.02)
                time.sleep(0.2)
        
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
    
    def advance_day(self):
        """Advance to the next day and update garden"""
        self.day += 1
        
        # Age all plants
        for plant in self.garden.values():
            plant["days_planted"] += 1
            
            # Reduce health if not cared for
            if plant["last_watered"] < self.day - 1:
                plant["health"] = max(0, plant["health"] - 10)
            
            if plant["last_sunlight"] < self.day - 1:
                plant["health"] = max(0, plant["health"] - 8)
        
        # Update garden health
        if self.garden:
            avg_health = sum(p["health"] for p in self.garden.values()) / len(self.garden)
            self.garden_health = int((self.garden_health + avg_health) / 2)
        
        # Show day transition
        clear_screen()
        slow_print(Fore.YELLOW + f"🌅 Day {self.day} dawns over your emotion garden...", delay=0.03)
        
        # Random daily events
        if random.random() < 0.3:
            self.random_garden_event()
        
        time.sleep(2)
    
    def random_garden_event(self):
        """Generate random garden events"""
        events = [
            ("🌧️ Gentle rain nourishes all plants!", "rain", 5),
            ("☀️ Perfect sunshine boosts plant growth!", "sun", 8),
            ("🦋 Butterflies bring joy to the garden!", "butterfly", 3),
            ("🐛 Pests attack unhealthy plants!", "pest", -10),
            ("🌙 Peaceful night restores garden harmony!", "peace", 10),
        ]
        
        event_text, event_type, effect = random.choice(events)
        
        slow_print(Fore.MAGENTA + f"\n✨ {event_text}", delay=0.03)
        
        if event_type == "pest":
            # Damage unhealthy plants
            for plant in self.garden.values():
                if plant["health"] < 50:
                    plant["health"] = max(0, plant["health"] + effect)
        else:
            # Boost all plants
            for plant in self.garden.values():
                plant["health"] = min(100, plant["health"] + effect)
        
        time.sleep(1.5)
    
    def show_final_garden(self):
        """Show the final garden evaluation"""
        clear_screen()
        
        final_banner = create_banner("GARDEN COMPLETE", color=Fore.MAGENTA)
        print(final_banner)
        
        slow_print(rainbow_text("🌸 Your 21-day emotional journey has ended! 🌸"), delay=0.05)
        time.sleep(2)
        
        # Calculate final scores
        diversity_score = len(set(plant["type"] for plant in self.garden.values())) * 10
        health_score = self.garden_health
        total_score = self.harmony_score + diversity_score + health_score
        
        # Display final statistics
        final_stats = [
            f"\n📊 FINAL GARDEN EVALUATION:",
            f"✨ Harmony Score: {self.harmony_score}",
            f"🎭 Diversity Bonus: {diversity_score} ({len(set(plant['type'] for plant in self.garden.values()))} emotion types)",
            f"🌿 Health Bonus: {health_score}",
            f"🏆 Total Score: {total_score}",
            f"🌸 Flowers Harvested: {self.total_flowers}",
        ]
        
        for stat in final_stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Garden mastery evaluation
        if total_score >= 800:
            slow_print(rainbow_text("🌟 MASTER EMOTIONAL GARDENER! 🌟"), delay=0.05)
            evaluation = "Your garden radiates perfect harmony and wisdom!"
        elif total_score >= 600:
            slow_print(Fore.MAGENTA + "🌸 Skilled Emotion Cultivator! 🌸", delay=0.03)
            evaluation = "You've created a beautiful and balanced emotional landscape!"
        elif total_score >= 400:
            slow_print(Fore.GREEN + "🌱 Growing Garden Tender! 🌱", delay=0.03)
            evaluation = "Your garden shows promise and growing wisdom!"
        elif total_score >= 200:
            slow_print(Fore.YELLOW + "🌿 Budding Emotional Gardener! 🌿", delay=0.03)
            evaluation = "You're learning to nurture your emotions well!"
        else:
            slow_print(Fore.BLUE + "🌱 Novice Garden Keeper! 🌱", delay=0.03)
            evaluation = "Every great gardener starts with a single seed!"
        
        slow_print(Fore.WHITE + f"\n💝 {evaluation}", delay=0.03)
        
        # Show final garden
        time.sleep(2)
        slow_print(Fore.GREEN + "\n🌸 Your final emotional garden:", delay=0.03)
        self.show_garden()
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.day <= self.max_days:
            self.show_garden()
            
            choice = self.show_daily_menu()
            
            if choice == "1":
                self.plant_emotion()
            elif choice == "2":
                self.water_plants()
            elif choice == "3":
                self.provide_sunlight()
            elif choice == "4":
                self.harvest_flowers()
            elif choice == "5":
                self.show_garden_status()
            elif choice == "6":
                self.advance_day()
            elif choice == "0":
                return
            else:
                slow_print(Fore.RED + "❌ Invalid choice! Try again.", delay=0.02)
                time.sleep(1)
        
        # Game completed
        self.show_final_garden()

def main():
    """Main game entry point"""
    try:
        game = EmotionGarden()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your emotional garden awaits your return!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Garden error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
