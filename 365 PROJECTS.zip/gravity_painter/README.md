# 🎨 Gravity Painter

**Created by Bhavyansh Soni**

## Description
A revolutionary physics-based art game where players paint with gravity-affected color drops! Experience the magic of watching paint fall, bounce, mix, and create stunning masterpieces through realistic physics simulation. Every brushstroke becomes a dance between intention and natural forces.

## Core Innovation
Unlike traditional digital painting, Gravity Painter simulates real physics for every paint drop. Watch colors flow downward with gravity, get pushed by wind forces, and interact naturally based on their density and viscosity properties. The result is organic, beautiful art that emerges from the interplay of intention and physics.

## Gameplay Features
- 🌊 **Real Physics Simulation**: Every paint drop obeys gravity, wind, and viscosity
- 🎨 **7 Unique Colors**: Each with distinct density and flow properties
- 🖌️ **5 Brush Types**: From precise droplets to explosive splashes
- ⚡ **Dynamic Forces**: Adjustable gravity and wind for creative control
- 🏆 **8 Art Challenges**: Master different physics painting techniques
- 🌈 **Natural Color Mixing**: Watch paints blend as they interact

## Physics Properties

### **Color Physics**
Each color has unique physical properties that affect how it flows:

- 🔴 **Crimson**: Dense and viscous (1.2 density, 0.8 viscosity) - Heavy, slow drops
- 🟡 **Golden**: Light and fluid (0.9 density, 0.6 viscosity) - Quick, flowing strokes  
- 🟢 **Emerald**: Balanced flow (1.0 density, 0.7 viscosity) - Natural painting feel
- 🔵 **Azure**: Light and smooth (0.8 density, 0.5 viscosity) - Ethereal, floating drops
- 🔵 **Sapphire**: Heavy and thick (1.1 density, 0.9 viscosity) - Rich, substantial drops
- 🟣 **Violet**: Heaviest paint (1.3 density, 1.0 viscosity) - Dramatic, weighty strokes
- ⚪ **Pearl**: Lightest paint (0.7 density, 0.4 viscosity) - Delicate, airy drops

### **Environmental Forces**
- **⬇️ Gravity (0.0-2.0)**: Controls how fast paint drops fall
- **💨 Wind (-1.0 to 1.0)**: Pushes drops horizontally, creating curves
- **🌊 Viscosity**: Individual to each color, affects flow resistance
- **⚖️ Density**: Determines how paint interacts with forces

## Brush Types & Techniques

### 🔸 **Droplet Brush**
- **Drops**: 1 precise drop
- **Spread**: None
- **Best For**: Detail work, precise lines, controlled painting

### 🌫️ **Spray Brush**  
- **Drops**: 5 scattered drops
- **Spread**: Medium randomization
- **Best For**: Texture effects, organic patterns, atmospheric painting

### 🌊 **Stream Brush**
- **Drops**: 3 in sequence
- **Spread**: None
- **Best For**: Flowing lines, continuous strokes, river-like effects

### 💥 **Splash Brush**
- **Drops**: 8 explosive drops
- **Spread**: Wide randomization  
- **Best For**: Dynamic bursts, energetic effects, impact painting

### ☁️ **Mist Brush**
- **Drops**: 12 fine drops
- **Spread**: Maximum dispersion
- **Best For**: Atmospheric effects, gentle coverage, subtle textures

## The Eight Art Challenges

### 🌧️ **Level 1: Rain Dance**
- **Theme**: Create vertical flowing patterns
- **Physics**: High gravity (1.0), no wind (0.0)
- **Goal**: Master downward paint flow
- **Technique**: Use stream and spray brushes for rainfall effects

### 🌪️ **Level 2: Wind Symphony**
- **Theme**: Paint with horizontal wind forces
- **Physics**: Medium gravity (0.6), strong wind (0.8)
- **Goal**: Create curved, wind-blown strokes
- **Technique**: Let wind carry your paint in flowing arcs

### 🌈 **Level 3: Color Cascade**
- **Theme**: Layer multiple colors beautifully
- **Physics**: Balanced gravity (0.8), light wind (0.2)
- **Goal**: Achieve color mixing and layering
- **Technique**: Use different color densities for layered effects

### ⚡ **Level 4: Lightning Strike**
- **Theme**: Create sharp angular patterns
- **Physics**: Strong gravity (1.2), medium wind (0.4)
- **Goal**: Make dramatic angular art
- **Technique**: Use droplet brush for precise geometric patterns

### 🌊 **Level 5: Ocean Waves**
- **Theme**: Flowing wave-like patterns
- **Physics**: Low gravity (0.4), strong wind (0.6)
- **Goal**: Create horizontal flowing waves
- **Technique**: Let low gravity and wind create undulating patterns

### 🎆 **Level 6: Fireworks**
- **Theme**: Explosive radiating patterns
- **Physics**: High gravity (0.9), light wind (0.3)
- **Goal**: Create radial burst patterns
- **Technique**: Use splash brush from center points

### 🌌 **Level 7: Galaxy Spiral**
- **Theme**: Swirling cosmic patterns
- **Physics**: Medium gravity (0.7), strong wind (0.9)
- **Goal**: Form spiral and swirling patterns
- **Technique**: Use wind to create curved, rotating flows

### ♾️ **Level 8: Infinite Flow**
- **Theme**: Master all physics forces
- **Physics**: Balanced forces (1.0 gravity, 0.5 wind)
- **Goal**: Create a masterpiece using all techniques
- **Technique**: Combine all previous skills for ultimate art

## Painting Commands & Controls

### **Basic Painting**
- `paint <x> <y>` - Drop paint at coordinates (0-23, 0-15)
- `color <1-7>` - Select paint color
- `brush <type>` - Change brush (droplet/spray/stream/splash/mist)

### **Physics Control**
- `physics` - Adjust gravity (0.0-2.0) and wind (-1.0 to 1.0)
- `step` - Advance physics simulation one step
- `auto` - Auto-simulate physics for 5 steps

### **Canvas Management**
- `clear` - Clear canvas and start over
- `finish` - Complete current painting and evaluate
- `quit` - Exit to main menu

## Scoring System

### **Art Evaluation Metrics**
- **🌈 Color Diversity**: 10 points per unique color used
- **🎨 Pattern Score**: Based on challenge-specific analysis
- **⚡ Energy Bonus**: Remaining energy ÷ 2
- **🏆 Total Score**: Sum of all metrics

### **Pattern Analysis Types**
- **Vertical Flow**: Detects continuous vertical paint streams
- **Curved Lines**: Recognizes wind-curved stroke patterns  
- **Color Mixing**: Rewards adjacent different colors
- **Angular Art**: Finds sharp geometric patterns
- **Wave Patterns**: Identifies horizontal flowing forms
- **Radial Burst**: Detects center-radiating patterns
- **Spiral Forms**: Recognizes swirling, rotating patterns
- **Overall Composition**: Evaluates masterpiece complexity

## Achievement Levels
- 🌟 **Physics Art Master**: Complete all 8 levels with high scores
- 🎨 **Gravity Artist Extraordinaire**: Complete 6+ levels excellently
- 🖌️ **Skilled Physics Painter**: Complete 4+ levels successfully
- 🌈 **Creative Explorer**: Complete 2+ levels while experimenting
- 🌱 **Budding Artist**: Beginning the physics painting journey

## Strategic Painting Tips

### **Physics Mastery**
1. **Understand Density**: Heavy colors (Violet, Crimson) fall faster
2. **Use Viscosity**: Low-viscosity colors (Pearl, Azure) flow more freely
3. **Wind Timing**: Apply wind after painting for dramatic curve effects
4. **Gravity Control**: Lower gravity for floating, ethereal effects

### **Brush Selection**
1. **Detail Work**: Use Droplet brush for precision
2. **Atmospheric Effects**: Mist brush for soft, ambient painting
3. **Dynamic Action**: Splash brush for energetic, explosive art
4. **Flowing Lines**: Stream brush for continuous, connected strokes
5. **Texture Building**: Spray brush for organic, natural textures

### **Color Strategy**
1. **Layer by Density**: Paint light colors first, heavy colors last
2. **Viscosity Mixing**: Combine fluid and thick paints for interesting effects
3. **Wind Interaction**: Light colors respond more dramatically to wind
4. **Gravity Play**: Heavy colors create strong vertical elements

### **Challenge Techniques**
1. **Rain Dance**: Use Stream brush with high gravity
2. **Wind Symphony**: Paint against strong wind for curves
3. **Color Cascade**: Layer different densities for natural mixing
4. **Lightning Strike**: Quick Droplet strokes with moderate wind
5. **Ocean Waves**: Low gravity + horizontal wind for flowing waves
6. **Fireworks**: Splash brush from center with radial planning
7. **Galaxy Spiral**: Curved brush movements with strong wind
8. **Infinite Flow**: Combine all techniques for ultimate expression

## Educational Value
- **Physics Understanding**: Learn gravity, density, viscosity concepts
- **Artistic Technique**: Develop understanding of flow and movement in art
- **Cause and Effect**: See immediate results of physics parameter changes
- **Creative Problem Solving**: Find artistic solutions within physical constraints
- **Pattern Recognition**: Understand how natural forces create recognizable forms
- **Resource Management**: Balance energy use with artistic ambition

## The Philosophy of Physics Art
"True art emerges not from fighting natural forces, but from dancing with them. In Gravity Painter, you become a conductor of physics, orchestrating the symphony of gravity, wind, and color. The most beautiful paintings arise when intention meets the unexpected grace of natural law."

## Technical Innovation
- Real-time physics simulation for individual paint drops
- Velocity and acceleration calculations for realistic movement
- Boundary collision detection with bounce effects
- Color-specific density and viscosity properties
- Wind force integration affecting horizontal movement
- Canvas interaction with natural paint settling
- Pattern recognition algorithms for artistic evaluation


