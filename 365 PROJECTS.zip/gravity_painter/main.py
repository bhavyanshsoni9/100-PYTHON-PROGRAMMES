#!/usr/bin/env python3
"""
🎨 GRAVITY PAINTER 🎨
Created by Bhavyansh Soni

An original physics-based art game where players paint with gravity-affected color drops!
Watch paint fall, bounce, mix, and create stunning masterpieces through the laws of physics.
Each brushstroke defies ordinary painting as colors flow and blend naturally!
"""

import random
import time
import sys
import os
import math
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class GravityPainter:
    def __init__(self):
        self.canvas_width = 24
        self.canvas_height = 16
        self.canvas = []
        self.paint_drops = []
        self.current_color = Fore.RED
        self.brush_size = 1
        self.gravity_strength = 0.8
        self.wind_force = 0.0
        self.viscosity = 0.9
        self.painting_energy = 100
        self.masterpiece_level = 1
        self.max_levels = 8
        self.art_score = 0
        
        # Color palette with physics properties
        self.color_palette = {
            Fore.RED: {"emoji": "🔴", "name": "Crimson", "density": 1.2, "viscosity": 0.8},
            Fore.YELLOW: {"emoji": "🟡", "name": "Golden", "density": 0.9, "viscosity": 0.6},
            Fore.GREEN: {"emoji": "🟢", "name": "Emerald", "density": 1.0, "viscosity": 0.7},
            Fore.CYAN: {"emoji": "🔵", "name": "Azure", "density": 0.8, "viscosity": 0.5},
            Fore.BLUE: {"emoji": "🔵", "name": "Sapphire", "density": 1.1, "viscosity": 0.9},
            Fore.MAGENTA: {"emoji": "🟣", "name": "Violet", "density": 1.3, "viscosity": 1.0},
            Fore.WHITE: {"emoji": "⚪", "name": "Pearl", "density": 0.7, "viscosity": 0.4}
        }
        
        # Brush types with different physics
        self.brush_types = {
            "droplet": {"size": 1, "drops": 1, "spread": 0, "description": "Single precise drop"},
            "spray": {"size": 2, "drops": 5, "spread": 2, "description": "Multiple scattered drops"},
            "stream": {"size": 1, "drops": 3, "spread": 0, "description": "Continuous flowing line"},
            "splash": {"size": 3, "drops": 8, "spread": 3, "description": "Explosive paint burst"},
            "mist": {"size": 1, "drops": 12, "spread": 4, "description": "Fine atmospheric spray"}
        }
        
        # Painting challenges
        self.painting_challenges = {
            1: {
                "name": "🌧️ Rain Dance",
                "theme": "Create vertical flowing patterns",
                "gravity": 1.0, "wind": 0.0, "target": "vertical_flow"
            },
            2: {
                "name": "🌪️ Wind Symphony", 
                "theme": "Paint with horizontal wind forces",
                "gravity": 0.6, "wind": 0.8, "target": "curved_lines"
            },
            3: {
                "name": "🌈 Color Cascade",
                "theme": "Layer multiple colors beautifully",
                "gravity": 0.8, "wind": 0.2, "target": "color_mixing"
            },
            4: {
                "name": "⚡ Lightning Strike",
                "theme": "Create sharp angular patterns",
                "gravity": 1.2, "wind": 0.4, "target": "angular_art"
            },
            5: {
                "name": "🌊 Ocean Waves",
                "theme": "Flowing wave-like patterns",
                "gravity": 0.4, "wind": 0.6, "target": "wave_pattern"
            },
            6: {
                "name": "🎆 Fireworks",
                "theme": "Explosive radiating patterns",
                "gravity": 0.9, "wind": 0.3, "target": "radial_burst"
            },
            7: {
                "name": "🌌 Galaxy Spiral",
                "theme": "Swirling cosmic patterns",
                "gravity": 0.7, "wind": 0.9, "target": "spiral_form"
            },
            8: {
                "name": "♾️ Infinite Flow",
                "theme": "Master all physics forces",
                "gravity": 1.0, "wind": 0.5, "target": "masterpiece"
            }
        }
        
        self.current_brush = "droplet"
        
    def show_intro(self):
        """Display game introduction and physics painting concepts"""
        clear_screen()
        
        intro_banner = create_banner("GRAVITY PAINTER", color=Fore.CYAN)
        print(intro_banner)
        
        slow_print(rainbow_text("🎨 Welcome to the most revolutionary painting experience! 🎨"), delay=0.03)
        time.sleep(1)
        
        physics_intro = [
            "\n🌌 PHYSICS-BASED PAINTING:",
            "Every drop of paint obeys the laws of physics!",
            "Gravity pulls colors downward with realistic force.",
            "Wind can blow drops sideways creating curved strokes.",
            "Different colors have unique density and viscosity.",
            "Paint drops bounce, merge, and create natural patterns!",
            "",
            "🎯 PAINTING MECHANICS:",
            "🖌️ Choose brush types with different physics properties",
            "🎨 Select colors with unique flow characteristics",
            "⚡ Adjust gravity and wind forces for your vision",
            "🌈 Watch paint drops interact and blend naturally",
            "🏆 Complete 8 physics challenges to master the art!",
            "",
            "🔬 PHYSICS FORCES:",
            "⬇️ Gravity: Pulls paint drops downward",
            "💨 Wind: Pushes drops horizontally", 
            "🌊 Viscosity: Controls how paint flows and sticks",
            "⚖️ Density: Affects how drops fall and interact",
        ]
        
        for text in physics_intro:
            if text.startswith("🌌") or text.startswith("🎯") or text.startswith("🔬"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.GREEN + "\n🎨 Ready to paint with physics? Press ENTER to begin!", delay=0.03)
        input()
    
    def initialize_canvas(self):
        """Initialize a blank canvas"""
        self.canvas = [[Fore.BLACK for _ in range(self.canvas_width)] for _ in range(self.canvas_height)]
        self.paint_drops = []
    
    def show_challenge_intro(self):
        """Display introduction for current painting challenge"""
        clear_screen()
        
        challenge = self.painting_challenges[self.masterpiece_level]
        
        challenge_banner = create_banner(f"LEVEL {self.masterpiece_level}", color=Fore.MAGENTA)
        print(challenge_banner)
        
        slow_print(f"{Fore.MAGENTA}🎨 {challenge['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}🎭 Theme: {challenge['theme']}", delay=0.02)
        slow_print(f"{Fore.WHITE}⬇️ Gravity: {challenge['gravity']}", delay=0.02)
        slow_print(f"{Fore.WHITE}💨 Wind: {challenge['wind']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🎯 Target: {challenge['target']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🎨 Energy: {self.painting_energy}%", delay=0.02)
        
        # Set physics for this challenge
        self.gravity_strength = challenge["gravity"]
        self.wind_force = challenge["wind"]
        
        time.sleep(2)
        slow_print(Fore.CYAN + "\n🖌️ Prepare your brushes! Press ENTER...", delay=0.03)
        input()
    
    def draw_canvas(self):
        """Draw the current canvas state with paint drops"""
        clear_screen()
        
        challenge = self.painting_challenges[self.masterpiece_level]
        
        # Header
        energy_color = Fore.GREEN if self.painting_energy > 60 else Fore.YELLOW if self.painting_energy > 30 else Fore.RED
        header = f"🎨 GRAVITY PAINTER | Level {self.masterpiece_level}: {challenge['name']} | Score: {self.art_score}"
        print(Fore.CYAN + header)
        
        physics_info = f"⬇️ Gravity: {self.gravity_strength:.1f} | 💨 Wind: {self.wind_force:.1f} | 🎨 Energy: {energy_color}{self.painting_energy}%"
        print(Fore.WHITE + physics_info)
        print(Fore.WHITE + "─" * 80)
        
        # Canvas with coordinates
        print(Fore.WHITE + "   " + "".join([f"{i%10}" for i in range(self.canvas_width)]))
        
        # Create display canvas
        display_canvas = [row[:] for row in self.canvas]
        
        # Add active paint drops
        for drop in self.paint_drops:
            x, y = int(drop["x"]), int(drop["y"])
            if 0 <= x < self.canvas_width and 0 <= y < self.canvas_height:
                color_info = self.color_palette[drop["color"]]
                display_canvas[y][x] = drop["color"] + color_info["emoji"]
        
        # Draw canvas
        for y in range(self.canvas_height):
            row_display = f"{y%10:1} "
            for x in range(self.canvas_width):
                cell = display_canvas[y][x]
                if cell == Fore.BLACK:
                    row_display += "⬛"
                else:
                    row_display += cell
            print(row_display)
        
        print(Fore.WHITE + "─" * 80)
        
        # Show current painting tools
        color_info = self.color_palette[self.current_color]
        brush_info = self.brush_types[self.current_brush]
        
        print(f"{Fore.YELLOW}🖌️ Brush: {self.current_brush} ({brush_info['description']})")
        print(f"{self.current_color}🎨 Color: {color_info['name']} {color_info['emoji']}")
    
    def show_painting_menu(self):
        """Show painting interface menu"""
        print(f"\n{Fore.GREEN}🎨 Painting Commands:")
        print(f"{Fore.WHITE}paint <x> <y> - Drop paint at coordinates")
        print(f"{Fore.WHITE}color <num> - Change color (1-7)")
        print(f"{Fore.WHITE}brush <type> - Change brush (droplet/spray/stream/splash/mist)")
        print(f"{Fore.WHITE}physics - Adjust gravity and wind forces")
        print(f"{Fore.WHITE}step - Advance physics simulation one step")
        print(f"{Fore.WHITE}auto - Auto-simulate physics for 5 steps")
        print(f"{Fore.WHITE}clear - Clear canvas")
        print(f"{Fore.WHITE}finish - Complete painting")
        print(f"{Fore.WHITE}quit - Exit to main menu")
        
        slow_print(Fore.CYAN + "\n🖌️ Your command: ", delay=0.02, end="")
        
        try:
            command = input().strip().lower()
            return command
        except:
            return ""
    
    def process_painting_command(self, command):
        """Process painting commands"""
        parts = command.split()
        
        if not parts:
            return True
        
        action = parts[0]
        
        if action == "paint" and len(parts) >= 3:
            try:
                x, y = int(parts[1]), int(parts[2])
                return self.drop_paint(x, y)
            except ValueError:
                slow_print(Fore.RED + "❌ Please use: paint <x> <y>", delay=0.02)
                time.sleep(1.5)
        
        elif action == "color" and len(parts) >= 2:
            try:
                color_num = int(parts[1])
                return self.change_color(color_num)
            except ValueError:
                slow_print(Fore.RED + "❌ Please use: color <1-7>", delay=0.02)
                time.sleep(1.5)
        
        elif action == "brush" and len(parts) >= 2:
            brush_type = parts[1]
            return self.change_brush(brush_type)
        
        elif action == "physics":
            return self.adjust_physics()
        
        elif action == "step":
            return self.simulate_physics_step()
        
        elif action == "auto":
            return self.auto_simulate()
        
        elif action == "clear":
            self.initialize_canvas()
            slow_print(Fore.YELLOW + "🎨 Canvas cleared!", delay=0.02)
            time.sleep(1)
        
        elif action == "finish":
            return self.finish_painting()
        
        elif action == "quit":
            return False
        
        else:
            slow_print(Fore.RED + "❌ Unknown command! See menu above.", delay=0.02)
            time.sleep(1.5)
        
        return True
    
    def drop_paint(self, x, y):
        """Drop paint at specified coordinates"""
        if not (0 <= x < self.canvas_width and 0 <= y < self.canvas_height):
            slow_print(Fore.RED + "❌ Coordinates out of bounds!", delay=0.02)
            time.sleep(1.5)
            return True
        
        if self.painting_energy < 5:
            slow_print(Fore.RED + "🎨 Insufficient painting energy!", delay=0.02)
            time.sleep(1.5)
            return True
        
        brush_info = self.brush_types[self.current_brush]
        color_info = self.color_palette[self.current_color]
        
        # Create paint drops based on brush type
        drops_created = 0
        for _ in range(brush_info["drops"]):
            # Add randomization based on brush spread
            spread = brush_info["spread"]
            drop_x = x + random.uniform(-spread/2, spread/2)
            drop_y = y + random.uniform(-spread/2, spread/2)
            
            # Create paint drop with physics properties
            paint_drop = {
                "x": drop_x,
                "y": drop_y,
                "vx": random.uniform(-0.3, 0.3),  # horizontal velocity
                "vy": random.uniform(-0.2, 0.2),  # vertical velocity
                "color": self.current_color,
                "density": color_info["density"],
                "viscosity": color_info["viscosity"],
                "life": 100,
                "stuck": False
            }
            
            self.paint_drops.append(paint_drop)
            drops_created += 1
        
        self.painting_energy -= 5
        
        slow_print(f"{self.current_color}🎨 Dropped {drops_created} paint drops at ({x}, {y})", delay=0.02)
        time.sleep(0.5)
        
        return True
    
    def change_color(self, color_num):
        """Change current paint color"""
        colors = list(self.color_palette.keys())
        
        if 1 <= color_num <= len(colors):
            self.current_color = colors[color_num - 1]
            color_info = self.color_palette[self.current_color]
            slow_print(f"{self.current_color}🎨 Color changed to {color_info['name']} {color_info['emoji']}", delay=0.02)
            time.sleep(1)
            return True
        else:
            slow_print(Fore.RED + f"❌ Color number must be 1-{len(colors)}", delay=0.02)
            time.sleep(1.5)
            return True
    
    def change_brush(self, brush_type):
        """Change current brush type"""
        if brush_type in self.brush_types:
            self.current_brush = brush_type
            brush_info = self.brush_types[brush_type]
            slow_print(f"{Fore.GREEN}🖌️ Brush changed to {brush_type} ({brush_info['description']})", delay=0.02)
            time.sleep(1)
            return True
        else:
            available_brushes = ", ".join(self.brush_types.keys())
            slow_print(Fore.RED + f"❌ Available brushes: {available_brushes}", delay=0.02)
            time.sleep(1.5)
            return True
    
    def adjust_physics(self):
        """Allow player to adjust physics forces"""
        clear_screen()
        
        slow_print(Fore.CYAN + "🔬 PHYSICS ADJUSTMENT", delay=0.03)
        slow_print(f"{Fore.WHITE}Current Gravity: {self.gravity_strength:.1f}", delay=0.02)
        slow_print(f"{Fore.WHITE}Current Wind: {self.wind_force:.1f}", delay=0.02)
        print()
        
        try:
            slow_print(Fore.GREEN + "⬇️ New gravity (0.0-2.0): ", delay=0.02, end="")
            gravity_input = input().strip()
            if gravity_input:
                new_gravity = float(gravity_input)
                if 0.0 <= new_gravity <= 2.0:
                    self.gravity_strength = new_gravity
                    slow_print(f"{Fore.GREEN}✅ Gravity set to {new_gravity:.1f}", delay=0.02)
                else:
                    slow_print(Fore.RED + "❌ Gravity must be between 0.0 and 2.0", delay=0.02)
            
            slow_print(Fore.GREEN + "💨 New wind (-1.0 to 1.0): ", delay=0.02, end="")
            wind_input = input().strip()
            if wind_input:
                new_wind = float(wind_input)
                if -1.0 <= new_wind <= 1.0:
                    self.wind_force = new_wind
                    slow_print(f"{Fore.GREEN}✅ Wind set to {new_wind:.1f}", delay=0.02)
                else:
                    slow_print(Fore.RED + "❌ Wind must be between -1.0 and 1.0", delay=0.02)
        
        except ValueError:
            slow_print(Fore.RED + "❌ Please enter valid numbers", delay=0.02)
        
        time.sleep(1.5)
        return True
    
    def simulate_physics_step(self):
        """Simulate one step of physics for paint drops"""
        if not self.paint_drops:
            slow_print(Fore.YELLOW + "🎨 No paint drops to simulate!", delay=0.02)
            time.sleep(1)
            return True
        
        drops_to_remove = []
        
        for i, drop in enumerate(self.paint_drops):
            if drop["stuck"]:
                continue
            
            # Apply gravity
            drop["vy"] += self.gravity_strength * 0.1
            
            # Apply wind
            drop["vx"] += self.wind_force * 0.05
            
            # Apply viscosity (resistance)
            drop["vx"] *= drop["viscosity"]
            drop["vy"] *= drop["viscosity"]
            
            # Update position
            drop["x"] += drop["vx"]
            drop["y"] += drop["vy"]
            
            # Check boundaries and stick to canvas
            x, y = int(drop["x"]), int(drop["y"])
            
            if y >= self.canvas_height - 1:  # Hit bottom
                drop["stuck"] = True
                drop["y"] = self.canvas_height - 1
                y = self.canvas_height - 1
            
            if x < 0:
                drop["x"] = 0
                drop["vx"] = -drop["vx"] * 0.5  # Bounce
            elif x >= self.canvas_width:
                drop["x"] = self.canvas_width - 1
                drop["vx"] = -drop["vx"] * 0.5  # Bounce
            
            # Paint the canvas if drop is in bounds
            if 0 <= x < self.canvas_width and 0 <= y < self.canvas_height:
                self.canvas[y][x] = drop["color"]
            
            # Age the drop
            drop["life"] -= 1
            if drop["life"] <= 0:
                drops_to_remove.append(i)
        
        # Remove expired drops
        for i in reversed(drops_to_remove):
            self.paint_drops.pop(i)
        
        active_drops = len([d for d in self.paint_drops if not d["stuck"]])
        slow_print(f"{Fore.CYAN}🌊 Physics step completed! Active drops: {active_drops}", delay=0.02)
        time.sleep(0.5)
        
        return True
    
    def auto_simulate(self):
        """Auto-simulate physics for several steps"""
        if not self.paint_drops:
            slow_print(Fore.YELLOW + "🎨 No paint drops to simulate!", delay=0.02)
            time.sleep(1)
            return True
        
        slow_print(Fore.MAGENTA + "🌊 Auto-simulating physics...", delay=0.03)
        
        for step in range(5):
            self.simulate_physics_step()
            time.sleep(0.3)
        
        slow_print(Fore.GREEN + "✅ Auto-simulation complete!", delay=0.02)
        time.sleep(1)
        
        return True
    
    def finish_painting(self):
        """Complete the current painting and evaluate it"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "🎨 PAINTING EVALUATION", delay=0.03)
        time.sleep(1)
        
        # Analyze painting for challenge completion
        challenge = self.painting_challenges[self.masterpiece_level]
        target = challenge["target"]
        
        # Calculate various art metrics
        color_diversity = self.calculate_color_diversity()
        pattern_score = self.calculate_pattern_score(target)
        energy_bonus = self.painting_energy // 2
        
        total_score = color_diversity + pattern_score + energy_bonus
        self.art_score += total_score
        
        slow_print(f"{Fore.WHITE}🎭 Challenge: {challenge['name']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🎯 Target: {target}", delay=0.02)
        
        # Show scoring breakdown
        score_info = [
            f"\n📊 PAINTING ANALYSIS:",
            f"🌈 Color Diversity: {color_diversity} points",
            f"🎨 Pattern Score: {pattern_score} points",
            f"⚡ Energy Bonus: {energy_bonus} points",
            f"🏆 Total Score: {total_score} points",
            f"🌟 Art Score: {self.art_score} points",
        ]
        
        for info in score_info:
            slow_print(Fore.CYAN + info, delay=0.02)
            time.sleep(0.5)
        
        # Evaluate painting quality
        if total_score >= 120:
            slow_print(Fore.MAGENTA + "\n🌟 MASTERPIECE! 🌟", delay=0.03)
            evaluation = "A transcendent work of physics art!"
        elif total_score >= 90:
            slow_print(Fore.YELLOW + "\n🎨 Excellent Art! 🎨", delay=0.03)
            evaluation = "Beautiful use of gravity and color!"
        elif total_score >= 60:
            slow_print(Fore.GREEN + "\n🖌️ Good Painting! 🖌️", delay=0.03)
            evaluation = "Creative exploration of physics!"
        else:
            slow_print(Fore.BLUE + "\n🌱 Artistic Beginning! 🌱", delay=0.03)
            evaluation = "Every master starts with experimentation!"
        
        slow_print(f"{Fore.WHITE}💫 {evaluation}", delay=0.03)
        
        # Restore some energy
        self.painting_energy = min(100, self.painting_energy + 40)
        
        time.sleep(3)
        
        if self.masterpiece_level < self.max_levels:
            slow_print(f"\n{Fore.CYAN}🎨 Preparing level {self.masterpiece_level + 1}...", delay=0.03)
            self.masterpiece_level += 1
            time.sleep(2)
            return True
        else:
            return False  # All levels complete
    
    def calculate_color_diversity(self):
        """Calculate color diversity score"""
        colors_used = set()
        
        for row in self.canvas:
            for cell in row:
                if cell != Fore.BLACK:
                    colors_used.add(cell)
        
        return len(colors_used) * 10
    
    def calculate_pattern_score(self, target):
        """Calculate pattern score based on target style"""
        score = 0
        
        if target == "vertical_flow":
            score = self.analyze_vertical_patterns()
        elif target == "curved_lines":
            score = self.analyze_curved_patterns()
        elif target == "color_mixing":
            score = self.analyze_color_mixing()
        elif target == "angular_art":
            score = self.analyze_angular_patterns()
        elif target == "wave_pattern":
            score = self.analyze_wave_patterns()
        elif target == "radial_burst":
            score = self.analyze_radial_patterns()
        elif target == "spiral_form":
            score = self.analyze_spiral_patterns()
        else:  # masterpiece
            score = self.analyze_overall_composition()
        
        return min(100, score)
    
    def analyze_vertical_patterns(self):
        """Analyze for vertical flowing patterns"""
        vertical_score = 0
        
        for x in range(self.canvas_width):
            consecutive_colors = 0
            for y in range(self.canvas_height):
                if self.canvas[y][x] != Fore.BLACK:
                    consecutive_colors += 1
                else:
                    if consecutive_colors >= 3:
                        vertical_score += consecutive_colors * 2
                    consecutive_colors = 0
            
            if consecutive_colors >= 3:
                vertical_score += consecutive_colors * 2
        
        return vertical_score
    
    def analyze_curved_patterns(self):
        """Analyze for curved line patterns"""
        # Simplified curve detection
        curve_score = 0
        
        for y in range(self.canvas_height - 1):
            for x in range(self.canvas_width - 2):
                if (self.canvas[y][x] != Fore.BLACK and 
                    self.canvas[y][x+1] != Fore.BLACK and
                    self.canvas[y+1][x+2] != Fore.BLACK):
                    curve_score += 5
        
        return curve_score
    
    def analyze_color_mixing(self):
        """Analyze for color variety and mixing"""
        mixing_score = 0
        
        for y in range(self.canvas_height):
            for x in range(self.canvas_width - 1):
                if (self.canvas[y][x] != Fore.BLACK and 
                    self.canvas[y][x+1] != Fore.BLACK and
                    self.canvas[y][x] != self.canvas[y][x+1]):
                    mixing_score += 3
        
        return mixing_score
    
    def analyze_angular_patterns(self):
        """Analyze for sharp angular patterns"""
        angular_score = 0
        
        # Look for diagonal patterns
        for y in range(self.canvas_height - 1):
            for x in range(self.canvas_width - 1):
                if (self.canvas[y][x] != Fore.BLACK and 
                    self.canvas[y+1][x+1] != Fore.BLACK):
                    angular_score += 2
        
        return angular_score
    
    def analyze_wave_patterns(self):
        """Analyze for wave-like flowing patterns"""
        wave_score = 0
        
        # Look for horizontal flowing patterns
        for y in range(self.canvas_height):
            consecutive = 0
            for x in range(self.canvas_width):
                if self.canvas[y][x] != Fore.BLACK:
                    consecutive += 1
                else:
                    if consecutive >= 4:
                        wave_score += consecutive
                    consecutive = 0
        
        return wave_score
    
    def analyze_radial_patterns(self):
        """Analyze for radial burst patterns"""
        radial_score = 0
        center_x, center_y = self.canvas_width // 2, self.canvas_height // 2
        
        # Check for paint spreading from center
        for radius in range(1, min(self.canvas_width, self.canvas_height) // 2):
            paint_at_radius = 0
            for angle in range(0, 360, 45):
                x = int(center_x + radius * math.cos(math.radians(angle)))
                y = int(center_y + radius * math.sin(math.radians(angle)))
                
                if (0 <= x < self.canvas_width and 0 <= y < self.canvas_height and
                    self.canvas[y][x] != Fore.BLACK):
                    paint_at_radius += 1
            
            if paint_at_radius >= 3:
                radial_score += paint_at_radius * 5
        
        return radial_score
    
    def analyze_spiral_patterns(self):
        """Analyze for spiral patterns"""
        # Simplified spiral detection
        spiral_score = 0
        
        for y in range(1, self.canvas_height - 1):
            for x in range(1, self.canvas_width - 1):
                if self.canvas[y][x] != Fore.BLACK:
                    # Check for spiral-like neighborhood
                    neighbors = [
                        self.canvas[y-1][x], self.canvas[y-1][x+1],
                        self.canvas[y][x+1], self.canvas[y+1][x+1],
                        self.canvas[y+1][x], self.canvas[y+1][x-1],
                        self.canvas[y][x-1], self.canvas[y-1][x-1]
                    ]
                    
                    painted_neighbors = sum(1 for n in neighbors if n != Fore.BLACK)
                    if 2 <= painted_neighbors <= 4:
                        spiral_score += 3
        
        return spiral_score
    
    def analyze_overall_composition(self):
        """Analyze overall artistic composition"""
        composition_score = 0
        
        # Multiple criteria for masterpiece
        composition_score += self.analyze_vertical_patterns() // 2
        composition_score += self.analyze_curved_patterns() // 2
        composition_score += self.analyze_color_mixing()
        composition_score += self.analyze_wave_patterns() // 2
        
        return composition_score
    
    def regenerate_energy(self):
        """Slowly regenerate painting energy"""
        if self.painting_energy < 100:
            self.painting_energy = min(100, self.painting_energy + 1)
    
    def show_final_gallery(self):
        """Show final art gallery results"""
        clear_screen()
        
        gallery_banner = create_banner("ART GALLERY MASTER", color=Fore.MAGENTA)
        print(gallery_banner)
        
        slow_print(rainbow_text("🎨 You have mastered the art of gravity painting! 🎨"), delay=0.05)
        time.sleep(2)
        
        # Show all completed challenges
        slow_print(f"\n{Fore.YELLOW}🖼️ YOUR ARTISTIC JOURNEY:", delay=0.03)
        
        for i in range(1, self.masterpiece_level):
            challenge = self.painting_challenges[i]
            slow_print(f"{Fore.CYAN}   {i}. {challenge['name']}", delay=0.02)
            time.sleep(0.3)
        
        # Final statistics
        avg_score = self.art_score // (self.masterpiece_level - 1) if self.masterpiece_level > 1 else 0
        
        stats = [
            f"\n📊 GALLERY STATISTICS:",
            f"🎨 Paintings Created: {self.masterpiece_level - 1}/{self.max_levels}",
            f"🏆 Total Art Score: {self.art_score}",
            f"🖌️ Average Painting Score: {avg_score}",
            f"⚡ Final Energy: {self.painting_energy}%",
        ]
        
        for stat in stats:
            slow_print(Fore.WHITE + stat, delay=0.02)
            time.sleep(0.5)
        
        # Art mastery evaluation
        completion_rate = ((self.masterpiece_level - 1) / self.max_levels) * 100
        
        if completion_rate == 100 and avg_score >= 90:
            slow_print(rainbow_text("🌟 PHYSICS ART MASTER! 🌟"), delay=0.05)
            evaluation = "You have transcended ordinary painting!"
        elif completion_rate >= 75:
            slow_print(Fore.MAGENTA + "🎨 Gravity Artist Extraordinaire! 🎨", delay=0.03)
            evaluation = "Your physics paintings are magnificent!"
        elif completion_rate >= 50:
            slow_print(Fore.YELLOW + "🖌️ Skilled Physics Painter! 🖌️", delay=0.03)
            evaluation = "You've learned to paint with natural forces!"
        elif completion_rate >= 25:
            slow_print(Fore.GREEN + "🌈 Creative Explorer! 🌈", delay=0.03)
            evaluation = "Your artistic journey through physics continues!"
        else:
            slow_print(Fore.BLUE + "🌱 Budding Artist! 🌱", delay=0.03)
            evaluation = "Every master painter started with a single drop!"
        
        slow_print(f"\n{Fore.CYAN}🎨 {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.masterpiece_level <= self.max_levels:
            # Initialize canvas
            self.initialize_canvas()
            
            # Show challenge introduction
            self.show_challenge_intro()
            
            # Painting loop
            while True:
                # Regenerate energy slowly
                self.regenerate_energy()
                
                # Draw and interact
                self.draw_canvas()
                command = self.show_painting_menu()
                
                continue_painting = self.process_painting_command(command)
                
                if not continue_painting:
                    if self.masterpiece_level > self.max_levels:
                        # All levels completed
                        self.show_final_gallery()
                    return
                elif self.masterpiece_level > self.max_levels:
                    # Completed all levels
                    self.show_final_gallery()
                    return
                else:
                    # Continue to next level or continue painting
                    if command == "finish":
                        break  # Move to next level
        
        # Show final results
        self.show_final_gallery()

def main():
    """Main game entry point"""
    try:
        game = GravityPainter()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your artistic canvas awaits your return!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Painting error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
