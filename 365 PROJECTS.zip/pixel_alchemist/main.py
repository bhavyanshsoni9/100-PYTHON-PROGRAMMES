#!/usr/bin/env python3
"""
🧪 PIXEL ALCHEMIST 🧪
Created by Bhavyansh Soni

An original ASCII transmutation game where players transform symbols into beautiful art!
Combine elemental characters, apply magical formulas, and discover the ancient art
of pixel alchemy. Turn simple text into stunning visual masterpieces!
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class PixelAlchemist:
    def __init__(self):
        self.laboratory_width = 20
        self.laboratory_height = 12
        self.transmutation_circle = []
        self.discovered_formulas = []
        self.element_inventory = {}
        self.alchemical_energy = 100
        self.mastery_level = 1
        self.max_levels = 9
        self.philosopher_points = 0
        
        # Elemental ASCII symbols with alchemical properties
        self.elemental_symbols = {
            "fire": {
                "chars": ["▲", "△", "🔥", "※", "✦", "✧", "⟡", "⋄"],
                "color": Fore.RED, "energy": 8, "volatility": 0.9,
                "essence": "passion", "emoji": "🔥"
            },
            "water": {
                "chars": ["▽", "∇", "≈", "~", "〜", "⟁", "∽", "⌇"],
                "color": Fore.BLUE, "energy": 6, "volatility": 0.3,
                "essence": "flow", "emoji": "💧"
            },
            "earth": {
                "chars": ["■", "▪", "▫", "□", "⬛", "⬜", "◼", "◻"],
                "color": Fore.GREEN, "energy": 4, "volatility": 0.1,
                "essence": "stability", "emoji": "🌍"
            },
            "air": {
                "chars": ["○", "◯", "◦", "●", "⚬", "⚭", "⚮", "⚯"],
                "color": Fore.CYAN, "energy": 7, "volatility": 0.7,
                "essence": "freedom", "emoji": "💨"
            },
            "light": {
                "chars": ["★", "☆", "✦", "✧", "✩", "✪", "✫", "✬"],
                "color": Fore.YELLOW, "energy": 9, "volatility": 0.8,
                "essence": "illumination", "emoji": "✨"
            },
            "shadow": {
                "chars": ["▓", "▒", "░", "▚", "▞", "▙", "▟", "▛"],
                "color": Fore.MAGENTA, "energy": 5, "volatility": 0.6,
                "essence": "mystery", "emoji": "🌑"
            },
            "void": {
                "chars": [" ", "⠀", "⠁", "⠂", "⠃", "⠄", "⠅", "⠆"],
                "color": Fore.BLACK, "energy": 10, "volatility": 1.0,
                "essence": "potential", "emoji": "🕳️"
            }
        }
        
        # Alchemical transmutation formulas
        self.transmutation_formulas = {
            1: {
                "name": "🔥 Flame Pattern",
                "elements": ["fire", "fire", "air"],
                "pattern": "triangle_flame",
                "difficulty": 1,
                "description": "Create a dancing flame"
            },
            2: {
                "name": "💧 Water Drop",
                "elements": ["water", "water", "earth"],
                "pattern": "droplet_form",
                "difficulty": 1,
                "description": "Form a perfect water droplet"
            },
            3: {
                "name": "🌟 Star Burst",
                "elements": ["light", "fire", "air", "light"],
                "pattern": "radial_star",
                "difficulty": 2,
                "description": "Explode light in all directions"
            },
            4: {
                "name": "🌙 Crescent Moon",
                "elements": ["shadow", "void", "light"],
                "pattern": "crescent_shape",
                "difficulty": 2,
                "description": "Balance light and shadow"
            },
            5: {
                "name": "🌊 Ocean Wave",
                "elements": ["water", "air", "water", "earth"],
                "pattern": "wave_motion",
                "difficulty": 3,
                "description": "Capture the essence of flowing water"
            },
            6: {
                "name": "🏔️ Mountain Peak",
                "elements": ["earth", "earth", "earth", "air", "shadow"],
                "pattern": "mountain_form",
                "difficulty": 3,
                "description": "Build towering strength"
            },
            7: {
                "name": "🌀 Spiral Galaxy",
                "elements": ["void", "light", "shadow", "air", "light"],
                "pattern": "spiral_cosmic",
                "difficulty": 4,
                "description": "Swirl the cosmic elements"
            },
            8: {
                "name": "🔮 Crystal Mandala",
                "elements": ["earth", "light", "water", "fire", "air", "shadow"],
                "pattern": "mandala_complex",
                "difficulty": 5,
                "description": "Perfect geometric harmony"
            },
            9: {
                "name": "♾️ Philosopher's Stone",
                "elements": ["fire", "water", "earth", "air", "light", "shadow", "void"],
                "pattern": "infinity_symbol",
                "difficulty": 6,
                "description": "The ultimate transmutation"
            }
        }
        
        # Pattern generation templates
        self.pattern_templates = {
            "triangle_flame": [
                "    ✦    ",
                "   ✦✦✦   ",
                "  ✦✦✦✦✦  ",
                " ✦✦✦✦✦✦✦ ",
                "✦✦✦✦✦✦✦✦✦"
            ],
            "droplet_form": [
                "   ●   ",
                "  ●●●  ",
                " ●●●●● ",
                "●●●●●●●",
                " ●●●●● ",
                "  ●●●  ",
                "   ●   "
            ],
            "radial_star": [
                "    ✦    ",
                " ✦  ✦  ✦ ",
                "✦ ✦ ✦ ✦ ✦",
                " ✦ ✦✦✦ ✦ ",
                "✦ ✦ ✦ ✦ ✦",
                " ✦  ✦  ✦ ",
                "    ✦    "
            ],
            "crescent_shape": [
                "  ●●●  ",
                " ●●●●● ",
                "●●● ●●●",
                "●●   ●●",
                "●●● ●●●",
                " ●●●●● ",
                "  ●●●  "
            ],
            "wave_motion": [
                "∽∽∽    ∽∽∽",
                " ∽∽∽  ∽∽∽ ",
                "  ∽∽∽∽∽∽  ",
                "   ∽∽∽∽   ",
                "  ∽∽∽∽∽∽  ",
                " ∽∽∽  ∽∽∽ ",
                "∽∽∽    ∽∽∽"
            ],
            "mountain_form": [
                "     ▲     ",
                "    ▲▲▲    ",
                "   ▲▲▲▲▲   ",
                "  ▲▲▲▲▲▲▲  ",
                " ▲▲▲▲▲▲▲▲▲ ",
                "▲▲▲▲▲▲▲▲▲▲▲"
            ],
            "spiral_cosmic": [
                "   ●●●●   ",
                "  ●    ●  ",
                " ●  ●●  ● ",
                "●  ●  ●  ●",
                " ●  ●●  ● ",
                "  ●    ●  ",
                "   ●●●●   "
            ],
            "mandala_complex": [
                "   ✦ ✦ ✦   ",
                "  ✦ ● ● ✦  ",
                " ✦ ● ✦ ● ✦ ",
                "✦ ● ✦ ✦ ✦ ● ✦",
                " ✦ ● ✦ ● ✦ ",
                "  ✦ ● ● ✦  ",
                "   ✦ ✦ ✦   "
            ],
            "infinity_symbol": [
                "  ●●    ●●  ",
                " ●  ●  ●  ● ",
                "●    ●●    ●",
                " ●  ●  ●  ● ",
                "  ●●    ●●  "
            ]
        }
        
    def show_intro(self):
        """Display game introduction and alchemical philosophy"""
        clear_screen()
        
        intro_banner = create_banner("PIXEL ALCHEMIST", color=Fore.MAGENTA)
        print(intro_banner)
        
        slow_print(rainbow_text("🧪 Welcome to the ancient art of ASCII transmutation! 🧪"), delay=0.03)
        time.sleep(1)
        
        alchemical_lore = [
            "\n✨ THE ALCHEMICAL ARTS:",
            "In the beginning, there were only simple symbols...",
            "But through the mystic art of pixel alchemy,",
            "these humble characters can be transmuted",
            "into works of transcendent beauty and power!",
            "",
            "🔬 TRANSMUTATION PROCESS:",
            "🧪 Gather elemental ASCII symbols",
            "📜 Learn ancient transmutation formulas", 
            "🔮 Combine elements in the transmutation circle",
            "✨ Channel alchemical energy to create art",
            "🏆 Master 9 levels of increasing complexity",
            "🌟 Discover the legendary Philosopher's Stone!",
            "",
            "⚗️ ELEMENTAL ESSENCES:",
            "Each element has unique properties and energies.",
            "Fire burns bright but volatile.",
            "Water flows smooth and stable.",
            "Earth provides solid foundation.",
            "Air brings freedom and movement.",
            "Light illuminates all possibilities.",
            "Shadow holds deep mysteries.",
            "Void contains infinite potential.",
        ]
        
        for text in alchemical_lore:
            if text.startswith("✨") or text.startswith("🔬") or text.startswith("⚗️"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.GREEN + "\n🧪 Ready to begin your alchemical journey? Press ENTER!", delay=0.03)
        input()
    
    def show_level_intro(self):
        """Display introduction for current mastery level"""
        clear_screen()
        
        formula = self.transmutation_formulas[self.mastery_level]
        
        level_banner = create_banner(f"MASTERY LEVEL {self.mastery_level}", color=Fore.MAGENTA)
        print(level_banner)
        
        slow_print(f"{Fore.MAGENTA}🧪 Next Transmutation: {formula['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}📜 Formula: {formula['description']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🔬 Difficulty: {formula['difficulty']}/6", delay=0.02)
        slow_print(f"{Fore.WHITE}⚗️ Alchemical Energy: {self.alchemical_energy}%", delay=0.02)
        slow_print(f"{Fore.WHITE}💎 Philosopher Points: {self.philosopher_points}", delay=0.02)
        
        # Show required elements
        slow_print(f"\n{Fore.CYAN}🧪 Required Elements:", delay=0.02)
        element_display = ""
        for element in formula["elements"]:
            element_data = self.elemental_symbols[element]
            element_display += f"{element_data['color']}{element_data['emoji']} "
        slow_print(element_display, delay=0.05)
        
        time.sleep(2)
        slow_print(Fore.GREEN + "\n⚗️ Enter the laboratory? Press ENTER...", delay=0.03)
        input()
    
    def initialize_inventory(self):
        """Initialize player's elemental inventory"""
        # Start with basic elements
        for element_name in self.elemental_symbols.keys():
            self.element_inventory[element_name] = random.randint(3, 8)
    
    def draw_laboratory(self):
        """Draw the alchemical laboratory interface"""
        clear_screen()
        
        formula = self.transmutation_formulas[self.mastery_level]
        
        # Header
        energy_color = Fore.GREEN if self.alchemical_energy > 60 else Fore.YELLOW if self.alchemical_energy > 30 else Fore.RED
        header = f"🧪 PIXEL ALCHEMIST | Level {self.mastery_level}: {formula['name']} | Points: {self.philosopher_points}"
        print(Fore.MAGENTA + header)
        
        status = f"⚗️ Energy: {energy_color}{self.alchemical_energy}% | 🔬 Difficulty: {formula['difficulty']}/6"
        print(Fore.WHITE + status)
        print(Fore.WHITE + "─" * 80)
        
        # Transmutation circle
        slow_print(Fore.CYAN + "🔮 TRANSMUTATION CIRCLE:", delay=0.01)
        if self.transmutation_circle:
            circle_display = " ".join([f"{self.elemental_symbols[elem]['color']}{self.elemental_symbols[elem]['emoji']}" 
                                     for elem in self.transmutation_circle])
            print(f"   {circle_display}")
        else:
            print(f"   {Fore.WHITE}(Empty - add elements to begin)")
        print()
        
        # Element inventory
        slow_print(Fore.YELLOW + "🧪 ELEMENTAL INVENTORY:", delay=0.01)
        for element, count in self.element_inventory.items():
            if count > 0:
                element_data = self.elemental_symbols[element]
                count_color = Fore.GREEN if count >= 3 else Fore.YELLOW if count >= 1 else Fore.RED
                print(f"   {element_data['color']}{element_data['emoji']} {element.title()}: {count_color}{count}")
        print()
        
        # Required formula
        slow_print(Fore.CYAN + f"📜 FORMULA - {formula['name']}:", delay=0.01)
        required_display = " + ".join([f"{self.elemental_symbols[elem]['color']}{self.elemental_symbols[elem]['emoji']}" 
                                     for elem in formula["elements"]])
        print(f"   {required_display}")
        print(f"   {Fore.WHITE}{formula['description']}")
        print(Fore.WHITE + "─" * 80)
    
    def show_alchemy_menu(self):
        """Show alchemical operation menu"""
        print(f"\n{Fore.GREEN}⚗️ Alchemical Operations:")
        print(f"{Fore.WHITE}add <element> - Add element to transmutation circle")
        print(f"{Fore.WHITE}remove <element> - Remove element from circle")
        print(f"{Fore.WHITE}clear - Clear transmutation circle")
        print(f"{Fore.WHITE}transmute - Attempt transmutation")
        print(f"{Fore.WHITE}gather - Gather more elemental materials")
        print(f"{Fore.WHITE}analyze - Analyze current circle composition")
        print(f"{Fore.WHITE}formulas - View discovered formulas")
        print(f"{Fore.WHITE}quit - Exit laboratory")
        
        slow_print(Fore.CYAN + "\n🔬 Your alchemical action: ", delay=0.02, end="")
        
        try:
            command = input().strip().lower()
            return command
        except:
            return ""
    
    def process_alchemy_command(self, command):
        """Process alchemical commands"""
        parts = command.split()
        
        if not parts:
            return True
        
        action = parts[0]
        
        if action == "add" and len(parts) >= 2:
            element = parts[1]
            return self.add_element_to_circle(element)
        
        elif action == "remove" and len(parts) >= 2:
            element = parts[1]
            return self.remove_element_from_circle(element)
        
        elif action == "clear":
            return self.clear_transmutation_circle()
        
        elif action == "transmute":
            return self.attempt_transmutation()
        
        elif action == "gather":
            return self.gather_elements()
        
        elif action == "analyze":
            return self.analyze_circle()
        
        elif action == "formulas":
            return self.show_formulas()
        
        elif action == "quit":
            return False
        
        else:
            slow_print(Fore.RED + "❌ Unknown alchemical operation! See menu above.", delay=0.02)
            time.sleep(1.5)
        
        return True
    
    def add_element_to_circle(self, element_name):
        """Add an element to the transmutation circle"""
        if element_name not in self.elemental_symbols:
            slow_print(Fore.RED + f"❌ Unknown element: {element_name}", delay=0.02)
            available = ", ".join(self.elemental_symbols.keys())
            slow_print(Fore.WHITE + f"Available: {available}", delay=0.01)
            time.sleep(2)
            return True
        
        if self.element_inventory.get(element_name, 0) <= 0:
            slow_print(Fore.RED + f"❌ No {element_name} elements in inventory!", delay=0.02)
            time.sleep(1.5)
            return True
        
        if self.alchemical_energy < 5:
            slow_print(Fore.RED + "⚗️ Insufficient alchemical energy!", delay=0.02)
            time.sleep(1.5)
            return True
        
        # Add element to circle
        self.transmutation_circle.append(element_name)
        self.element_inventory[element_name] -= 1
        self.alchemical_energy -= 5
        
        element_data = self.elemental_symbols[element_name]
        slow_print(f"{element_data['color']}✨ Added {element_data['emoji']} {element_name.title()} to the circle!", delay=0.02)
        time.sleep(1)
        
        return True
    
    def remove_element_from_circle(self, element_name):
        """Remove an element from the transmutation circle"""
        if element_name not in self.transmutation_circle:
            slow_print(Fore.RED + f"❌ {element_name} not in transmutation circle!", delay=0.02)
            time.sleep(1.5)
            return True
        
        # Remove element and return to inventory
        self.transmutation_circle.remove(element_name)
        self.element_inventory[element_name] += 1
        
        element_data = self.elemental_symbols[element_name]
        slow_print(f"{element_data['color']}🔄 Removed {element_data['emoji']} {element_name.title()} from circle", delay=0.02)
        time.sleep(1)
        
        return True
    
    def clear_transmutation_circle(self):
        """Clear the entire transmutation circle"""
        if not self.transmutation_circle:
            slow_print(Fore.YELLOW + "🔮 Transmutation circle is already empty!", delay=0.02)
            time.sleep(1)
            return True
        
        # Return all elements to inventory
        for element in self.transmutation_circle:
            self.element_inventory[element] += 1
        
        self.transmutation_circle.clear()
        
        slow_print(Fore.CYAN + "🌀 Transmutation circle cleared! Elements returned to inventory.", delay=0.02)
        time.sleep(1.5)
        return True
    
    def attempt_transmutation(self):
        """Attempt to transmute current circle contents"""
        if not self.transmutation_circle:
            slow_print(Fore.RED + "❌ Transmutation circle is empty! Add elements first.", delay=0.02)
            time.sleep(1.5)
            return True
        
        if self.alchemical_energy < 20:
            slow_print(Fore.RED + "⚗️ Insufficient energy for transmutation! Need at least 20%.", delay=0.02)
            time.sleep(1.5)
            return True
        
        formula = self.transmutation_formulas[self.mastery_level]
        
        clear_screen()
        slow_print(Fore.MAGENTA + "✨ BEGINNING TRANSMUTATION ✨", delay=0.03)
        time.sleep(1)
        
        # Check if circle matches required formula
        required_elements = sorted(formula["elements"])
        circle_elements = sorted(self.transmutation_circle)
        
        if required_elements == circle_elements:
            return self.successful_transmutation(formula)
        else:
            return self.failed_transmutation(formula)
    
    def successful_transmutation(self, formula):
        """Handle successful transmutation"""
        self.alchemical_energy -= 20
        
        # Transmutation animation
        slow_print(Fore.YELLOW + "🔥 Elements combining in perfect harmony...", delay=0.05)
        time.sleep(1)
        
        slow_print(Fore.CYAN + "⚡ Alchemical energies resonating...", delay=0.05)
        time.sleep(1)
        
        slow_print(Fore.GREEN + "✨ Transmutation successful!", delay=0.05)
        time.sleep(1)
        
        # Show the created pattern
        self.display_transmuted_pattern(formula)
        
        # Award points
        points = formula["difficulty"] * 50 + (self.alchemical_energy // 10)
        self.philosopher_points += points
        
        # Clear circle
        self.transmutation_circle.clear()
        
        # Add to discovered formulas
        if formula["name"] not in self.discovered_formulas:
            self.discovered_formulas.append(formula["name"])
        
        slow_print(f"\n{Fore.YELLOW}🏆 Formula mastered: {formula['name']}", delay=0.02)
        slow_print(f"{Fore.GREEN}💎 Philosopher Points: +{points} (Total: {self.philosopher_points})", delay=0.02)
        
        time.sleep(3)
        
        if self.mastery_level < self.max_levels:
            slow_print(f"\n{Fore.CYAN}🧪 Advancing to mastery level {self.mastery_level + 1}...", delay=0.03)
            self.mastery_level += 1
            self.alchemical_energy = min(100, self.alchemical_energy + 30)  # Restore some energy
            time.sleep(2)
            return True
        else:
            return False  # All levels complete
    
    def failed_transmutation(self, formula):
        """Handle failed transmutation"""
        self.alchemical_energy -= 10
        
        slow_print(Fore.RED + "💥 Elements resist combination...", delay=0.05)
        time.sleep(1)
        
        slow_print(Fore.YELLOW + "⚠️ Transmutation failed! Formula mismatch detected.", delay=0.03)
        time.sleep(1)
        
        # Show what was expected
        required_display = " + ".join([f"{self.elemental_symbols[elem]['emoji']}" 
                                     for elem in formula["elements"]])
        actual_display = " + ".join([f"{self.elemental_symbols[elem]['emoji']}" 
                                   for elem in self.transmutation_circle])
        
        slow_print(f"\n{Fore.WHITE}📜 Required: {required_display}", delay=0.02)
        slow_print(f"{Fore.RED}🔮 Attempted: {actual_display}", delay=0.02)
        
        # Elements remain in circle for retry
        slow_print(f"\n{Fore.CYAN}💡 Elements remain in circle. Adjust and try again!", delay=0.02)
        time.sleep(2)
        
        return True
    
    def display_transmuted_pattern(self, formula):
        """Display the beautiful ASCII art pattern created"""
        pattern_name = formula["pattern"]
        if pattern_name not in self.pattern_templates:
            return
        
        clear_screen()
        slow_print(Fore.MAGENTA + f"✨ {formula['name']} ✨", delay=0.03)
        print()
        
        pattern = self.pattern_templates[pattern_name]
        
        # Choose colors based on elements used
        colors = [self.elemental_symbols[elem]["color"] for elem in formula["elements"]]
        
        for line in pattern:
            colored_line = ""
            for i, char in enumerate(line):
                if char != " ":
                    color = colors[i % len(colors)]
                    colored_line += color + char
                else:
                    colored_line += char
            
            slow_print(colored_line, delay=0.1)
            time.sleep(0.3)
        
        print()
        slow_print(rainbow_text("A masterpiece of pixel alchemy!"), delay=0.05)
        time.sleep(2)
    
    def gather_elements(self):
        """Gather more elemental materials"""
        if self.alchemical_energy < 15:
            slow_print(Fore.RED + "⚗️ Too exhausted to gather elements! Rest first.", delay=0.02)
            time.sleep(1.5)
            return True
        
        self.alchemical_energy -= 15
        
        slow_print(Fore.GREEN + "🌿 Venturing forth to gather elemental materials...", delay=0.03)
        time.sleep(1)
        
        # Randomly gather 2-4 elements
        gathered_count = random.randint(2, 4)
        element_names = list(self.elemental_symbols.keys())
        
        for _ in range(gathered_count):
            element = random.choice(element_names)
            amount = random.randint(1, 3)
            self.element_inventory[element] += amount
            
            element_data = self.elemental_symbols[element]
            slow_print(f"{element_data['color']}✨ Found {amount} {element_data['emoji']} {element.title()}", delay=0.02)
            time.sleep(0.5)
        
        slow_print(Fore.CYAN + "🎒 Materials gathered successfully!", delay=0.02)
        time.sleep(1.5)
        
        return True
    
    def analyze_circle(self):
        """Analyze current transmutation circle composition"""
        if not self.transmutation_circle:
            slow_print(Fore.YELLOW + "🔮 Transmutation circle is empty - nothing to analyze.", delay=0.02)
            time.sleep(1.5)
            return True
        
        clear_screen()
        slow_print(Fore.CYAN + "🔬 CIRCLE ANALYSIS", delay=0.03)
        time.sleep(1)
        
        # Element composition
        element_counts = {}
        total_energy = 0
        total_volatility = 0
        
        for element in self.transmutation_circle:
            element_counts[element] = element_counts.get(element, 0) + 1
            element_data = self.elemental_symbols[element]
            total_energy += element_data["energy"]
            total_volatility += element_data["volatility"]
        
        slow_print(f"{Fore.WHITE}🧪 Circle Composition:", delay=0.02)
        for element, count in element_counts.items():
            element_data = self.elemental_symbols[element]
            print(f"{element_data['color']}  {element_data['emoji']} {element.title()}: {count}")
            time.sleep(0.3)
        
        avg_energy = total_energy / len(self.transmutation_circle)
        avg_volatility = total_volatility / len(self.transmutation_circle)
        
        analysis = [
            f"\n📊 ENERGETIC ANALYSIS:",
            f"⚡ Average Energy: {avg_energy:.1f}/10",
            f"🌀 Average Volatility: {avg_volatility:.1f}",
            f"🔢 Total Elements: {len(self.transmutation_circle)}",
            f"🌈 Element Diversity: {len(element_counts)}",
        ]
        
        for item in analysis:
            slow_print(Fore.CYAN + item, delay=0.02)
            time.sleep(0.3)
        
        # Stability prediction
        if avg_volatility < 0.4:
            slow_print(Fore.GREEN + "✅ Circle appears stable for transmutation", delay=0.02)
        elif avg_volatility < 0.7:
            slow_print(Fore.YELLOW + "⚠️ Circle has moderate volatility", delay=0.02)
        else:
            slow_print(Fore.RED + "⚡ Circle is highly volatile - proceed with caution!", delay=0.02)
        
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
        return True
    
    def show_formulas(self):
        """Show discovered transmutation formulas"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "📜 ALCHEMICAL FORMULAS", delay=0.03)
        time.sleep(1)
        
        if not self.discovered_formulas:
            slow_print(Fore.YELLOW + "🔍 No formulas discovered yet. Complete transmutations to unlock!", delay=0.02)
            time.sleep(2)
            return True
        
        slow_print(f"{Fore.CYAN}✨ Discovered Formulas ({len(self.discovered_formulas)}/{len(self.transmutation_formulas)}):", delay=0.02)
        print()
        
        for formula_name in self.discovered_formulas:
            # Find the formula details
            for level, formula in self.transmutation_formulas.items():
                if formula["name"] == formula_name:
                    elements_display = " + ".join([f"{self.elemental_symbols[elem]['emoji']}" 
                                                 for elem in formula["elements"]])
                    
                    print(f"{Fore.YELLOW}{formula['name']}")
                    print(f"  {Fore.WHITE}Elements: {elements_display}")
                    print(f"  {Fore.CYAN}Description: {formula['description']}")
                    print()
                    time.sleep(0.5)
                    break
        
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()
        return True
    
    def regenerate_energy(self):
        """Slowly regenerate alchemical energy"""
        if self.alchemical_energy < 100:
            self.alchemical_energy = min(100, self.alchemical_energy + 1)
    
    def show_final_mastery(self):
        """Show final alchemical mastery achievement"""
        clear_screen()
        
        mastery_banner = create_banner("GRAND ALCHEMIST", color=Fore.MAGENTA)
        print(mastery_banner)
        
        slow_print(rainbow_text("🧪 You have achieved the ultimate alchemical mastery! 🧪"), delay=0.05)
        time.sleep(2)
        
        # Show all mastered formulas
        slow_print(f"\n{Fore.YELLOW}✨ YOUR ALCHEMICAL ACHIEVEMENTS:", delay=0.03)
        
        for level in range(1, self.mastery_level):
            formula = self.transmutation_formulas[level]
            slow_print(f"{Fore.CYAN}   {level}. {formula['name']}", delay=0.02)
            time.sleep(0.3)
        
        # Final statistics
        total_formulas = len(self.transmutation_formulas)
        mastery_rate = ((self.mastery_level - 1) / total_formulas) * 100
        
        stats = [
            f"\n📊 MASTERY STATISTICS:",
            f"🧪 Formulas Mastered: {self.mastery_level - 1}/{total_formulas}",
            f"💎 Philosopher Points: {self.philosopher_points}",
            f"📜 Discovered Formulas: {len(self.discovered_formulas)}",
            f"⚗️ Final Energy: {self.alchemical_energy}%",
            f"🎯 Mastery Rate: {mastery_rate:.1f}%",
        ]
        
        for stat in stats:
            slow_print(Fore.WHITE + stat, delay=0.02)
            time.sleep(0.5)
        
        # Alchemical mastery evaluation
        if mastery_rate == 100:
            slow_print(rainbow_text("🌟 PHILOSOPHER'S STONE ACHIEVED! 🌟"), delay=0.05)
            evaluation = "You have unlocked the ultimate secrets of creation!"
        elif mastery_rate >= 80:
            slow_print(Fore.MAGENTA + "🔮 Master Transmutator! 🔮", delay=0.03)
            evaluation = "Your alchemical skills are legendary!"
        elif mastery_rate >= 60:
            slow_print(Fore.YELLOW + "✨ Skilled Alchemist! ✨", delay=0.03)
            evaluation = "You have learned to shape reality itself!"
        elif mastery_rate >= 40:
            slow_print(Fore.GREEN + "🧪 Apprentice Transmutator! 🧪", delay=0.03)
            evaluation = "Your journey into the alchemical arts progresses!"
        else:
            slow_print(Fore.BLUE + "🌱 Novice Alchemist! 🌱", delay=0.03)
            evaluation = "Every master began with a single transmutation!"
        
        slow_print(f"\n{Fore.CYAN}⚗️ {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        # Initialize inventory
        self.initialize_inventory()
        
        while self.mastery_level <= self.max_levels:
            # Show level introduction
            self.show_level_intro()
            
            # Laboratory loop
            while True:
                # Regenerate energy slowly
                self.regenerate_energy()
                
                # Draw and interact
                self.draw_laboratory()
                command = self.show_alchemy_menu()
                
                continue_level = self.process_alchemy_command(command)
                
                if not continue_level:
                    if self.mastery_level > self.max_levels:
                        # All levels completed
                        self.show_final_mastery()
                    return
                elif self.mastery_level > self.max_levels:
                    # Completed all levels
                    self.show_final_mastery()
                    return
                else:
                    # Continue level or advance
                    continue
        
        # Show final results
        self.show_final_mastery()

def main():
    """Main game entry point"""
    try:
        game = PixelAlchemist()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your alchemical laboratory awaits your return!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Alchemical error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
