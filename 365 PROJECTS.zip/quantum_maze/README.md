# ⚛️ Quantum Maze

**Created by Bhavyansh Soni**

## Description
A mind-bending puzzle game inspired by quantum physics! Navigate through mazes where walls exist in quantum superposition - they might or might not be there until you observe them. Master concepts like wave function collapse, quantum entanglement, and uncertainty principle to solve increasingly complex puzzles.

## Quantum Mechanics Features
- ⚛️ **Quantum Superposition**: Walls exist in multiple states simultaneously
- 👁️ **Wave Function Collapse**: Observation determines reality
- 🔗 **Quantum Entanglement**: Paired walls affect each other instantly
- 🌀 **Uncertainty Principle**: Unobserved walls shift probability over time
- ⚡ **Observation Energy**: Limited ability to collapse quantum states
- 🎯 **Probability Visualization**: Different colors show wall existence likelihood

## Visual Quantum States
- 🟦 **Blue walls** (▓): High probability (70-90%) - likely to be solid
- 🟨 **Yellow walls** (▒): Medium probability (40-70%) - uncertain
- 🟥 **Red walls** (░): Low probability (10-40%) - likely passable
- ⬜ **White walls** (█): Collapsed state - definitely solid
- 🟪 **Purple walls** (▓): Quantum entangled - correlated with partner
- ⬛ **Empty space**: Confirmed passable areas

## Game Mechanics
- 👁️ **Player**: Observer who collapses quantum states
- 🎯 **Goal**: Reach the target while managing quantum resources
- ⚡ **Energy System**: 100% observation energy, costs 10% per observation
- 🔄 **Energy Regeneration**: Slowly recovers over time
- 💥 **Quantum Collisions**: Moving into superposition forces observation

## Controls
- **W/A/S/D**: Move up/left/down/right
- **SPACE**: Observe area around player (collapses quantum states)
- **Q**: Quit to main menu

## Strategic Elements
1. **Energy Management**: Use observations wisely to reveal optimal paths
2. **Probability Reading**: Interpret colors to predict wall behavior
3. **Entanglement Awareness**: Observing one wall affects its entangled partner
4. **Quantum Timing**: Unobserved walls slowly shift toward 50% probability
5. **Risk Assessment**: Sometimes moving into superposition is worth the gamble

## Scoring System
- **Level Completion**: 100 points × level number
- **Energy Efficiency**: 2 points × remaining energy percentage
- **Example**: Complete level 3 with 60% energy = 300 + 120 = 420 points

## Physics Education
Learn real quantum concepts through gameplay:
- **Superposition**: Particles existing in multiple states
- **Measurement Problem**: How observation affects reality
- **Entanglement**: Spooky action at a distance
- **Uncertainty**: Fundamental limits of knowledge
- **Wave Function Collapse**: Transition from quantum to classical

## Difficulty Progression
- **Levels 1-2**: Simple superposition and observation
- **Levels 3-4**: Introduction of quantum entanglement
- **Levels 5-6**: Complex entanglement networks
- **Levels 7-8**: Maximum uncertainty and energy management

## Achievement Levels
- 🌟 **Quantum Physicist**: Complete all 8 levels (100%)
- ⚛️ **Quantum Engineer**: 75%+ completion
- 🔬 **Quantum Student**: 50%+ completion  
- 📚 **Quantum Apprentice**: 25%+ completion
- 🌱 **Classical Thinker**: Below 25% - embrace uncertainty!

## Tips for Quantum Mastery
1. **Observe Strategically**: Don't waste energy on unnecessary observations
2. **Read Probabilities**: High-probability walls are usually safe to assume solid
3. **Use Entanglement**: Observing one entangled wall reveals its partner
4. **Plan Ahead**: Consider how quantum decay will affect your path
5. **Embrace Uncertainty**: Sometimes the quantum gamble pays off!

## Educational Value
- Introduces complex physics concepts through interactive gameplay
- Develops strategic thinking under uncertainty
- Teaches resource management and risk assessment
- Demonstrates how quantum mechanics differs from classical physics
- Makes abstract concepts tangible and engaging
