#!/usr/bin/env python3
"""
⚛️ QUANTUM MAZE ⚛️
Created by Bhavyansh Soni

An original physics-inspired puzzle game where players navigate through
probability-based mazes. Walls exist in quantum superposition and collapse
when observed! Master quantum mechanics to solve mind-bending puzzles.
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class QuantumMaze:
    def __init__(self):
        self.width = 15
        self.height = 10
        self.player_x = 1
        self.player_y = 1
        self.goal_x = self.width - 2
        self.goal_y = self.height - 2
        self.level = 1
        self.max_levels = 8
        self.score = 0
        self.observation_energy = 100
        self.max_energy = 100
        
        # Quantum states
        self.quantum_walls = {}  # Stores probability of wall existence
        self.observed_walls = {}  # Stores collapsed wall states
        self.entangled_pairs = []  # Pairs of quantum-entangled walls
        self.superposition_particles = []  # Particles in multiple states
        
        # Game mechanics
        self.observation_radius = 2
        self.quantum_decay_rate = 0.02
        self.entanglement_chance = 0.3
        
    def show_intro(self):
        """Display game introduction and quantum mechanics tutorial"""
        clear_screen()
        
        intro_banner = create_banner("QUANTUM MAZE", color=Fore.CYAN)
        print(intro_banner)
        
        slow_print(rainbow_text("⚛️ Welcome to the quantum realm of infinite possibilities! ⚛️"), delay=0.03)
        time.sleep(1)
        
        tutorial = [
            "\n🔬 QUANTUM MECHANICS TUTORIAL:",
            "⚛️ Walls exist in SUPERPOSITION - they might or might not be there!",
            "👁️ OBSERVATION collapses quantum states - walls become real or vanish",
            "🔗 ENTANGLED walls affect each other across the maze",
            "⚡ Each observation costs ENERGY - use it wisely!",
            "🌀 UNOBSERVED walls slowly decay and change probability",
            "🎯 Reach the goal while managing your quantum energy!",
            "\n🧪 QUANTUM PHENOMENA:",
            "🟦 Blue walls: High probability of existence (70-90%)",
            "🟨 Yellow walls: Medium probability (40-70%)",
            "🟥 Red walls: Low probability (10-40%)",
            "⬜ White walls: Collapsed state (observed)",
            "🔗 Purple walls: Quantum entangled",
            "\n💡 STRATEGY: Observe carefully to find the optimal path!",
        ]
        
        for text in tutorial:
            slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.4)
        
        slow_print(Fore.GREEN + "\n⚛️ Ready to enter the quantum realm? Press ENTER!", delay=0.03)
        input()
    
    def generate_quantum_maze(self):
        """Generate a maze with quantum properties"""
        # Initialize quantum wall probabilities
        self.quantum_walls = {}
        self.observed_walls = {}
        self.entangled_pairs = []
        
        # Create maze structure with quantum walls
        for y in range(self.height):
            for x in range(self.width):
                if (x == 0 or x == self.width - 1 or 
                    y == 0 or y == self.height - 1):
                    # Border walls are always solid
                    self.observed_walls[(x, y)] = True
                elif (x == self.player_x and y == self.player_y) or \
                     (x == self.goal_x and y == self.goal_y):
                    # Player and goal positions are always clear
                    self.observed_walls[(x, y)] = False
                else:
                    # Create quantum walls with random probabilities
                    if random.random() < 0.4:  # 40% chance of quantum wall
                        probability = random.uniform(0.1, 0.9)
                        self.quantum_walls[(x, y)] = probability
        
        # Create quantum entanglements
        quantum_positions = list(self.quantum_walls.keys())
        
        for _ in range(min(3, len(quantum_positions) // 4)):
            if len(quantum_positions) >= 2:
                pos1 = random.choice(quantum_positions)
                pos2 = random.choice([p for p in quantum_positions if p != pos1])
                self.entangled_pairs.append((pos1, pos2))
                quantum_positions.remove(pos1)
                quantum_positions.remove(pos2)
    
    def observe_area(self, center_x, center_y):
        """Observe an area and collapse quantum states"""
        if self.observation_energy < 10:
            return False
        
        self.observation_energy -= 10
        observed_positions = []
        
        # Observe walls within radius
        for dy in range(-self.observation_radius, self.observation_radius + 1):
            for dx in range(-self.observation_radius, self.observation_radius + 1):
                x, y = center_x + dx, center_y + dy
                
                if (x, y) in self.quantum_walls and (x, y) not in self.observed_walls:
                    # Collapse quantum state
                    probability = self.quantum_walls[(x, y)]
                    exists = random.random() < probability
                    self.observed_walls[(x, y)] = exists
                    observed_positions.append((x, y))
                    
                    # Handle entanglement
                    self.handle_entanglement((x, y), exists)
        
        return len(observed_positions) > 0
    
    def handle_entanglement(self, position, state):
        """Handle quantum entanglement effects"""
        for pair in self.entangled_pairs:
            if position in pair:
                # Find entangled partner
                partner = pair[1] if pair[0] == position else pair[0]
                
                if partner in self.quantum_walls and partner not in self.observed_walls:
                    # Entangled particles have correlated states
                    if random.random() < 0.7:  # 70% correlation
                        self.observed_walls[partner] = state
                    else:
                        self.observed_walls[partner] = not state
    
    def quantum_decay(self):
        """Apply quantum decay to unobserved walls"""
        for position, probability in list(self.quantum_walls.items()):
            if position not in self.observed_walls:
                # Probability slowly shifts toward 0.5 (maximum uncertainty)
                if probability > 0.5:
                    self.quantum_walls[position] = max(0.5, probability - self.quantum_decay_rate)
                else:
                    self.quantum_walls[position] = min(0.5, probability + self.quantum_decay_rate)
    
    def can_move(self, x, y):
        """Check if movement to position is possible"""
        # Check boundaries
        if x < 0 or x >= self.width or y < 0 or y >= self.height:
            return False
        
        # Check observed walls
        if (x, y) in self.observed_walls:
            return not self.observed_walls[(x, y)]
        
        # Position is quantum superposition - assume passable until observed
        return True
    
    def get_wall_color(self, x, y):
        """Get color representation of wall state"""
        if (x, y) in self.observed_walls:
            if self.observed_walls[(x, y)]:
                return Fore.WHITE + "█"  # Solid wall
            else:
                return Fore.BLACK + " "  # Empty space
        elif (x, y) in self.quantum_walls:
            probability = self.quantum_walls[(x, y)]
            
            # Check if entangled
            is_entangled = any((x, y) in pair for pair in self.entangled_pairs)
            
            if is_entangled:
                return Fore.MAGENTA + "▓"  # Entangled wall
            elif probability > 0.7:
                return Fore.BLUE + "▓"    # High probability
            elif probability > 0.4:
                return Fore.YELLOW + "▒"  # Medium probability
            else:
                return Fore.RED + "░"     # Low probability
        else:
            return " "  # Empty space
    
    def draw_maze(self):
        """Draw the current maze state"""
        clear_screen()
        
        # Game info
        energy_bar = "█" * (self.observation_energy // 5) + "░" * (20 - self.observation_energy // 5)
        energy_color = Fore.GREEN if self.observation_energy > 50 else Fore.YELLOW if self.observation_energy > 20 else Fore.RED
        
        info = f"⚛️ QUANTUM MAZE | Level: {self.level} | Score: {self.score} | Energy: {energy_color}[{energy_bar}] {self.observation_energy}%"
        print(Fore.CYAN + info)
        print(Fore.WHITE + "─" * 80)
        
        # Draw maze
        for y in range(self.height):
            row = ""
            for x in range(self.width):
                if x == self.player_x and y == self.player_y:
                    row += Fore.GREEN + "👁️"  # Player (observer)
                elif x == self.goal_x and y == self.goal_y:
                    row += Fore.YELLOW + "🎯"  # Goal
                else:
                    row += self.get_wall_color(x, y)
            
            print(f"{Fore.WHITE}│{row}{Fore.WHITE}│")
        
        print(Fore.WHITE + "─" * 80)
        
        # Controls and quantum info
        print(Fore.CYAN + "Controls: WASD=Move | SPACE=Observe Area | Q=Quit")
        
        # Show quantum status
        unobserved_count = len([p for p in self.quantum_walls if p not in self.observed_walls])
        entangled_count = len(self.entangled_pairs) * 2
        
        print(f"{Fore.WHITE}🔬 Quantum Status: {Fore.YELLOW}{unobserved_count} unobserved walls | {Fore.MAGENTA}{entangled_count} entangled particles")
    
    def move_player(self, direction):
        """Move player in specified direction"""
        new_x, new_y = self.player_x, self.player_y
        
        if direction == 'w':
            new_y -= 1
        elif direction == 's':
            new_y += 1
        elif direction == 'a':
            new_x -= 1
        elif direction == 'd':
            new_x += 1
        
        # Check quantum collision
        if (new_x, new_y) in self.quantum_walls and (new_x, new_y) not in self.observed_walls:
            # Moving into quantum superposition - force observation
            slow_print(Fore.YELLOW + "⚛️ Quantum collision detected! Auto-observing...", delay=0.02)
            time.sleep(1)
            
            probability = self.quantum_walls[(new_x, new_y)]
            exists = random.random() < probability
            self.observed_walls[(new_x, new_y)] = exists
            self.handle_entanglement((new_x, new_y), exists)
            
            if exists:
                slow_print(Fore.RED + "💥 Wall materialized! Movement blocked!", delay=0.02)
                self.observation_energy = max(0, self.observation_energy - 5)
                time.sleep(1)
                return False
            else:
                slow_print(Fore.GREEN + "✨ Wall dissolved! Path clear!", delay=0.02)
                time.sleep(1)
        
        if self.can_move(new_x, new_y):
            self.player_x, self.player_y = new_x, new_y
            return True
        
        return False
    
    def check_goal(self):
        """Check if player reached the goal"""
        return self.player_x == self.goal_x and self.player_y == self.goal_y
    
    def show_level_complete(self):
        """Show level completion animation"""
        clear_screen()
        
        level_banner = create_banner(f"LEVEL {self.level} COMPLETE", color=Fore.GREEN)
        print(level_banner)
        
        # Calculate score
        energy_bonus = self.observation_energy * 2
        level_points = self.level * 100
        total_points = energy_bonus + level_points
        self.score += total_points
        
        score_info = [
            f"🎯 Level completed!",
            f"⚡ Energy bonus: {energy_bonus} points ({self.observation_energy}% × 2)",
            f"🏆 Level bonus: {level_points} points",
            f"💰 Total earned: {total_points} points",
            f"📊 New total score: {self.score}",
        ]
        
        for info in score_info:
            slow_print(Fore.YELLOW + info, delay=0.02)
            time.sleep(0.5)
        
        if self.level < self.max_levels:
            slow_print(Fore.CYAN + f"\n⚛️ Preparing quantum level {self.level + 1}...", delay=0.03)
        else:
            slow_print(Fore.MAGENTA + "\n🌟 Final quantum realm awaits!", delay=0.03)
        
        time.sleep(2)
    
    def regenerate_energy(self):
        """Slowly regenerate observation energy"""
        if self.observation_energy < self.max_energy:
            self.observation_energy = min(self.max_energy, self.observation_energy + 1)
    
    def show_game_over(self, victory=False):
        """Show final game results"""
        clear_screen()
        
        if victory:
            victory_banner = create_banner("QUANTUM MASTER!", color=Fore.MAGENTA)
            print(victory_banner)
            
            slow_print(rainbow_text("⚛️🏆 You've mastered the quantum realm! 🏆⚛️"), delay=0.05)
            time.sleep(2)
            
            slow_print(Fore.CYAN + "🌌 Reality bends to your will! 🌌", delay=0.03)
        else:
            game_over_banner = create_banner("QUANTUM COLLAPSE", color=Fore.RED)
            print(game_over_banner)
            
            slow_print(Fore.RED + "⚛️ Lost in quantum uncertainty...", delay=0.03)
        
        # Show final statistics
        levels_completed = self.level - 1 if not victory else self.max_levels
        completion_rate = (levels_completed / self.max_levels) * 100
        
        stats = [
            f"\n📊 QUANTUM STATISTICS:",
            f"🎯 Levels completed: {levels_completed}/{self.max_levels}",
            f"🏆 Final score: {self.score}",
            f"📈 Completion rate: {completion_rate:.1f}%",
            f"⚡ Final energy: {self.observation_energy}%",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Quantum mastery evaluation
        if completion_rate == 100:
            slow_print(rainbow_text("🌟 QUANTUM PHYSICIST! 🌟"), delay=0.05)
        elif completion_rate >= 75:
            slow_print(Fore.MAGENTA + "⚛️ Quantum Engineer! ⚛️", delay=0.03)
        elif completion_rate >= 50:
            slow_print(Fore.CYAN + "🔬 Quantum Student! 🔬", delay=0.03)
        elif completion_rate >= 25:
            slow_print(Fore.BLUE + "📚 Quantum Apprentice! 📚", delay=0.03)
        else:
            slow_print(Fore.WHITE + "🌱 Classical Thinker - Embrace uncertainty! 🌱", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.level <= self.max_levels:
            # Initialize level
            self.player_x, self.player_y = 1, 1
            self.observation_energy = self.max_energy
            self.generate_quantum_maze()
            
            # Level loop
            while True:
                self.draw_maze()
                
                # Apply quantum effects
                self.quantum_decay()
                self.regenerate_energy()
                
                # Get input
                slow_print(Fore.GREEN + "\n👁️ Your action: ", delay=0.02, end="")
                try:
                    action = input().lower().strip()
                    
                    if action == 'q':
                        return
                    elif action == ' ':
                        if not self.observe_area(self.player_x, self.player_y):
                            slow_print(Fore.RED + "⚡ Insufficient observation energy!", delay=0.02)
                            time.sleep(1)
                    elif action in ['w', 'a', 's', 'd']:
                        self.move_player(action)
                    else:
                        slow_print(Fore.YELLOW + "❓ Invalid action! Use WASD, SPACE, or Q", delay=0.02)
                        time.sleep(1)
                        continue
                    
                    # Check win condition
                    if self.check_goal():
                        self.show_level_complete()
                        self.level += 1
                        break
                        
                except KeyboardInterrupt:
                    return
                except Exception as e:
                    slow_print(Fore.RED + f"🚫 Error: {e}", delay=0.02)
                    time.sleep(1)
        
        # All levels completed
        self.show_game_over(victory=True)

def main():
    """Main game entry point"""
    try:
        game = QuantumMaze()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Quantum superposition collapsed!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Quantum error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
