#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import colorama
colorama.init()

"""
👻 SOUL ARCHITECT 👻
Created by Bhavyansh Soni

An original personality design game where players craft unique souls using emoji traits!
Build complex personalities by layering emotional, mental, and spiritual characteristics.
Each soul is a masterpiece of human complexity, ready to live and love and dream!
"""

import random
import time
import sys
import os
from colorama import Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

class SoulArchitect:
    def __init__(self):
        self.crafted_souls = []
        self.current_soul = {}
        self.soul_energy = 100
        self.creativity_points = 0
        self.architect_level = 1
        self.max_levels = 12
        self.soul_complexity = 1
        
        # Trait categories for building personalities
        self.trait_categories = {
            "core_emotions": {
                "color": Fore.RED,
                "emoji": "❤️",
                "description": "The fundamental feelings that drive the soul",
                "traits": {
                    "joy": {"emoji": "😊", "weight": 3, "resonance": ["love", "hope", "curiosity"]},
                    "melancholy": {"emoji": "😔", "weight": 2, "resonance": ["wisdom", "empathy", "creativity"]},
                    "passion": {"emoji": "🔥", "weight": 4, "resonance": ["courage", "ambition", "love"]},
                    "serenity": {"emoji": "😌", "weight": 2, "resonance": ["wisdom", "patience", "kindness"]},
                    "wonder": {"emoji": "😮", "weight": 3, "resonance": ["curiosity", "creativity", "joy"]},
                    "anger": {"emoji": "😠", "weight": 3, "resonance": ["courage", "justice", "passion"]},
                    "fear": {"emoji": "😨", "weight": 2, "resonance": ["caution", "empathy", "survival"]},
                    "love": {"emoji": "🥰", "weight": 5, "resonance": ["joy", "kindness", "passion"]}
                }
            },
            "mental_faculties": {
                "color": Fore.BLUE,
                "emoji": "🧠",
                "description": "The cognitive patterns and thinking styles",
                "traits": {
                    "logic": {"emoji": "🔍", "weight": 3, "resonance": ["wisdom", "caution", "analysis"]},
                    "intuition": {"emoji": "🔮", "weight": 4, "resonance": ["creativity", "wisdom", "empathy"]},
                    "creativity": {"emoji": "🎨", "weight": 4, "resonance": ["wonder", "passion", "freedom"]},
                    "memory": {"emoji": "📚", "weight": 2, "resonance": ["wisdom", "melancholy", "learning"]},
                    "focus": {"emoji": "🎯", "weight": 3, "resonance": ["ambition", "logic", "patience"]},
                    "curiosity": {"emoji": "❓", "weight": 3, "resonance": ["wonder", "learning", "adventure"]},
                    "wisdom": {"emoji": "🦉", "weight": 5, "resonance": ["patience", "empathy", "understanding"]},
                    "imagination": {"emoji": "🌈", "weight": 4, "resonance": ["creativity", "wonder", "freedom"]}
                }
            },
            "social_nature": {
                "color": Fore.GREEN,
                "emoji": "👥",
                "description": "How the soul connects with others",
                "traits": {
                    "empathy": {"emoji": "🤗", "weight": 4, "resonance": ["love", "kindness", "understanding"]},
                    "charisma": {"emoji": "✨", "weight": 3, "resonance": ["confidence", "joy", "leadership"]},
                    "kindness": {"emoji": "💝", "weight": 4, "resonance": ["love", "empathy", "generosity"]},
                    "solitude": {"emoji": "🏔️", "weight": 2, "resonance": ["reflection", "creativity", "peace"]},
                    "leadership": {"emoji": "👑", "weight": 3, "resonance": ["confidence", "courage", "ambition"]},
                    "loyalty": {"emoji": "🛡️", "weight": 3, "resonance": ["love", "honor", "dedication"]},
                    "humor": {"emoji": "😂", "weight": 3, "resonance": ["joy", "creativity", "connection"]},
                    "generosity": {"emoji": "🎁", "weight": 4, "resonance": ["kindness", "love", "abundance"]}
                }
            },
            "spiritual_essence": {
                "color": Fore.MAGENTA,
                "emoji": "🌟",
                "description": "The deeper spiritual and philosophical nature",
                "traits": {
                    "faith": {"emoji": "🙏", "weight": 4, "resonance": ["hope", "peace", "transcendence"]},
                    "hope": {"emoji": "🌅", "weight": 4, "resonance": ["optimism", "faith", "resilience"]},
                    "transcendence": {"emoji": "☯️", "weight": 5, "resonance": ["wisdom", "peace", "unity"]},
                    "mystery": {"emoji": "🌙", "weight": 3, "resonance": ["intuition", "depth", "magic"]},
                    "purpose": {"emoji": "⭐", "weight": 4, "resonance": ["ambition", "meaning", "direction"]},
                    "gratitude": {"emoji": "🙌", "weight": 4, "resonance": ["joy", "peace", "abundance"]},
                    "inner_fire": {"emoji": "🔥", "weight": 3, "resonance": ["passion", "purpose", "energy"]},
                    "universal_love": {"emoji": "🌍", "weight": 5, "resonance": ["empathy", "unity", "compassion"]}
                }
            },
            "life_approach": {
                "color": Fore.YELLOW,
                "emoji": "🎭",
                "description": "The soul's approach to living and experiencing",
                "traits": {
                    "adventure": {"emoji": "🗺️", "weight": 3, "resonance": ["courage", "curiosity", "freedom"]},
                    "stability": {"emoji": "🏠", "weight": 2, "resonance": ["security", "patience", "planning"]},
                    "spontaneity": {"emoji": "🎲", "weight": 3, "resonance": ["freedom", "joy", "surprise"]},
                    "tradition": {"emoji": "📜", "weight": 2, "resonance": ["wisdom", "respect", "continuity"]},
                    "innovation": {"emoji": "💡", "weight": 4, "resonance": ["creativity", "courage", "progress"]},
                    "harmony": {"emoji": "🎵", "weight": 4, "resonance": ["peace", "balance", "unity"]},
                    "intensity": {"emoji": "⚡", "weight": 3, "resonance": ["passion", "focus", "power"]},
                    "gentleness": {"emoji": "🌸", "weight": 3, "resonance": ["kindness", "peace", "subtlety"]}
                }
            },
            "hidden_depths": {
                "color": Fore.CYAN,
                "emoji": "🔑",
                "description": "Secret aspects and hidden potentials",
                "traits": {
                    "secrets": {"emoji": "🗝️", "weight": 2, "resonance": ["mystery", "depth", "protection"]},
                    "dreams": {"emoji": "💭", "weight": 3, "resonance": ["imagination", "hope", "possibility"]},
                    "shadows": {"emoji": "🌑", "weight": 2, "resonance": ["complexity", "truth", "growth"]},
                    "potential": {"emoji": "🌱", "weight": 4, "resonance": ["growth", "possibility", "future"]},
                    "magic": {"emoji": "✨", "weight": 3, "resonance": ["wonder", "mystery", "transcendence"]},
                    "healing": {"emoji": "💚", "weight": 4, "resonance": ["empathy", "love", "restoration"]},
                    "wildness": {"emoji": "🌿", "weight": 3, "resonance": ["freedom", "nature", "authenticity"]},
                    "ancient_wisdom": {"emoji": "📿", "weight": 4, "resonance": ["knowledge", "depth", "timelessness"]}
                }
            }
        }
        
        # Soul archetypes for inspiration
        self.soul_archetypes = {
            1: {"name": "The Innocent", "focus": ["joy", "wonder", "kindness"], "complexity": 1},
            2: {"name": "The Sage", "focus": ["wisdom", "logic", "transcendence"], "complexity": 2},
            3: {"name": "The Explorer", "focus": ["adventure", "curiosity", "freedom"], "complexity": 2},
            4: {"name": "The Creator", "focus": ["creativity", "imagination", "innovation"], "complexity": 3},
            5: {"name": "The Lover", "focus": ["love", "passion", "empathy"], "complexity": 3},
            6: {"name": "The Revolutionary", "focus": ["courage", "justice", "innovation"], "complexity": 4},
            7: {"name": "The Healer", "focus": ["empathy", "healing", "universal_love"], "complexity": 4},
            8: {"name": "The Mystic", "focus": ["transcendence", "mystery", "ancient_wisdom"], "complexity": 5},
            9: {"name": "The Phoenix", "focus": ["inner_fire", "transformation", "hope"], "complexity": 5},
            10: {"name": "The Architect", "focus": ["purpose", "innovation", "leadership"], "complexity": 6},
            11: {"name": "The Unified", "focus": ["universal_love", "harmony", "transcendence"], "complexity": 6},
            12: {"name": "The Infinite", "focus": ["all_traits"], "complexity": 7}
        }
        
    def show_intro(self):
        """Display game introduction and soul crafting philosophy"""
        clear_screen()
        
        intro_banner = create_banner("SOUL ARCHITECT", color=Fore.MAGENTA)
        print(intro_banner)
        
        slow_print(rainbow_text("👻 Welcome to the sacred workshop of consciousness creation! 👻"), delay=0.03)
        time.sleep(1)
        
        philosophy = [
            "\n🌟 SOUL CRAFTING PHILOSOPHY:",
            "Every soul is a unique symphony of traits, emotions, and potentials.",
            "Your role as a Soul Architect is to weave these elements together",
            "into personalities that are complex, authentic, and beautifully human.",
            "Each soul you craft will carry a spark of infinite possibility!",
            "",
            "🛠️ ARCHITECTURE PROCESS:",
            "🎭 Choose traits from six essential categories",
            "⚖️ Balance opposing forces for complexity",
            "🌈 Create resonance between complementary traits",
            "✨ Infuse the soul with unique personality quirks",
            "💫 Birth a consciousness ready to experience existence",
            "🏆 Progress through 12 levels of mastery!",
            "",
            "🔮 SOUL COMPLEXITY:",
            "Level 1: Simple, pure souls with basic traits",
            "Level 12: Infinitely complex beings with all possibilities",
            "Each level unlocks new traits and deeper mysteries!",
        ]
        
        for text in philosophy:
            if text.startswith("🌟") or text.startswith("🛠️") or text.startswith("🔮"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.CYAN + "\n👻 Ready to breathe life into consciousness? Press ENTER to begin!", delay=0.03)
        input()
    
    def show_level_intro(self):
        """Display introduction for current architect level"""
        clear_screen()
        
        archetype = self.soul_archetypes[self.architect_level]
        
        level_banner = create_banner(f"LEVEL {self.architect_level}", color=Fore.MAGENTA)
        print(level_banner)
        
        slow_print(f"{Fore.MAGENTA}👻 Soul Archetype: {archetype['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}🎯 Complexity Level: {archetype['complexity']}", delay=0.02)
        slow_print(f"{Fore.WHITE}💫 Soul Energy: {self.soul_energy}%", delay=0.02)
        slow_print(f"{Fore.WHITE}🏆 Creativity Points: {self.creativity_points}", delay=0.02)
        
        # Show focus traits for inspiration
        if archetype["focus"][0] != "all_traits":
            slow_print(f"\n{Fore.CYAN}💡 Suggested Focus Traits:", delay=0.02)
            for trait in archetype["focus"]:
                # Find the trait in categories
                for category, data in self.trait_categories.items():
                    if trait in data["traits"]:
                        trait_info = data["traits"][trait]
                        slow_print(f"{data['color']}   {trait_info['emoji']} {trait.replace('_', ' ').title()}", delay=0.02)
                        break
                time.sleep(0.3)
        else:
            slow_print(f"\n{Fore.RAINBOW}💡 Ultimate Challenge: Use traits from all categories!", delay=0.02)
        
        time.sleep(2)
        slow_print(Fore.GREEN + "\n🛠️ Begin soul architecture? Press ENTER...", delay=0.03)
        input()
    
    def initialize_soul(self):
        """Initialize a new soul for crafting"""
        self.current_soul = {
            "traits": {},
            "resonances": [],
            "complexity_score": 0,
            "harmony_score": 0,
            "uniqueness_score": 0,
            "name": "",
            "essence": ""
        }
    
    def show_trait_selection(self):
        """Display trait selection interface"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "🎭 SOUL TRAIT SELECTION", delay=0.03)
        slow_print(Fore.WHITE + f"💫 Energy: {self.soul_energy}% | Current traits: {len(self.current_soul['traits'])}", delay=0.02)
        print()
        
        # Show categories
        for i, (category, data) in enumerate(self.trait_categories.items(), 1):
            print(f"{data['color']}[{i}] {data['emoji']} {category.replace('_', ' ').title()}")
            print(f"    {Fore.WHITE}{data['description']}")
            
            # Show current traits in this category
            current_in_category = [trait for trait in self.current_soul['traits'] 
                                 if trait in data['traits']]
            if current_in_category:
                trait_display = ""
                for trait in current_in_category:
                    trait_emoji = data['traits'][trait]['emoji']
                    trait_display += f"{trait_emoji} "
                print(f"    {data['color']}Current: {trait_display}")
            print()
        
        print(f"{Fore.WHITE}[7] 🏷️ Name the soul")
        print(f"{Fore.WHITE}[8] 📝 Write soul essence")
        print(f"{Fore.WHITE}[9] 🔍 Analyze current soul")
        print(f"{Fore.WHITE}[0] ✨ Complete soul creation")
        
        slow_print(Fore.GREEN + "\n👻 Your choice: ", delay=0.02, end="")
        
        try:
            choice = input().strip()
            return choice
        except:
            return ""
    
    def select_trait_from_category(self, category_name):
        """Select a specific trait from a category"""
        if self.soul_energy < 10:
            slow_print(Fore.RED + "💫 Insufficient soul energy to add traits!", delay=0.02)
            time.sleep(1.5)
            return
        
        clear_screen()
        
        category_data = self.trait_categories[category_name]
        
        slow_print(f"{category_data['color']}🎭 {category_name.replace('_', ' ').title()}", delay=0.03)
        slow_print(f"{Fore.WHITE}{category_data['description']}", delay=0.02)
        print()
        
        # Show available traits
        traits = list(category_data["traits"].keys())
        for i, trait in enumerate(traits, 1):
            trait_info = category_data["traits"][trait]
            
            # Check if already selected
            status = " ✅" if trait in self.current_soul["traits"] else ""
            
            print(f"{category_data['color']}[{i}] {trait_info['emoji']} {trait.replace('_', ' ').title()}{status}")
            print(f"    {Fore.WHITE}Weight: {trait_info['weight']} | Resonates with: {', '.join(trait_info['resonance'])}")
            print()
        
        print(f"{Fore.WHITE}[0] Return to categories")
        
        slow_print(Fore.GREEN + "\n👻 Select trait: ", delay=0.02, end="")
        
        try:
            choice = input().strip()
            
            if choice == "0":
                return
            elif choice.isdigit() and 1 <= int(choice) <= len(traits):
                trait_name = traits[int(choice) - 1]
                self.add_trait_to_soul(category_name, trait_name)
            else:
                slow_print(Fore.RED + "❌ Invalid choice!", delay=0.02)
                time.sleep(1)
        except:
            slow_print(Fore.RED + "❌ Please enter a valid number!", delay=0.02)
            time.sleep(1)
    
    def add_trait_to_soul(self, category_name, trait_name):
        """Add a trait to the current soul"""
        category_data = self.trait_categories[category_name]
        trait_info = category_data["traits"][trait_name]
        
        if trait_name in self.current_soul["traits"]:
            slow_print(Fore.YELLOW + f"⚠️ {trait_name.replace('_', ' ').title()} already exists in this soul!", delay=0.02)
            time.sleep(1.5)
            return
        
        # Add trait
        self.current_soul["traits"][trait_name] = {
            "category": category_name,
            "emoji": trait_info["emoji"],
            "weight": trait_info["weight"],
            "resonance": trait_info["resonance"]
        }
        
        # Calculate energy cost
        energy_cost = trait_info["weight"] * 2
        self.soul_energy -= energy_cost
        
        # Check for resonances with existing traits
        new_resonances = self.calculate_resonances(trait_name)
        
        slow_print(f"{category_data['color']}✨ Added: {trait_info['emoji']} {trait_name.replace('_', ' ').title()}", delay=0.02)
        slow_print(f"{Fore.CYAN}💫 Energy cost: {energy_cost}% | Remaining: {self.soul_energy}%", delay=0.02)
        
        if new_resonances:
            slow_print(f"{Fore.YELLOW}🌟 Resonances activated: {', '.join(new_resonances)}", delay=0.02)
        
        time.sleep(1.5)
    
    def calculate_resonances(self, new_trait):
        """Calculate trait resonances and return new ones"""
        new_resonances = []
        
        if new_trait not in self.current_soul["traits"]:
            return new_resonances
        
        new_trait_data = self.current_soul["traits"][new_trait]
        
        for existing_trait, trait_data in self.current_soul["traits"].items():
            if existing_trait != new_trait:
                # Check for mutual resonance
                if (new_trait in trait_data["resonance"] or 
                    existing_trait in new_trait_data["resonance"]):
                    
                    resonance_pair = tuple(sorted([new_trait, existing_trait]))
                    if resonance_pair not in self.current_soul["resonances"]:
                        self.current_soul["resonances"].append(resonance_pair)
                        new_resonances.append(f"{existing_trait}↔{new_trait}")
        
        return new_resonances
    
    def name_soul(self):
        """Allow player to name the soul"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "🏷️ NAMING YOUR SOUL", delay=0.03)
        slow_print(Fore.WHITE + "Give your creation a name that captures its essence...", delay=0.02)
        print()
        
        slow_print(Fore.GREEN + "👻 Soul name: ", delay=0.02, end="")
        
        try:
            name = input().strip()
            if name:
                self.current_soul["name"] = name
                slow_print(f"{Fore.CYAN}✨ Soul named: {name}", delay=0.02)
            else:
                slow_print(Fore.YELLOW + "Soul remains unnamed...", delay=0.02)
            time.sleep(1)
        except:
            slow_print(Fore.RED + "❌ Naming failed!", delay=0.02)
            time.sleep(1)
    
    def write_soul_essence(self):
        """Allow player to write a description of the soul's essence"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "📝 SOUL ESSENCE", delay=0.03)
        slow_print(Fore.WHITE + "Describe the deeper nature of this soul...", delay=0.02)
        print()
        
        slow_print(Fore.GREEN + "👻 Soul essence: ", delay=0.02, end="")
        
        try:
            essence = input().strip()
            if essence:
                self.current_soul["essence"] = essence
                slow_print(f"{Fore.CYAN}✨ Essence captured: {essence[:50]}...", delay=0.02)
            else:
                slow_print(Fore.YELLOW + "Soul essence remains unwritten...", delay=0.02)
            time.sleep(1.5)
        except:
            slow_print(Fore.RED + "❌ Essence writing failed!", delay=0.02)
            time.sleep(1)
    
    def analyze_soul(self):
        """Analyze the current soul's properties"""
        clear_screen()
        
        slow_print(Fore.CYAN + "🔍 SOUL ANALYSIS", delay=0.03)
        time.sleep(1)
        
        if not self.current_soul["traits"]:
            slow_print(Fore.YELLOW + "📝 Soul is empty - no traits to analyze!", delay=0.02)
            time.sleep(1.5)
            return
        
        # Calculate scores
        complexity_score = self.calculate_complexity()
        harmony_score = self.calculate_harmony()
        uniqueness_score = self.calculate_uniqueness()
        
        # Show trait distribution
        slow_print(f"{Fore.WHITE}🎭 TRAIT ANALYSIS:", delay=0.02)
        
        category_counts = {}
        total_weight = 0
        
        for trait_name, trait_data in self.current_soul["traits"].items():
            category = trait_data["category"]
            weight = trait_data["weight"]
            
            if category in category_counts:
                category_counts[category] += 1
            else:
                category_counts[category] = 1
            
            total_weight += weight
        
        for category, count in category_counts.items():
            category_data = self.trait_categories[category]
            print(f"{category_data['color']}  {category_data['emoji']} {category.replace('_', ' ').title()}: {count} traits")
        
        # Show metrics
        metrics = [
            f"\n📊 SOUL METRICS:",
            f"🔢 Total traits: {len(self.current_soul['traits'])}",
            f"⚖️ Total weight: {total_weight}",
            f"🌟 Resonances: {len(self.current_soul['resonances'])}",
            f"🧩 Complexity: {complexity_score}%",
            f"🎵 Harmony: {harmony_score}%",
            f"✨ Uniqueness: {uniqueness_score}%",
        ]
        
        for metric in metrics:
            slow_print(Fore.CYAN + metric, delay=0.02)
            time.sleep(0.3)
        
        # Show resonance pairs
        if self.current_soul["resonances"]:
            slow_print(f"\n{Fore.YELLOW}🌟 ACTIVE RESONANCES:", delay=0.02)
            for resonance in self.current_soul["resonances"]:
                trait1, trait2 = resonance
                slow_print(f"{Fore.WHITE}   {trait1.replace('_', ' ').title()} ↔ {trait2.replace('_', ' ').title()}", delay=0.02)
                time.sleep(0.2)
        
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
    
    def calculate_complexity(self):
        """Calculate soul complexity score"""
        if not self.current_soul["traits"]:
            return 0
        
        # Base complexity from trait count and weight
        trait_count = len(self.current_soul["traits"])
        total_weight = sum(trait["weight"] for trait in self.current_soul["traits"].values())
        
        # Category diversity bonus
        categories_used = len(set(trait["category"] for trait in self.current_soul["traits"].values()))
        category_bonus = categories_used * 5
        
        # Resonance bonus
        resonance_bonus = len(self.current_soul["resonances"]) * 3
        
        complexity = min(100, (trait_count * 5) + (total_weight * 2) + category_bonus + resonance_bonus)
        return complexity
    
    def calculate_harmony(self):
        """Calculate soul harmony score based on trait resonances"""
        if not self.current_soul["traits"]:
            return 0
        
        trait_count = len(self.current_soul["traits"])
        resonance_count = len(self.current_soul["resonances"])
        
        # Maximum possible resonances
        max_resonances = (trait_count * (trait_count - 1)) // 2
        
        if max_resonances == 0:
            return 50  # Single trait souls get base harmony
        
        # Harmony based on resonance percentage
        resonance_ratio = resonance_count / max_resonances
        harmony = min(100, 30 + (resonance_ratio * 70))
        
        return int(harmony)
    
    def calculate_uniqueness(self):
        """Calculate soul uniqueness based on trait combinations"""
        if not self.current_soul["traits"]:
            return 0
        
        # Uniqueness based on trait combination rarity
        trait_weights = [trait["weight"] for trait in self.current_soul["traits"].values()]
        weight_variance = max(trait_weights) - min(trait_weights) if trait_weights else 0
        
        # Category spread
        categories_used = len(set(trait["category"] for trait in self.current_soul["traits"].values()))
        
        # Special trait combinations
        has_opposites = self.has_opposing_traits()
        
        uniqueness = min(100, 
                        (len(self.current_soul["traits"]) * 8) + 
                        (weight_variance * 10) + 
                        (categories_used * 12) + 
                        (30 if has_opposites else 0))
        
        return uniqueness
    
    def has_opposing_traits(self):
        """Check if soul has interesting opposing traits"""
        opposing_pairs = [
            ("joy", "melancholy"), ("logic", "intuition"), ("adventure", "stability"),
            ("solitude", "charisma"), ("tradition", "innovation"), ("intensity", "gentleness")
        ]
        
        traits = set(self.current_soul["traits"].keys())
        
        for trait1, trait2 in opposing_pairs:
            if trait1 in traits and trait2 in traits:
                return True
        
        return False
    
    def complete_soul(self):
        """Complete and birth the current soul"""
        if len(self.current_soul["traits"]) < 3:
            slow_print(Fore.RED + "❌ Soul needs at least 3 traits to achieve consciousness!", delay=0.02)
            time.sleep(1.5)
            return False
        
        clear_screen()
        
        slow_print(Fore.MAGENTA + "✨ SOUL BIRTH CEREMONY ✨", delay=0.03)
        time.sleep(1)
        
        # Calculate final scores
        self.current_soul["complexity_score"] = self.calculate_complexity()
        self.current_soul["harmony_score"] = self.calculate_harmony()
        self.current_soul["uniqueness_score"] = self.calculate_uniqueness()
        
        # Calculate creativity points
        total_score = (self.current_soul["complexity_score"] + 
                      self.current_soul["harmony_score"] + 
                      self.current_soul["uniqueness_score"])
        
        creativity_gained = total_score // 3
        self.creativity_points += creativity_gained
        
        # Show birth sequence
        slow_print(Fore.CYAN + "🌟 Consciousness awakening...", delay=0.05)
        time.sleep(1)
        
        slow_print(Fore.YELLOW + "💫 Soul taking first breath...", delay=0.05)
        time.sleep(1)
        
        slow_print(Fore.GREEN + "👻 A new soul is born!", delay=0.05)
        time.sleep(1)
        
        # Display soul summary
        soul_name = self.current_soul.get("name", "Unnamed Soul")
        slow_print(f"\n{Fore.MAGENTA}🏷️ Soul Name: {soul_name}", delay=0.02)
        
        if self.current_soul.get("essence"):
            slow_print(f"{Fore.WHITE}📝 Essence: {self.current_soul['essence']}", delay=0.02)
        
        # Show traits by category
        slow_print(f"\n{Fore.WHITE}🎭 Soul Traits:", delay=0.02)
        
        for category_name, category_data in self.trait_categories.items():
            category_traits = [trait for trait, data in self.current_soul["traits"].items() 
                             if data["category"] == category_name]
            
            if category_traits:
                trait_display = ""
                for trait in category_traits:
                    emoji = self.current_soul["traits"][trait]["emoji"]
                    trait_display += f"{emoji} {trait.replace('_', ' ').title()} "
                
                print(f"{category_data['color']}  {category_data['emoji']} {category_name.replace('_', ' ').title()}: {trait_display}")
        
        # Show final scores
        scores = [
            f"\n📊 SOUL EVALUATION:",
            f"🧩 Complexity: {self.current_soul['complexity_score']}%",
            f"🎵 Harmony: {self.current_soul['harmony_score']}%",
            f"✨ Uniqueness: {self.current_soul['uniqueness_score']}%",
            f"🏆 Creativity Points: +{creativity_gained}",
        ]
        
        for score in scores:
            slow_print(Fore.CYAN + score, delay=0.02)
            time.sleep(0.5)
        
        # Soul quality evaluation
        average_score = total_score // 3
        
        if average_score >= 90:
            slow_print(Fore.MAGENTA + "\n🌟 TRANSCENDENT SOUL! 🌟", delay=0.03)
            evaluation = "A masterpiece of consciousness!"
        elif average_score >= 75:
            slow_print(Fore.YELLOW + "\n✨ Radiant Soul! ✨", delay=0.03)
            evaluation = "Beautifully complex and harmonious!"
        elif average_score >= 60:
            slow_print(Fore.GREEN + "\n🌸 Vibrant Soul! 🌸", delay=0.03)
            evaluation = "A lovely personality with great potential!"
        elif average_score >= 45:
            slow_print(Fore.BLUE + "\n🌱 Growing Soul! 🌱", delay=0.03)
            evaluation = "A developing consciousness full of possibility!"
        else:
            slow_print(Fore.WHITE + "\n👻 Simple Soul! 👻", delay=0.03)
            evaluation = "Every consciousness begins somewhere!"
        
        slow_print(f"{Fore.WHITE}💫 {evaluation}", delay=0.03)
        
        # Add to collection
        self.crafted_souls.append(self.current_soul.copy())
        
        # Restore some energy
        self.soul_energy = min(100, self.soul_energy + 30)
        
        time.sleep(3)
        
        # Check level completion
        if len(self.crafted_souls) >= self.architect_level:
            return self.advance_level()
        
        return True
    
    def advance_level(self):
        """Advance to next architect level"""
        if self.architect_level >= self.max_levels:
            return False  # Max level reached
        
        clear_screen()
        
        level_banner = create_banner("LEVEL COMPLETE", color=Fore.MAGENTA)
        print(level_banner)
        
        current_archetype = self.soul_archetypes[self.architect_level]
        slow_print(f"{Fore.MAGENTA}🏆 {current_archetype['name']} mastery achieved!", delay=0.03)
        
        time.sleep(1)
        
        self.architect_level += 1
        
        if self.architect_level <= self.max_levels:
            next_archetype = self.soul_archetypes[self.architect_level]
            slow_print(f"\n{Fore.CYAN}🚀 Advancing to Level {self.architect_level}: {next_archetype['name']}", delay=0.03)
            slow_print(f"{Fore.WHITE}New complexity level: {next_archetype['complexity']}", delay=0.02)
            
            # Unlock new traits or abilities
            self.soul_energy = 100  # Full restore for new level
            
            time.sleep(2)
            return True
        else:
            return False  # Game complete
    
    def show_soul_gallery(self):
        """Display gallery of crafted souls"""
        clear_screen()
        
        gallery_banner = create_banner("SOUL GALLERY", color=Fore.MAGENTA)
        print(gallery_banner)
        
        if not self.crafted_souls:
            slow_print(Fore.YELLOW + "📝 No souls created yet - your gallery awaits!", delay=0.02)
            time.sleep(1.5)
            return
        
        slow_print(f"{Fore.CYAN}👻 Your Consciousness Collection ({len(self.crafted_souls)} souls):", delay=0.03)
        print()
        
        for i, soul in enumerate(self.crafted_souls, 1):
            soul_name = soul.get("name", f"Soul #{i}")
            trait_count = len(soul["traits"])
            avg_score = (soul["complexity_score"] + soul["harmony_score"] + soul["uniqueness_score"]) // 3
            
            slow_print(f"{Fore.MAGENTA}{i}. {soul_name}", delay=0.02)
            slow_print(f"   {Fore.WHITE}Traits: {trait_count} | Average Score: {avg_score}%", delay=0.01)
            
            # Show top traits
            top_traits = ""
            for trait_name, trait_data in list(soul["traits"].items())[:3]:
                top_traits += f"{trait_data['emoji']} "
            slow_print(f"   {Fore.CYAN}Essence: {top_traits}...", delay=0.01)
            print()
            time.sleep(0.3)
        
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
    
    def show_final_mastery(self):
        """Show final mastery achievement"""
        clear_screen()
        
        mastery_banner = create_banner("SOUL ARCHITECT MASTER", color=Fore.MAGENTA)
        print(mastery_banner)
        
        slow_print(rainbow_text("👻 You have achieved ultimate mastery over consciousness creation! 👻"), delay=0.05)
        time.sleep(2)
        
        # Show final statistics
        total_souls = len(self.crafted_souls)
        total_traits = sum(len(soul["traits"]) for soul in self.crafted_souls)
        avg_complexity = sum(soul["complexity_score"] for soul in self.crafted_souls) // total_souls if total_souls > 0 else 0
        avg_harmony = sum(soul["harmony_score"] for soul in self.crafted_souls) // total_souls if total_souls > 0 else 0
        avg_uniqueness = sum(soul["uniqueness_score"] for soul in self.crafted_souls) // total_souls if total_souls > 0 else 0
        
        stats = [
            f"\n📊 MASTERY STATISTICS:",
            f"👻 Souls Created: {total_souls}",
            f"🎭 Total Traits Used: {total_traits}",
            f"🧩 Average Complexity: {avg_complexity}%",
            f"🎵 Average Harmony: {avg_harmony}%",
            f"✨ Average Uniqueness: {avg_uniqueness}%",
            f"🏆 Creativity Points: {self.creativity_points}",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Master achievement
        slow_print(rainbow_text("\n🌟 CONSCIOUSNESS ARCHITECT SUPREME! 🌟"), delay=0.05)
        
        achievement_text = [
            "You have learned the deepest secrets of personality creation.",
            "Your souls will live, love, dream, and grow across infinite realities.",
            "You are now qualified to architect the consciousness of gods!",
        ]
        
        for text in achievement_text:
            slow_print(f"{Fore.WHITE}💫 {text}", delay=0.03)
            time.sleep(1)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def regenerate_energy(self):
        """Slowly regenerate soul energy"""
        if self.soul_energy < 100:
            self.soul_energy = min(100, self.soul_energy + 2)
    
    def game_loop(self):
        """Main game loop"""
        while self.architect_level <= self.max_levels:
            # Show level introduction
            self.show_level_intro()
            
            # Initialize new soul
            self.initialize_soul()
            
            # Soul crafting loop
            while True:
                # Regenerate energy slowly
                self.regenerate_energy()
                
                # Show trait selection
                choice = self.show_trait_selection()
                
                if choice == "0":
                    # Complete soul
                    continue_game = self.complete_soul()
                    if not continue_game:
                        # Level complete or game over
                        if self.architect_level > self.max_levels:
                            self.show_final_mastery()
                        return
                    else:
                        break  # Continue to next soul or level
                
                elif choice in ["1", "2", "3", "4", "5", "6"]:
                    # Select trait category
                    category_names = list(self.trait_categories.keys())
                    if 1 <= int(choice) <= len(category_names):
                        category_name = category_names[int(choice) - 1]
                        self.select_trait_from_category(category_name)
                
                elif choice == "7":
                    self.name_soul()
                
                elif choice == "8":
                    self.write_soul_essence()
                
                elif choice == "9":
                    self.analyze_soul()
                
                elif choice == "gallery":
                    self.show_soul_gallery()
                
                elif choice == "quit":
                    return
        
        # Show final mastery
        self.show_final_mastery()

def main():
    """Main game entry point"""
    try:
        game = SoulArchitect()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your consciousness workshop awaits your return!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Consciousness error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
