# ⏰ Time Fragments

**Created by Bhavyansh Soni**

## Description
An innovative temporal puzzle adventure where players become Temporal Archaeologists, collecting scattered moments of history across fractured timelines. Navigate through 10 distinct historical eras, gather precious time fragments, and restore timeline stability before paradoxes tear reality apart!

## Core Concept
Reality has shattered across multiple timelines, leaving precious moments of history scattered through time. Each fragment holds the power to restore timeline stability, but collecting them risks creating paradoxes that could unravel existence itself.

## Gameplay Features
- ⏰ **10 Historical Eras**: From primordial dawn to temporal nexus
- 💎 **6 Fragment Types**: Each with unique temporal properties and paradox risks
- 🌀 **Temporal Navigation**: Move through both space and time
- ⚡ **Energy Management**: Temporal travel requires careful resource planning
- 🛡️ **Timeline Stability**: Maintain reality's structural integrity
- 🌀 **Paradox System**: High-risk, high-reward temporal mechanics

## The Ten Temporal Eras

### 🌋 **Era 1: Primordial Dawn**
- **Period**: The birth of consciousness
- **Hazards**: Temporal storms, reality flux
- **Common Fragments**: Memory, emotion
- **Challenge**: Unstable early timeline

### 🏛️ **Era 2: Ancient Wisdom**
- **Period**: Foundations of civilization
- **Hazards**: Chronos echoes, paradox ripples
- **Common Fragments**: Decision, discovery
- **Challenge**: Pivotal historical moments

### ⚔️ **Era 3: Age of Heroes**
- **Period**: Legends carved in time
- **Hazards**: Warrior spirits, epic resonance
- **Common Fragments**: Emotion, decision
- **Challenge**: Legendary temporal resonance

### 📚 **Era 4: Renaissance Bloom**
- **Period**: The awakening of minds
- **Hazards**: Inspiration overflow, genius paradox
- **Common Fragments**: Discovery, creation
- **Challenge**: Creative temporal overflow

### ⚙️ **Era 5: Industrial Revolution**
- **Period**: Machines reshape existence
- **Hazards**: Steam chronos, gear time
- **Common Fragments**: Creation, decision
- **Challenge**: Mechanical temporal disruption

### 🌍 **Era 6: Global Awakening**
- **Period**: The world becomes one
- **Hazards**: Connection loops, global sync
- **Common Fragments**: Memory, discovery
- **Challenge**: Global temporal synchronization

### 💻 **Era 7: Digital Dawn**
- **Period**: Information becomes reality
- **Hazards**: Data fragments, virtual time
- **Common Fragments**: Creation, nexus
- **Challenge**: Digital temporal anomalies

### 🚀 **Era 8: Space Age**
- **Period**: Reaching beyond the stars
- **Hazards**: Cosmic drift, stellar time
- **Common Fragments**: Discovery, nexus
- **Challenge**: Cosmic temporal distortion

### 🧬 **Era 9: Genetic Frontier**
- **Period**: Rewriting the code of life
- **Hazards**: DNA spirals, evolution loops
- **Common Fragments**: Creation, decision
- **Challenge**: Evolutionary temporal loops

### ♾️ **Era 10: Temporal Nexus**
- **Period**: Where all timelines converge
- **Hazards**: Reality collapse, infinite recursion
- **Common Fragments**: Nexus, memory
- **Challenge**: Ultimate temporal complexity

## Fragment Types & Properties

### 💭 **Memory Fragments**
- **Value**: 10 points
- **Temporal Weight**: 1
- **Paradox Risk**: 10%
- **Description**: Crystallized moments of remembrance
- **Strategy**: Safe to collect, good for beginners

### 💖 **Emotion Fragments**
- **Value**: 15 points
- **Temporal Weight**: 2
- **Paradox Risk**: 20%
- **Description**: Raw feelings frozen in temporal amber
- **Strategy**: Moderate risk, emotional timeline events

### ⚖️ **Decision Fragments**
- **Value**: 20 points
- **Temporal Weight**: 3
- **Paradox Risk**: 30%
- **Description**: Pivotal choices that shaped history
- **Strategy**: Higher risk but valuable for timeline repair

### 💡 **Discovery Fragments**
- **Value**: 25 points
- **Temporal Weight**: 4
- **Paradox Risk**: 40%
- **Description**: Moments of breakthrough understanding
- **Strategy**: High value for scientific/knowledge eras

### ✨ **Creation Fragments**
- **Value**: 30 points
- **Temporal Weight**: 5
- **Paradox Risk**: 50%
- **Description**: Birth moments of something new
- **Strategy**: Very valuable but risky to collect

### 🌀 **Nexus Fragments**
- **Value**: 50 points
- **Temporal Weight**: 10
- **Paradox Risk**: 80%
- **Description**: Convergence points of multiple timelines
- **Strategy**: Extreme risk/reward, only for experts

## Core Mechanics

### **Temporal Navigation**
- **WASD**: Move through spatial dimensions
- **Q/E**: Move backward/forward through time
- **Time Position**: 0-100% scale through each era
- **Energy Cost**: Spatial movement (2%), temporal movement (5%)

### **Fragment Collection**
- **Temporal Alignment**: Must be within ±20% of fragment's time position
- **Collection Success**: Requires precise temporal positioning
- **Stability Bonus**: Each fragment restores timeline stability
- **Paradox Risk**: Higher value fragments have greater paradox chance

### **Timeline Stability System**
- **Starting Stability**: 100% per era
- **Stability Loss**: Temporal hazards, paradoxes
- **Stability Gain**: Successful fragment collection, repairs
- **Critical Threshold**: Below 0% causes timeline collapse

### **Paradox Mechanics**
- **Creation Triggers**: High-value fragment collection, temporal misalignment
- **Effects**: Damage timeline stability, reality distortion
- **Types**: Causality loops, butterfly effects, quantum uncertainty
- **Resolution**: Temporal repair using collected fragments

## Strategic Elements

### **Energy Management**
- **Conservation**: Plan movement routes efficiently
- **Regeneration**: 1% per turn passive recovery
- **Critical Actions**: Temporal scanning (15%), repairs (25%)
- **Emergency Tactics**: Balance exploration with energy costs

### **Risk Assessment**
- **Fragment Priority**: Balance value against paradox risk
- **Temporal Positioning**: Align time position before collection
- **Hazard Avoidance**: Navigate around temporal dangers
- **Stability Monitoring**: Maintain minimum stability thresholds

### **Advanced Techniques**
1. **Temporal Scanning**: Locate fragments and analyze time positions
2. **Timeline Repair**: Use fragments to fix stability damage
3. **Paradox Prevention**: Collect low-risk fragments first
4. **Era Completion**: Strategic fragment selection for efficiency

## Controls & Commands
- **WASD**: Spatial movement (costs 2% energy each)
- **Q/E**: Temporal movement (costs 5% energy each)
- **SPACE**: Collect fragment at current location
- **R**: Attempt timeline repair (costs 25% energy)
- **T**: Temporal scan for fragments (costs 15% energy)
- **X**: Exit current era (if completion criteria met)

## Scoring System
- **Fragment Points**: Based on fragment type and value
- **Era Bonus**: Completion rate × stability × 10
- **Efficiency Bonus**: High stability, low paradox count
- **Mastery Bonus**: Complete all eras with high scores

## Achievement Levels
- 🌟 **Master of Time**: Complete all 10 eras with high stability
- ⏰ **Temporal Guardian**: Complete 8+ eras successfully
- 🕰️ **Time Archaeologist**: Complete 6+ eras with good performance
- ⏳ **Temporal Explorer**: Complete 4+ eras while learning
- 🌱 **Chronos Apprentice**: Beginning the temporal journey

## Advanced Strategies
1. **Timeline Preservation**: Prioritize stability over points
2. **Temporal Alignment**: Perfect timing for fragment collection
3. **Hazard Management**: Use hazards strategically for shortcuts
4. **Fragment Synergy**: Combine fragments for powerful repairs
5. **Era Specialization**: Adapt strategy to each era's characteristics
6. **Paradox Recovery**: Plan repairs for inevitable paradoxes

## Educational Value
- **Historical Awareness**: Learn about different time periods
- **Cause and Effect**: Understand temporal consequences
- **Risk Management**: Balance reward against potential damage
- **Strategic Planning**: Long-term thinking across multiple eras
- **Resource Management**: Careful use of limited temporal energy
- **Pattern Recognition**: Identify optimal fragment collection routes

## The Philosophy of Time
"Time is not a river flowing in one direction, but an ocean with currents, eddies, and storms. The fragments you collect are not just memories—they are the building blocks of reality itself. Handle them with the respect they deserve, for in your hands lies the power to heal or destroy the very fabric of existence."

