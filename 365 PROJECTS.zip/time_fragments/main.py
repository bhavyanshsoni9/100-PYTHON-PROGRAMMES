# -*- coding: utf-8 -*-
import colorama
colorama.init()

#!/usr/bin/env python3
"""
⏰ TIME FRAGMENTS ⏰
Created by Bhavyansh Soni

An original temporal puzzle game where players collect moments scattered across timelines!
Navigate through different time periods, gather temporal fragments, and reconstruct
the flow of history before paradoxes tear reality apart!
"""

import random
import time
import sys
import os
from colorama import Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

class TimeFragments:
    def __init__(self):
        self.timeline_width = 16
        self.timeline_height = 10
        self.current_era = 1
        self.max_eras = 10
        self.temporal_energy = 100
        self.collected_fragments = []
        self.timeline_stability = 100
        self.paradox_count = 0
        self.time_score = 0
        
        # Player position in time-space
        self.player_x = 5
        self.player_y = 5
        self.player_time_position = 50  # 0-100 scale through current era
        
        # Time fragment types with temporal properties
        self.fragment_types = {
            "memory": {
                "emoji": "💭", "color": Fore.CYAN, "value": 10,
                "description": "A crystallized moment of remembrance",
                "temporal_weight": 1, "paradox_risk": 0.1
            },
            "emotion": {
                "emoji": "💖", "color": Fore.RED, "value": 15,
                "description": "Raw feelings frozen in temporal amber",
                "temporal_weight": 2, "paradox_risk": 0.2
            },
            "decision": {
                "emoji": "⚖️", "color": Fore.YELLOW, "value": 20,
                "description": "A pivotal choice that shaped history",
                "temporal_weight": 3, "paradox_risk": 0.3
            },
            "discovery": {
                "emoji": "💡", "color": Fore.GREEN, "value": 25,
                "description": "An instant of breakthrough understanding",
                "temporal_weight": 4, "paradox_risk": 0.4
            },
            "creation": {
                "emoji": "✨", "color": Fore.MAGENTA, "value": 30,
                "description": "The birth moment of something new",
                "temporal_weight": 5, "paradox_risk": 0.5
            },
            "nexus": {
                "emoji": "🌀", "color": Fore.WHITE, "value": 50,
                "description": "A convergence point of multiple timelines",
                "temporal_weight": 10, "paradox_risk": 0.8
            }
        }
        
        # Historical eras with unique characteristics
        self.time_eras = {
            1: {
                "name": "🌋 Primordial Dawn",
                "period": "The birth of consciousness",
                "color": Fore.RED,
                "hazards": ["temporal_storms", "reality_flux"],
                "common_fragments": ["memory", "emotion"]
            },
            2: {
                "name": "🏛️ Ancient Wisdom",
                "period": "Foundations of civilization",
                "color": Fore.YELLOW,
                "hazards": ["chronos_echoes", "paradox_ripples"],
                "common_fragments": ["decision", "discovery"]
            },
            3: {
                "name": "⚔️ Age of Heroes",
                "period": "Legends carved in time",
                "color": Fore.BLUE,
                "hazards": ["warrior_spirits", "epic_resonance"],
                "common_fragments": ["emotion", "decision"]
            },
            4: {
                "name": "📚 Renaissance Bloom",
                "period": "The awakening of minds",
                "color": Fore.GREEN,
                "hazards": ["inspiration_overflow", "genius_paradox"],
                "common_fragments": ["discovery", "creation"]
            },
            5: {
                "name": "⚙️ Industrial Revolution",
                "period": "Machines reshape existence",
                "color": Fore.CYAN,
                "hazards": ["steam_chronos", "gear_time"],
                "common_fragments": ["creation", "decision"]
            },
            6: {
                "name": "🌍 Global Awakening",
                "period": "The world becomes one",
                "color": Fore.MAGENTA,
                "hazards": ["connection_loops", "global_sync"],
                "common_fragments": ["memory", "discovery"]
            },
            7: {
                "name": "💻 Digital Dawn",
                "period": "Information becomes reality",
                "color": Fore.WHITE,
                "hazards": ["data_fragments", "virtual_time"],
                "common_fragments": ["creation", "nexus"]
            },
            8: {
                "name": "🚀 Space Age",
                "period": "Reaching beyond the stars",
                "color": Fore.BLUE,
                "hazards": ["cosmic_drift", "stellar_time"],
                "common_fragments": ["discovery", "nexus"]
            },
            9: {
                "name": "🧬 Genetic Frontier",
                "period": "Rewriting the code of life",
                "color": Fore.GREEN,
                "hazards": ["dna_spirals", "evolution_loops"],
                "common_fragments": ["creation", "decision"]
            },
            10: {
                "name": "♾️ Temporal Nexus",
                "period": "Where all timelines converge",
                "color": Fore.MAGENTA,
                "hazards": ["reality_collapse", "infinite_recursion"],
                "common_fragments": ["nexus", "memory"]
            }
        }
        
        # Timeline grid
        self.timeline_grid = []
        self.temporal_hazards = []
        self.active_fragments = []
        
    def show_intro(self):
        """Display game introduction and temporal mechanics"""
        clear_screen()
        
        intro_banner = create_banner("TIME FRAGMENTS", color=Fore.CYAN)
        print(intro_banner)
        
        slow_print(rainbow_text("⏰ Welcome to the shattered corridors of time itself! ⏰"), delay=0.03)
        time.sleep(1)
        
        temporal_lore = [
            "\n🌀 TEMPORAL CRISIS:",
            "Reality has fractured across multiple timelines!",
            "Precious moments of history lie scattered through time,",
            "threatening to create paradoxes that could unravel existence.",
            "As a Temporal Archaeologist, you must collect these fragments",
            "and restore the flow of history before it's too late!",
            "",
            "⏳ TEMPORAL MECHANICS:",
            "🚶 Navigate through time-space using arrow keys",
            "💎 Collect temporal fragments to restore timeline stability",
            "⚡ Manage temporal energy - moving through time is costly",
            "🌀 Avoid paradoxes - they damage timeline stability",
            "🎯 Each era has unique fragments and temporal hazards",
            "🏆 Complete all 10 eras to become a Master of Time!",
            "",
            "⚠️ WARNING:",
            "Collecting fragments may create temporal ripples.",
            "High-value fragments carry greater paradox risks!",
        ]
        
        for text in temporal_lore:
            if text.startswith("🌀") or text.startswith("⏳") or text.startswith("⚠️"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.GREEN + "\n⏰ Ready to enter the timestream? Press ENTER to begin!", delay=0.03)
        input()
    
    def initialize_era(self):
        """Initialize the current era's timeline grid"""
        self.timeline_grid = [["⬛" for _ in range(self.timeline_width)] for _ in range(self.timeline_height)]
        self.temporal_hazards = []
        self.active_fragments = []
        
        era_info = self.time_eras[self.current_era]
        
        # Place temporal fragments
        fragment_count = random.randint(5, 8)
        for _ in range(fragment_count):
            x = random.randint(1, self.timeline_width - 2)
            y = random.randint(1, self.timeline_height - 2)
            
            # Choose fragment type based on era
            fragment_type = random.choice(era_info["common_fragments"])
            if random.random() < 0.15:  # 15% chance for any type
                fragment_type = random.choice(list(self.fragment_types.keys()))
            
            fragment = {
                "type": fragment_type,
                "x": x, "y": y,
                "time_position": random.randint(10, 90),
                "collected": False
            }
            self.active_fragments.append(fragment)
        
        # Place temporal hazards
        hazard_count = random.randint(3, 6)
        for _ in range(hazard_count):
            x = random.randint(0, self.timeline_width - 1)
            y = random.randint(0, self.timeline_height - 1)
            
            hazard_type = random.choice(era_info["hazards"])
            hazard = {
                "type": hazard_type,
                "x": x, "y": y,
                "intensity": random.randint(10, 30),
                "active": True
            }
            self.temporal_hazards.append(hazard)
        
        # Reset player position
        self.player_x = self.timeline_width // 2
        self.player_y = self.timeline_height // 2
        self.player_time_position = 50
    
    def show_era_intro(self):
        """Display introduction for current era"""
        clear_screen()
        
        era_info = self.time_eras[self.current_era]
        color = era_info["color"]
        
        era_banner = create_banner(f"ERA {self.current_era}", color=color)
        print(era_banner)
        
        slow_print(f"{color}🕰️ Entering: {era_info['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}📜 Period: {era_info['period']}", delay=0.02)
        slow_print(f"{Fore.WHITE}⚡ Temporal Energy: {self.temporal_energy}%", delay=0.02)
        slow_print(f"{Fore.WHITE}🛡️ Timeline Stability: {self.timeline_stability}%", delay=0.02)
        slow_print(f"{Fore.WHITE}🌀 Paradox Count: {self.paradox_count}", delay=0.02)
        
        # Show era hazards
        slow_print(f"\n{color}⚠️ Temporal Hazards:", delay=0.02)
        for hazard in era_info["hazards"]:
            hazard_display = hazard.replace("_", " ").title()
            slow_print(f"{Fore.RED}   • {hazard_display}", delay=0.02)
            time.sleep(0.3)
        
        time.sleep(2)
        slow_print(Fore.CYAN + "\n🌀 Initializing temporal field...", delay=0.03)
        time.sleep(1)
    
    def draw_timeline(self):
        """Draw the current timeline state"""
        clear_screen()
        
        era_info = self.time_eras[self.current_era]
        color = era_info["color"]
        
        # Header
        stability_color = Fore.GREEN if self.timeline_stability > 70 else Fore.YELLOW if self.timeline_stability > 40 else Fore.RED
        energy_color = Fore.GREEN if self.temporal_energy > 50 else Fore.YELLOW if self.temporal_energy > 20 else Fore.RED
        
        header = f"⏰ TIME FRAGMENTS | Era {self.current_era}: {era_info['name']} | Score: {self.time_score}"
        print(color + header)
        
        status = f"⚡ Energy: {energy_color}{self.temporal_energy}% | 🛡️ Stability: {stability_color}{self.timeline_stability}% | 🌀 Paradoxes: {self.paradox_count}"
        print(Fore.WHITE + status)
        print(Fore.WHITE + "─" * 80)
        
        # Timeline grid
        display_grid = [row[:] for row in self.timeline_grid]
        
        # Place temporal hazards
        for hazard in self.temporal_hazards:
            if hazard["active"] and 0 <= hazard["x"] < self.timeline_width and 0 <= hazard["y"] < self.timeline_height:
                display_grid[hazard["y"]][hazard["x"]] = Fore.RED + "💀"
        
        # Place temporal fragments
        for fragment in self.active_fragments:
            if not fragment["collected"]:
                fragment_data = self.fragment_types[fragment["type"]]
                x, y = fragment["x"], fragment["y"]
                if 0 <= x < self.timeline_width and 0 <= y < self.timeline_height:
                    display_grid[y][x] = fragment_data["color"] + fragment_data["emoji"]
        
        # Place player
        if 0 <= self.player_x < self.timeline_width and 0 <= self.player_y < self.timeline_height:
            display_grid[self.player_y][self.player_x] = Fore.YELLOW + "🕰️"
        
        # Draw grid with coordinates
        print(Fore.WHITE + "   " + "".join([f"{i:2}" for i in range(self.timeline_width)]))
        
        for y in range(self.timeline_height):
            row_display = f"{y:2} "
            for x in range(self.timeline_width):
                row_display += display_grid[y][x] + " "
            print(row_display)
        
        print(Fore.WHITE + "─" * 80)
        
        # Show collected fragments
        if self.collected_fragments:
            fragment_display = "🎒 Collected: "
            for fragment in self.collected_fragments[-10:]:  # Show last 10
                fragment_data = self.fragment_types[fragment["type"]]
                fragment_display += f"{fragment_data['color']}{fragment_data['emoji']}"
            print(fragment_display)
        
        # Time position indicator
        time_bar = "🕐" * (self.player_time_position // 10) + "⬜" * (10 - self.player_time_position // 10)
        print(f"{Fore.CYAN}⏰ Time Position: [{time_bar}] {self.player_time_position}%")
    
    def show_controls(self):
        """Show movement and interaction controls"""
        print(f"\n{Fore.GREEN}⏰ Temporal Navigation:")
        print(f"{Fore.WHITE}WASD: Move through space | Q/E: Move through time | SPACE: Collect fragment")
        print(f"{Fore.WHITE}R: Attempt temporal repair | T: Time scan | X: Exit era")
        
        slow_print(Fore.CYAN + "\n🕰️ Your action: ", delay=0.02, end="")
        
        try:
            action = input().strip().lower()
            return action
        except:
            return ""
    
    def move_player(self, direction):
        """Move player through space or time"""
        if self.temporal_energy < 5:
            slow_print(Fore.RED + "⚡ Insufficient temporal energy!", delay=0.02)
            time.sleep(1.5)
            return
        
        if direction == 'w' and self.player_y > 0:
            self.player_y -= 1
            self.temporal_energy -= 2
        elif direction == 's' and self.player_y < self.timeline_height - 1:
            self.player_y += 1
            self.temporal_energy -= 2
        elif direction == 'a' and self.player_x > 0:
            self.player_x -= 1
            self.temporal_energy -= 2
        elif direction == 'd' and self.player_x < self.timeline_width - 1:
            self.player_x += 1
            self.temporal_energy -= 2
        elif direction == 'q' and self.player_time_position > 0:
            self.player_time_position = max(0, self.player_time_position - 10)
            self.temporal_energy -= 5
            slow_print(Fore.CYAN + "⏪ Moving backward through time...", delay=0.02)
            time.sleep(0.5)
        elif direction == 'e' and self.player_time_position < 100:
            self.player_time_position = min(100, self.player_time_position + 10)
            self.temporal_energy -= 5
            slow_print(Fore.CYAN + "⏩ Moving forward through time...", delay=0.02)
            time.sleep(0.5)
        
        # Check for hazard collision
        self.check_hazard_collision()
    
    def check_hazard_collision(self):
        """Check if player collided with temporal hazards"""
        for hazard in self.temporal_hazards:
            if (hazard["x"] == self.player_x and hazard["y"] == self.player_y and 
                hazard["active"]):
                
                damage = hazard["intensity"]
                self.timeline_stability = max(0, self.timeline_stability - damage)
                self.temporal_energy = max(0, self.temporal_energy - damage // 2)
                
                hazard_name = hazard["type"].replace("_", " ").title()
                slow_print(Fore.RED + f"💀 Temporal hazard: {hazard_name}! Stability -{damage}%", delay=0.02)
                
                if random.random() < 0.3:  # 30% chance to disable hazard
                    hazard["active"] = False
                    slow_print(Fore.YELLOW + "⚡ Hazard destabilized and dissipated!", delay=0.02)
                
                time.sleep(1.5)
    
    def collect_fragment(self):
        """Attempt to collect temporal fragment at current position"""
        for fragment in self.active_fragments:
            if (fragment["x"] == self.player_x and fragment["y"] == self.player_y and 
                not fragment["collected"]):
                
                fragment_data = self.fragment_types[fragment["type"]]
                
                # Check temporal alignment
                time_difference = abs(fragment["time_position"] - self.player_time_position)
                
                if time_difference <= 20:  # Within temporal range
                    # Successful collection
                    fragment["collected"] = True
                    self.collected_fragments.append(fragment)
                    
                    points = fragment_data["value"]
                    self.time_score += points
                    
                    # Restore some timeline stability
                    stability_bonus = fragment_data["temporal_weight"] * 2
                    self.timeline_stability = min(100, self.timeline_stability + stability_bonus)
                    
                    slow_print(f"{fragment_data['color']}✨ Collected: {fragment_data['description']}", delay=0.02)
                    slow_print(f"{Fore.GREEN}🏆 +{points} points | 🛡️ +{stability_bonus}% stability", delay=0.02)
                    
                    # Paradox risk
                    if random.random() < fragment_data["paradox_risk"]:
                        self.create_paradox()
                    
                    time.sleep(1.5)
                    return True
                else:
                    slow_print(Fore.YELLOW + f"⏰ Temporal misalignment! Need to be within ±20% of fragment's time position.", delay=0.02)
                    slow_print(f"{Fore.CYAN}Fragment time: {fragment['time_position']}% | Your time: {self.player_time_position}%", delay=0.02)
                    time.sleep(1.5)
                    return False
        
        slow_print(Fore.RED + "❌ No temporal fragment at this location!", delay=0.02)
        time.sleep(1)
        return False
    
    def create_paradox(self):
        """Handle paradox creation"""
        self.paradox_count += 1
        paradox_damage = random.randint(15, 25)
        self.timeline_stability = max(0, self.timeline_stability - paradox_damage)
        
        paradox_effects = [
            "Reality flickers as causality loops back on itself!",
            "Temporal echoes ripple through the fabric of time!",
            "A butterfly effect cascades across multiple timelines!",
            "Quantum uncertainty spills into the macro timeline!",
            "Past and future momentarily swap places!"
        ]
        
        effect = random.choice(paradox_effects)
        slow_print(Fore.RED + f"🌀 PARADOX CREATED! {effect}", delay=0.02)
        slow_print(Fore.RED + f"💥 Timeline stability -{paradox_damage}%", delay=0.02)
        time.sleep(2)
    
    def time_scan(self):
        """Scan for temporal fragments and their time positions"""
        if self.temporal_energy < 15:
            slow_print(Fore.RED + "⚡ Insufficient energy for temporal scan!", delay=0.02)
            time.sleep(1.5)
            return
        
        self.temporal_energy -= 15
        
        clear_screen()
        slow_print(Fore.CYAN + "🔍 TEMPORAL SCAN INITIATED", delay=0.03)
        time.sleep(1)
        
        uncollected_fragments = [f for f in self.active_fragments if not f["collected"]]
        
        if not uncollected_fragments:
            slow_print(Fore.GREEN + "✅ All fragments in this era have been collected!", delay=0.02)
        else:
            slow_print(Fore.WHITE + "📊 Temporal Fragment Analysis:", delay=0.02)
            
            for fragment in uncollected_fragments:
                fragment_data = self.fragment_types[fragment["type"]]
                distance = abs(fragment["x"] - self.player_x) + abs(fragment["y"] - self.player_y)
                time_diff = abs(fragment["time_position"] - self.player_time_position)
                
                print(f"{fragment_data['color']}  {fragment_data['emoji']} {fragment['type'].title()}")
                print(f"    {Fore.WHITE}Location: ({fragment['x']}, {fragment['y']}) | Distance: {distance}")
                print(f"    {Fore.CYAN}Time Position: {fragment['time_position']}% | Time Diff: {time_diff}%")
                print(f"    {Fore.YELLOW}Value: {fragment_data['value']} points")
                print()
                time.sleep(0.5)
        
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
    
    def attempt_repair(self):
        """Attempt to repair timeline stability"""
        if self.temporal_energy < 25:
            slow_print(Fore.RED + "⚡ Insufficient energy for temporal repair!", delay=0.02)
            time.sleep(1.5)
            return
        
        if len(self.collected_fragments) < 2:
            slow_print(Fore.YELLOW + "🔧 Need at least 2 fragments to attempt repair!", delay=0.02)
            time.sleep(1.5)
            return
        
        self.temporal_energy -= 25
        
        slow_print(Fore.MAGENTA + "🔧 Attempting temporal repair...", delay=0.03)
        time.sleep(1)
        
        # Use collected fragments for repair
        repair_power = sum(self.fragment_types[f["type"]]["temporal_weight"] for f in self.collected_fragments[-3:])
        repair_amount = min(30, repair_power * 3)
        
        self.timeline_stability = min(100, self.timeline_stability + repair_amount)
        
        if random.random() < 0.7:  # 70% success rate
            slow_print(Fore.GREEN + f"✅ Temporal repair successful! +{repair_amount}% stability", delay=0.02)
            
            # Reduce paradox count
            if self.paradox_count > 0 and random.random() < 0.4:
                self.paradox_count -= 1
                slow_print(Fore.CYAN + "🌀 Paradox resolved through temporal adjustment!", delay=0.02)
        else:
            slow_print(Fore.RED + "❌ Repair failed! Temporal fluctuations too severe.", delay=0.02)
            self.timeline_stability = max(0, self.timeline_stability - 10)
        
        time.sleep(2)
    
    def check_era_complete(self):
        """Check if current era is complete"""
        uncollected = [f for f in self.active_fragments if not f["collected"]]
        
        if len(uncollected) == 0:
            return True
        elif len(uncollected) <= 2 and self.timeline_stability >= 60:
            return True  # Allow completion with some fragments remaining if stability is good
        else:
            return False
    
    def complete_era(self):
        """Complete current era and advance"""
        clear_screen()
        
        era_info = self.time_eras[self.current_era]
        
        completion_banner = create_banner("ERA COMPLETE", color=era_info["color"])
        print(completion_banner)
        
        slow_print(f"{era_info['color']}🕰️ {era_info['name']} timeline stabilized!", delay=0.03)
        time.sleep(1)
        
        # Calculate era bonus
        collected_count = len([f for f in self.active_fragments if f["collected"]])
        total_fragments = len(self.active_fragments)
        completion_rate = (collected_count / total_fragments) * 100
        
        era_bonus = int(completion_rate * self.timeline_stability / 100 * 10)
        self.time_score += era_bonus
        
        # Show statistics
        stats = [
            f"\n📊 ERA STATISTICS:",
            f"🎯 Fragments collected: {collected_count}/{total_fragments} ({completion_rate:.1f}%)",
            f"🛡️ Final stability: {self.timeline_stability}%",
            f"🌀 Paradoxes created: {self.paradox_count}",
            f"🏆 Era bonus: {era_bonus} points",
            f"⭐ Total score: {self.time_score}",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Restore some energy for next era
        self.temporal_energy = min(100, self.temporal_energy + 40)
        
        time.sleep(2)
        
        if self.current_era < self.max_eras:
            slow_print(f"\n{Fore.YELLOW}⏰ Preparing to enter era {self.current_era + 1}...", delay=0.03)
            self.current_era += 1
            time.sleep(2)
            return True
        else:
            return False  # All eras complete
    
    def regenerate_energy(self):
        """Slowly regenerate temporal energy"""
        if self.temporal_energy < 100:
            self.temporal_energy = min(100, self.temporal_energy + 1)
    
    def show_final_timeline(self):
        """Show final game results"""
        clear_screen()
        
        if self.current_era > self.max_eras:
            master_banner = create_banner("TEMPORAL MASTER", color=Fore.MAGENTA)
            print(master_banner)
            
            slow_print(rainbow_text("⏰ You have mastered the flow of time itself! ⏰"), delay=0.05)
        else:
            timeline_banner = create_banner("TIMELINE COMPLETE", color=Fore.CYAN)
            print(timeline_banner)
            
            slow_print(Fore.CYAN + "⏰ Your temporal journey has concluded...", delay=0.03)
        
        time.sleep(2)
        
        # Final statistics
        total_fragments = len(self.collected_fragments)
        eras_completed = self.current_era - 1 if self.current_era <= self.max_eras else self.max_eras
        
        stats = [
            f"\n📊 TEMPORAL LEGACY:",
            f"🕰️ Eras traversed: {eras_completed}/{self.max_eras}",
            f"💎 Total fragments collected: {total_fragments}",
            f"🏆 Final score: {self.time_score}",
            f"🛡️ Timeline stability: {self.timeline_stability}%",
            f"🌀 Paradoxes created: {self.paradox_count}",
            f"⚡ Remaining energy: {self.temporal_energy}%",
        ]
        
        for stat in stats:
            slow_print(Fore.WHITE + stat, delay=0.02)
            time.sleep(0.5)
        
        # Temporal mastery evaluation
        completion_rate = (eras_completed / self.max_eras) * 100
        
        if completion_rate == 100 and self.timeline_stability > 80:
            slow_print(rainbow_text("🌟 MASTER OF TIME! 🌟"), delay=0.05)
            evaluation = "You have achieved perfect temporal mastery!"
        elif completion_rate >= 80:
            slow_print(Fore.MAGENTA + "⏰ Temporal Guardian! ⏰", delay=0.03)
            evaluation = "You've become a skilled protector of the timeline!"
        elif completion_rate >= 60:
            slow_print(Fore.YELLOW + "🕰️ Time Archaeologist! 🕰️", delay=0.03)
            evaluation = "You've learned to navigate the streams of time!"
        elif completion_rate >= 40:
            slow_print(Fore.GREEN + "⏳ Temporal Explorer! ⏳", delay=0.03)
            evaluation = "You've begun to understand time's mysteries!"
        else:
            slow_print(Fore.BLUE + "🌱 Chronos Apprentice! 🌱", delay=0.03)
            evaluation = "Your journey through time has just begun!"
        
        slow_print(f"\n{Fore.CYAN}⏰ {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.current_era <= self.max_eras and self.timeline_stability > 0:
            # Initialize era
            self.show_era_intro()
            self.initialize_era()
            
            # Era gameplay loop
            while True:
                # Regenerate energy slowly
                self.regenerate_energy()
                
                # Draw and get input
                self.draw_timeline()
                action = self.show_controls()
                
                if action in ['w', 'a', 's', 'd', 'q', 'e']:
                    self.move_player(action)
                elif action == ' ':
                    self.collect_fragment()
                elif action == 'r':
                    self.attempt_repair()
                elif action == 't':
                    self.time_scan()
                elif action == 'x':
                    if self.check_era_complete():
                        if not self.complete_era():
                            # All eras completed
                            self.show_final_timeline()
                            return
                        else:
                            break  # Continue to next era
                    else:
                        uncollected = len([f for f in self.active_fragments if not f["collected"]])
                        slow_print(Fore.YELLOW + f"⏰ Era incomplete! {uncollected} fragments remaining and/or stability too low.", delay=0.02)
                        time.sleep(1.5)
                elif action == 'quit':
                    return
                
                # Check for timeline collapse
                if self.timeline_stability <= 0:
                    slow_print(Fore.RED + "💥 TIMELINE COLLAPSE! Reality has unraveled!", delay=0.03)
                    time.sleep(2)
                    self.show_final_timeline()
                    return
        
        # Show final results
        self.show_final_timeline()

def main():
    """Main game entry point"""
    try:
        game = TimeFragments()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Time awaits your return, temporal archaeologist!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Temporal error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
