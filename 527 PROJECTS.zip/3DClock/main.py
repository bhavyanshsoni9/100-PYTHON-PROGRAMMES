#!/usr/bin/env python3
"""
3DClock - 3D ASCII Clock Display
Created by BHAVYANSH SONI
A retro-style 3D ASCII clock with colored output
"""

import time
import sys
import os
from datetime import datetime
from colorama import init, Fore, Back, Style
import math

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.CYAN}{'='*60}
{Fore.GREEN}    ██████╗ ██████╗  ██████╗██╗      ██████╗  ██████╗██╗  ██╗
{Fore.GREEN}    ╚════██╗██╔══██╗██╔════╝██║     ██╔═══██╗██╔════╝██║ ██╔╝
{Fore.GREEN}     █████╔╝██║  ██║██║     ██║     ██║   ██║██║     █████╔╝ 
{Fore.GREEN}     ╚═══██╗██║  ██║██║     ██║     ██║   ██║██║     ██╔═██╗ 
{Fore.GREEN}    ██████╔╝██████╔╝╚██████╗███████╗╚██████╔╝╚██████╗██║  ██╗
{Fore.GREEN}    ╚═════╝ ╚═════╝  ╚═════╝╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝
{Fore.CYAN}{'='*60}
{Fore.YELLOW}    ⏰ 3D ASCII Clock Display - Real-time 3D Clock
{Fore.MAGENTA}    🎨 Created by: BHAVYANSH SONI
{Fore.CYAN}{'='*60}
"""
    print(header)

def get_3d_digit(digit):
    """Get 3D ASCII representation of a digit"""
    digits = {
        '0': [
            "███████",
            "██   ██",
            "██   ██",
            "██   ██",
            "██   ██",
            "██   ██",
            "███████"
        ],
        '1': [
            "   ██  ",
            "  ███  ",
            "   ██  ",
            "   ██  ",
            "   ██  ",
            "   ██  ",
            "███████"
        ],
        '2': [
            "███████",
            "      ██",
            "      ██",
            "███████",
            "██     ",
            "██     ",
            "███████"
        ],
        '3': [
            "███████",
            "      ██",
            "      ██",
            "███████",
            "      ██",
            "      ██",
            "███████"
        ],
        '4': [
            "██   ██",
            "██   ██",
            "██   ██",
            "███████",
            "      ██",
            "      ██",
            "      ██"
        ],
        '5': [
            "███████",
            "██     ",
            "██     ",
            "███████",
            "      ██",
            "      ██",
            "███████"
        ],
        '6': [
            "███████",
            "██     ",
            "██     ",
            "███████",
            "██   ██",
            "██   ██",
            "███████"
        ],
        '7': [
            "███████",
            "      ██",
            "      ██",
            "      ██",
            "      ██",
            "      ██",
            "      ██"
        ],
        '8': [
            "███████",
            "██   ██",
            "██   ██",
            "███████",
            "██   ██",
            "██   ██",
            "███████"
        ],
        '9': [
            "███████",
            "██   ██",
            "██   ██",
            "███████",
            "      ██",
            "      ██",
            "███████"
        ],
        ':': [
            "       ",
            "  ███  ",
            "  ███  ",
            "       ",
            "  ███  ",
            "  ███  ",
            "       "
        ],
        ' ': [
            "       ",
            "       ",
            "       ",
            "       ",
            "       ",
            "       ",
            "       "
        ]
    }
    
    return digits.get(digit, digits[' '])

def create_3d_time(time_str):
    """Create 3D ASCII representation of time"""
    digit_arrays = []
    
    # Get 3D representation for each character
    for char in time_str:
        digit_arrays.append(get_3d_digit(char))
    
    # Combine all digits horizontally
    combined_lines = []
    for line_idx in range(7):
        line = ""
        for digit_array in digit_arrays:
            line += digit_array[line_idx] + "  "
        combined_lines.append(line)
    
    return combined_lines

def add_3d_effect(lines, color=Fore.CYAN):
    """Add 3D shadow effect to the ASCII art"""
    shadow_lines = []
    
    for i, line in enumerate(lines):
        # Create main line with color
        main_line = color + line + Style.RESET_ALL
        
        # Create shadow line
        shadow_line = ""
        for char in line:
            if char == '█':
                shadow_line += Fore.BLACK + Back.BLACK + '▓' + Style.RESET_ALL
            else:
                shadow_line += char
        
        shadow_lines.append(main_line)
        if i < len(lines) - 1:  # Don't add shadow to last line
            shadow_lines.append("  " + shadow_line)
    
    return shadow_lines

def create_digital_frame(width, height):
    """Create a digital frame around the clock"""
    frame = []
    
    # Top border
    frame.append(f"{Fore.GREEN}╔" + "═" * (width - 2) + "╗")
    
    # Side borders
    for _ in range(height - 2):
        frame.append(f"{Fore.GREEN}║" + " " * (width - 2) + "║")
    
    # Bottom border
    frame.append(f"{Fore.GREEN}╚" + "═" * (width - 2) + "╝")
    
    return frame

def get_gradient_color(index, total):
    """Get gradient color based on index"""
    colors = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA]
    return colors[index % len(colors)]

def display_analog_clock():
    """Display ASCII analog clock"""
    now = datetime.now()
    hour = now.hour % 12
    minute = now.minute
    second = now.second
    
    # Calculate angles
    hour_angle = (hour * 30) + (minute * 0.5)  # 30 degrees per hour
    minute_angle = minute * 6  # 6 degrees per minute
    second_angle = second * 6  # 6 degrees per second
    
    # Create clock face
    clock_face = []
    radius = 12
    
    for y in range(-radius, radius + 1):
        line = ""
        for x in range(-radius * 2, radius * 2 + 1):
            # Calculate distance from center
            distance = math.sqrt(x**2 + y**2)
            
            if distance <= radius:
                # Check if this is a hour marker
                angle = math.degrees(math.atan2(y, x))
                if angle < 0:
                    angle += 360
                
                # Hour markers
                if any(abs(angle - h*30) < 5 for h in range(12)):
                    line += f"{Fore.YELLOW}●"
                # Clock hands
                elif distance <= radius * 0.6:  # Hour hand
                    hand_angle = (90 - hour_angle) % 360
                    if abs(angle - hand_angle) < 15:
                        line += f"{Fore.RED}▄"
                    elif distance <= radius * 0.8:  # Minute hand
                        hand_angle = (90 - minute_angle) % 360
                        if abs(angle - hand_angle) < 10:
                            line += f"{Fore.GREEN}▄"
                        elif distance <= radius * 0.9:  # Second hand
                            hand_angle = (90 - second_angle) % 360
                            if abs(angle - hand_angle) < 8:
                                line += f"{Fore.CYAN}▄"
                            else:
                                line += " "
                        else:
                            line += " "
                    else:
                        line += " "
                else:
                    line += " "
            else:
                line += " "
        
        clock_face.append(line)
    
    return clock_face

def display_date_info():
    """Display date information"""
    now = datetime.now()
    
    date_info = [
        f"{Fore.CYAN}📅 Date: {Fore.WHITE}{now.strftime('%A, %B %d, %Y')}",
        f"{Fore.CYAN}🕐 Time: {Fore.WHITE}{now.strftime('%I:%M:%S %p')}",
        f"{Fore.CYAN}🌍 Timezone: {Fore.WHITE}{now.strftime('%Z')}",
        f"{Fore.CYAN}📊 Day of Year: {Fore.WHITE}{now.strftime('%j')}",
        f"{Fore.CYAN}📈 Week: {Fore.WHITE}{now.strftime('%U')}"
    ]
    
    return date_info

def main():
    """Main function"""
    print_header()
    
    slow_print(f"{Fore.YELLOW}🎨 Select Clock Mode:", 0.02)
    slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Digital 3D Clock", 0.02)
    slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Analog ASCII Clock", 0.02)
    slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Both (Split Screen)", 0.02)
    
    choice = input(f"\n{Fore.CYAN}Select mode (1-3): ").strip()
    
    try:
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            
            now = datetime.now()
            current_time = now.strftime("%H:%M:%S")
            
            if choice == '1':
                # Digital 3D Clock
                print(f"{Fore.MAGENTA}🕐 3D Digital Clock")
                print(f"{Fore.CYAN}{'='*60}")
                
                # Create 3D time display
                time_lines = create_3d_time(current_time)
                colored_lines = add_3d_effect(time_lines, Fore.CYAN)
                
                # Center the clock
                for line in colored_lines:
                    print(f"{' ' * 10}{line}")
                
                # Display date info
                print(f"\n{Fore.YELLOW}{'─' * 60}")
                date_info = display_date_info()
                for info in date_info:
                    print(f"{' ' * 10}{info}")
                
            elif choice == '2':
                # Analog ASCII Clock
                print(f"{Fore.MAGENTA}🕐 ASCII Analog Clock")
                print(f"{Fore.CYAN}{'='*60}")
                
                clock_face = display_analog_clock()
                for line in clock_face:
                    print(f"{' ' * 10}{line}")
                
                # Display current time
                print(f"\n{Fore.YELLOW}{'─' * 60}")
                print(f"{' ' * 15}{Fore.CYAN}Current Time: {Fore.WHITE}{current_time}")
                
            elif choice == '3':
                # Both clocks
                print(f"{Fore.MAGENTA}🕐 Dual Clock Display")
                print(f"{Fore.CYAN}{'='*80}")
                
                # Digital clock
                time_lines = create_3d_time(current_time)
                colored_lines = add_3d_effect(time_lines, Fore.CYAN)
                
                # Analog clock
                clock_face = display_analog_clock()
                
                # Display side by side
                max_lines = max(len(colored_lines), len(clock_face))
                for i in range(max_lines):
                    digital_line = colored_lines[i] if i < len(colored_lines) else " " * 50
                    analog_line = clock_face[i] if i < len(clock_face) else " " * 30
                    print(f"{digital_line}  {analog_line}")
                
                # Display date info
                print(f"\n{Fore.YELLOW}{'─' * 80}")
                date_info = display_date_info()
                for info in date_info:
                    print(f"{' ' * 20}{info}")
            
            print(f"\n{Fore.GREEN}{'='*60}")
            print(f"{Fore.MAGENTA}⏰ Live Clock - Press Ctrl+C to exit")
            
            time.sleep(1)
            
    except KeyboardInterrupt:
        slow_print(f"\n{Fore.YELLOW}👋 Thanks for using 3DClock! Time flies!", 0.03)
        sys.exit(0)

if __name__ == "__main__":
    main()
