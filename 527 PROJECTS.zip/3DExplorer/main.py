#!/usr/bin/env python3
"""
3DExplorer - 3D File System Explorer
Created by BHAVYANSH SONI
A retro-style 3D file system navigator with colored output
"""

import os
import sys
import time
from datetime import datetime
from colorama import init, Fore, Back, Style
import stat
import shutil

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.CYAN}{'='*60}
{Fore.GREEN}    ██████╗ ██████╗ ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██████╗ ███████╗██████╗ 
{Fore.GREEN}    ╚════██╗██╔══██╗██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██╔══██╗██╔════╝██╔══██╗
{Fore.GREEN}     █████╔╝██║  ██║█████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██████╔╝█████╗  ██████╔╝
{Fore.GREEN}     ╚═══██╗██║  ██║██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██╔══██╗██╔══╝  ██╔══██╗
{Fore.GREEN}    ██████╔╝██████╔╝███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║  ██║███████╗██║  ██║
{Fore.GREEN}    ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
{Fore.CYAN}{'='*60}
{Fore.YELLOW}    📁 3D File System Explorer - Navigate with Style
{Fore.MAGENTA}    🎯 Created by: BHAVYANSH SONI
{Fore.CYAN}{'='*60}
"""
    print(header)

def get_file_icon(file_path):
    """Get appropriate icon for file type"""
    if os.path.isdir(file_path):
        return "📁"
    
    _, ext = os.path.splitext(file_path)
    ext = ext.lower()
    
    icon_map = {
        '.py': '🐍',
        '.js': '📜',
        '.html': '🌐',
        '.css': '🎨',
        '.json': '📋',
        '.xml': '📄',
        '.txt': '📝',
        '.md': '📖',
        '.pdf': '📕',
        '.doc': '📘',
        '.docx': '📘',
        '.xls': '📊',
        '.xlsx': '📊',
        '.ppt': '📺',
        '.pptx': '📺',
        '.jpg': '🖼️',
        '.jpeg': '🖼️',
        '.png': '🖼️',
        '.gif': '🎬',
        '.mp4': '🎥',
        '.avi': '🎥',
        '.mov': '🎥',
        '.mp3': '🎵',
        '.wav': '🎵',
        '.zip': '📦',
        '.tar': '📦',
        '.gz': '📦',
        '.exe': '⚙️',
        '.dll': '🔧',
        '.so': '🔧',
        '.db': '🗃️',
        '.sql': '🗃️',
        '.log': '📋',
        '.cfg': '⚙️',
        '.ini': '⚙️',
        '.sh': '🖥️',
        '.bat': '🖥️',
        '.cmd': '🖥️'
    }
    
    return icon_map.get(ext, '📄')

def format_file_size(size_bytes):
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f} {size_names[i]}"

def get_file_info(file_path):
    """Get detailed file information"""
    try:
        stat_info = os.stat(file_path)
        
        info = {
            'size': stat_info.st_size,
            'modified': datetime.fromtimestamp(stat_info.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
            'permissions': stat.filemode(stat_info.st_mode),
            'owner': stat_info.st_uid,
            'group': stat_info.st_gid,
            'is_dir': os.path.isdir(file_path),
            'is_link': os.path.islink(file_path)
        }
        
        return info
    except:
        return None

def create_3d_tree(directory, level=0, max_level=3):
    """Create 3D tree structure of directory"""
    if level > max_level:
        return []
    
    tree_lines = []
    
    try:
        items = sorted(os.listdir(directory))
        
        for i, item in enumerate(items):
            item_path = os.path.join(directory, item)
            
            # Skip hidden files unless specifically requested
            if item.startswith('.'):
                continue
            
            # Create tree structure
            if level == 0:
                prefix = ""
            else:
                prefix = "│   " * (level - 1)
                if i == len(items) - 1:
                    prefix += "└── "
                else:
                    prefix += "├── "
            
            # Get file info
            icon = get_file_icon(item_path)
            file_info = get_file_info(item_path)
            
            if file_info:
                if file_info['is_dir']:
                    color = Fore.CYAN
                    size_info = f"[DIR]"
                else:
                    color = Fore.GREEN
                    size_info = f"[{format_file_size(file_info['size'])}]"
                
                line = f"{prefix}{icon} {color}{item}{Style.RESET_ALL} {Fore.YELLOW}{size_info}{Style.RESET_ALL}"
                tree_lines.append(line)
                
                # Recursively add subdirectories
                if file_info['is_dir'] and level < max_level:
                    sub_tree = create_3d_tree(item_path, level + 1, max_level)
                    tree_lines.extend(sub_tree)
    
    except PermissionError:
        tree_lines.append(f"{prefix}❌ {Fore.RED}Permission Denied{Style.RESET_ALL}")
    
    return tree_lines

def display_directory_stats(directory):
    """Display directory statistics"""
    stats = {
        'total_files': 0,
        'total_dirs': 0,
        'total_size': 0,
        'file_types': {}
    }
    
    try:
        for root, dirs, files in os.walk(directory):
            stats['total_dirs'] += len(dirs)
            stats['total_files'] += len(files)
            
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    file_size = os.path.getsize(file_path)
                    stats['total_size'] += file_size
                    
                    _, ext = os.path.splitext(file)
                    ext = ext.lower()
                    if ext:
                        stats['file_types'][ext] = stats['file_types'].get(ext, 0) + 1
                except:
                    pass
    
    except:
        pass
    
    return stats

def create_breadcrumb(path):
    """Create breadcrumb navigation"""
    parts = path.split(os.sep)
    breadcrumb = ""
    
    for i, part in enumerate(parts):
        if i == 0:
            breadcrumb += f"{Fore.CYAN}🏠 {part or '/'}"
        else:
            breadcrumb += f" {Fore.YELLOW}▶ {Fore.WHITE}{part}"
    
    return breadcrumb

def display_file_details(file_path):
    """Display detailed file information"""
    info = get_file_info(file_path)
    
    if not info:
        slow_print(f"{Fore.RED}❌ Cannot access file information", 0.02)
        return
    
    icon = get_file_icon(file_path)
    filename = os.path.basename(file_path)
    
    slow_print(f"\n{Fore.CYAN}{'='*60}", 0.01)
    slow_print(f"{Fore.YELLOW}📋 File Details", 0.02)
    slow_print(f"{Fore.CYAN}{'='*60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Name: {Fore.WHITE}{icon} {filename}", 0.02)
    slow_print(f"{Fore.GREEN}Path: {Fore.WHITE}{file_path}", 0.02)
    slow_print(f"{Fore.GREEN}Size: {Fore.WHITE}{format_file_size(info['size'])}", 0.02)
    slow_print(f"{Fore.GREEN}Modified: {Fore.WHITE}{info['modified']}", 0.02)
    slow_print(f"{Fore.GREEN}Permissions: {Fore.WHITE}{info['permissions']}", 0.02)
    slow_print(f"{Fore.GREEN}Type: {Fore.WHITE}{'Directory' if info['is_dir'] else 'File'}", 0.02)
    
    if info['is_link']:
        slow_print(f"{Fore.GREEN}Link: {Fore.WHITE}Yes", 0.02)
    
    slow_print(f"{Fore.CYAN}{'='*60}", 0.01)

def main():
    """Main function"""
    print_header()
    
    current_directory = os.getcwd()
    
    while True:
        # Display current location
        breadcrumb = create_breadcrumb(current_directory)
        slow_print(f"\n{Fore.MAGENTA}📍 Current Location:", 0.02)
        slow_print(f"{breadcrumb}", 0.02)
        
        # Display directory tree
        slow_print(f"\n{Fore.CYAN}🌳 Directory Tree:", 0.02)
        slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
        
        tree_lines = create_3d_tree(current_directory)
        for line in tree_lines[:20]:  # Limit to first 20 items
            print(line)
        
        if len(tree_lines) > 20:
            slow_print(f"{Fore.YELLOW}... and {len(tree_lines) - 20} more items", 0.02)
        
        # Display directory stats
        stats = display_directory_stats(current_directory)
        slow_print(f"\n{Fore.CYAN}📊 Directory Statistics:", 0.02)
        slow_print(f"{Fore.GREEN}Directories: {Fore.WHITE}{stats['total_dirs']}", 0.02)
        slow_print(f"{Fore.GREEN}Files: {Fore.WHITE}{stats['total_files']}", 0.02)
        slow_print(f"{Fore.GREEN}Total Size: {Fore.WHITE}{format_file_size(stats['total_size'])}", 0.02)
        
        # Display menu
        slow_print(f"\n{Fore.YELLOW}🎯 Navigation Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Change Directory", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}View File Details", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Go to Parent Directory", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Go to Home Directory", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Search Files", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.CYAN}Select option (1-6): ").strip()
        
        if choice == '1':
            new_dir = input(f"{Fore.YELLOW}Enter directory path: ").strip()
            if new_dir:
                if os.path.exists(new_dir) and os.path.isdir(new_dir):
                    current_directory = os.path.abspath(new_dir)
                    slow_print(f"{Fore.GREEN}✅ Changed to: {current_directory}", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Directory not found", 0.02)
        
        elif choice == '2':
            file_path = input(f"{Fore.YELLOW}Enter file/directory path: ").strip()
            if file_path:
                if not os.path.isabs(file_path):
                    file_path = os.path.join(current_directory, file_path)
                
                if os.path.exists(file_path):
                    display_file_details(file_path)
                else:
                    slow_print(f"{Fore.RED}❌ File not found", 0.02)
        
        elif choice == '3':
            parent_dir = os.path.dirname(current_directory)
            if parent_dir != current_directory:
                current_directory = parent_dir
                slow_print(f"{Fore.GREEN}✅ Moved to parent directory", 0.02)
            else:
                slow_print(f"{Fore.YELLOW}⚠️ Already at root directory", 0.02)
        
        elif choice == '4':
            current_directory = os.path.expanduser("~")
            slow_print(f"{Fore.GREEN}✅ Moved to home directory", 0.02)
        
        elif choice == '5':
            search_term = input(f"{Fore.YELLOW}Enter search term: ").strip()
            if search_term:
                slow_print(f"{Fore.CYAN}🔍 Searching for '{search_term}'...", 0.02)
                found_files = []
                
                for root, dirs, files in os.walk(current_directory):
                    for file in files:
                        if search_term.lower() in file.lower():
                            found_files.append(os.path.join(root, file))
                    
                    if len(found_files) >= 10:  # Limit results
                        break
                
                if found_files:
                    slow_print(f"{Fore.GREEN}📁 Found {len(found_files)} files:", 0.02)
                    for file in found_files:
                        icon = get_file_icon(file)
                        rel_path = os.path.relpath(file, current_directory)
                        slow_print(f"  {icon} {Fore.WHITE}{rel_path}", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ No files found", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using 3DExplorer! Happy exploring!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '6':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
