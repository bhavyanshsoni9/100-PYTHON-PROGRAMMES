import tkinter as tk
from tkinter import filedialog, messagebox
import os

def open_folder():
    path = filedialog.askdirectory()
    if path:
        files.delete(0, tk.END)
        for f in os.listdir(path):
            files.insert(tk.END, f)

win = tk.Tk()
win.title("File Manager")
win.geometry("400x300")

tk.Button(win, text="📂 Browse Folder", command=open_folder).pack(pady=10)
files = tk.Listbox(win)
files.pack(expand=True, fill='both')

win.mainloop()
