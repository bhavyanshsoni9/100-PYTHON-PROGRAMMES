import tkinter as tk

def respond():
    user_input = entry.get().lower()
    if "hello" in user_input:
        response = "Hi there!"
    elif "your name" in user_input:
        response = "I'm MiniGPT 🤖"
    elif "bye" in user_input:
        response = "Goodbye!"
    else:
        response = "Sorry, I don't understand yet."
    
    chatbox.insert(tk.END, f"You: {user_input}")
    chatbox.insert(tk.END, f"Bot: {response}")
    entry.delete(0, tk.END)

win = tk.Tk()
win.title("ChatBot")
win.geometry("400x400")

chatbox = tk.Listbox(win)
chatbox.pack(fill='both', expand=True)

entry = tk.Entry(win)
entry.pack(fill='x')
tk.Button(win, text="Send", command=respond).pack()

win.mainloop()
