#!/usr/bin/env python3
"""
AiMusic - AI Music Generator and Analyzer
Created by BHAVYANSH SONI
A retro-style AI-powered music composition tool
"""

import os
import sys
import time
import random
import json
from datetime import datetime
from colorama import init, Fore, Back, Style
import math

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.MAGENTA}{'='*60}
{Fore.CYAN}     █████╗ ██╗███╗   ███╗██╗   ██╗███████╗██╗ ██████╗
{Fore.CYAN}    ██╔══██╗██║████╗ ████║██║   ██║██╔════╝██║██╔════╝
{Fore.CYAN}    ███████║██║██╔████╔██║██║   ██║███████╗██║██║     
{Fore.CYAN}    ██╔══██║██║██║╚██╔╝██║██║   ██║╚════██║██║██║     
{Fore.CYAN}    ██║  ██║██║██║ ╚═╝ ██║╚██████╔╝███████║██║╚██████╗
{Fore.CYAN}    ╚═╝  ╚═╝╚═╝╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚═╝ ╚═════╝
{Fore.MAGENTA}{'='*60}
{Fore.YELLOW}    🎵 AI Music Generator & Analyzer - Compose with AI
{Fore.MAGENTA}    🎹 Created by: BHAVYANSH SONI
{Fore.MAGENTA}{'='*60}
"""
    print(header)

class MusicGenerator:
    """AI Music Generator class"""
    
    def __init__(self):
        self.scales = {
            'major': [0, 2, 4, 5, 7, 9, 11],
            'minor': [0, 2, 3, 5, 7, 8, 10],
            'pentatonic': [0, 2, 4, 7, 9],
            'blues': [0, 3, 5, 6, 7, 10],
            'dorian': [0, 2, 3, 5, 7, 9, 10],
            'mixolydian': [0, 2, 4, 5, 7, 9, 10]
        }
        
        self.chord_progressions = {
            'pop': ['I', 'V', 'vi', 'IV'],
            'jazz': ['ii', 'V', 'I', 'vi'],
            'blues': ['I', 'I', 'I', 'I', 'IV', 'IV', 'I', 'I', 'V', 'IV', 'I', 'V'],
            'rock': ['I', 'bVII', 'IV', 'I'],
            'folk': ['I', 'vi', 'IV', 'V']
        }
        
        self.note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
        
        self.rhythms = {
            'simple': [1, 1, 1, 1],
            'syncopated': [1, 0.5, 0.5, 1, 1],
            'triplet': [0.33, 0.33, 0.33, 1],
            'swing': [0.67, 0.33, 0.67, 0.33]
        }

    def generate_melody(self, scale_type='major', root_note='C', length=16):
        """Generate AI melody"""
        scale = self.scales[scale_type]
        root_index = self.note_names.index(root_note)
        
        melody = []
        current_octave = 4
        last_note_index = 0
        
        for i in range(length):
            # AI logic for note selection
            if i == 0:
                # Start with root note
                note_index = 0
            else:
                # Weighted random selection favoring stepwise motion
                weights = []
                for j, interval in enumerate(scale):
                    distance = abs(j - last_note_index)
                    if distance == 0:
                        weight = 0.1  # Avoid repeating
                    elif distance == 1:
                        weight = 0.4  # Favor stepwise
                    elif distance == 2:
                        weight = 0.3  # Second choice
                    else:
                        weight = 0.2 / distance  # Diminishing returns
                    weights.append(weight)
                
                note_index = random.choices(range(len(scale)), weights=weights)[0]
            
            # Calculate actual note
            note_value = (root_index + scale[note_index]) % 12
            note_name = self.note_names[note_value]
            
            # Octave management
            if note_index > last_note_index + 3:
                current_octave = max(3, current_octave - 1)
            elif note_index < last_note_index - 3:
                current_octave = min(6, current_octave + 1)
            
            melody.append({
                'note': note_name,
                'octave': current_octave,
                'duration': random.choice([0.5, 1, 1.5, 2])
            })
            
            last_note_index = note_index
        
        return melody

    def generate_chord_progression(self, style='pop', key='C'):
        """Generate chord progression"""
        progression = self.chord_progressions[style]
        root_index = self.note_names.index(key)
        
        chords = []
        
        for chord_symbol in progression:
            # Parse chord symbol
            if chord_symbol == 'I':
                chord_root = 0
                chord_type = 'major'
            elif chord_symbol == 'ii':
                chord_root = 2
                chord_type = 'minor'
            elif chord_symbol == 'iii':
                chord_root = 4
                chord_type = 'minor'
            elif chord_symbol == 'IV':
                chord_root = 5
                chord_type = 'major'
            elif chord_symbol == 'V':
                chord_root = 7
                chord_type = 'major'
            elif chord_symbol == 'vi':
                chord_root = 9
                chord_type = 'minor'
            elif chord_symbol == 'bVII':
                chord_root = 10
                chord_type = 'major'
            else:
                chord_root = 0
                chord_type = 'major'
            
            # Calculate chord notes
            chord_note = (root_index + chord_root) % 12
            chord_name = self.note_names[chord_note]
            
            chords.append({
                'root': chord_name,
                'type': chord_type,
                'symbol': chord_symbol
            })
        
        return chords

    def analyze_melody(self, melody):
        """Analyze melody for AI insights"""
        if not melody:
            return {}
        
        # Note distribution
        note_counts = {}
        for note_data in melody:
            note = note_data['note']
            note_counts[note] = note_counts.get(note, 0) + 1
        
        # Interval analysis
        intervals = []
        for i in range(1, len(melody)):
            prev_note = self.note_names.index(melody[i-1]['note'])
            curr_note = self.note_names.index(melody[i]['note'])
            interval = (curr_note - prev_note) % 12
            intervals.append(interval)
        
        # Rhythm analysis
        durations = [note['duration'] for note in melody]
        avg_duration = sum(durations) / len(durations)
        
        analysis = {
            'note_distribution': note_counts,
            'most_common_note': max(note_counts, key=note_counts.get),
            'intervals': intervals,
            'avg_duration': avg_duration,
            'total_duration': sum(durations),
            'unique_notes': len(note_counts),
            'range': max(note_counts.keys()) + ' - ' + min(note_counts.keys())
        }
        
        return analysis

def display_melody(melody, title="Generated Melody"):
    """Display melody in a visual format"""
    slow_print(f"\n{Fore.CYAN}🎵 {title}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    # Create a visual representation
    staff_lines = ["    " + "─" * 50 for _ in range(5)]
    
    for i, note_data in enumerate(melody):
        note = note_data['note']
        octave = note_data['octave']
        duration = note_data['duration']
        
        # Determine note position on staff (simplified)
        note_pos = 2  # Default middle position
        
        # Create note symbol based on duration
        if duration <= 0.5:
            symbol = "♪"
        elif duration <= 1:
            symbol = "♩"
        elif duration <= 2:
            symbol = "♫"
        else:
            symbol = "♬"
        
        # Add note to display
        position = min(i * 3, 45)  # Limit to staff width
        if position < 45:
            staff_lines[note_pos] = staff_lines[note_pos][:position + 4] + symbol + staff_lines[note_pos][position + 5:]
        
        # Display note info
        duration_str = f"{duration:.1f}"
        slow_print(f"{Fore.GREEN}{i+1:2d}. {note}{octave} {Fore.WHITE}({duration_str}s) {Fore.CYAN}{symbol}", 0.02)
    
    slow_print(f"\n{Fore.YELLOW}Staff Representation:", 0.02)
    for line in staff_lines:
        slow_print(f"{Fore.WHITE}{line}", 0.01)

def display_chord_progression(chords, title="Chord Progression"):
    """Display chord progression"""
    slow_print(f"\n{Fore.CYAN}🎹 {title}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    for i, chord in enumerate(chords):
        chord_display = f"{chord['root']} {chord['type']}"
        slow_print(f"{Fore.GREEN}{i+1}. {Fore.WHITE}{chord_display} {Fore.CYAN}({chord['symbol']})", 0.02)
    
    # Visual chord progression
    slow_print(f"\n{Fore.YELLOW}Progression:", 0.02)
    progression_line = ""
    for chord in chords:
        progression_line += f"{chord['root']:>4} "
    slow_print(f"{Fore.WHITE}{progression_line}", 0.02)

def display_analysis(analysis, title="Melody Analysis"):
    """Display melody analysis"""
    slow_print(f"\n{Fore.CYAN}📊 {title}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Most Common Note: {Fore.WHITE}{analysis['most_common_note']}", 0.02)
    slow_print(f"{Fore.GREEN}Unique Notes: {Fore.WHITE}{analysis['unique_notes']}", 0.02)
    slow_print(f"{Fore.GREEN}Average Duration: {Fore.WHITE}{analysis['avg_duration']:.2f}s", 0.02)
    slow_print(f"{Fore.GREEN}Total Duration: {Fore.WHITE}{analysis['total_duration']:.2f}s", 0.02)
    
    slow_print(f"\n{Fore.YELLOW}Note Distribution:", 0.02)
    for note, count in analysis['note_distribution'].items():
        bar = "█" * count
        slow_print(f"{Fore.CYAN}{note:>2}: {Fore.WHITE}{bar} {Fore.YELLOW}({count})", 0.02)

def create_music_visualization(melody):
    """Create ASCII music visualization"""
    slow_print(f"\n{Fore.CYAN}🎨 Music Visualization", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    # Create frequency visualization
    note_heights = {}
    for note_data in melody:
        note = note_data['note']
        octave = note_data['octave']
        height = octave * 2 + (len(note) - 1)  # Simple height calculation
        note_heights[note] = max(note_heights.get(note, 0), height)
    
    max_height = max(note_heights.values()) if note_heights else 1
    
    # Draw visualization
    for level in range(max_height, 0, -1):
        line = ""
        for note in ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']:
            if note in note_heights and note_heights[note] >= level:
                line += f"{Fore.GREEN}█ "
            else:
                line += "  "
        slow_print(f"{Fore.WHITE}{line}", 0.01)
    
    # Note labels
    label_line = ""
    for note in ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']:
        if note in note_heights:
            label_line += f"{Fore.CYAN}{note:<2}"
        else:
            label_line += "  "
    slow_print(f"{label_line}", 0.02)

def main():
    """Main function"""
    print_header()
    
    generator = MusicGenerator()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🎵 AiMusic Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Generate Melody", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Generate Chord Progression", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Analyze Melody", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Create Full Composition", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Music Theory Helper", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-6): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}🎼 Melody Generation", 0.02)
            
            # Get parameters
            scale_type = input(f"{Fore.YELLOW}Scale type (major/minor/pentatonic/blues): ").strip() or 'major'
            root_note = input(f"{Fore.YELLOW}Root note (C/D/E/F/G/A/B): ").strip().upper() or 'C'
            length = int(input(f"{Fore.YELLOW}Melody length (notes): ").strip() or '16')
            
            slow_print(f"\n{Fore.YELLOW}🤖 AI is composing your melody...", 0.02)
            time.sleep(2)
            
            melody = generator.generate_melody(scale_type, root_note, length)
            display_melody(melody, f"AI Melody in {root_note} {scale_type}")
            
            # Analysis
            analysis = generator.analyze_melody(melody)
            display_analysis(analysis)
            
            # Visualization
            create_music_visualization(melody)
        
        elif choice == '2':
            slow_print(f"\n{Fore.CYAN}🎹 Chord Progression Generation", 0.02)
            
            style = input(f"{Fore.YELLOW}Style (pop/jazz/blues/rock/folk): ").strip() or 'pop'
            key = input(f"{Fore.YELLOW}Key (C/D/E/F/G/A/B): ").strip().upper() or 'C'
            
            slow_print(f"\n{Fore.YELLOW}🤖 AI is creating chord progression...", 0.02)
            time.sleep(1)
            
            chords = generator.generate_chord_progression(style, key)
            display_chord_progression(chords, f"{style.title()} Progression in {key}")
        
        elif choice == '3':
            slow_print(f"\n{Fore.CYAN}📊 Melody Analysis", 0.02)
            
            # Generate sample melody for analysis
            melody = generator.generate_melody('major', 'C', 12)
            display_melody(melody, "Sample Melody for Analysis")
            
            analysis = generator.analyze_melody(melody)
            display_analysis(analysis)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}🎼 Full Composition Generation", 0.02)
            
            key = input(f"{Fore.YELLOW}Key (C/D/E/F/G/A/B): ").strip().upper() or 'C'
            style = input(f"{Fore.YELLOW}Style (pop/jazz/blues/rock/folk): ").strip() or 'pop'
            
            slow_print(f"\n{Fore.YELLOW}🤖 AI is creating a full composition...", 0.02)
            time.sleep(3)
            
            # Generate components
            chords = generator.generate_chord_progression(style, key)
            melody = generator.generate_melody('major', key, 16)
            
            # Display composition
            slow_print(f"\n{Fore.MAGENTA}🎵 FULL COMPOSITION", 0.02)
            slow_print(f"{Fore.MAGENTA}{'='*60}", 0.01)
            slow_print(f"{Fore.YELLOW}Title: AI Composition in {key} {style.title()}", 0.02)
            slow_print(f"{Fore.YELLOW}Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 0.02)
            slow_print(f"{Fore.YELLOW}Created by: BHAVYANSH SONI's AiMusic", 0.02)
            
            display_chord_progression(chords, "Harmony")
            display_melody(melody, "Main Melody")
            
            analysis = generator.analyze_melody(melody)
            display_analysis(analysis, "Composition Analysis")
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}🎓 Music Theory Helper", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Available Scales:", 0.02)
            for scale, intervals in generator.scales.items():
                slow_print(f"{Fore.GREEN}{scale.title()}: {Fore.WHITE}{intervals}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Chord Progressions:", 0.02)
            for style, progression in generator.chord_progressions.items():
                slow_print(f"{Fore.GREEN}{style.title()}: {Fore.WHITE}{' - '.join(progression)}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Note Circle:", 0.02)
            circle_line = ""
            for note in generator.note_names:
                circle_line += f"{Fore.CYAN}{note} "
            slow_print(f"{circle_line}", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using AiMusic! Keep composing!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '6':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
