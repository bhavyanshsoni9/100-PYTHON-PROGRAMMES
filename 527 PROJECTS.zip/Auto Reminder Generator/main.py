import re

def extract_reminders(text):
    patterns = [r'\b\d{1,2} ?(AM|PM)\b', r'\b\d{1,2}:\d{2}\b']
    reminders = []
    for pattern in patterns:
        matches = re.findall(pattern, text, flags=re.IGNORECASE)
        reminders.extend(matches)
    return reminders

if __name__ == "__main__":
    text = input("Paste your chat/conversation text:\n")
    reminders = extract_reminders(text)
    if reminders:
        print("\nReminders Found:")
        for r in reminders:
            print(f"- {r}")
    else:
        print("No reminders found.")