#!/usr/bin/env python3
"""
AutoBack - Automated Backup System
Created by BHAVYANSH SONI
A retro-style automated backup and restore system with colored output
"""

import os
import sys
import time
import shutil
import hashlib
import json
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import threading
import zipfile
import tarfile

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.BLUE}{'='*60}
{Fore.CYAN}     █████╗ ██╗   ██╗████████╗ ██████╗ ██████╗  █████╗  ██████╗██╗  ██╗
{Fore.CYAN}    ██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██╔══██╗██╔══██╗██╔════╝██║ ██╔╝
{Fore.CYAN}    ███████║██║   ██║   ██║   ██║   ██║██████╔╝███████║██║     █████╔╝ 
{Fore.CYAN}    ██╔══██║██║   ██║   ██║   ██║   ██║██╔══██╗██╔══██║██║     ██╔═██╗ 
{Fore.CYAN}    ██║  ██║╚██████╔╝   ██║   ╚██████╔╝██████╔╝██║  ██║╚██████╗██║  ██╗
{Fore.CYAN}    ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝
{Fore.BLUE}{'='*60}
{Fore.YELLOW}    💾 Automated Backup System - Protect Your Data
{Fore.MAGENTA}    🔒 Created by: BHAVYANSH SONI
{Fore.BLUE}{'='*60}
"""
    print(header)

class AutoBackup:
    """Automated backup system class"""
    
    def __init__(self):
        self.backup_dir = "backups"
        self.config_file = "autoback_config.json"
        self.backup_jobs = []
        self.backup_history = []
        self.compression_types = ['zip', 'tar', 'tar.gz']
        self.max_backups = 10
        self.ensure_backup_dir()
        self.load_config()
    
    def ensure_backup_dir(self):
        """Ensure backup directory exists"""
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)
    
    def load_config(self):
        """Load configuration from file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.backup_jobs = config.get('backup_jobs', [])
                    self.backup_history = config.get('backup_history', [])
        except Exception as e:
            slow_print(f"{Fore.YELLOW}⚠️ Could not load config: {str(e)}", 0.02)
    
    def save_config(self):
        """Save configuration to file"""
        try:
            config = {
                'backup_jobs': self.backup_jobs,
                'backup_history': self.backup_history
            }
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            slow_print(f"{Fore.RED}❌ Could not save config: {str(e)}", 0.02)
    
    def calculate_file_hash(self, file_path):
        """Calculate SHA256 hash of file"""
        try:
            hash_obj = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_obj.update(chunk)
            return hash_obj.hexdigest()
        except:
            return None
    
    def get_directory_size(self, directory):
        """Get total size of directory"""
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(directory):
                for filename in filenames:
                    file_path = os.path.join(dirpath, filename)
                    if os.path.exists(file_path):
                        total_size += os.path.getsize(file_path)
        except:
            pass
        return total_size
    
    def format_size(self, size_bytes):
        """Format bytes to human readable format"""
        if size_bytes == 0:
            return "0 B"
        
        size_names = ["B", "KB", "MB", "GB", "TB"]
        i = 0
        
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
        
        return f"{size_bytes:.1f} {size_names[i]}"
    
    def create_backup_job(self, name, source_path, backup_type='zip', schedule='daily'):
        """Create a new backup job"""
        job = {
            'id': len(self.backup_jobs) + 1,
            'name': name,
            'source_path': source_path,
            'backup_type': backup_type,
            'schedule': schedule,
            'created': datetime.now().isoformat(),
            'last_backup': None,
            'enabled': True,
            'retain_count': self.max_backups
        }
        
        self.backup_jobs.append(job)
        self.save_config()
        return job
    
    def compress_directory(self, source_path, output_path, compression_type='zip'):
        """Compress directory with specified compression type"""
        try:
            if compression_type == 'zip':
                with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for root, dirs, files in os.walk(source_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, source_path)
                            zipf.write(file_path, arcname)
            
            elif compression_type == 'tar':
                with tarfile.open(output_path, 'w') as tar:
                    tar.add(source_path, arcname=os.path.basename(source_path))
            
            elif compression_type == 'tar.gz':
                with tarfile.open(output_path, 'w:gz') as tar:
                    tar.add(source_path, arcname=os.path.basename(source_path))
            
            return True
        except Exception as e:
            slow_print(f"{Fore.RED}❌ Compression failed: {str(e)}", 0.02)
            return False
    
    def perform_backup(self, job):
        """Perform backup for a specific job"""
        source_path = job['source_path']
        
        if not os.path.exists(source_path):
            return {"success": False, "error": "Source path does not exist"}
        
        # Generate backup filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{job['name']}_{timestamp}"
        
        # Determine file extension
        if job['backup_type'] == 'zip':
            backup_file = f"{backup_name}.zip"
        elif job['backup_type'] == 'tar':
            backup_file = f"{backup_name}.tar"
        elif job['backup_type'] == 'tar.gz':
            backup_file = f"{backup_name}.tar.gz"
        
        backup_path = os.path.join(self.backup_dir, backup_file)
        
        slow_print(f"{Fore.YELLOW}📦 Creating backup: {backup_file}", 0.02)
        
        # Calculate source size
        if os.path.isdir(source_path):
            source_size = self.get_directory_size(source_path)
        else:
            source_size = os.path.getsize(source_path)
        
        # Perform backup
        start_time = time.time()
        
        if os.path.isdir(source_path):
            success = self.compress_directory(source_path, backup_path, job['backup_type'])
        else:
            # Single file backup
            try:
                shutil.copy2(source_path, backup_path)
                success = True
            except Exception as e:
                slow_print(f"{Fore.RED}❌ Backup failed: {str(e)}", 0.02)
                success = False
        
        end_time = time.time()
        duration = end_time - start_time
        
        if success:
            backup_size = os.path.getsize(backup_path)
            compression_ratio = (1 - backup_size / source_size) * 100 if source_size > 0 else 0
            
            # Update job
            job['last_backup'] = datetime.now().isoformat()
            
            # Record backup history
            backup_record = {
                'job_id': job['id'],
                'job_name': job['name'],
                'timestamp': datetime.now().isoformat(),
                'backup_file': backup_file,
                'source_size': source_size,
                'backup_size': backup_size,
                'compression_ratio': compression_ratio,
                'duration': duration,
                'success': True
            }
            
            self.backup_history.append(backup_record)
            self.save_config()
            
            # Clean up old backups
            self.cleanup_old_backups(job)
            
            return {
                "success": True,
                "backup_file": backup_file,
                "source_size": source_size,
                "backup_size": backup_size,
                "compression_ratio": compression_ratio,
                "duration": duration
            }
        else:
            return {"success": False, "error": "Backup operation failed"}
    
    def cleanup_old_backups(self, job):
        """Clean up old backups for a job"""
        # Get all backup files for this job
        job_backups = []
        for record in self.backup_history:
            if record['job_id'] == job['id']:
                backup_file = os.path.join(self.backup_dir, record['backup_file'])
                if os.path.exists(backup_file):
                    job_backups.append((record['timestamp'], backup_file))
        
        # Sort by timestamp (newest first)
        job_backups.sort(reverse=True)
        
        # Remove old backups
        if len(job_backups) > job['retain_count']:
            for _, backup_file in job_backups[job['retain_count']:]:
                try:
                    os.remove(backup_file)
                    slow_print(f"{Fore.YELLOW}🗑️ Cleaned up old backup: {os.path.basename(backup_file)}", 0.02)
                except:
                    pass
    
    def restore_backup(self, backup_file, restore_path):
        """Restore backup from file"""
        backup_path = os.path.join(self.backup_dir, backup_file)
        
        if not os.path.exists(backup_path):
            return {"success": False, "error": "Backup file not found"}
        
        try:
            if backup_file.endswith('.zip'):
                with zipfile.ZipFile(backup_path, 'r') as zipf:
                    zipf.extractall(restore_path)
            elif backup_file.endswith('.tar.gz'):
                with tarfile.open(backup_path, 'r:gz') as tar:
                    tar.extractall(restore_path)
            elif backup_file.endswith('.tar'):
                with tarfile.open(backup_path, 'r') as tar:
                    tar.extractall(restore_path)
            else:
                # Single file restore
                shutil.copy2(backup_path, restore_path)
            
            return {"success": True, "restore_path": restore_path}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_backup_statistics(self):
        """Get backup statistics"""
        total_backups = len(self.backup_history)
        successful_backups = sum(1 for record in self.backup_history if record['success'])
        total_size = sum(record['backup_size'] for record in self.backup_history)
        
        return {
            'total_jobs': len(self.backup_jobs),
            'total_backups': total_backups,
            'successful_backups': successful_backups,
            'total_size': total_size,
            'success_rate': (successful_backups / total_backups * 100) if total_backups > 0 else 0
        }

def display_backup_jobs(jobs):
    """Display backup jobs"""
    if not jobs:
        slow_print(f"{Fore.YELLOW}📋 No backup jobs configured", 0.02)
        return
    
    slow_print(f"\n{Fore.CYAN}📋 Backup Jobs:", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    for job in jobs:
        status = "✅ Enabled" if job['enabled'] else "❌ Disabled"
        last_backup = job['last_backup'][:19] if job['last_backup'] else "Never"
        
        slow_print(f"{Fore.GREEN}{job['id']}. {Fore.WHITE}{job['name']}", 0.02)
        slow_print(f"   {Fore.CYAN}Source: {Fore.WHITE}{job['source_path']}", 0.02)
        slow_print(f"   {Fore.CYAN}Type: {Fore.WHITE}{job['backup_type']}", 0.02)
        slow_print(f"   {Fore.CYAN}Schedule: {Fore.WHITE}{job['schedule']}", 0.02)
        slow_print(f"   {Fore.CYAN}Last Backup: {Fore.WHITE}{last_backup}", 0.02)
        slow_print(f"   {Fore.CYAN}Status: {Fore.WHITE}{status}", 0.02)
        print()

def display_backup_history(history):
    """Display backup history"""
    if not history:
        slow_print(f"{Fore.YELLOW}📜 No backup history", 0.02)
        return
    
    slow_print(f"\n{Fore.CYAN}📜 Backup History (Recent 10):", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    recent_history = sorted(history, key=lambda x: x['timestamp'], reverse=True)[:10]
    
    for record in recent_history:
        status = "✅" if record['success'] else "❌"
        timestamp = record['timestamp'][:19]
        
        slow_print(f"{status} {Fore.WHITE}{record['job_name']} - {timestamp}", 0.02)
        slow_print(f"   {Fore.CYAN}File: {Fore.WHITE}{record['backup_file']}", 0.02)
        slow_print(f"   {Fore.CYAN}Size: {Fore.WHITE}{AutoBackup().format_size(record['backup_size'])}", 0.02)
        slow_print(f"   {Fore.CYAN}Compression: {Fore.WHITE}{record['compression_ratio']:.1f}%", 0.02)
        slow_print(f"   {Fore.CYAN}Duration: {Fore.WHITE}{record['duration']:.2f}s", 0.02)
        print()

def display_statistics(stats):
    """Display backup statistics"""
    slow_print(f"\n{Fore.CYAN}📊 Backup Statistics", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Total Jobs: {Fore.WHITE}{stats['total_jobs']}", 0.02)
    slow_print(f"{Fore.GREEN}Total Backups: {Fore.WHITE}{stats['total_backups']}", 0.02)
    slow_print(f"{Fore.GREEN}Successful Backups: {Fore.WHITE}{stats['successful_backups']}", 0.02)
    slow_print(f"{Fore.GREEN}Success Rate: {Fore.WHITE}{stats['success_rate']:.1f}%", 0.02)
    slow_print(f"{Fore.GREEN}Total Size: {Fore.WHITE}{AutoBackup().format_size(stats['total_size'])}", 0.02)

def main():
    """Main function"""
    print_header()
    
    backup_system = AutoBackup()
    
    while True:
        slow_print(f"\n{Fore.CYAN}💾 AutoBack Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Create Backup Job", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Run Backup", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}View Backup Jobs", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Restore Backup", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Backup History", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Statistics", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Settings", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}📝 Create Backup Job", 0.02)
            
            name = input(f"{Fore.YELLOW}Job name: ").strip()
            if not name:
                slow_print(f"{Fore.RED}❌ Job name is required", 0.02)
                continue
            
            source_path = input(f"{Fore.YELLOW}Source path: ").strip()
            if not source_path or not os.path.exists(source_path):
                slow_print(f"{Fore.RED}❌ Valid source path is required", 0.02)
                continue
            
            slow_print(f"\n{Fore.YELLOW}Backup types:", 0.02)
            for i, btype in enumerate(backup_system.compression_types, 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{btype}", 0.02)
            
            try:
                type_choice = int(input(f"{Fore.YELLOW}Select type (1-3): ").strip()) - 1
                if 0 <= type_choice < len(backup_system.compression_types):
                    backup_type = backup_system.compression_types[type_choice]
                else:
                    backup_type = 'zip'
            except ValueError:
                backup_type = 'zip'
            
            job = backup_system.create_backup_job(name, source_path, backup_type)
            slow_print(f"\n{Fore.GREEN}✅ Backup job created: {job['name']}", 0.02)
        
        elif choice == '2':
            if not backup_system.backup_jobs:
                slow_print(f"{Fore.RED}❌ No backup jobs configured", 0.02)
                continue
            
            slow_print(f"\n{Fore.CYAN}🚀 Run Backup", 0.02)
            display_backup_jobs(backup_system.backup_jobs)
            
            try:
                job_id = int(input(f"{Fore.YELLOW}Select job ID: ").strip())
                job = next((j for j in backup_system.backup_jobs if j['id'] == job_id), None)
                
                if job:
                    slow_print(f"\n{Fore.YELLOW}🔄 Starting backup for: {job['name']}", 0.02)
                    result = backup_system.perform_backup(job)
                    
                    if result['success']:
                        slow_print(f"\n{Fore.GREEN}✅ Backup completed successfully!", 0.02)
                        slow_print(f"{Fore.CYAN}Backup file: {Fore.WHITE}{result['backup_file']}", 0.02)
                        slow_print(f"{Fore.CYAN}Original size: {Fore.WHITE}{backup_system.format_size(result['source_size'])}", 0.02)
                        slow_print(f"{Fore.CYAN}Backup size: {Fore.WHITE}{backup_system.format_size(result['backup_size'])}", 0.02)
                        slow_print(f"{Fore.CYAN}Compression: {Fore.WHITE}{result['compression_ratio']:.1f}%", 0.02)
                        slow_print(f"{Fore.CYAN}Duration: {Fore.WHITE}{result['duration']:.2f}s", 0.02)
                    else:
                        slow_print(f"\n{Fore.RED}❌ Backup failed: {result['error']}", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Job not found", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid job ID", 0.02)
        
        elif choice == '3':
            display_backup_jobs(backup_system.backup_jobs)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}🔄 Restore Backup", 0.02)
            
            # List available backups
            backup_files = [f for f in os.listdir(backup_system.backup_dir) if f.endswith(('.zip', '.tar', '.tar.gz'))]
            
            if not backup_files:
                slow_print(f"{Fore.RED}❌ No backup files found", 0.02)
                continue
            
            slow_print(f"\n{Fore.YELLOW}Available backups:", 0.02)
            for i, backup_file in enumerate(backup_files, 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{backup_file}", 0.02)
            
            try:
                backup_choice = int(input(f"{Fore.YELLOW}Select backup (1-{len(backup_files)}): ").strip()) - 1
                if 0 <= backup_choice < len(backup_files):
                    backup_file = backup_files[backup_choice]
                    restore_path = input(f"{Fore.YELLOW}Restore to path: ").strip()
                    
                    if restore_path:
                        slow_print(f"\n{Fore.YELLOW}🔄 Restoring backup...", 0.02)
                        result = backup_system.restore_backup(backup_file, restore_path)
                        
                        if result['success']:
                            slow_print(f"\n{Fore.GREEN}✅ Backup restored successfully!", 0.02)
                            slow_print(f"{Fore.CYAN}Restored to: {Fore.WHITE}{result['restore_path']}", 0.02)
                        else:
                            slow_print(f"\n{Fore.RED}❌ Restore failed: {result['error']}", 0.02)
                    else:
                        slow_print(f"{Fore.RED}❌ Restore path is required", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid backup selection", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid selection", 0.02)
        
        elif choice == '5':
            display_backup_history(backup_system.backup_history)
        
        elif choice == '6':
            stats = backup_system.get_backup_statistics()
            display_statistics(stats)
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}⚙️ Settings", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            slow_print(f"{Fore.GREEN}Backup Directory: {Fore.WHITE}{backup_system.backup_dir}", 0.02)
            slow_print(f"{Fore.GREEN}Max Backups per Job: {Fore.WHITE}{backup_system.max_backups}", 0.02)
            slow_print(f"{Fore.GREEN}Supported Formats: {Fore.WHITE}{', '.join(backup_system.compression_types)}", 0.02)
            slow_print(f"{Fore.GREEN}Config File: {Fore.WHITE}{backup_system.config_file}", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using AutoBack! Your data is safe!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
