#!/usr/bin/env python3
"""
BinViz - Binary File Visualizer
Created by BHAVYANSH SONI
A retro-style binary file analyzer and visualizer with colored output
"""

import os
import sys
import time
from colorama import init, Fore, Back, Style
import math
import hashlib

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.MAGENTA}{'='*60}
{Fore.CYAN}    ██████╗ ██╗███╗   ██╗██╗   ██╗██╗███████╗
{Fore.CYAN}    ██╔══██╗██║████╗  ██║██║   ██║██║╚══███╔╝
{Fore.CYAN}    ██████╔╝██║██╔██╗ ██║██║   ██║██║  ███╔╝ 
{Fore.CYAN}    ██╔══██╗██║██║╚██╗██║╚██╗ ██╔╝██║ ███╔╝  
{Fore.CYAN}    ██████╔╝██║██║ ╚████║ ╚████╔╝ ██║███████╗
{Fore.CYAN}    ╚═════╝ ╚═╝╚═╝  ╚═══╝  ╚═══╝  ╚═╝╚══════╝
{Fore.MAGENTA}{'='*60}
{Fore.YELLOW}    🔍 Binary File Visualizer - Analyze Binary Data
{Fore.MAGENTA}    📊 Created by: BHAVYANSH SONI
{Fore.MAGENTA}{'='*60}
"""
    print(header)

class BinaryVisualizer:
    """Binary file visualization class"""
    
    def __init__(self):
        self.chunk_size = 1024
        self.max_display_bytes = 10000
        
    def read_binary_file(self, file_path):
        """Read binary file and return data"""
        try:
            with open(file_path, 'rb') as f:
                return f.read()
        except Exception as e:
            return None
    
    def analyze_file(self, file_path):
        """Analyze binary file"""
        if not os.path.exists(file_path):
            return None
        
        data = self.read_binary_file(file_path)
        if data is None:
            return None
        
        analysis = {
            'file_size': len(data),
            'entropy': self.calculate_entropy(data),
            'byte_frequency': self.analyze_byte_frequency(data),
            'file_type': self.detect_file_type(data),
            'checksum': self.calculate_checksum(data),
            'ascii_ratio': self.calculate_ascii_ratio(data),
            'null_bytes': data.count(0),
            'unique_bytes': len(set(data))
        }
        
        return analysis
    
    def calculate_entropy(self, data):
        """Calculate Shannon entropy"""
        if not data:
            return 0
        
        byte_counts = [0] * 256
        for byte in data:
            byte_counts[byte] += 1
        
        entropy = 0
        length = len(data)
        
        for count in byte_counts:
            if count > 0:
                probability = count / length
                entropy -= probability * math.log2(probability)
        
        return entropy
    
    def analyze_byte_frequency(self, data):
        """Analyze byte frequency distribution"""
        frequency = [0] * 256
        for byte in data:
            frequency[byte] += 1
        
        return frequency
    
    def detect_file_type(self, data):
        """Detect file type from header"""
        if not data:
            return "Unknown"
        
        headers = {
            b'\x89PNG\r\n\x1a\n': 'PNG Image',
            b'\xff\xd8\xff': 'JPEG Image',
            b'GIF87a': 'GIF Image',
            b'GIF89a': 'GIF Image',
            b'%PDF': 'PDF Document',
            b'PK\x03\x04': 'ZIP Archive',
            b'\x7fELF': 'ELF Executable',
            b'MZ': 'Windows Executable',
            b'\x00\x00\x01\x00': 'ICO Image',
            b'RIFF': 'RIFF Container',
            b'\xca\xfe\xba\xbe': 'Java Class',
            b'\xfe\xed\xfa': 'Mach-O Binary'
        }
        
        for header, file_type in headers.items():
            if data.startswith(header):
                return file_type
        
        # Check for text files
        try:
            data[:100].decode('utf-8')
            return "Text File"
        except:
            pass
        
        return "Binary Data"
    
    def calculate_checksum(self, data):
        """Calculate various checksums"""
        md5_hash = hashlib.md5(data).hexdigest()
        sha1_hash = hashlib.sha1(data).hexdigest()
        sha256_hash = hashlib.sha256(data).hexdigest()
        
        return {
            'md5': md5_hash,
            'sha1': sha1_hash,
            'sha256': sha256_hash
        }
    
    def calculate_ascii_ratio(self, data):
        """Calculate ratio of ASCII printable characters"""
        if not data:
            return 0
        
        ascii_count = 0
        for byte in data:
            if 32 <= byte <= 126:  # Printable ASCII range
                ascii_count += 1
        
        return ascii_count / len(data)
    
    def create_hex_dump(self, data, start_offset=0, length=256):
        """Create hex dump visualization"""
        lines = []
        end_offset = min(start_offset + length, len(data))
        
        for i in range(start_offset, end_offset, 16):
            # Address
            address = f"{i:08x}"
            
            # Hex bytes
            hex_bytes = []
            ascii_chars = []
            
            for j in range(16):
                if i + j < len(data):
                    byte = data[i + j]
                    hex_bytes.append(f"{byte:02x}")
                    
                    # ASCII representation
                    if 32 <= byte <= 126:
                        ascii_chars.append(chr(byte))
                    else:
                        ascii_chars.append('.')
                else:
                    hex_bytes.append('  ')
                    ascii_chars.append(' ')
            
            # Format line
            hex_part = ' '.join(hex_bytes[:8]) + '  ' + ' '.join(hex_bytes[8:])
            ascii_part = ''.join(ascii_chars)
            
            lines.append(f"{address}  {hex_part}  |{ascii_part}|")
        
        return lines
    
    def create_byte_histogram(self, frequency, width=50):
        """Create ASCII histogram of byte frequency"""
        if not frequency:
            return []
        
        max_freq = max(frequency)
        if max_freq == 0:
            return []
        
        histogram = []
        
        # Show most frequent bytes
        byte_freq_pairs = [(i, freq) for i, freq in enumerate(frequency) if freq > 0]
        byte_freq_pairs.sort(key=lambda x: x[1], reverse=True)
        
        histogram.append("Top 20 Most Frequent Bytes:")
        histogram.append("-" * 40)
        
        for i, (byte_val, freq) in enumerate(byte_freq_pairs[:20]):
            bar_length = int((freq / max_freq) * width)
            bar = '█' * bar_length
            percentage = (freq / sum(frequency)) * 100
            
            histogram.append(f"0x{byte_val:02x} ({byte_val:3d}): {bar:<{width}} {freq:6d} ({percentage:5.1f}%)")
        
        return histogram
    
    def visualize_entropy_map(self, data, block_size=256):
        """Create entropy visualization map"""
        if len(data) < block_size:
            return []
        
        entropy_map = []
        entropy_map.append("Entropy Map (per block):")
        entropy_map.append("-" * 40)
        
        for i in range(0, len(data), block_size):
            block = data[i:i+block_size]
            if len(block) < block_size:
                break
            
            entropy = self.calculate_entropy(block)
            bar_length = int((entropy / 8.0) * 30)  # Max entropy is 8
            bar = '█' * bar_length + '░' * (30 - bar_length)
            
            entropy_map.append(f"Block {i//block_size:4d}: {bar} {entropy:.2f}")
        
        return entropy_map

def display_file_analysis(analysis, file_path):
    """Display file analysis results"""
    slow_print(f"\n{Fore.CYAN}📊 File Analysis: {os.path.basename(file_path)}", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}File Size: {Fore.WHITE}{analysis['file_size']:,} bytes", 0.02)
    slow_print(f"{Fore.GREEN}File Type: {Fore.WHITE}{analysis['file_type']}", 0.02)
    slow_print(f"{Fore.GREEN}Entropy: {Fore.WHITE}{analysis['entropy']:.4f} bits", 0.02)
    slow_print(f"{Fore.GREEN}ASCII Ratio: {Fore.WHITE}{analysis['ascii_ratio']:.1%}", 0.02)
    slow_print(f"{Fore.GREEN}Null Bytes: {Fore.WHITE}{analysis['null_bytes']:,}", 0.02)
    slow_print(f"{Fore.GREEN}Unique Bytes: {Fore.WHITE}{analysis['unique_bytes']}/256", 0.02)
    
    # Entropy analysis
    if analysis['entropy'] > 7.5:
        entropy_desc = "Very High (Encrypted/Compressed)"
        entropy_color = Fore.RED
    elif analysis['entropy'] > 6.0:
        entropy_desc = "High (Binary Data)"
        entropy_color = Fore.YELLOW
    elif analysis['entropy'] > 4.0:
        entropy_desc = "Medium (Mixed Content)"
        entropy_color = Fore.CYAN
    else:
        entropy_desc = "Low (Structured/Text)"
        entropy_color = Fore.GREEN
    
    slow_print(f"{Fore.GREEN}Entropy Level: {entropy_color}{entropy_desc}", 0.02)

def display_checksums(checksums):
    """Display file checksums"""
    slow_print(f"\n{Fore.CYAN}🔐 File Checksums", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}MD5:    {Fore.WHITE}{checksums['md5']}", 0.02)
    slow_print(f"{Fore.GREEN}SHA1:   {Fore.WHITE}{checksums['sha1']}", 0.02)
    slow_print(f"{Fore.GREEN}SHA256: {Fore.WHITE}{checksums['sha256']}", 0.02)

def display_hex_dump(hex_lines):
    """Display hex dump"""
    slow_print(f"\n{Fore.CYAN}🔍 Hex Dump", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    for line in hex_lines[:20]:  # Limit display
        slow_print(f"{Fore.WHITE}{line}", 0.01)
    
    if len(hex_lines) > 20:
        slow_print(f"{Fore.YELLOW}... ({len(hex_lines) - 20} more lines)", 0.02)

def display_histogram(histogram):
    """Display byte frequency histogram"""
    slow_print(f"\n{Fore.CYAN}📈 Byte Frequency Analysis", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    for line in histogram:
        if line.startswith("0x"):
            slow_print(f"{Fore.GREEN}{line}", 0.01)
        else:
            slow_print(f"{Fore.CYAN}{line}", 0.01)

def main():
    """Main function"""
    print_header()
    
    visualizer = BinaryVisualizer()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🔍 BinViz Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Analyze Binary File", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Hex Dump View", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Byte Frequency Analysis", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Entropy Visualization", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}File Comparison", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-6): ").strip()
        
        if choice == '1':
            file_path = input(f"{Fore.YELLOW}Enter file path: ").strip()
            if not file_path:
                slow_print(f"{Fore.RED}❌ Please enter a file path", 0.02)
                continue
            
            slow_print(f"\n{Fore.YELLOW}🔄 Analyzing file...", 0.02)
            analysis = visualizer.analyze_file(file_path)
            
            if analysis:
                display_file_analysis(analysis, file_path)
                display_checksums(analysis['checksum'])
            else:
                slow_print(f"{Fore.RED}❌ Could not analyze file", 0.02)
        
        elif choice == '2':
            file_path = input(f"{Fore.YELLOW}Enter file path: ").strip()
            if not file_path:
                slow_print(f"{Fore.RED}❌ Please enter a file path", 0.02)
                continue
            
            offset = input(f"{Fore.YELLOW}Start offset (default 0): ").strip()
            length = input(f"{Fore.YELLOW}Length (default 256): ").strip()
            
            try:
                offset = int(offset) if offset else 0
                length = int(length) if length else 256
            except ValueError:
                offset, length = 0, 256
            
            data = visualizer.read_binary_file(file_path)
            if data:
                hex_lines = visualizer.create_hex_dump(data, offset, length)
                display_hex_dump(hex_lines)
            else:
                slow_print(f"{Fore.RED}❌ Could not read file", 0.02)
        
        elif choice == '3':
            file_path = input(f"{Fore.YELLOW}Enter file path: ").strip()
            if not file_path:
                slow_print(f"{Fore.RED}❌ Please enter a file path", 0.02)
                continue
            
            data = visualizer.read_binary_file(file_path)
            if data:
                frequency = visualizer.analyze_byte_frequency(data)
                histogram = visualizer.create_byte_histogram(frequency)
                display_histogram(histogram)
            else:
                slow_print(f"{Fore.RED}❌ Could not read file", 0.02)
        
        elif choice == '4':
            file_path = input(f"{Fore.YELLOW}Enter file path: ").strip()
            if not file_path:
                slow_print(f"{Fore.RED}❌ Please enter a file path", 0.02)
                continue
            
            data = visualizer.read_binary_file(file_path)
            if data:
                entropy_map = visualizer.visualize_entropy_map(data)
                
                slow_print(f"\n{Fore.CYAN}📊 Entropy Visualization", 0.02)
                slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
                
                for line in entropy_map[:30]:  # Limit display
                    if "Block" in line:
                        slow_print(f"{Fore.WHITE}{line}", 0.01)
                    else:
                        slow_print(f"{Fore.CYAN}{line}", 0.01)
            else:
                slow_print(f"{Fore.RED}❌ Could not read file", 0.02)
        
        elif choice == '5':
            file1 = input(f"{Fore.YELLOW}Enter first file path: ").strip()
            file2 = input(f"{Fore.YELLOW}Enter second file path: ").strip()
            
            if not file1 or not file2:
                slow_print(f"{Fore.RED}❌ Please enter both file paths", 0.02)
                continue
            
            analysis1 = visualizer.analyze_file(file1)
            analysis2 = visualizer.analyze_file(file2)
            
            if analysis1 and analysis2:
                slow_print(f"\n{Fore.CYAN}📊 File Comparison", 0.02)
                slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
                
                slow_print(f"{Fore.GREEN}File 1: {Fore.WHITE}{os.path.basename(file1)}", 0.02)
                slow_print(f"{Fore.GREEN}File 2: {Fore.WHITE}{os.path.basename(file2)}", 0.02)
                
                slow_print(f"\n{Fore.CYAN}Size Comparison:", 0.02)
                slow_print(f"{Fore.WHITE}File 1: {analysis1['file_size']:,} bytes", 0.02)
                slow_print(f"{Fore.WHITE}File 2: {analysis2['file_size']:,} bytes", 0.02)
                
                slow_print(f"\n{Fore.CYAN}Entropy Comparison:", 0.02)
                slow_print(f"{Fore.WHITE}File 1: {analysis1['entropy']:.4f} bits", 0.02)
                slow_print(f"{Fore.WHITE}File 2: {analysis2['entropy']:.4f} bits", 0.02)
                
                slow_print(f"\n{Fore.CYAN}Type Comparison:", 0.02)
                slow_print(f"{Fore.WHITE}File 1: {analysis1['file_type']}", 0.02)
                slow_print(f"{Fore.WHITE}File 2: {analysis2['file_type']}", 0.02)
                
                # Check if files are identical
                if analysis1['checksum']['md5'] == analysis2['checksum']['md5']:
                    slow_print(f"\n{Fore.GREEN}✅ Files are identical (same MD5)", 0.02)
                else:
                    slow_print(f"\n{Fore.RED}❌ Files are different", 0.02)
            else:
                slow_print(f"{Fore.RED}❌ Could not analyze one or both files", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using BinViz! Happy analyzing!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '6':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
