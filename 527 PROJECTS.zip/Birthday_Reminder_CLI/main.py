from time import sleep
from datetime import datetime
from colorama import Fore, Style, init
import os

init(autoreset=True)

def slow_print(text, color=Fore.WHITE, delay=0.03):
    for char in text:
        print(color + char, end='', flush=True)
        sleep(delay)
    print("\n")

def get_dates_files():
    # Always get the latest list of files
    return os.listdir("dates")

def add_to_dates(file, content):
    with open(f"dates/{file}.txt", "w") as f:
        f.write(content)

def add_date():
    slow_print("You Chose To Add Dates!")
    name = input("Name>> ").strip()
    date = input("Date (YYYY-MM-DD)>> ").strip()
    # Optional: Validate date format
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        slow_print("Invalid date format! Please use YYYY-MM-DD.", Fore.RED)
        return
    slow_print(f"Date Saved As {name}.txt with Date {date}")
    add_to_dates(name.lower(), date)

def remove_date():
    files = get_dates_files()
    slow_print("You Chose To Remove Dates!")
    if not files:
        slow_print("File is Empty. You Should Add Dates First!", Fore.YELLOW)
        return
    for i, fname in enumerate(files, 1):
        print(f"{i}. {fname}")
    name = input("Enter the name to remove (without .txt)>> ").strip().lower()
    filename = f"{name}.txt"
    if filename in files:
        os.remove(f"dates/{filename}")
        slow_print(f"Removed 🗑 {filename} From Dates!", Fore.GREEN)
    else:
        slow_print("Invalid name!", Fore.RED)

def edit_date():
    files = get_dates_files()
    slow_print("You Chose To Edit Dates!")
    if not files:
        slow_print("No dates to edit. Please add some first.", Fore.YELLOW)
        return
    for i, fname in enumerate(files, 1):
        print(f"{i}. {fname}")
    name = input("Enter the name to edit (without .txt)>> ").strip().lower()
    filename = f"{name}.txt"
    if filename in files:
        new_date = input("Enter the new date (YYYY-MM-DD)>> ").strip()
        try:
            datetime.strptime(new_date, "%Y-%m-%d")
        except ValueError:
            slow_print("Invalid date format! Please use YYYY-MM-DD.", Fore.RED)
            return
        add_to_dates(name, new_date)
        slow_print(f"Updated {filename} with new date {new_date}.", Fore.GREEN)
    else:
        slow_print("Invalid name!", Fore.RED)

def see_date():
    files = get_dates_files()
    slow_print("You Chose To See Dates!")
    if not files:
        slow_print("No dates to show. Please add some first.", Fore.YELLOW)
        return
    for i, fname in enumerate(files, 1):
        print(f"{i}. {fname}")
    name = input("Enter the name to view (without .txt)>> ").strip().lower()
    filename = f"{name}.txt"
    if filename in files:
        with open(f"dates/{filename}", "r") as f:
            date = f.read().strip()
        slow_print(f"{name.title()}'s birthday is on {date}.", Fore.CYAN)
    else:
        slow_print("Invalid name!", Fore.RED)

def menu():
    while True:
        slow_print("Now What You Want To Do: ")
        slow_print("1. Add Date!")
        slow_print("2. Remove Date!")
        slow_print("3. Edit Date!")
        slow_print("4. See Date!")
        slow_print("5. Exit!")

        try:
            action = int(input(">> "))
            if action == 1:
                add_date()
            elif action == 2:
                remove_date()
            elif action == 3:
                edit_date()
            elif action == 4:
                see_date()
            elif action == 5:
                slow_print("GoodBye... Exiting...", Fore.MAGENTA)
                break
            else:
                slow_print("Invalid Action!", Fore.RED)
        except ValueError:
            slow_print("Invalid Action!", Fore.RED)

if __name__ == "__main__":
    slow_print("Welcome To The BIRTHDAY REMINDER!", Fore.MAGENTA)
    slow_print("Here You Can Save Anyone's Birthday Date!", Fore.MAGENTA)
    slow_print("So, That You Can't Forget It!", Fore.MAGENTA)
    menu()