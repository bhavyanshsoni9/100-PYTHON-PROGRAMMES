#!/usr/bin/env python3
"""
BrainAI - Neural Network Simulator
Created by BHAVYANSH SONI
A retro-style neural network simulator and AI learning tool with colored output
"""

import os
import sys
import time
import random
import math
from datetime import datetime
from colorama import init, Fore, Back, Style
import json

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.BLUE}{'='*60}
{Fore.CYAN}    ██████╗ ██████╗  █████╗ ██╗███╗   ██╗ █████╗ ██╗
{Fore.CYAN}    ██╔══██╗██╔══██╗██╔══██╗██║████╗  ██║██╔══██╗██║
{Fore.CYAN}    ██████╔╝██████╔╝███████║██║██╔██╗ ██║███████║██║
{Fore.CYAN}    ██╔══██╗██╔══██╗██╔══██║██║██║╚██╗██║██╔══██║██║
{Fore.CYAN}    ██████╔╝██║  ██║██║  ██║██║██║ ╚████║██║  ██║██║
{Fore.CYAN}    ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝
{Fore.BLUE}{'='*60}
{Fore.YELLOW}    🧠 Neural Network Simulator - AI Learning Lab
{Fore.MAGENTA}    🤖 Created by: BHAVYANSH SONI
{Fore.BLUE}{'='*60}
"""
    print(header)

class Neuron:
    """Individual neuron class"""
    
    def __init__(self, num_inputs):
        self.weights = [random.uniform(-1, 1) for _ in range(num_inputs)]
        self.bias = random.uniform(-1, 1)
        self.output = 0
        self.delta = 0
    
    def activate(self, inputs):
        """Calculate neuron activation"""
        total = sum(w * x for w, x in zip(self.weights, inputs)) + self.bias
        self.output = self.sigmoid(total)
        return self.output
    
    def sigmoid(self, x):
        """Sigmoid activation function"""
        return 1 / (1 + math.exp(-max(-500, min(500, x))))
    
    def relu(self, x):
        """ReLU activation function"""
        return max(0, x)
    
    def tanh_activation(self, x):
        """Tanh activation function"""
        return math.tanh(x)

class NeuralLayer:
    """Neural network layer"""
    
    def __init__(self, num_neurons, num_inputs):
        self.neurons = [Neuron(num_inputs) for _ in range(num_neurons)]
    
    def forward_pass(self, inputs):
        """Forward pass through layer"""
        outputs = []
        for neuron in self.neurons:
            output = neuron.activate(inputs)
            outputs.append(output)
        return outputs

class NeuralNetwork:
    """Complete neural network"""
    
    def __init__(self, architecture):
        self.layers = []
        self.architecture = architecture
        self.learning_rate = 0.1
        self.training_history = []
        
        # Create layers
        for i in range(len(architecture) - 1):
            layer = NeuralLayer(architecture[i + 1], architecture[i])
            self.layers.append(layer)
    
    def predict(self, inputs):
        """Make prediction"""
        current_inputs = inputs
        
        for layer in self.layers:
            current_inputs = layer.forward_pass(current_inputs)
        
        return current_inputs
    
    def train(self, training_data, epochs=100):
        """Train the neural network"""
        for epoch in range(epochs):
            total_error = 0
            
            for inputs, targets in training_data:
                # Forward pass
                outputs = self.predict(inputs)
                
                # Calculate error
                error = sum((t - o) ** 2 for t, o in zip(targets, outputs)) / len(targets)
                total_error += error
                
                # Backpropagation (simplified)
                self.backpropagate(inputs, targets, outputs)
            
            avg_error = total_error / len(training_data)
            self.training_history.append(avg_error)
            
            if epoch % 10 == 0:
                slow_print(f"{Fore.CYAN}Epoch {epoch}: Error = {avg_error:.6f}", 0.01)
    
    def backpropagate(self, inputs, targets, outputs):
        """Simplified backpropagation"""
        # Calculate output layer deltas
        output_layer = self.layers[-1]
        for i, neuron in enumerate(output_layer.neurons):
            error = targets[i] - outputs[i]
            neuron.delta = error * outputs[i] * (1 - outputs[i])
        
        # Update weights (simplified)
        for layer in self.layers:
            for neuron in layer.neurons:
                for j in range(len(neuron.weights)):
                    neuron.weights[j] += self.learning_rate * neuron.delta * random.uniform(-0.1, 0.1)
                neuron.bias += self.learning_rate * neuron.delta

class BrainAI:
    """Main BrainAI system"""
    
    def __init__(self):
        self.networks = {}
        self.datasets = {}
        self.current_network = None
        self.load_sample_datasets()
    
    def load_sample_datasets(self):
        """Load sample training datasets"""
        # XOR problem
        self.datasets['XOR'] = [
            ([0, 0], [0]),
            ([0, 1], [1]),
            ([1, 0], [1]),
            ([1, 1], [0])
        ]
        
        # AND problem
        self.datasets['AND'] = [
            ([0, 0], [0]),
            ([0, 1], [0]),
            ([1, 0], [0]),
            ([1, 1], [1])
        ]
        
        # OR problem
        self.datasets['OR'] = [
            ([0, 0], [0]),
            ([0, 1], [1]),
            ([1, 0], [1]),
            ([1, 1], [1])
        ]
        
        # Simple pattern recognition
        self.datasets['Pattern'] = [
            ([1, 0, 1], [1]),
            ([0, 1, 0], [0]),
            ([1, 1, 1], [1]),
            ([0, 0, 0], [0]),
            ([1, 0, 0], [0]),
            ([0, 1, 1], [1])
        ]
    
    def create_network(self, name, architecture):
        """Create a new neural network"""
        network = NeuralNetwork(architecture)
        self.networks[name] = network
        self.current_network = network
        return network
    
    def visualize_network(self, network):
        """Visualize network architecture"""
        lines = []
        lines.append("Network Architecture:")
        lines.append("=" * 40)
        
        for i, layer_size in enumerate(network.architecture):
            if i == 0:
                lines.append(f"Input Layer:  {layer_size} neurons")
            elif i == len(network.architecture) - 1:
                lines.append(f"Output Layer: {layer_size} neurons")
            else:
                lines.append(f"Hidden Layer {i}: {layer_size} neurons")
        
        lines.append("")
        lines.append("Visual Representation:")
        lines.append("-" * 40)
        
        # Create ASCII visualization
        max_layer_size = max(network.architecture)
        
        for layer_idx, layer_size in enumerate(network.architecture):
            layer_line = ""
            padding = (max_layer_size - layer_size) // 2
            
            layer_line += " " * (padding * 3)
            for neuron_idx in range(layer_size):
                layer_line += "●  "
            
            if layer_idx == 0:
                layer_line += "  (Input)"
            elif layer_idx == len(network.architecture) - 1:
                layer_line += "  (Output)"
            else:
                layer_line += f"  (Hidden {layer_idx})"
            
            lines.append(layer_line)
            
            # Add connections
            if layer_idx < len(network.architecture) - 1:
                connection_line = ""
                for _ in range(max_layer_size):
                    connection_line += "|  "
                lines.append(connection_line)
        
        return lines
    
    def test_network(self, network, test_data):
        """Test network accuracy"""
        correct = 0
        total = len(test_data)
        
        results = []
        
        for inputs, expected in test_data:
            prediction = network.predict(inputs)
            predicted_class = 1 if prediction[0] > 0.5 else 0
            expected_class = expected[0]
            
            is_correct = predicted_class == expected_class
            if is_correct:
                correct += 1
            
            results.append({
                'inputs': inputs,
                'expected': expected_class,
                'predicted': predicted_class,
                'confidence': prediction[0],
                'correct': is_correct
            })
        
        accuracy = correct / total if total > 0 else 0
        return accuracy, results

def display_network_visualization(visualization):
    """Display network visualization"""
    slow_print(f"\n{Fore.CYAN}🧠 Neural Network Visualization", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    for line in visualization:
        if "●" in line:
            slow_print(f"{Fore.GREEN}{line}", 0.02)
        elif "Layer" in line or "Architecture" in line:
            slow_print(f"{Fore.CYAN}{line}", 0.02)
        elif "|" in line:
            slow_print(f"{Fore.YELLOW}{line}", 0.01)
        else:
            slow_print(f"{Fore.WHITE}{line}", 0.02)

def display_training_progress(history):
    """Display training progress"""
    slow_print(f"\n{Fore.CYAN}📈 Training Progress", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    # Show error reduction
    if len(history) > 0:
        initial_error = history[0]
        final_error = history[-1]
        improvement = ((initial_error - final_error) / initial_error) * 100
        
        slow_print(f"{Fore.GREEN}Initial Error: {Fore.WHITE}{initial_error:.6f}", 0.02)
        slow_print(f"{Fore.GREEN}Final Error: {Fore.WHITE}{final_error:.6f}", 0.02)
        slow_print(f"{Fore.GREEN}Improvement: {Fore.WHITE}{improvement:.2f}%", 0.02)
        
        # Simple ASCII graph
        slow_print(f"\n{Fore.YELLOW}Error Over Time:", 0.02)
        max_error = max(history)
        for i, error in enumerate(history[::10]):  # Show every 10th epoch
            bar_length = int((error / max_error) * 30)
            bar = "█" * bar_length
            slow_print(f"{Fore.CYAN}Epoch {i*10:3d}: {Fore.RED}{bar:<30} {error:.6f}", 0.01)

def display_test_results(accuracy, results):
    """Display test results"""
    slow_print(f"\n{Fore.CYAN}🎯 Test Results", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Accuracy: {Fore.WHITE}{accuracy:.1%}", 0.02)
    
    slow_print(f"\n{Fore.YELLOW}Detailed Results:", 0.02)
    for i, result in enumerate(results):
        status = "✅" if result['correct'] else "❌"
        inputs_str = str(result['inputs'])
        confidence = result['confidence']
        
        slow_print(f"{status} Input: {inputs_str} → Expected: {result['expected']}, "
                  f"Predicted: {result['predicted']} (Confidence: {confidence:.3f})", 0.02)

def main():
    """Main function"""
    print_header()
    
    brain_ai = BrainAI()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🧠 BrainAI Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Create Neural Network", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Train Network", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Test Network", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Visualize Network", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Make Prediction", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}View Datasets", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Neural Network Info", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}🔨 Create Neural Network", 0.02)
            
            name = input(f"{Fore.YELLOW}Network name: ").strip()
            if not name:
                slow_print(f"{Fore.RED}❌ Please enter a network name", 0.02)
                continue
            
            try:
                architecture_str = input(f"{Fore.YELLOW}Architecture (e.g., 2,3,1): ").strip()
                architecture = [int(x.strip()) for x in architecture_str.split(',')]
                
                if len(architecture) < 2:
                    slow_print(f"{Fore.RED}❌ Network must have at least 2 layers", 0.02)
                    continue
                
                network = brain_ai.create_network(name, architecture)
                slow_print(f"\n{Fore.GREEN}✅ Neural network '{name}' created!", 0.02)
                slow_print(f"{Fore.CYAN}Architecture: {architecture}", 0.02)
                
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid architecture format", 0.02)
        
        elif choice == '2':
            if not brain_ai.current_network:
                slow_print(f"{Fore.RED}❌ Please create a network first", 0.02)
                continue
            
            slow_print(f"\n{Fore.CYAN}🎓 Train Neural Network", 0.02)
            
            # Show available datasets
            slow_print(f"{Fore.YELLOW}Available datasets:", 0.02)
            for i, dataset_name in enumerate(brain_ai.datasets.keys(), 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{dataset_name}", 0.02)
            
            try:
                dataset_choice = int(input(f"{Fore.YELLOW}Select dataset: ").strip()) - 1
                dataset_names = list(brain_ai.datasets.keys())
                
                if 0 <= dataset_choice < len(dataset_names):
                    dataset_name = dataset_names[dataset_choice]
                    training_data = brain_ai.datasets[dataset_name]
                    
                    epochs = int(input(f"{Fore.YELLOW}Training epochs (default 100): ").strip() or "100")
                    
                    slow_print(f"\n{Fore.YELLOW}🔄 Training network on {dataset_name} dataset...", 0.02)
                    brain_ai.current_network.train(training_data, epochs)
                    
                    display_training_progress(brain_ai.current_network.training_history)
                    slow_print(f"\n{Fore.GREEN}✅ Training completed!", 0.02)
                    
                else:
                    slow_print(f"{Fore.RED}❌ Invalid dataset choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '3':
            if not brain_ai.current_network:
                slow_print(f"{Fore.RED}❌ Please create a network first", 0.02)
                continue
            
            slow_print(f"\n{Fore.CYAN}🧪 Test Neural Network", 0.02)
            
            # Show available datasets
            slow_print(f"{Fore.YELLOW}Available datasets:", 0.02)
            for i, dataset_name in enumerate(brain_ai.datasets.keys(), 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{dataset_name}", 0.02)
            
            try:
                dataset_choice = int(input(f"{Fore.YELLOW}Select test dataset: ").strip()) - 1
                dataset_names = list(brain_ai.datasets.keys())
                
                if 0 <= dataset_choice < len(dataset_names):
                    dataset_name = dataset_names[dataset_choice]
                    test_data = brain_ai.datasets[dataset_name]
                    
                    slow_print(f"\n{Fore.YELLOW}🔄 Testing network...", 0.02)
                    accuracy, results = brain_ai.test_network(brain_ai.current_network, test_data)
                    
                    display_test_results(accuracy, results)
                    
                else:
                    slow_print(f"{Fore.RED}❌ Invalid dataset choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '4':
            if not brain_ai.current_network:
                slow_print(f"{Fore.RED}❌ Please create a network first", 0.02)
                continue
            
            visualization = brain_ai.visualize_network(brain_ai.current_network)
            display_network_visualization(visualization)
        
        elif choice == '5':
            if not brain_ai.current_network:
                slow_print(f"{Fore.RED}❌ Please create a network first", 0.02)
                continue
            
            slow_print(f"\n{Fore.CYAN}🔮 Make Prediction", 0.02)
            
            try:
                input_size = brain_ai.current_network.architecture[0]
                inputs_str = input(f"{Fore.YELLOW}Enter {input_size} inputs (comma-separated): ").strip()
                inputs = [float(x.strip()) for x in inputs_str.split(',')]
                
                if len(inputs) != input_size:
                    slow_print(f"{Fore.RED}❌ Expected {input_size} inputs, got {len(inputs)}", 0.02)
                    continue
                
                prediction = brain_ai.current_network.predict(inputs)
                
                slow_print(f"\n{Fore.GREEN}🎯 Prediction Results:", 0.02)
                slow_print(f"{Fore.CYAN}Input: {Fore.WHITE}{inputs}", 0.02)
                slow_print(f"{Fore.CYAN}Output: {Fore.WHITE}{[f'{p:.6f}' for p in prediction]}", 0.02)
                
                if len(prediction) == 1:
                    classification = "Class 1" if prediction[0] > 0.5 else "Class 0"
                    confidence = prediction[0] if prediction[0] > 0.5 else 1 - prediction[0]
                    slow_print(f"{Fore.CYAN}Classification: {Fore.WHITE}{classification} (Confidence: {confidence:.1%})", 0.02)
                
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input format", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}📋 Available Datasets", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            for dataset_name, data in brain_ai.datasets.items():
                slow_print(f"{Fore.GREEN}{dataset_name} Dataset:", 0.02)
                slow_print(f"{Fore.CYAN}  Samples: {len(data)}", 0.02)
                slow_print(f"{Fore.CYAN}  Input size: {len(data[0][0])}", 0.02)
                slow_print(f"{Fore.CYAN}  Output size: {len(data[0][1])}", 0.02)
                
                slow_print(f"{Fore.YELLOW}  Sample data:", 0.02)
                for i, (inputs, outputs) in enumerate(data[:3]):
                    slow_print(f"    {inputs} → {outputs}", 0.02)
                if len(data) > 3:
                    slow_print(f"    ... and {len(data) - 3} more samples", 0.02)
                print()
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}📖 Neural Network Information", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            info = [
                "🧠 Neural Networks are computational models inspired by biological brains",
                "⚡ They consist of interconnected nodes (neurons) organized in layers",
                "📊 Training involves adjusting weights to minimize prediction errors",
                "🎯 Common applications: pattern recognition, classification, prediction",
                "🔄 Backpropagation is used to update weights during training",
                "📈 Learning rate controls how fast the network learns",
                "🎲 Activation functions introduce non-linearity",
                "💡 More layers can learn more complex patterns"
            ]
            
            for line in info:
                slow_print(f"{Fore.WHITE}{line}", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using BrainAI! Keep learning!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
