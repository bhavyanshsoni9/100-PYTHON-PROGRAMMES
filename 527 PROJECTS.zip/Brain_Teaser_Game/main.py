import random
import time
import os
from colorama import Fore, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class BrainTeaser:
    def __init__(self):
        self.score = 0
        self.total_questions = 0
        self.riddles = [
            {
                "question": "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?",
                "answer": "echo",
                "hint": "You can hear me in the mountains"
            },
            {
                "question": "What has keys, but no locks; space, but no room; and you can enter, but not go in?",
                "answer": "keyboard",
                "hint": "You use me to type"
            },
            {
                "question": "The more you take, the more you leave behind. What am I?",
                "answer": "footsteps",
                "hint": "You make these when you walk"
            }
        ]
        self.word_puzzles = [
            {
                "question": "Rearrange 'TAPEL' to make a common word",
                "answer": "plate",
                "hint": "You eat from this"
            },
            {
                "question": "Rearrange 'HEART' to make another word",
                "answer": "earth",
                "hint": "The planet we live on"
            },
            {
                "question": "What 4-letter word can be written forward, backward or upside down, and can still be read from left to right?",
                "answer": "noon",
                "hint": "Middle of the day"
            }
        ]
        self.math_puzzles = [
            {
                "question": "If 2 + 3 = 10, 3 + 7 = 27, 4 + 5 = 32, then 1 + 6 = ?",
                "answer": "21",
                "hint": "Look for the pattern: First number × Second number + First number"
            },
            {
                "question": "What number should come next: 2, 6, 12, 20, ?",
                "answer": "30",
                "hint": "Add 4, then 6, then 8..."
            },
            {
                "question": "Complete the sequence: 1, 4, 9, 16, 25, ?",
                "answer": "36",
                "hint": "These are square numbers"
            }
        ]

    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔════════════════════════════════════╗
║      Welcome to Brain Teaser       ║
║        By: Bhavyansh Soni         ║
╚════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def ask_question(self, puzzle, category):
        """Ask a question and handle user input"""
        self.total_questions += 1
        slow_print(f"\n{Fore.YELLOW}Category: {category}{Style.RESET_ALL}")
        slow_print(f"{Fore.WHITE}{puzzle['question']}{Style.RESET_ALL}")
        
        attempts = 3
        while attempts > 0:
            answer = input(f"\n{Fore.GREEN}Your answer (attempts left: {attempts}): {Style.RESET_ALL}").lower().strip()
            
            if answer == puzzle['answer']:
                slow_print(f"{Fore.GREEN}Correct! Well done!{Style.RESET_ALL}")
                self.score += attempts  # More points for fewer attempts
                return True
            elif answer == 'hint':
                slow_print(f"{Fore.YELLOW}Hint: {puzzle['hint']}{Style.RESET_ALL}")
                attempts -= 1
            else:
                attempts -= 1
                if attempts > 0:
                    slow_print(f"{Fore.RED}Wrong! Try again! (Type 'hint' for a clue){Style.RESET_ALL}")
                else:
                    slow_print(f"{Fore.RED}Sorry! The correct answer was: {puzzle['answer']}{Style.RESET_ALL}")
        return False

    def play_round(self, puzzle_list, category):
        """Play a round of puzzles from a specific category"""
        puzzle = random.choice(puzzle_list)
        return self.ask_question(puzzle, category)

    def show_score(self):
        """Display current score"""
        if self.total_questions > 0:
            percentage = (self.score / (self.total_questions * 3)) * 100  # Max 3 points per question
            slow_print(f"\n{Fore.CYAN}Your current score: {self.score} points")
            slow_print(f"Success rate: {percentage:.1f}%{Style.RESET_ALL}")
        else:
            slow_print(f"\n{Fore.CYAN}No questions attempted yet!{Style.RESET_ALL}")

    def main_menu(self):
        """Main game loop"""
        while True:
            clear_screen()
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Choose a category:{Style.RESET_ALL}")
            slow_print("1. Riddles")
            slow_print("2. Word Puzzles")
            slow_print("3. Math Puzzles")
            slow_print("4. View Score")
            slow_print("5. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-5): {Style.RESET_ALL}")
            
            if choice == '1':
                self.play_round(self.riddles, "Riddles")
            elif choice == '2':
                self.play_round(self.word_puzzles, "Word Puzzles")
            elif choice == '3':
                self.play_round(self.math_puzzles, "Math Puzzles")
            elif choice == '4':
                self.show_score()
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
            elif choice == '5':
                slow_print(f"\n{Fore.YELLOW}Thanks for playing Brain Teaser!{Style.RESET_ALL}")
                break
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
                time.sleep(1)

if __name__ == "__main__":
    try:
        game = BrainTeaser()
        game.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Game terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}") 