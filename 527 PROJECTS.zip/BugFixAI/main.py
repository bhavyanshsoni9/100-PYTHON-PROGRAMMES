#!/usr/bin/env python3
"""
BugFixAI - AI-Powered Bug Detection and Fixing Tool
Created by BHAVYANSH SONI
A retro-style AI bug detection and fixing assistant with colored output
"""

import os
import sys
import time
import re
import ast
from datetime import datetime
from colorama import init, Fore, Back, Style
import random

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.GREEN}{'='*60}
{Fore.CYAN}    ██████╗ ██╗   ██╗ ██████╗ ███████╗██╗██╗  ██╗ █████╗ ██╗
{Fore.CYAN}    ██╔══██╗██║   ██║██╔════╝ ██╔════╝██║╚██╗██╔╝██╔══██╗██║
{Fore.CYAN}    ██████╔╝██║   ██║██║  ███╗█████╗  ██║ ╚███╔╝ ███████║██║
{Fore.CYAN}    ██╔══██╗██║   ██║██║   ██║██╔══╝  ██║ ██╔██╗ ██╔══██║██║
{Fore.CYAN}    ██████╔╝╚██████╔╝╚██████╔╝██║     ██║██╔╝ ██╗██║  ██║██║
{Fore.CYAN}    ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝
{Fore.GREEN}{'='*60}
{Fore.YELLOW}    🐛 AI-Powered Bug Detection & Fixing Tool
{Fore.MAGENTA}    🤖 Created by: BHAVYANSH SONI
{Fore.GREEN}{'='*60}
"""
    print(header)

class BugPattern:
    """Bug pattern detection class"""
    
    def __init__(self, name, pattern, severity, description, fix_suggestion):
        self.name = name
        self.pattern = pattern
        self.severity = severity
        self.description = description
        self.fix_suggestion = fix_suggestion

class BugFixAI:
    """AI bug detection and fixing system"""
    
    def __init__(self):
        self.bug_patterns = self.load_bug_patterns()
        self.analysis_history = []
        self.fix_templates = self.load_fix_templates()
        self.code_quality_rules = self.load_quality_rules()
        
    def load_bug_patterns(self):
        """Load common bug patterns"""
        patterns = [
            BugPattern(
                "Infinite Loop",
                r'while\s+True\s*:|for\s+.*\s+in\s+.*:\s*(?:\n\s*)*(?!.*break)',
                "High",
                "Potential infinite loop without break condition",
                "Add a break condition or use a counter"
            ),
            BugPattern(
                "SQL Injection",
                r'execute\s*\(\s*["\'].*%s.*["\']',
                "Critical",
                "Potential SQL injection vulnerability",
                "Use parameterized queries instead of string formatting"
            ),
            BugPattern(
                "Unused Variables",
                r'(\w+)\s*=\s*.*(?:\n(?!.*\1).*)*$',
                "Low",
                "Variable assigned but never used",
                "Remove unused variable or use it in the code"
            ),
            BugPattern(
                "Missing Exception Handling",
                r'open\s*\([^)]*\)(?!\s*.*except)',
                "Medium",
                "File operation without exception handling",
                "Wrap in try-except block"
            ),
            BugPattern(
                "Hard-coded Credentials",
                r'(password|secret|key|token)\s*=\s*["\'][^"\']+["\']',
                "Critical",
                "Hard-coded credentials in source code",
                "Use environment variables or configuration files"
            ),
            BugPattern(
                "Division by Zero",
                r'\/\s*[a-zA-Z_]\w*(?!\s*(?:!=|==|\+|\-)\s*0)',
                "High",
                "Potential division by zero",
                "Check if denominator is zero before division"
            ),
            BugPattern(
                "Memory Leak",
                r'while\s+.*:\s*(?:\n\s*)*.*append\s*\(',
                "Medium",
                "Potential memory leak in loop",
                "Consider using generators or clearing collections"
            ),
            BugPattern(
                "Insecure Random",
                r'random\.random\(\)|random\.choice\(',
                "Medium",
                "Using non-cryptographic random for security purposes",
                "Use secrets module for cryptographic randomness"
            )
        ]
        return patterns
    
    def load_fix_templates(self):
        """Load code fix templates"""
        return {
            "try_except": """try:
    {original_code}
except Exception as e:
    print(f"Error: {{e}}")
    # Handle error appropriately""",
            
            "parameter_check": """if {parameter} is None or {parameter} == 0:
    raise ValueError("Invalid parameter value")
{original_code}""",
            
            "safe_division": """if {denominator} != 0:
    result = {numerator} / {denominator}
else:
    result = 0  # or handle division by zero appropriately""",
            
            "environment_var": """import os
{variable_name} = os.getenv('{env_var_name}', 'default_value')"""
        }
    
    def load_quality_rules(self):
        """Load code quality rules"""
        return {
            "line_length": 80,
            "function_complexity": 10,
            "class_complexity": 20,
            "max_parameters": 5,
            "max_nesting": 4
        }
    
    def analyze_code(self, code):
        """Analyze code for bugs and issues"""
        issues = []
        lines = code.split('\n')
        
        # Pattern-based detection
        for pattern in self.bug_patterns:
            matches = re.finditer(pattern.pattern, code, re.MULTILINE | re.IGNORECASE)
            for match in matches:
                line_num = code[:match.start()].count('\n') + 1
                issues.append({
                    'type': pattern.name,
                    'severity': pattern.severity,
                    'line': line_num,
                    'description': pattern.description,
                    'suggestion': pattern.fix_suggestion,
                    'code_snippet': lines[line_num - 1].strip() if line_num <= len(lines) else ""
                })
        
        # AST-based analysis
        try:
            ast_issues = self.analyze_ast(code)
            issues.extend(ast_issues)
        except SyntaxError as e:
            issues.append({
                'type': 'Syntax Error',
                'severity': 'Critical',
                'line': e.lineno or 0,
                'description': f"Syntax error: {e.msg}",
                'suggestion': "Fix syntax error",
                'code_snippet': ""
            })
        
        # Code quality analysis
        quality_issues = self.analyze_code_quality(code)
        issues.extend(quality_issues)
        
        return issues
    
    def analyze_ast(self, code):
        """Analyze code using AST"""
        issues = []
        
        try:
            tree = ast.parse(code)
            
            # Check for unreachable code
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # Check for functions with too many parameters
                    if len(node.args.args) > self.code_quality_rules['max_parameters']:
                        issues.append({
                            'type': 'Too Many Parameters',
                            'severity': 'Medium',
                            'line': node.lineno,
                            'description': f"Function has {len(node.args.args)} parameters (max recommended: {self.code_quality_rules['max_parameters']})",
                            'suggestion': "Consider using a configuration object or breaking down the function",
                            'code_snippet': f"def {node.name}(...)"
                        })
                
                # Check for nested complexity
                if isinstance(node, (ast.For, ast.While, ast.If)):
                    nesting_level = self.calculate_nesting_level(node, tree)
                    if nesting_level > self.code_quality_rules['max_nesting']:
                        issues.append({
                            'type': 'Deep Nesting',
                            'severity': 'Medium',
                            'line': node.lineno,
                            'description': f"Nesting level {nesting_level} exceeds recommended maximum",
                            'suggestion': "Extract nested logic into separate functions",
                            'code_snippet': ""
                        })
        
        except Exception:
            pass
        
        return issues
    
    def calculate_nesting_level(self, target_node, tree):
        """Calculate nesting level of a node"""
        level = 0
        for node in ast.walk(tree):
            if isinstance(node, (ast.For, ast.While, ast.If, ast.FunctionDef, ast.ClassDef)):
                for child in ast.walk(node):
                    if child is target_node:
                        level += 1
        return level
    
    def analyze_code_quality(self, code):
        """Analyze code quality metrics"""
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Check line length
            if len(line) > self.code_quality_rules['line_length']:
                issues.append({
                    'type': 'Long Line',
                    'severity': 'Low',
                    'line': i,
                    'description': f"Line exceeds {self.code_quality_rules['line_length']} characters",
                    'suggestion': "Break long line into multiple lines",
                    'code_snippet': line.strip()
                })
            
            # Check for TODO/FIXME comments
            if re.search(r'#\s*(TODO|FIXME|HACK)', line, re.IGNORECASE):
                issues.append({
                    'type': 'Technical Debt',
                    'severity': 'Low',
                    'line': i,
                    'description': "Code contains TODO/FIXME comment",
                    'suggestion': "Address the technical debt",
                    'code_snippet': line.strip()
                })
        
        return issues
    
    def suggest_fix(self, issue, code):
        """Suggest automatic fix for an issue"""
        fixes = []
        
        if issue['type'] == 'Missing Exception Handling':
            original_line = issue['code_snippet']
            fixed_code = self.fix_templates['try_except'].format(original_code=original_line)
            fixes.append({
                'description': 'Add exception handling',
                'original': original_line,
                'fixed': fixed_code
            })
        
        elif issue['type'] == 'Hard-coded Credentials':
            # Extract variable name and value
            match = re.search(r'(\w+)\s*=\s*["\']([^"\']+)["\']', issue['code_snippet'])
            if match:
                var_name, value = match.groups()
                env_var_name = var_name.upper()
                fixed_code = self.fix_templates['environment_var'].format(
                    variable_name=var_name,
                    env_var_name=env_var_name
                )
                fixes.append({
                    'description': 'Use environment variable',
                    'original': issue['code_snippet'],
                    'fixed': fixed_code
                })
        
        elif issue['type'] == 'Division by Zero':
            # Extract division operation
            match = re.search(r'(\w+)\s*/\s*(\w+)', issue['code_snippet'])
            if match:
                numerator, denominator = match.groups()
                fixed_code = self.fix_templates['safe_division'].format(
                    numerator=numerator,
                    denominator=denominator
                )
                fixes.append({
                    'description': 'Add zero division check',
                    'original': issue['code_snippet'],
                    'fixed': fixed_code
                })
        
        return fixes
    
    def calculate_code_score(self, issues):
        """Calculate overall code quality score"""
        severity_weights = {
            'Critical': 10,
            'High': 5,
            'Medium': 2,
            'Low': 1
        }
        
        total_penalty = sum(severity_weights.get(issue['severity'], 1) for issue in issues)
        max_score = 100
        score = max(0, max_score - total_penalty)
        
        return score
    
    def generate_report(self, code, issues):
        """Generate comprehensive bug report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_issues': len(issues),
            'severity_breakdown': {},
            'code_score': self.calculate_code_score(issues),
            'issues': issues,
            'recommendations': self.generate_recommendations(issues)
        }
        
        # Count issues by severity
        for issue in issues:
            severity = issue['severity']
            report['severity_breakdown'][severity] = report['severity_breakdown'].get(severity, 0) + 1
        
        return report

    def generate_recommendations(self, issues):
        """Generate high-level recommendations"""
        recommendations = []
        
        critical_count = sum(1 for issue in issues if issue['severity'] == 'Critical')
        high_count = sum(1 for issue in issues if issue['severity'] == 'High')
        
        if critical_count > 0:
            recommendations.append("🚨 Address critical security vulnerabilities immediately")
        
        if high_count > 0:
            recommendations.append("⚠️ Fix high-severity issues to prevent potential failures")
        
        # Pattern-based recommendations
        issue_types = [issue['type'] for issue in issues]
        
        if 'Missing Exception Handling' in issue_types:
            recommendations.append("🛡️ Implement comprehensive error handling")
        
        if 'Long Line' in issue_types:
            recommendations.append("📏 Follow PEP 8 line length guidelines")
        
        if 'Too Many Parameters' in issue_types:
            recommendations.append("🔧 Refactor functions with too many parameters")
        
        return recommendations

def display_analysis_results(report):
    """Display code analysis results"""
    slow_print(f"\n{Fore.CYAN}🔍 Code Analysis Report", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Code Quality Score: {Fore.WHITE}{report['code_score']}/100", 0.02)
    slow_print(f"{Fore.GREEN}Total Issues: {Fore.WHITE}{report['total_issues']}", 0.02)
    
    # Severity breakdown
    slow_print(f"\n{Fore.YELLOW}Issues by Severity:", 0.02)
    severity_colors = {
        'Critical': Fore.MAGENTA,
        'High': Fore.RED,
        'Medium': Fore.YELLOW,
        'Low': Fore.GREEN
    }
    
    for severity, count in report['severity_breakdown'].items():
        color = severity_colors.get(severity, Fore.WHITE)
        slow_print(f"{color}{severity}: {count} issues", 0.02)
    
    # Display issues
    if report['issues']:
        slow_print(f"\n{Fore.YELLOW}Detailed Issues:", 0.02)
        slow_print(f"{Fore.CYAN}{'─'*60}", 0.01)
        
        for i, issue in enumerate(report['issues'][:10], 1):  # Show first 10
            color = severity_colors.get(issue['severity'], Fore.WHITE)
            slow_print(f"\n{color}{i}. {issue['type']} (Line {issue['line']})", 0.02)
            slow_print(f"   {Fore.WHITE}Description: {issue['description']}", 0.02)
            slow_print(f"   {Fore.CYAN}Suggestion: {issue['suggestion']}", 0.02)
            if issue['code_snippet']:
                slow_print(f"   {Fore.YELLOW}Code: {issue['code_snippet']}", 0.02)
        
        if len(report['issues']) > 10:
            slow_print(f"\n{Fore.YELLOW}... and {len(report['issues']) - 10} more issues", 0.02)
    
    # Recommendations
    if report['recommendations']:
        slow_print(f"\n{Fore.YELLOW}🎯 Recommendations:", 0.02)
        for rec in report['recommendations']:
            slow_print(f"   {Fore.GREEN}{rec}", 0.02)

def display_fix_suggestions(fixes):
    """Display automatic fix suggestions"""
    if not fixes:
        slow_print(f"{Fore.YELLOW}No automatic fixes available for this issue", 0.02)
        return
    
    slow_print(f"\n{Fore.CYAN}🔧 Automatic Fix Suggestions:", 0.02)
    slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
    
    for i, fix in enumerate(fixes, 1):
        slow_print(f"\n{Fore.GREEN}{i}. {fix['description']}", 0.02)
        slow_print(f"{Fore.RED}   Original:", 0.02)
        slow_print(f"   {fix['original']}", 0.02)
        slow_print(f"{Fore.GREEN}   Fixed:", 0.02)
        for line in fix['fixed'].split('\n'):
            slow_print(f"   {line}", 0.02)

def main():
    """Main function"""
    print_header()
    
    bug_fix_ai = BugFixAI()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🐛 BugFixAI Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Analyze Code", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Load Code from File", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Quick Security Scan", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Code Quality Check", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Generate Fix", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Bug Patterns Guide", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-7): ").strip()
        
        if choice == '1':
            slow_print(f"\n{Fore.CYAN}📝 Enter Code to Analyze", 0.02)
            slow_print(f"{Fore.YELLOW}(Enter 'END' on a new line to finish)", 0.02)
            
            code_lines = []
            while True:
                line = input()
                if line.strip() == 'END':
                    break
                code_lines.append(line)
            
            code = '\n'.join(code_lines)
            
            if code.strip():
                slow_print(f"\n{Fore.YELLOW}🔄 Analyzing code...", 0.02)
                time.sleep(2)
                
                issues = bug_fix_ai.analyze_code(code)
                report = bug_fix_ai.generate_report(code, issues)
                
                display_analysis_results(report)
            else:
                slow_print(f"{Fore.RED}❌ No code provided", 0.02)
        
        elif choice == '2':
            file_path = input(f"{Fore.YELLOW}Enter file path: ").strip()
            
            try:
                with open(file_path, 'r') as f:
                    code = f.read()
                
                slow_print(f"\n{Fore.YELLOW}🔄 Analyzing file: {file_path}", 0.02)
                time.sleep(2)
                
                issues = bug_fix_ai.analyze_code(code)
                report = bug_fix_ai.generate_report(code, issues)
                
                display_analysis_results(report)
                
            except FileNotFoundError:
                slow_print(f"{Fore.RED}❌ File not found", 0.02)
            except Exception as e:
                slow_print(f"{Fore.RED}❌ Error reading file: {str(e)}", 0.02)
        
        elif choice == '3':
            slow_print(f"\n{Fore.CYAN}🔒 Quick Security Scan", 0.02)
            
            # Security-focused patterns
            security_patterns = [p for p in bug_fix_ai.bug_patterns 
                               if p.severity in ['Critical', 'High']]
            
            slow_print(f"{Fore.YELLOW}Checking for {len(security_patterns)} security patterns...", 0.02)
            
            for pattern in security_patterns:
                slow_print(f"{Fore.CYAN}• {pattern.name}: {pattern.description}", 0.02)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}📊 Code Quality Guidelines", 0.02)
            slow_print(f"{Fore.YELLOW}{'─'*60}", 0.01)
            
            for rule, value in bug_fix_ai.code_quality_rules.items():
                slow_print(f"{Fore.GREEN}{rule.replace('_', ' ').title()}: {Fore.WHITE}{value}", 0.02)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}🔧 Generate Fix", 0.02)
            
            # Show issue types that can be auto-fixed
            fixable_types = ['Missing Exception Handling', 'Hard-coded Credentials', 'Division by Zero']
            
            slow_print(f"{Fore.YELLOW}Fixable issue types:", 0.02)
            for i, issue_type in enumerate(fixable_types, 1):
                slow_print(f"{Fore.GREEN}{i}. {issue_type}", 0.02)
            
            try:
                choice_idx = int(input(f"{Fore.YELLOW}Select issue type: ").strip()) - 1
                if 0 <= choice_idx < len(fixable_types):
                    issue_type = fixable_types[choice_idx]
                    
                    # Create sample issue for demonstration
                    sample_issue = {
                        'type': issue_type,
                        'code_snippet': 'file = open("data.txt")' if issue_type == 'Missing Exception Handling' else 'password = "secret123"'
                    }
                    
                    fixes = bug_fix_ai.suggest_fix(sample_issue, "")
                    display_fix_suggestions(fixes)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}📖 Bug Patterns Guide", 0.02)
            slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
            
            for pattern in bug_fix_ai.bug_patterns:
                severity_colors = {
                    'Critical': Fore.MAGENTA,
                    'High': Fore.RED,
                    'Medium': Fore.YELLOW,
                    'Low': Fore.GREEN
                }
                
                color = severity_colors.get(pattern.severity, Fore.WHITE)
                slow_print(f"\n{color}{pattern.name} ({pattern.severity})", 0.02)
                slow_print(f"{Fore.WHITE}Description: {pattern.description}", 0.02)
                slow_print(f"{Fore.CYAN}Fix: {pattern.fix_suggestion}", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using BugFixAI! Keep coding bug-free!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '7':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
