#!/usr/bin/env python3
"""
ByteMon - System Resource Monitor
Created by BHAVYANSH SONI
A retro-style terminal-based system monitor with colored output
"""

import os
import sys
import time
import psutil
from colorama import init, Fore, Back, Style
import platform
from datetime import datetime

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.GREEN}{'='*60}
{Fore.CYAN}    ██████╗ ██╗   ██╗████████╗███████╗███╗   ███╗ ██████╗ ███╗   ██╗
{Fore.CYAN}    ██╔══██╗╚██╗ ██╔╝╚══██╔══╝██╔════╝████╗ ████║██╔═══██╗████╗  ██║
{Fore.CYAN}    ██████╔╝ ╚████╔╝    ██║   █████╗  ██╔████╔██║██║   ██║██╔██╗ ██║
{Fore.CYAN}    ██╔══██╗  ╚██╔╝     ██║   ██╔══╝  ██║╚██╔╝██║██║   ██║██║╚██╗██║
{Fore.CYAN}    ██████╔╝   ██║      ██║   ███████╗██║ ╚═╝ ██║╚██████╔╝██║ ╚████║
{Fore.CYAN}    ╚═════╝    ╚═╝      ╚═╝   ╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝
{Fore.GREEN}{'='*60}
{Fore.YELLOW}    🖥️  System Resource Monitor - Real-time Stats
{Fore.MAGENTA}    📊 Created by: BHAVYANSH SONI
{Fore.GREEN}{'='*60}
"""
    print(header)

def get_system_info():
    """Get basic system information"""
    info = {
        'system': platform.system(),
        'node': platform.node(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'boot_time': datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
    }
    return info

def get_cpu_info():
    """Get CPU information and usage"""
    cpu_percent = psutil.cpu_percent(interval=1)
    cpu_count = psutil.cpu_count()
    cpu_freq = psutil.cpu_freq()
    
    return {
        'usage': cpu_percent,
        'count': cpu_count,
        'freq': cpu_freq.current if cpu_freq else 0
    }

def get_memory_info():
    """Get memory information"""
    memory = psutil.virtual_memory()
    swap = psutil.swap_memory()
    
    return {
        'total': memory.total,
        'available': memory.available,
        'used': memory.used,
        'percent': memory.percent,
        'swap_total': swap.total,
        'swap_used': swap.used,
        'swap_percent': swap.percent
    }

def get_disk_info():
    """Get disk information"""
    disk = psutil.disk_usage('/')
    return {
        'total': disk.total,
        'used': disk.used,
        'free': disk.free,
        'percent': (disk.used / disk.total) * 100
    }

def format_bytes(bytes_value):
    """Format bytes to human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_value < 1024.0:
            return f"{bytes_value:.2f} {unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.2f} PB"

def create_progress_bar(percent, width=20):
    """Create a colored progress bar"""
    filled = int(width * percent / 100)
    bar = '█' * filled + '░' * (width - filled)
    
    if percent < 50:
        color = Fore.GREEN
    elif percent < 80:
        color = Fore.YELLOW
    else:
        color = Fore.RED
    
    return f"{color}{bar}{Style.RESET_ALL} {percent:.1f}%"

def display_system_stats():
    """Display real-time system statistics"""
    while True:
        print_header()
        
        # System Info
        sys_info = get_system_info()
        slow_print(f"{Fore.CYAN}🖥️  System Information:", 0.01)
        slow_print(f"   {Fore.GREEN}System: {Fore.WHITE}{sys_info['system']} {sys_info['release']}", 0.01)
        slow_print(f"   {Fore.GREEN}Node: {Fore.WHITE}{sys_info['node']}", 0.01)
        slow_print(f"   {Fore.GREEN}Boot Time: {Fore.WHITE}{sys_info['boot_time']}", 0.01)
        
        print(f"\n{Fore.YELLOW}{'─' * 60}")
        
        # CPU Info
        cpu_info = get_cpu_info()
        slow_print(f"{Fore.CYAN}🔥 CPU Information:", 0.01)
        slow_print(f"   {Fore.GREEN}Cores: {Fore.WHITE}{cpu_info['count']}", 0.01)
        slow_print(f"   {Fore.GREEN}Frequency: {Fore.WHITE}{cpu_info['freq']:.2f} MHz", 0.01)
        slow_print(f"   {Fore.GREEN}Usage: {create_progress_bar(cpu_info['usage'])}", 0.01)
        
        print(f"\n{Fore.YELLOW}{'─' * 60}")
        
        # Memory Info
        mem_info = get_memory_info()
        slow_print(f"{Fore.CYAN}🧠 Memory Information:", 0.01)
        slow_print(f"   {Fore.GREEN}Total: {Fore.WHITE}{format_bytes(mem_info['total'])}", 0.01)
        slow_print(f"   {Fore.GREEN}Used: {Fore.WHITE}{format_bytes(mem_info['used'])}", 0.01)
        slow_print(f"   {Fore.GREEN}Available: {Fore.WHITE}{format_bytes(mem_info['available'])}", 0.01)
        slow_print(f"   {Fore.GREEN}Usage: {create_progress_bar(mem_info['percent'])}", 0.01)
        
        print(f"\n{Fore.YELLOW}{'─' * 60}")
        
        # Disk Info
        disk_info = get_disk_info()
        slow_print(f"{Fore.CYAN}💾 Disk Information:", 0.01)
        slow_print(f"   {Fore.GREEN}Total: {Fore.WHITE}{format_bytes(disk_info['total'])}", 0.01)
        slow_print(f"   {Fore.GREEN}Used: {Fore.WHITE}{format_bytes(disk_info['used'])}", 0.01)
        slow_print(f"   {Fore.GREEN}Free: {Fore.WHITE}{format_bytes(disk_info['free'])}", 0.01)
        slow_print(f"   {Fore.GREEN}Usage: {create_progress_bar(disk_info['percent'])}", 0.01)
        
        print(f"\n{Fore.GREEN}{'=' * 60}")
        slow_print(f"{Fore.MAGENTA}📊 Press Ctrl+C to exit | Updating every 5 seconds...", 0.01)
        
        try:
            time.sleep(5)
        except KeyboardInterrupt:
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using ByteMon! Goodbye!", 0.02)
            sys.exit(0)

def main():
    """Main function"""
    try:
        display_system_stats()
    except KeyboardInterrupt:
        slow_print(f"\n{Fore.YELLOW}👋 Thanks for using ByteMon! Goodbye!", 0.02)
        sys.exit(0)
    except Exception as e:
        slow_print(f"{Fore.RED}❌ Error: {str(e)}", 0.02)
        sys.exit(1)

if __name__ == "__main__":
    main()
