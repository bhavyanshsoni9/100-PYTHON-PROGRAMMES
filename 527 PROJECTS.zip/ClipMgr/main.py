#!/usr/bin/env python3
"""
ClipMgr - Advanced Clipboard Manager
Created by BHAVYANSH SONI
A retro-style clipboard manager with history and advanced features
"""

import os
import sys
import time
import json
import hashlib
from datetime import datetime
from colorama import init, Fore, Back, Style
import subprocess
import tempfile
import base64

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.GREEN}{'='*60}
{Fore.CYAN}     ██████╗██╗     ██╗██████╗ ███╗   ███╗ ██████╗ ██████╗ 
{Fore.CYAN}    ██╔════╝██║     ██║██╔══██╗████╗ ████║██╔════╝ ██╔══██╗
{Fore.CYAN}    ██║     ██║     ██║██████╔╝██╔████╔██║██║  ███╗██████╔╝
{Fore.CYAN}    ██║     ██║     ██║██╔═══╝ ██║╚██╔╝██║██║   ██║██╔══██╗
{Fore.CYAN}    ╚██████╗███████╗██║██║     ██║ ╚═╝ ██║╚██████╔╝██║  ██║
{Fore.CYAN}     ╚═════╝╚══════╝╚═╝╚═╝     ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝
{Fore.GREEN}{'='*60}
{Fore.YELLOW}    📋 Advanced Clipboard Manager - Never Lose Your Clips
{Fore.MAGENTA}    🔄 Created by: BHAVYANSH SONI
{Fore.GREEN}{'='*60}
"""
    print(header)

class ClipboardItem:
    """Individual clipboard item"""
    
    def __init__(self, content, content_type="text"):
        self.content = content
        self.content_type = content_type
        self.timestamp = datetime.now()
        self.hash = hashlib.md5(str(content).encode()).hexdigest()[:8]
        self.size = len(str(content))
        self.favorite = False
        self.tags = []
        self.access_count = 0

class ClipboardManager:
    """Advanced clipboard manager"""
    
    def __init__(self):
        self.history = []
        self.favorites = []
        self.max_history = 100
        self.data_file = "clipboard_data.json"
        self.current_clipboard = ""
        self.load_history()
        
    def get_clipboard_content(self):
        """Get current clipboard content"""
        try:
            if os.name == 'nt':
                # Windows
                import subprocess
                result = subprocess.run(['powershell', '-command', 'Get-Clipboard'], 
                                      capture_output=True, text=True)
                return result.stdout.strip()
            else:
                # Linux/Mac
                try:
                    # Try xclip first
                    result = subprocess.run(['xclip', '-selection', 'clipboard', '-o'], 
                                          capture_output=True, text=True)
                    return result.stdout
                except FileNotFoundError:
                    # Try pbpaste (macOS)
                    try:
                        result = subprocess.run(['pbpaste'], capture_output=True, text=True)
                        return result.stdout
                    except FileNotFoundError:
                        return ""
        except Exception:
            return ""
    
    def set_clipboard_content(self, content):
        """Set clipboard content"""
        try:
            if os.name == 'nt':
                # Windows
                subprocess.run(['powershell', '-command', f'Set-Clipboard -Value "{content}"'])
            else:
                # Linux/Mac
                try:
                    # Try xclip first
                    proc = subprocess.Popen(['xclip', '-selection', 'clipboard'], 
                                          stdin=subprocess.PIPE, text=True)
                    proc.communicate(input=content)
                except FileNotFoundError:
                    # Try pbcopy (macOS)
                    try:
                        proc = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE, text=True)
                        proc.communicate(input=content)
                    except FileNotFoundError:
                        pass
            return True
        except Exception:
            return False
    
    def add_to_history(self, content, content_type="text"):
        """Add item to clipboard history"""
        if not content or content.strip() == "":
            return False
        
        # Check if already exists
        for item in self.history:
            if item.content == content:
                item.access_count += 1
                item.timestamp = datetime.now()
                return True
        
        # Add new item
        item = ClipboardItem(content, content_type)
        self.history.insert(0, item)
        
        # Maintain max history
        if len(self.history) > self.max_history:
            self.history = self.history[:self.max_history]
        
        self.save_history()
        return True
    
    def get_history_stats(self):
        """Get clipboard history statistics"""
        if not self.history:
            return {}
        
        total_items = len(self.history)
        total_size = sum(item.size for item in self.history)
        avg_size = total_size / total_items
        
        # Content type distribution
        type_counts = {}
        for item in self.history:
            type_counts[item.content_type] = type_counts.get(item.content_type, 0) + 1
        
        # Most accessed items
        most_accessed = sorted(self.history, key=lambda x: x.access_count, reverse=True)[:5]
        
        return {
            'total_items': total_items,
            'total_size': total_size,
            'avg_size': avg_size,
            'type_counts': type_counts,
            'most_accessed': most_accessed,
            'favorites_count': len(self.favorites)
        }
    
    def search_history(self, query):
        """Search through clipboard history"""
        results = []
        query_lower = query.lower()
        
        for item in self.history:
            if query_lower in str(item.content).lower():
                results.append(item)
        
        return results
    
    def save_history(self):
        """Save clipboard history to file"""
        try:
            data = []
            for item in self.history:
                data.append({
                    'content': item.content,
                    'content_type': item.content_type,
                    'timestamp': item.timestamp.isoformat(),
                    'hash': item.hash,
                    'size': item.size,
                    'favorite': item.favorite,
                    'tags': item.tags,
                    'access_count': item.access_count
                })
            
            with open(self.data_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            slow_print(f"{Fore.RED}❌ Error saving history: {str(e)}", 0.02)
    
    def load_history(self):
        """Load clipboard history from file"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                
                for item_data in data:
                    item = ClipboardItem(item_data['content'], item_data.get('content_type', 'text'))
                    item.timestamp = datetime.fromisoformat(item_data['timestamp'])
                    item.hash = item_data.get('hash', '')
                    item.size = item_data.get('size', 0)
                    item.favorite = item_data.get('favorite', False)
                    item.tags = item_data.get('tags', [])
                    item.access_count = item_data.get('access_count', 0)
                    
                    self.history.append(item)
                    
                    if item.favorite:
                        self.favorites.append(item)
        except Exception as e:
            slow_print(f"{Fore.YELLOW}⚠️ Could not load history: {str(e)}", 0.02)

def display_clipboard_history(manager, limit=20):
    """Display clipboard history"""
    slow_print(f"\n{Fore.CYAN}📋 Clipboard History", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    if not manager.history:
        slow_print(f"{Fore.YELLOW}📋 No clipboard history available", 0.02)
        return
    
    for i, item in enumerate(manager.history[:limit], 1):
        # Truncate long content
        preview = str(item.content)[:50]
        if len(str(item.content)) > 50:
            preview += "..."
        
        # Format timestamp
        time_str = item.timestamp.strftime("%H:%M:%S")
        
        # Favorite indicator
        fav_icon = "⭐" if item.favorite else "  "
        
        # Access count indicator
        access_info = f"({item.access_count}x)" if item.access_count > 0 else ""
        
        slow_print(f"{fav_icon}{Fore.GREEN}{i:2d}. {Fore.WHITE}{preview}", 0.01)
        slow_print(f"     {Fore.CYAN}Time: {time_str} | Size: {item.size} chars | Hash: {item.hash} {access_info}", 0.01)
        print()

def display_clipboard_stats(stats):
    """Display clipboard statistics"""
    slow_print(f"\n{Fore.CYAN}📊 Clipboard Statistics", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Total Items: {Fore.WHITE}{stats['total_items']}", 0.02)
    slow_print(f"{Fore.GREEN}Total Size: {Fore.WHITE}{stats['total_size']} characters", 0.02)
    slow_print(f"{Fore.GREEN}Average Size: {Fore.WHITE}{stats['avg_size']:.1f} characters", 0.02)
    slow_print(f"{Fore.GREEN}Favorites: {Fore.WHITE}{stats['favorites_count']}", 0.02)
    
    if stats['type_counts']:
        slow_print(f"\n{Fore.YELLOW}Content Types:", 0.02)
        for content_type, count in stats['type_counts'].items():
            slow_print(f"{Fore.CYAN}• {content_type}: {Fore.WHITE}{count} items", 0.02)
    
    if stats['most_accessed']:
        slow_print(f"\n{Fore.YELLOW}Most Accessed:", 0.02)
        for item in stats['most_accessed']:
            if item.access_count > 0:
                preview = str(item.content)[:30] + "..." if len(str(item.content)) > 30 else str(item.content)
                slow_print(f"{Fore.CYAN}• {preview} {Fore.WHITE}({item.access_count}x)", 0.02)

def display_search_results(results, query):
    """Display search results"""
    slow_print(f"\n{Fore.CYAN}🔍 Search Results for '{query}'", 0.02)
    slow_print(f"{Fore.YELLOW}{'─' * 80}", 0.01)
    
    if not results:
        slow_print(f"{Fore.YELLOW}No results found", 0.02)
        return
    
    for i, item in enumerate(results, 1):
        preview = str(item.content)[:60]
        if len(str(item.content)) > 60:
            preview += "..."
        
        time_str = item.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        
        slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{preview}", 0.02)
        slow_print(f"   {Fore.CYAN}Time: {time_str} | Size: {item.size} chars", 0.02)
        print()

def main():
    """Main function"""
    print_header()
    
    manager = ClipboardManager()
    
    while True:
        slow_print(f"\n{Fore.CYAN}📋 ClipMgr Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}View Clipboard History", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Current Clipboard", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Copy Text to Clipboard", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Search History", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Clipboard Statistics", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Manage Favorites", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Clear History", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            display_clipboard_history(manager)
            
            if manager.history:
                try:
                    item_num = input(f"\n{Fore.YELLOW}Select item to copy (1-{len(manager.history)}) or Enter to skip: ").strip()
                    if item_num:
                        item_idx = int(item_num) - 1
                        if 0 <= item_idx < len(manager.history):
                            item = manager.history[item_idx]
                            if manager.set_clipboard_content(item.content):
                                item.access_count += 1
                                slow_print(f"{Fore.GREEN}✅ Copied to clipboard!", 0.02)
                            else:
                                slow_print(f"{Fore.RED}❌ Failed to copy to clipboard", 0.02)
                        else:
                            slow_print(f"{Fore.RED}❌ Invalid item number", 0.02)
                except ValueError:
                    slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '2':
            current = manager.get_clipboard_content()
            slow_print(f"\n{Fore.CYAN}📋 Current Clipboard Content:", 0.02)
            slow_print(f"{Fore.YELLOW}{'─' * 60}", 0.01)
            
            if current:
                slow_print(f"{Fore.WHITE}{current}", 0.02)
                slow_print(f"\n{Fore.CYAN}Size: {Fore.WHITE}{len(current)} characters", 0.02)
                
                # Ask to add to history
                add_to_history = input(f"\n{Fore.YELLOW}Add to history? (y/n): ").strip().lower()
                if add_to_history == 'y':
                    if manager.add_to_history(current):
                        slow_print(f"{Fore.GREEN}✅ Added to history!", 0.02)
                    else:
                        slow_print(f"{Fore.YELLOW}⚠️ Already in history or empty", 0.02)
            else:
                slow_print(f"{Fore.YELLOW}📋 Clipboard is empty", 0.02)
        
        elif choice == '3':
            text = input(f"{Fore.YELLOW}Enter text to copy: ").strip()
            if text:
                if manager.set_clipboard_content(text):
                    manager.add_to_history(text)
                    slow_print(f"{Fore.GREEN}✅ Text copied to clipboard and added to history!", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Failed to copy to clipboard", 0.02)
            else:
                slow_print(f"{Fore.RED}❌ No text provided", 0.02)
        
        elif choice == '4':
            query = input(f"{Fore.YELLOW}Enter search query: ").strip()
            if query:
                results = manager.search_history(query)
                display_search_results(results, query)
                
                if results:
                    try:
                        item_num = input(f"\n{Fore.YELLOW}Select result to copy (1-{len(results)}) or Enter to skip: ").strip()
                        if item_num:
                            item_idx = int(item_num) - 1
                            if 0 <= item_idx < len(results):
                                item = results[item_idx]
                                if manager.set_clipboard_content(item.content):
                                    item.access_count += 1
                                    slow_print(f"{Fore.GREEN}✅ Copied to clipboard!", 0.02)
                                else:
                                    slow_print(f"{Fore.RED}❌ Failed to copy to clipboard", 0.02)
                    except ValueError:
                        slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '5':
            stats = manager.get_history_stats()
            if stats:
                display_clipboard_stats(stats)
            else:
                slow_print(f"{Fore.YELLOW}📊 No statistics available", 0.02)
        
        elif choice == '6':
            slow_print(f"\n{Fore.CYAN}⭐ Favorites Management", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}View Favorites", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Add to Favorites", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Remove from Favorites", 0.02)
            
            fav_choice = input(f"\n{Fore.YELLOW}Select option (1-3): ").strip()
            
            if fav_choice == '1':
                if manager.favorites:
                    slow_print(f"\n{Fore.CYAN}⭐ Favorites:", 0.02)
                    for i, item in enumerate(manager.favorites, 1):
                        preview = str(item.content)[:50] + "..." if len(str(item.content)) > 50 else str(item.content)
                        slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{preview}", 0.02)
                else:
                    slow_print(f"{Fore.YELLOW}⭐ No favorites yet", 0.02)
            
            elif fav_choice == '2':
                display_clipboard_history(manager, 10)
                try:
                    item_num = int(input(f"\n{Fore.YELLOW}Select item to favorite (1-{min(10, len(manager.history))}): ").strip()) - 1
                    if 0 <= item_num < len(manager.history):
                        item = manager.history[item_num]
                        if not item.favorite:
                            item.favorite = True
                            manager.favorites.append(item)
                            manager.save_history()
                            slow_print(f"{Fore.GREEN}✅ Added to favorites!", 0.02)
                        else:
                            slow_print(f"{Fore.YELLOW}⚠️ Already in favorites", 0.02)
                except (ValueError, IndexError):
                    slow_print(f"{Fore.RED}❌ Invalid selection", 0.02)
        
        elif choice == '7':
            confirm = input(f"{Fore.RED}⚠️ Clear all clipboard history? (yes/no): ").strip().lower()
            if confirm == 'yes':
                manager.history.clear()
                manager.favorites.clear()
                manager.save_history()
                slow_print(f"{Fore.GREEN}✅ Clipboard history cleared!", 0.02)
            else:
                slow_print(f"{Fore.YELLOW}Operation cancelled", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using ClipMgr! Keep clipping!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
