import time


hour = time.strftime("%H")
minute = time.strftime("%M")
second = time.strftime("%S")

print("Welcome To Clock Made By Bhavyansh Soni!")
print(f"The Current Time is: {hour}:{minute}:{second}")
