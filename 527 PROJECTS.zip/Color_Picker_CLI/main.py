import time
import os
import re
from colorama import Fore, Back, Style, init

# Initialize colorama for Windows compatibility
init()

def slow_print(text, delay=0.03):
    """Print text with a typing effect"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

class ColorPicker:
    def __init__(self):
        self.color_history = []
        self.max_history = 10

    def display_welcome(self):
        """Display welcome screen with animation"""
        clear_screen()
        banner = """
╔═══════════════════════════════════════╗
║         Color Picker CLI              ║
║         By: Bhavyansh Soni            ║
╚═══════════════════════════════════════╝
        """
        for line in banner.split('\n'):
            slow_print(Fore.CYAN + line + Style.RESET_ALL)
        time.sleep(1)

    def rgb_to_hex(self, r, g, b):
        """Convert RGB to HEX color"""
        return f"#{r:02x}{g:02x}{b:02x}"

    def hex_to_rgb(self, hex_color):
        """Convert HEX to RGB color"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

    def validate_rgb(self, r, g, b):
        """Validate RGB values"""
        return all(0 <= x <= 255 for x in (r, g, b))

    def validate_hex(self, hex_color):
        """Validate HEX color format"""
        pattern = r'^#?[0-9A-Fa-f]{6}$'
        return bool(re.match(pattern, hex_color))

    def display_color(self, hex_color, rgb=None):
        """Display color preview in terminal"""
        if not rgb:
            rgb = self.hex_to_rgb(hex_color)
        
        print("\nColor Preview:")
        print("═" * 40)
        
        # Create a color block
        for _ in range(3):
            print(Back.WHITE + " " * 5 + Back.RESET, end="")
            print(f"\033[48;2;{rgb[0]};{rgb[1]};{rgb[2]}m" + " " * 30 + Style.RESET_ALL)
        
        print(Back.WHITE + " " * 5 + Back.RESET)
        print("═" * 40)
        
        # Display color codes
        print(f"HEX: {hex_color}")
        print(f"RGB: rgb{rgb}")
        
        # Add to history
        if hex_color not in self.color_history:
            self.color_history.append(hex_color)
            if len(self.color_history) > self.max_history:
                self.color_history.pop(0)

    def input_rgb(self):
        """Get RGB input from user"""
        try:
            print(f"\n{Fore.CYAN}Enter RGB values (0-255):{Style.RESET_ALL}")
            r = int(input("Red: "))
            g = int(input("Green: "))
            b = int(input("Blue: "))
            
            if self.validate_rgb(r, g, b):
                hex_color = self.rgb_to_hex(r, g, b)
                self.display_color(hex_color, (r, g, b))
            else:
                slow_print(f"{Fore.RED}Invalid RGB values! Use numbers between 0-255.{Style.RESET_ALL}")
        except ValueError:
            slow_print(f"{Fore.RED}Invalid input! Please enter numbers only.{Style.RESET_ALL}")

    def input_hex(self):
        """Get HEX input from user"""
        hex_color = input(f"\n{Fore.CYAN}Enter HEX color code (e.g., #FF0000): {Style.RESET_ALL}")
        
        if not hex_color.startswith('#'):
            hex_color = '#' + hex_color
            
        if self.validate_hex(hex_color):
            self.display_color(hex_color)
        else:
            slow_print(f"{Fore.RED}Invalid HEX color code! Use format: #RRGGBB{Style.RESET_ALL}")

    def show_history(self):
        """Display color history"""
        if not self.color_history:
            slow_print(f"\n{Fore.YELLOW}No colors in history!{Style.RESET_ALL}")
            return
            
        print(f"\n{Fore.CYAN}Color History (Latest first):{Style.RESET_ALL}")
        print("═" * 40)
        
        for hex_color in reversed(self.color_history):
            rgb = self.hex_to_rgb(hex_color)
            print(f"\033[48;2;{rgb[0]};{rgb[1]};{rgb[2]}m" + " " * 20 + Style.RESET_ALL, end=" ")
            print(f"{hex_color} - rgb{rgb}")

    def show_common_colors(self):
        """Display common color presets"""
        common_colors = {
            "Red": "#FF0000",
            "Green": "#00FF00",
            "Blue": "#0000FF",
            "Yellow": "#FFFF00",
            "Cyan": "#00FFFF",
            "Magenta": "#FF00FF",
            "White": "#FFFFFF",
            "Black": "#000000"
        }
        
        print(f"\n{Fore.CYAN}Common Colors:{Style.RESET_ALL}")
        print("═" * 40)
        
        for name, hex_color in common_colors.items():
            rgb = self.hex_to_rgb(hex_color)
            print(f"{name}: ", end="")
            print(f"\033[48;2;{rgb[0]};{rgb[1]};{rgb[2]}m" + " " * 20 + Style.RESET_ALL, end=" ")
            print(f"{hex_color}")

    def main_menu(self):
        """Main program loop"""
        while True:
            clear_screen()
            self.display_welcome()
            
            slow_print(f"\n{Fore.YELLOW}Options:{Style.RESET_ALL}")
            slow_print("1. Enter RGB Values")
            slow_print("2. Enter HEX Color")
            slow_print("3. View Color History")
            slow_print("4. View Common Colors")
            slow_print("5. Exit")
            
            choice = input(f"\n{Fore.GREEN}Enter your choice (1-5): {Style.RESET_ALL}")
            
            if choice == '1':
                self.input_rgb()
            elif choice == '2':
                self.input_hex()
            elif choice == '3':
                self.show_history()
            elif choice == '4':
                self.show_common_colors()
            elif choice == '5':
                slow_print(f"\n{Fore.YELLOW}Thank you for using Color Picker CLI!{Style.RESET_ALL}")
                break
            else:
                slow_print(f"{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")
            
            input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")

if __name__ == "__main__":
    try:
        picker = ColorPicker()
        picker.main_menu()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(f"\n{Fore.YELLOW}Program terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        slow_print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}") 