import os
import random
import time

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
except:
    class Fore:
        RED = ''
        GREEN = ''
        YELLOW = ''
        CYAN = ''
        MAGENTA = ''
    class Style:
        BRIGHT = ''
        RESET_ALL = ''

EMOJI_CRICKET = "🏏"
EMOJI_CHECK = "✅"
EMOJI_CROSS = "❌"
EMOJI_BALL = "⚾"
EMOJI_BAT = "🏏"
EMOJI_OUT = "💀"
EMOJI_RUN = "🏃"

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_delay(text, delay=0.05):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def toss():
    print(f"{Fore.YELLOW}Toss Time... (Heads/Tails)")
    user_call = input("Your call (Heads/Tails): ").capitalize()
    result = random.choice(["Heads", "Tails"])
    time.sleep(1)
    print(f"Toss result: {result}")
    time.sleep(1)
    if user_call == result:
        print(f"{Fore.GREEN}{EMOJI_CHECK} You won the toss!")
        choice = input("Choose Bat or Bowl: ").lower()
    else:
        print(f"{Fore.RED}{EMOJI_CROSS} You lost the toss!")
        choice = random.choice(['bat', 'bowl'])
        print(f"Opponent chooses to {choice}.")
    time.sleep(1)
    return choice

def commentary(action):
    lines = {
        "run": ["drives it beautifully", "steers it to the gap", "nudges it for a run", "punches it past the bowler"],
        "4": ["CRACKS it through the covers! FOUR!", "Beautiful shot! It's a boundary!", "Straight as an arrow! FOUR!"],
        "6": ["Massive hit! It's going all the way! SIX!", "What a shot! Into the stands! SIX!", "Clean as a whistle! SIX!"],
        "out": ["Gone! Caught behind!", "Bowled him! Clean bowled!", "Straight to the fielder! OUT!", "Big appeal... and he's given! OUT!"]
    }
    print_delay(random.choice(lines.get(action, ["Plays a shot..."])), 0.04)

def ball_animation():
    print(f"{Fore.CYAN}Bowler is running in... {EMOJI_BALL}")
    time.sleep(1)
    print(f"{Fore.CYAN}Delivers the ball... {EMOJI_BALL}")
    time.sleep(1)

def play_innings(player, target=None):
    runs = 0
    wickets = 0
    overs = 2  # 2 overs = 12 balls
    balls = overs * 6
    print(f"\n{Fore.CYAN}{player} is batting now! {EMOJI_CRICKET}")
    time.sleep(1)

    for ball in range(1, balls + 1):
        if wickets >= 2:  # 2 wickets limit
            print(f"{Fore.RED}All wickets down!")
            break

        print(f"\n{Fore.YELLOW}Ball {ball} of {overs} overs")
        ball_animation()

        if player == "You":
            try:
                shot = int(input("Choose your shot (1-6): "))
                if shot not in range(1, 7):
                    raise ValueError
            except:
                print(f"{Fore.RED}Invalid input. Dot ball.")
                shot = 0
        else:
            shot = random.randint(1, 6)
            print(f"Opponent plays: {shot}")

        # Chance of out
        out_chance = random.choice([False]*5 + [True])  # ~16% chance
        if out_chance:
            print(f"{Fore.RED}{EMOJI_OUT} OUT!")
            commentary("out")
            wickets += 1
            continue

        if shot == 4:
            print(f"{Fore.GREEN}🏏 FOUR! {EMOJI_RUN}")
            commentary("4")
            runs += 4
        elif shot == 6:
            print(f"{Fore.GREEN}🏏 SIX! {EMOJI_RUN}")
            commentary("6")
            runs += 6
        elif shot == 0:
            print(f"{Fore.CYAN}No run. Dot ball.")
        else:
            print(f"{Fore.GREEN}🏃 {shot} run(s)")
            commentary("run")
            runs += shot

        print(f"{Fore.MAGENTA}Score: {runs}/{wickets}")

        if target and runs >= target:
            print(f"{Fore.GREEN}Target achieved!")
            break

        time.sleep(1)

    print(f"\nInnings over. {player} scored {runs} runs.")
    return runs

def cricket_game():
    clear()
    print(f"{Fore.MAGENTA}{Style.BRIGHT}🏏 Terminal Cricket Game — Extended Version 🏏\n")
    user_choice = toss()

    if user_choice == "bat":
        user_runs = play_innings("You")
        print(f"\nTarget for opponent: {user_runs + 1}")
        opponent_runs = play_innings("Opponent", target=user_runs + 1)
    else:
        opponent_runs = play_innings("Opponent")
        print(f"\nTarget for you: {opponent_runs + 1}")
        user_runs = play_innings("You", target=opponent_runs + 1)

    print("\n🏏 Match Result 🏏")
    if user_runs > opponent_runs:
        print(f"{Fore.GREEN}🎉 You WON the match by {user_runs - opponent_runs} runs!")
    elif user_runs < opponent_runs:
        print(f"{Fore.RED}😢 You LOST the match by {opponent_runs - user_runs} runs.")
    else:
        print(f"{Fore.YELLOW}🤝 Match Drawn!")

    input("\nPress Enter to exit...")

if __name__ == "__main__":
    cricket_game()
