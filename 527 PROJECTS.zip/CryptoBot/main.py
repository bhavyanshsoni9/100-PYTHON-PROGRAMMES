#!/usr/bin/env python3
"""
CryptoBot - Cryptocurrency Analysis and Trading Bot
Created by BHAVYANSH SONI
A retro-style cryptocurrency analysis and trading simulation tool
"""

import os
import sys
import time
import random
import json
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import hashlib
import hmac

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.YELLOW}{'='*60}
{Fore.CYAN}     ██████╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗ ██████╗  ██████╗ ████████╗
{Fore.CYAN}    ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗██╔══██╗██╔═══██╗╚══██╔══╝
{Fore.CYAN}    ██║     ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║██████╔╝██║   ██║   ██║   
{Fore.CYAN}    ██║     ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║██╔══██╗██║   ██║   ██║   
{Fore.CYAN}    ╚██████╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝██████╔╝╚██████╔╝   ██║   
{Fore.CYAN}     ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝   
{Fore.YELLOW}{'='*60}
{Fore.YELLOW}    💰 Cryptocurrency Analysis & Trading Bot
{Fore.MAGENTA}    📈 Created by: BHAVYANSH SONI
{Fore.YELLOW}{'='*60}
"""
    print(header)

class CryptoCurrency:
    """Cryptocurrency data model"""
    
    def __init__(self, symbol, name, current_price, market_cap=0, volume_24h=0):
        self.symbol = symbol
        self.name = name
        self.current_price = current_price
        self.market_cap = market_cap
        self.volume_24h = volume_24h
        self.price_history = [current_price]
        self.last_updated = datetime.now()
        
    def update_price(self, new_price):
        """Update cryptocurrency price"""
        self.price_history.append(new_price)
        self.current_price = new_price
        self.last_updated = datetime.now()
        
        # Keep only last 100 price points
        if len(self.price_history) > 100:
            self.price_history = self.price_history[-100:]
    
    def get_price_change_24h(self):
        """Get 24h price change percentage"""
        if len(self.price_history) < 2:
            return 0
        
        old_price = self.price_history[0] if len(self.price_history) > 24 else self.price_history[0]
        return ((self.current_price - old_price) / old_price) * 100
    
    def get_volatility(self):
        """Calculate price volatility"""
        if len(self.price_history) < 2:
            return 0
        
        prices = self.price_history[-20:]  # Last 20 prices
        avg_price = sum(prices) / len(prices)
        variance = sum((price - avg_price) ** 2 for price in prices) / len(prices)
        return (variance ** 0.5) / avg_price * 100

class TradingBot:
    """Cryptocurrency trading bot"""
    
    def __init__(self, initial_balance=10000):
        self.balance_usd = initial_balance
        self.initial_balance = initial_balance
        self.portfolio = {}
        self.trade_history = []
        self.trading_strategies = {
            'sma_crossover': self.sma_crossover_strategy,
            'rsi_overbought': self.rsi_strategy,
            'momentum': self.momentum_strategy,
            'mean_reversion': self.mean_reversion_strategy
        }
        self.active_strategy = 'sma_crossover'
        self.risk_level = 'medium'
    
    def execute_trade(self, crypto, action, amount, price):
        """Execute a trade"""
        trade_value = amount * price
        fee = trade_value * 0.001  # 0.1% trading fee
        
        if action == 'buy':
            total_cost = trade_value + fee
            if self.balance_usd >= total_cost:
                self.balance_usd -= total_cost
                if crypto.symbol in self.portfolio:
                    self.portfolio[crypto.symbol] += amount
                else:
                    self.portfolio[crypto.symbol] = amount
                
                trade = {
                    'timestamp': datetime.now(),
                    'action': action,
                    'symbol': crypto.symbol,
                    'amount': amount,
                    'price': price,
                    'value': trade_value,
                    'fee': fee,
                    'total': total_cost
                }
                self.trade_history.append(trade)
                return True
        
        elif action == 'sell':
            if crypto.symbol in self.portfolio and self.portfolio[crypto.symbol] >= amount:
                self.portfolio[crypto.symbol] -= amount
                self.balance_usd += trade_value - fee
                
                if self.portfolio[crypto.symbol] == 0:
                    del self.portfolio[crypto.symbol]
                
                trade = {
                    'timestamp': datetime.now(),
                    'action': action,
                    'symbol': crypto.symbol,
                    'amount': amount,
                    'price': price,
                    'value': trade_value,
                    'fee': fee,
                    'total': trade_value - fee
                }
                self.trade_history.append(trade)
                return True
        
        return False
    
    def sma_crossover_strategy(self, crypto):
        """Simple Moving Average crossover strategy"""
        if len(crypto.price_history) < 20:
            return None
        
        # Calculate SMAs
        sma_short = sum(crypto.price_history[-5:]) / 5
        sma_long = sum(crypto.price_history[-20:]) / 20
        
        # Previous SMAs
        prev_sma_short = sum(crypto.price_history[-6:-1]) / 5
        prev_sma_long = sum(crypto.price_history[-21:-1]) / 20
        
        # Crossover signals
        if prev_sma_short <= prev_sma_long and sma_short > sma_long:
            return 'buy'
        elif prev_sma_short >= prev_sma_long and sma_short < sma_long:
            return 'sell'
        
        return None
    
    def rsi_strategy(self, crypto):
        """RSI-based strategy"""
        if len(crypto.price_history) < 14:
            return None
        
        # Calculate RSI
        prices = crypto.price_history[-14:]
        gains = []
        losses = []
        
        for i in range(1, len(prices)):
            change = prices[i] - prices[i-1]
            if change > 0:
                gains.append(change)
                losses.append(0)
            else:
                gains.append(0)
                losses.append(-change)
        
        avg_gain = sum(gains) / len(gains)
        avg_loss = sum(losses) / len(losses)
        
        if avg_loss == 0:
            return None
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        if rsi < 30:  # Oversold
            return 'buy'
        elif rsi > 70:  # Overbought
            return 'sell'
        
        return None
    
    def momentum_strategy(self, crypto):
        """Momentum-based strategy"""
        if len(crypto.price_history) < 10:
            return None
        
        # Calculate momentum
        current_price = crypto.current_price
        price_10_periods_ago = crypto.price_history[-10]
        momentum = ((current_price - price_10_periods_ago) / price_10_periods_ago) * 100
        
        if momentum > 5:  # Strong upward momentum
            return 'buy'
        elif momentum < -5:  # Strong downward momentum
            return 'sell'
        
        return None
    
    def mean_reversion_strategy(self, crypto):
        """Mean reversion strategy"""
        if len(crypto.price_history) < 20:
            return None
        
        # Calculate moving average and deviation
        ma = sum(crypto.price_history[-20:]) / 20
        current_price = crypto.current_price
        deviation = ((current_price - ma) / ma) * 100
        
        if deviation < -10:  # Price significantly below average
            return 'buy'
        elif deviation > 10:  # Price significantly above average
            return 'sell'
        
        return None
    
    def get_position_size(self, crypto, action):
        """Calculate position size based on risk level"""
        portfolio_value = self.get_portfolio_value({crypto.symbol: crypto})
        
        risk_percentages = {
            'low': 0.05,    # 5% of portfolio
            'medium': 0.10, # 10% of portfolio
            'high': 0.20    # 20% of portfolio
        }
        
        risk_pct = risk_percentages.get(self.risk_level, 0.10)
        
        if action == 'buy':
            max_investment = self.balance_usd * risk_pct
            return max_investment / crypto.current_price
        elif action == 'sell':
            if crypto.symbol in self.portfolio:
                return self.portfolio[crypto.symbol] * risk_pct
        
        return 0
    
    def get_portfolio_value(self, crypto_data):
        """Calculate total portfolio value"""
        total_value = self.balance_usd
        
        for symbol, amount in self.portfolio.items():
            if symbol in crypto_data:
                total_value += amount * crypto_data[symbol].current_price
        
        return total_value
    
    def get_portfolio_performance(self):
        """Calculate portfolio performance"""
        if not self.trade_history:
            return 0
        
        total_invested = 0
        total_profit = 0
        
        for trade in self.trade_history:
            if trade['action'] == 'buy':
                total_invested += trade['total']
            else:
                total_profit += trade['total']
        
        if total_invested == 0:
            return 0
        
        return ((total_profit - total_invested) / total_invested) * 100

class CryptoMarket:
    """Cryptocurrency market simulator"""
    
    def __init__(self):
        self.cryptocurrencies = {}
        self.initialize_market()
        
    def initialize_market(self):
        """Initialize market with popular cryptocurrencies"""
        initial_cryptos = [
            ('BTC', 'Bitcoin', 45000),
            ('ETH', 'Ethereum', 3200),
            ('BNB', 'Binance Coin', 420),
            ('ADA', 'Cardano', 1.25),
            ('DOT', 'Polkadot', 25),
            ('XRP', 'Ripple', 0.85),
            ('LTC', 'Litecoin', 180),
            ('LINK', 'Chainlink', 28),
            ('BCH', 'Bitcoin Cash', 520),
            ('XLM', 'Stellar', 0.35)
        ]
        
        for symbol, name, price in initial_cryptos:
            market_cap = price * random.randint(1000000, 100000000)
            volume_24h = market_cap * random.uniform(0.05, 0.3)
            
            crypto = CryptoCurrency(symbol, name, price, market_cap, volume_24h)
            self.cryptocurrencies[symbol] = crypto
    
    def simulate_price_movement(self):
        """Simulate realistic price movements"""
        for crypto in self.cryptocurrencies.values():
            # Random price movement with some trends
            volatility = random.uniform(0.01, 0.05)
            trend = random.uniform(-0.02, 0.02)
            
            price_change = crypto.current_price * (trend + random.uniform(-volatility, volatility))
            new_price = max(0.01, crypto.current_price + price_change)
            
            crypto.update_price(new_price)
    
    def get_market_summary(self):
        """Get market summary statistics"""
        total_market_cap = sum(crypto.market_cap for crypto in self.cryptocurrencies.values())
        total_volume = sum(crypto.volume_24h for crypto in self.cryptocurrencies.values())
        
        gainers = []
        losers = []
        
        for crypto in self.cryptocurrencies.values():
            change_24h = crypto.get_price_change_24h()
            if change_24h > 0:
                gainers.append((crypto.symbol, change_24h))
            elif change_24h < 0:
                losers.append((crypto.symbol, change_24h))
        
        gainers.sort(key=lambda x: x[1], reverse=True)
        losers.sort(key=lambda x: x[1])
        
        return {
            'total_market_cap': total_market_cap,
            'total_volume': total_volume,
            'top_gainers': gainers[:3],
            'top_losers': losers[:3]
        }

def display_market_overview(market):
    """Display cryptocurrency market overview"""
    slow_print(f"\n{Fore.CYAN}📊 Cryptocurrency Market Overview", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    summary = market.get_market_summary()
    
    slow_print(f"{Fore.GREEN}Total Market Cap: {Fore.WHITE}${summary['total_market_cap']:,.0f}", 0.02)
    slow_print(f"{Fore.GREEN}24h Volume: {Fore.WHITE}${summary['total_volume']:,.0f}", 0.02)
    
    slow_print(f"\n{Fore.GREEN}Top Gainers (24h):", 0.02)
    for symbol, change in summary['top_gainers']:
        slow_print(f"  {Fore.CYAN}{symbol}: {Fore.GREEN}+{change:.2f}%", 0.02)
    
    slow_print(f"\n{Fore.RED}Top Losers (24h):", 0.02)
    for symbol, change in summary['top_losers']:
        slow_print(f"  {Fore.CYAN}{symbol}: {Fore.RED}{change:.2f}%", 0.02)

def display_crypto_prices(market):
    """Display cryptocurrency prices"""
    slow_print(f"\n{Fore.CYAN}💰 Cryptocurrency Prices", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*100}", 0.01)
    
    # Header
    slow_print(f"{Fore.GREEN}{'Symbol':<8} {'Name':<15} {'Price':<12} {'24h Change':<12} {'Volatility':<12} {'Volume':<15}", 0.01)
    slow_print(f"{Fore.YELLOW}{'-'*90}", 0.01)
    
    for crypto in market.cryptocurrencies.values():
        change_24h = crypto.get_price_change_24h()
        volatility = crypto.get_volatility()
        
        # Color based on price change
        change_color = Fore.GREEN if change_24h >= 0 else Fore.RED
        change_sign = "+" if change_24h >= 0 else ""
        
        slow_print(f"{Fore.CYAN}{crypto.symbol:<8} {Fore.WHITE}{crypto.name:<15} "
                  f"${crypto.current_price:<11,.2f} {change_color}{change_sign}{change_24h:<11.2f}% "
                  f"{Fore.YELLOW}{volatility:<11.2f}% {Fore.WHITE}${crypto.volume_24h:<14,.0f}", 0.01)

def display_portfolio(bot, market):
    """Display trading bot portfolio"""
    slow_print(f"\n{Fore.CYAN}💼 Trading Portfolio", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    slow_print(f"{Fore.GREEN}USD Balance: {Fore.WHITE}${bot.balance_usd:,.2f}", 0.02)
    
    if bot.portfolio:
        slow_print(f"\n{Fore.GREEN}Holdings:", 0.02)
        slow_print(f"{Fore.GREEN}{'Symbol':<8} {'Amount':<15} {'Value':<15} {'Price':<12}", 0.01)
        slow_print(f"{Fore.YELLOW}{'-'*50}", 0.01)
        
        total_holdings_value = 0
        for symbol, amount in bot.portfolio.items():
            if symbol in market.cryptocurrencies:
                crypto = market.cryptocurrencies[symbol]
                value = amount * crypto.current_price
                total_holdings_value += value
                
                slow_print(f"{Fore.CYAN}{symbol:<8} {Fore.WHITE}{amount:<15.6f} "
                          f"${value:<14,.2f} ${crypto.current_price:<11,.2f}", 0.01)
        
        total_portfolio_value = bot.balance_usd + total_holdings_value
        portfolio_change = ((total_portfolio_value - bot.initial_balance) / bot.initial_balance) * 100
        
        slow_print(f"\n{Fore.GREEN}Total Holdings Value: {Fore.WHITE}${total_holdings_value:,.2f}", 0.02)
        slow_print(f"{Fore.GREEN}Total Portfolio Value: {Fore.WHITE}${total_portfolio_value:,.2f}", 0.02)
        
        change_color = Fore.GREEN if portfolio_change >= 0 else Fore.RED
        change_sign = "+" if portfolio_change >= 0 else ""
        slow_print(f"{Fore.GREEN}Portfolio Performance: {change_color}{change_sign}{portfolio_change:.2f}%", 0.02)
    else:
        slow_print(f"{Fore.YELLOW}No cryptocurrency holdings", 0.02)

def display_trade_history(bot):
    """Display trading history"""
    slow_print(f"\n{Fore.CYAN}📈 Trading History", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*100}", 0.01)
    
    if not bot.trade_history:
        slow_print(f"{Fore.YELLOW}No trades executed yet", 0.02)
        return
    
    # Header
    slow_print(f"{Fore.GREEN}{'Time':<12} {'Action':<6} {'Symbol':<8} {'Amount':<12} {'Price':<12} {'Value':<12}", 0.01)
    slow_print(f"{Fore.YELLOW}{'-'*70}", 0.01)
    
    for trade in bot.trade_history[-10:]:  # Show last 10 trades
        time_str = trade['timestamp'].strftime("%H:%M:%S")
        action_color = Fore.GREEN if trade['action'] == 'buy' else Fore.RED
        
        slow_print(f"{Fore.WHITE}{time_str:<12} {action_color}{trade['action'].upper():<6} "
                  f"{Fore.CYAN}{trade['symbol']:<8} {Fore.WHITE}{trade['amount']:<12.6f} "
                  f"${trade['price']:<11.2f} ${trade['value']:<11.2f}", 0.01)

def main():
    """Main function"""
    print_header()
    
    market = CryptoMarket()
    trading_bot = TradingBot()
    
    while True:
        slow_print(f"\n{Fore.CYAN}💰 CryptoBot Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Market Overview", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}View Prices", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Portfolio", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Manual Trading", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Auto Trading", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Trading History", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Market Simulation", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            display_market_overview(market)
        
        elif choice == '2':
            display_crypto_prices(market)
        
        elif choice == '3':
            display_portfolio(trading_bot, market)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}💱 Manual Trading", 0.02)
            
            # Show available cryptocurrencies
            symbols = list(market.cryptocurrencies.keys())
            slow_print(f"{Fore.YELLOW}Available cryptocurrencies:", 0.02)
            for i, symbol in enumerate(symbols, 1):
                crypto = market.cryptocurrencies[symbol]
                slow_print(f"{Fore.GREEN}{i}. {symbol} - ${crypto.current_price:,.2f}", 0.02)
            
            try:
                crypto_choice = int(input(f"\n{Fore.YELLOW}Select cryptocurrency (1-{len(symbols)}): ").strip()) - 1
                if 0 <= crypto_choice < len(symbols):
                    symbol = symbols[crypto_choice]
                    crypto = market.cryptocurrencies[symbol]
                    
                    action = input(f"{Fore.YELLOW}Action (buy/sell): ").strip().lower()
                    if action in ['buy', 'sell']:
                        amount = float(input(f"{Fore.YELLOW}Amount: ").strip())
                        
                        if trading_bot.execute_trade(crypto, action, amount, crypto.current_price):
                            slow_print(f"{Fore.GREEN}✅ Trade executed successfully!", 0.02)
                            slow_print(f"{Fore.CYAN}{action.title()} {amount:.6f} {symbol} at ${crypto.current_price:.2f}", 0.02)
                        else:
                            slow_print(f"{Fore.RED}❌ Trade failed - insufficient balance or holdings", 0.02)
                    else:
                        slow_print(f"{Fore.RED}❌ Invalid action", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid cryptocurrency choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '5':
            slow_print(f"\n{Fore.CYAN}🤖 Auto Trading Configuration", 0.02)
            
            strategies = list(trading_bot.trading_strategies.keys())
            slow_print(f"{Fore.YELLOW}Available strategies:", 0.02)
            for i, strategy in enumerate(strategies, 1):
                active = " (Active)" if strategy == trading_bot.active_strategy else ""
                slow_print(f"{Fore.GREEN}{i}. {strategy.replace('_', ' ').title()}{active}", 0.02)
            
            try:
                strategy_choice = int(input(f"\n{Fore.YELLOW}Select strategy (1-{len(strategies)}): ").strip()) - 1
                if 0 <= strategy_choice < len(strategies):
                    trading_bot.active_strategy = strategies[strategy_choice]
                    slow_print(f"{Fore.GREEN}✅ Strategy set to {trading_bot.active_strategy}", 0.02)
                    
                    # Run auto trading simulation
                    slow_print(f"\n{Fore.YELLOW}🤖 Running auto trading for 10 cycles...", 0.02)
                    
                    for cycle in range(10):
                        market.simulate_price_movement()
                        
                        for symbol, crypto in market.cryptocurrencies.items():
                            strategy_func = trading_bot.trading_strategies[trading_bot.active_strategy]
                            signal = strategy_func(crypto)
                            
                            if signal:
                                amount = trading_bot.get_position_size(crypto, signal)
                                if amount > 0:
                                    if trading_bot.execute_trade(crypto, signal, amount, crypto.current_price):
                                        slow_print(f"{Fore.CYAN}Auto {signal}: {amount:.6f} {symbol} at ${crypto.current_price:.2f}", 0.02)
                        
                        time.sleep(0.5)
                    
                    slow_print(f"{Fore.GREEN}✅ Auto trading simulation completed!", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid strategy choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '6':
            display_trade_history(trading_bot)
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}🎲 Market Simulation", 0.02)
            
            duration = input(f"{Fore.YELLOW}Simulation duration in cycles (default 20): ").strip()
            try:
                duration = int(duration) if duration else 20
                duration = max(1, min(100, duration))
            except ValueError:
                duration = 20
            
            slow_print(f"\n{Fore.YELLOW}🔄 Simulating market for {duration} cycles...", 0.02)
            
            for cycle in range(duration):
                market.simulate_price_movement()
                
                if cycle % 5 == 0:  # Show progress every 5 cycles
                    slow_print(f"{Fore.CYAN}Cycle {cycle + 1}/{duration} - Market moving...", 0.02)
                
                time.sleep(0.1)
            
            slow_print(f"\n{Fore.GREEN}✅ Market simulation completed!", 0.02)
            slow_print(f"{Fore.CYAN}Updated prices available in View Prices menu", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using CryptoBot! Happy trading!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
