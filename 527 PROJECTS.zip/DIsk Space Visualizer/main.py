"""
Disk Space Visualizer - Colorful GUI Version

Author: Bhavyansh Coder
"""

import os
import tkinter as tk
from tkinter import filedialog, messagebox
import matplotlib.pyplot as plt


def get_folder_size(path):
    total = 0
    try:
        for entry in os.scandir(path):
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_folder_size(entry.path)
    except PermissionError:
        pass
    return total


def scan_folder(path):
    sizes = {}
    try:
        for entry in os.scandir(path):
            if entry.is_file():
                sizes[entry.name] = entry.stat().st_size
            elif entry.is_dir():
                sizes[entry.name + "/"] = get_folder_size(entry.path)
    except PermissionError:
        pass
    return sizes


def visualize_folder(path):
    sizes = scan_folder(path)
    labels = []
    values = []

    for name, size in sizes.items():
        labels.append(name)
        values.append(size)

    if not values:
        messagebox.showerror("Error", "No files or folders found!")
        return

    colors = plt.cm.coolwarm(range(len(labels)))

    plt.figure(figsize=(8, 6))
    plt.title(f"Disk Usage for {os.path.basename(path)}", fontsize=14, color="#00bfa6")

    plt.pie(
        values,
        labels=labels,
        colors=colors,
        autopct=lambda p: '{:.1f}%'.format(p) if p > 0 else '',
        startangle=140
    )
    plt.axis('equal')
    plt.show()


def gui():
    root = tk.Tk()
    root.title("Disk Space Visualizer")
    root.geometry("500x300")
    root.config(bg="#1e1e2f")

    tk.Label(
        root,
        text="💾 Disk Space Visualizer",
        font=("Arial", 20, "bold"),
        bg="#1e1e2f",
        fg="#00ffcc"
    ).pack(pady=20)

    def choose_folder():
        path = filedialog.askdirectory(title="Select Folder")
        if path:
            visualize_folder(path)

    button_style = {
        "font": ("Arial", 12, "bold"),
        "bg": "#00ffcc",
        "fg": "#000000",
        "activebackground": "#00bfa6",
        "activeforeground": "#ffffff",
        "bd": 0,
        "relief": "flat",
        "width": 25,
        "height": 2
    }

    tk.Button(root, text="📁 Choose Folder", command=choose_folder, **button_style).pack(pady=20)
    tk.Button(root, text="❌ Exit", command=root.destroy, **button_style).pack(pady=10)

    root.mainloop()


if __name__ == "__main__":
    gui()
