from datetime import date
import time
import os

def slow_print(text, delay = 0.02):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def welcome():
    slow_print("Welcome To The Daily School 🏫 Diary 📘 Maker!")
    slow_print("By: Bhavyansh Soni!")
    slow_print("In This Programme You Can Make A Dairy Note For Students!")
    slow_print("So, That They Can Do Their HomeWork 📚")
    slow_print("So Let's Make Daily Diary!\n")

def create_diary_directory():
    today = str(date.today())
    if not os.path.exists(today):
        try:
            os.makedirs(today)
            slow_print(f"Created directory for {today} 📁")
        except OSError as e:
            slow_print(f"Error creating directory: {e}")
            return False
    return True

def add_today_work():
    slow_print(f"So, What Work Had Been Done ✔ Today ({date.today()})")
    today_work = input(">>\n")
    try:
        with open(f"{date.today()}/today_work.txt", "w") as f:
            slow_print("Uploading...")
            f.write(today_work)
        slow_print("Today's Work Uploaded Successfully ✅")
    except IOError as e:
        slow_print(f"Error saving today's work: {e}")

def add_homework():
    slow_print("So, What's The HomeWork For Today!")
    homework = input(">>\n")
    try:
        with open(f"{date.today()}/homework.txt", "w") as f:
            slow_print("Uploading...")
            f.write(homework)
        slow_print("Home Work Uploaded Successfully ✅")
    except IOError as e:
        slow_print(f"Error saving homework: {e}")

def main():
    welcome()
    if create_diary_directory():
        add_today_work()
        add_homework()
    else:
        slow_print("Cannot proceed due to directory creation error.")

if __name__ == "__main__":
    main()


