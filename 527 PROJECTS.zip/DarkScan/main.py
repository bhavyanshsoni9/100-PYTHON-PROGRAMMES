#!/usr/bin/env python3
"""
DarkScan - Advanced Network and Vulnerability Scanner
Created by BHAVYANSH SONI
A retro-style advanced network scanner with stealth capabilities
"""

import os
import sys
import time
import random
import socket
import threading
import subprocess
from datetime import datetime, timedelta
from colorama import init, Fore, Back, Style
import ipaddress
import struct

# Initialize colorama
init(autoreset=True)

def slow_print(text, delay=0.03):
    """Print text character by character with delay"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def print_header():
    """Print the program header with credits"""
    os.system('cls' if os.name == 'nt' else 'clear')
    header = f"""
{Fore.RED}{'='*60}
{Fore.GREEN}    ██████╗  █████╗ ██████╗ ██╗  ██╗███████╗ ██████╗ █████╗ ███╗   ██╗
{Fore.GREEN}    ██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔════╝██╔══██╗████╗  ██║
{Fore.GREEN}    ██║  ██║███████║██████╔╝█████╔╝ ███████╗██║     ███████║██╔██╗ ██║
{Fore.GREEN}    ██║  ██║██╔══██║██╔══██╗██╔═██╗ ╚════██║██║     ██╔══██║██║╚██╗██║
{Fore.GREEN}    ██████╔╝██║  ██║██║  ██║██║  ██╗███████║╚██████╗██║  ██║██║ ╚████║
{Fore.GREEN}    ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝
{Fore.RED}{'='*60}
{Fore.YELLOW}    🔍 Advanced Network & Vulnerability Scanner
{Fore.MAGENTA}    🌐 Created by: BHAVYANSH SONI
{Fore.RED}{'='*60}
"""
    print(header)

class AdvancedScanner:
    """Advanced network and vulnerability scanner"""
    
    def __init__(self):
        self.scan_results = {}
        self.discovered_hosts = []
        self.scan_techniques = [
            'TCP Connect Scan',
            'SYN Stealth Scan',
            'UDP Scan',
            'FIN Scan',
            'Xmas Scan',
            'NULL Scan',
            'ACK Scan',
            'Window Scan'
        ]
        self.service_fingerprints = self.load_service_fingerprints()
        self.vulnerability_database = self.load_vulnerability_database()
        
    def load_service_fingerprints(self):
        """Load service fingerprinting database"""
        return {
            21: {'service': 'FTP', 'versions': ['vsftpd 3.0.3', 'ProFTPD 1.3.6', 'Pure-FTPd 1.0.47']},
            22: {'service': 'SSH', 'versions': ['OpenSSH 8.2', 'OpenSSH 7.4', 'Dropbear sshd 2019.78']},
            23: {'service': 'Telnet', 'versions': ['Linux telnetd', 'Windows Telnet']},
            25: {'service': 'SMTP', 'versions': ['Postfix smtpd', 'Microsoft ESMTP 10.0', 'Exim 4.94']},
            53: {'service': 'DNS', 'versions': ['BIND 9.16.1', 'Microsoft DNS 10.0', 'dnsmasq-2.80']},
            80: {'service': 'HTTP', 'versions': ['Apache httpd 2.4.41', 'nginx 1.18.0', 'Microsoft-IIS/10.0']},
            110: {'service': 'POP3', 'versions': ['Dovecot pop3d', 'Microsoft POP3 service']},
            135: {'service': 'RPC', 'versions': ['Microsoft Windows RPC']},
            139: {'service': 'NetBIOS-SSN', 'versions': ['Microsoft Windows netbios-ssn']},
            143: {'service': 'IMAP', 'versions': ['Dovecot imapd', 'Microsoft Exchange IMAP4']},
            443: {'service': 'HTTPS', 'versions': ['Apache httpd 2.4.41', 'nginx 1.18.0', 'Microsoft-IIS/10.0']},
            445: {'service': 'SMB', 'versions': ['Microsoft Windows SMB']},
            993: {'service': 'IMAPS', 'versions': ['Dovecot imapd']},
            995: {'service': 'POP3S', 'versions': ['Dovecot pop3d']},
            1433: {'service': 'MSSQL', 'versions': ['Microsoft SQL Server 2019']},
            3306: {'service': 'MySQL', 'versions': ['MySQL 8.0.25', 'MariaDB 10.5']},
            3389: {'service': 'RDP', 'versions': ['Microsoft Terminal Services']},
            5432: {'service': 'PostgreSQL', 'versions': ['PostgreSQL DB 13.3']},
            8080: {'service': 'HTTP-Proxy', 'versions': ['Apache Tomcat 9.0', 'Jetty 9.4']}
        }
    
    def load_vulnerability_database(self):
        """Load vulnerability database"""
        return {
            'OpenSSH 7.4': [
                {'cve': 'CVE-2018-15473', 'severity': 'Medium', 'description': 'Username enumeration'},
                {'cve': 'CVE-2019-6111', 'severity': 'Medium', 'description': 'SCP client command injection'}
            ],
            'Apache httpd 2.4.41': [
                {'cve': 'CVE-2021-34798', 'severity': 'High', 'description': 'NULL pointer dereference'},
                {'cve': 'CVE-2021-39275', 'severity': 'High', 'description': 'Out-of-bounds write'}
            ],
            'Microsoft-IIS/10.0': [
                {'cve': 'CVE-2021-31207', 'severity': 'High', 'description': 'HTTP Protocol Stack Remote Code Execution'}
            ],
            'MySQL 8.0.25': [
                {'cve': 'CVE-2021-2471', 'severity': 'Medium', 'description': 'Server: Replication unspecified vulnerability'}
            ],
            'nginx 1.18.0': [
                {'cve': 'CVE-2021-23017', 'severity': 'High', 'description': '1-byte memory overwrite in resolver'}
            ]
        }
    
    def ping_sweep(self, network):
        """Perform ping sweep to discover live hosts"""
        live_hosts = []
        
        try:
            network_obj = ipaddress.IPv4Network(network, strict=False)
            hosts_to_scan = list(network_obj.hosts())[:50]  # Limit to first 50 hosts
            
            slow_print(f"{Fore.YELLOW}🔍 Performing ping sweep on {network}...", 0.02)
            
            for host in hosts_to_scan:
                # Simulate ping with random success rate
                if random.random() < 0.2:  # 20% chance of host being alive
                    live_hosts.append(str(host))
                    slow_print(f"{Fore.GREEN}✓ {host} is alive", 0.01)
                
                time.sleep(0.1)
            
        except ipaddress.AddressValueError:
            slow_print(f"{Fore.RED}❌ Invalid network format", 0.02)
            return []
        
        self.discovered_hosts = live_hosts
        return live_hosts
    
    def port_scan(self, target, ports, scan_type='tcp_connect'):
        """Advanced port scanning with multiple techniques"""
        open_ports = []
        filtered_ports = []
        closed_ports = []
        
        slow_print(f"{Fore.YELLOW}🔍 Scanning {target} using {scan_type.replace('_', ' ').title()}...", 0.02)
        
        for port in ports:
            result = self.scan_port(target, port, scan_type)
            
            if result == 'open':
                open_ports.append(port)
                service_info = self.service_fingerprinting(target, port)
                slow_print(f"{Fore.GREEN}Port {port}: OPEN - {service_info['service']}", 0.01)
            elif result == 'filtered':
                filtered_ports.append(port)
                slow_print(f"{Fore.YELLOW}Port {port}: FILTERED", 0.01)
            else:
                closed_ports.append(port)
            
            time.sleep(0.05)  # Small delay for stealth
        
        scan_result = {
            'target': target,
            'scan_type': scan_type,
            'open_ports': open_ports,
            'filtered_ports': filtered_ports,
            'closed_ports': closed_ports,
            'timestamp': datetime.now().isoformat(),
            'services': {}
        }
        
        # Get detailed service information for open ports
        for port in open_ports:
            scan_result['services'][port] = self.service_fingerprinting(target, port)
        
        self.scan_results[f"{target}_{scan_type}"] = scan_result
        return scan_result
    
    def scan_port(self, target, port, scan_type):
        """Simulate different port scanning techniques"""
        # Simulate different scan results based on technique
        if scan_type == 'tcp_connect':
            # TCP Connect scan - most reliable
            return random.choices(['open', 'closed', 'filtered'], weights=[0.15, 0.80, 0.05], k=1)[0]
        elif scan_type == 'syn_stealth':
            # SYN Stealth scan - stealthier
            return random.choices(['open', 'closed', 'filtered'], weights=[0.12, 0.83, 0.05], k=1)[0]
        elif scan_type == 'udp_scan':
            # UDP scan - more filtered responses
            return random.choices(['open', 'closed', 'filtered'], weights=[0.05, 0.70, 0.25], k=1)[0]
        elif scan_type in ['fin_scan', 'xmas_scan', 'null_scan']:
            # Stealth scans - more filtered/inconclusive
            return random.choices(['open', 'closed', 'filtered'], weights=[0.08, 0.75, 0.17], k=1)[0]
        else:
            return random.choices(['open', 'closed', 'filtered'], weights=[0.10, 0.80, 0.10], k=1)[0]
    
    def service_fingerprinting(self, target, port):
        """Perform service version detection"""
        if port in self.service_fingerprints:
            service_info = self.service_fingerprints[port].copy()
            # Randomly select a version
            service_info['version'] = random.choice(service_info['versions'])
            service_info['confidence'] = random.uniform(0.7, 1.0)
            
            # Check for vulnerabilities
            service_info['vulnerabilities'] = self.check_vulnerabilities(service_info['version'])
            
            return service_info
        else:
            return {
                'service': 'Unknown',
                'version': 'Unknown',
                'confidence': 0.0,
                'vulnerabilities': []
            }
    
    def check_vulnerabilities(self, service_version):
        """Check for known vulnerabilities in service version"""
        vulnerabilities = []
        
        for version_pattern, vulns in self.vulnerability_database.items():
            if version_pattern in service_version:
                vulnerabilities.extend(vulns)
        
        return vulnerabilities
    
    def os_fingerprinting(self, target):
        """Perform OS fingerprinting"""
        os_signatures = [
            {'os': 'Linux 4.15-5.8', 'confidence': 95, 'details': 'Ubuntu 18.04-20.04'},
            {'os': 'Windows 10/Server 2019', 'confidence': 90, 'details': 'Build 1909-2004'},
            {'os': 'FreeBSD 12.1-13.0', 'confidence': 85, 'details': 'FreeBSD'},
            {'os': 'macOS 10.15-11.6', 'confidence': 88, 'details': 'Catalina-Big Sur'},
            {'os': 'CentOS 7-8', 'confidence': 92, 'details': 'RHEL-based'},
            {'os': 'Cisco IOS 15.x', 'confidence': 87, 'details': 'Network device'},
            {'os': 'Windows Server 2016', 'confidence': 89, 'details': 'Build 14393'}
        ]
        
        # Simulate OS detection
        return random.choice(os_signatures)
    
    def vulnerability_scan(self, target):
        """Perform vulnerability assessment"""
        vulnerabilities = []
        
        if target in self.scan_results:
            # Use scan results to find vulnerabilities
            for scan_key, scan_data in self.scan_results.items():
                if target in scan_key:
                    for port, service_info in scan_data.get('services', {}).items():
                        if 'vulnerabilities' in service_info:
                            for vuln in service_info['vulnerabilities']:
                                vuln_entry = vuln.copy()
                                vuln_entry['port'] = port
                                vuln_entry['service'] = service_info['service']
                                vuln_entry['version'] = service_info['version']
                                vulnerabilities.append(vuln_entry)
        
        # Add some additional simulated vulnerabilities
        additional_vulns = [
            {'cve': 'CVE-2021-44228', 'severity': 'Critical', 'description': 'Log4j Remote Code Execution', 'port': 8080, 'service': 'HTTP'},
            {'cve': 'CVE-2021-34527', 'severity': 'Critical', 'description': 'Windows Print Spooler RCE', 'port': 135, 'service': 'RPC'},
            {'cve': 'CVE-2021-1675', 'severity': 'High', 'description': 'Windows Print Spooler Elevation', 'port': 445, 'service': 'SMB'},
            {'cve': 'CVE-2020-1472', 'severity': 'Critical', 'description': 'Netlogon Elevation of Privilege', 'port': 445, 'service': 'SMB'}
        ]
        
        # Randomly add some additional vulnerabilities
        num_additional = random.randint(0, 3)
        vulnerabilities.extend(random.sample(additional_vulns, num_additional))
        
        return vulnerabilities
    
    def stealth_scan(self, target, ports):
        """Perform stealth scanning with evasion techniques"""
        techniques = [
            'Fragment packets',
            'Decoy hosts',
            'Idle scan',
            'Source port manipulation',
            'Timing delays',
            'MTU discovery'
        ]
        
        active_techniques = random.sample(techniques, random.randint(2, 4))
        
        slow_print(f"{Fore.MAGENTA}🥷 Initiating stealth scan on {target}...", 0.02)
        slow_print(f"{Fore.CYAN}Active evasion techniques:", 0.02)
        for technique in active_techniques:
            slow_print(f"  • {technique}", 0.02)
        
        time.sleep(2)
        
        # Perform stealthier scan with lower detection rate
        return self.port_scan(target, ports, 'syn_stealth')
    
    def generate_scan_report(self, target):
        """Generate comprehensive scan report"""
        report = {
            'target': target,
            'timestamp': datetime.now().isoformat(),
            'scans_performed': [],
            'open_ports': [],
            'services': {},
            'vulnerabilities': [],
            'os_fingerprint': None,
            'risk_assessment': 'Low'
        }
        
        # Compile scan results
        for scan_key, scan_data in self.scan_results.items():
            if target in scan_key:
                report['scans_performed'].append(scan_data['scan_type'])
                report['open_ports'].extend(scan_data['open_ports'])
                report['services'].update(scan_data['services'])
        
        # Remove duplicates
        report['open_ports'] = list(set(report['open_ports']))
        
        # Get vulnerabilities
        report['vulnerabilities'] = self.vulnerability_scan(target)
        
        # Get OS fingerprint
        report['os_fingerprint'] = self.os_fingerprinting(target)
        
        # Calculate risk assessment
        critical_vulns = len([v for v in report['vulnerabilities'] if v['severity'] == 'Critical'])
        high_vulns = len([v for v in report['vulnerabilities'] if v['severity'] == 'High'])
        
        if critical_vulns > 0:
            report['risk_assessment'] = 'Critical'
        elif high_vulns > 2:
            report['risk_assessment'] = 'High'
        elif high_vulns > 0 or len(report['open_ports']) > 10:
            report['risk_assessment'] = 'Medium'
        else:
            report['risk_assessment'] = 'Low'
        
        return report

def display_scan_results(scan_result):
    """Display detailed scan results"""
    slow_print(f"\n{Fore.CYAN}📊 Scan Results for {scan_result['target']}", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    slow_print(f"{Fore.GREEN}Scan Type: {Fore.WHITE}{scan_result['scan_type'].replace('_', ' ').title()}", 0.02)
    slow_print(f"{Fore.GREEN}Timestamp: {Fore.WHITE}{scan_result['timestamp'][:19]}", 0.02)
    slow_print(f"{Fore.GREEN}Open Ports: {Fore.WHITE}{len(scan_result['open_ports'])}", 0.02)
    slow_print(f"{Fore.GREEN}Filtered Ports: {Fore.WHITE}{len(scan_result['filtered_ports'])}", 0.02)
    slow_print(f"{Fore.GREEN}Closed Ports: {Fore.WHITE}{len(scan_result['closed_ports'])}", 0.02)
    
    if scan_result['open_ports']:
        slow_print(f"\n{Fore.CYAN}🔓 Open Ports and Services:", 0.02)
        slow_print(f"{Fore.YELLOW}{'─'*70}", 0.01)
        
        for port in scan_result['open_ports']:
            if port in scan_result['services']:
                service = scan_result['services'][port]
                confidence = f"({service['confidence']:.0%})" if service['confidence'] > 0 else ""
                slow_print(f"{Fore.GREEN}Port {port}: {Fore.WHITE}{service['service']} {service['version']} {confidence}", 0.02)
                
                if service.get('vulnerabilities'):
                    for vuln in service['vulnerabilities']:
                        severity_color = {
                            'Critical': Fore.MAGENTA,
                            'High': Fore.RED,
                            'Medium': Fore.YELLOW,
                            'Low': Fore.GREEN
                        }.get(vuln['severity'], Fore.WHITE)
                        
                        slow_print(f"  {severity_color}⚠️  {vuln['cve']} ({vuln['severity']}): {vuln['description']}", 0.02)

def display_vulnerability_report(vulnerabilities):
    """Display vulnerability assessment results"""
    if not vulnerabilities:
        slow_print(f"{Fore.GREEN}✅ No vulnerabilities detected", 0.02)
        return
    
    slow_print(f"\n{Fore.CYAN}🚨 Vulnerability Assessment", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    severity_counts = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}
    
    for vuln in vulnerabilities:
        severity_counts[vuln['severity']] += 1
        
        severity_color = {
            'Critical': Fore.MAGENTA,
            'High': Fore.RED,
            'Medium': Fore.YELLOW,
            'Low': Fore.GREEN
        }.get(vuln['severity'], Fore.WHITE)
        
        slow_print(f"{severity_color}🔥 {vuln['cve']} ({vuln['severity']})", 0.02)
        slow_print(f"   {Fore.WHITE}Description: {vuln['description']}", 0.02)
        if 'port' in vuln:
            slow_print(f"   {Fore.WHITE}Port: {vuln['port']} ({vuln.get('service', 'Unknown')})", 0.02)
        print()
    
    slow_print(f"{Fore.CYAN}Vulnerability Summary:", 0.02)
    slow_print(f"{Fore.MAGENTA}Critical: {severity_counts['Critical']}", 0.02)
    slow_print(f"{Fore.RED}High: {severity_counts['High']}", 0.02)
    slow_print(f"{Fore.YELLOW}Medium: {severity_counts['Medium']}", 0.02)
    slow_print(f"{Fore.GREEN}Low: {severity_counts['Low']}", 0.02)

def display_comprehensive_report(report):
    """Display comprehensive scan report"""
    slow_print(f"\n{Fore.CYAN}📋 Comprehensive Scan Report", 0.02)
    slow_print(f"{Fore.YELLOW}{'='*80}", 0.01)
    
    slow_print(f"{Fore.GREEN}Target: {Fore.WHITE}{report['target']}", 0.02)
    slow_print(f"{Fore.GREEN}Scan Date: {Fore.WHITE}{report['timestamp'][:19]}", 0.02)
    slow_print(f"{Fore.GREEN}Scans Performed: {Fore.WHITE}{', '.join(report['scans_performed'])}", 0.02)
    
    # Risk assessment with color coding
    risk_colors = {
        'Critical': Fore.MAGENTA,
        'High': Fore.RED,
        'Medium': Fore.YELLOW,
        'Low': Fore.GREEN
    }
    risk_color = risk_colors.get(report['risk_assessment'], Fore.WHITE)
    slow_print(f"{Fore.GREEN}Risk Assessment: {risk_color}{report['risk_assessment']}", 0.02)
    
    # OS Fingerprint
    if report['os_fingerprint']:
        os_info = report['os_fingerprint']
        slow_print(f"\n{Fore.CYAN}🖥️ Operating System:", 0.02)
        slow_print(f"{Fore.GREEN}OS: {Fore.WHITE}{os_info['os']} ({os_info['confidence']}% confidence)", 0.02)
        slow_print(f"{Fore.GREEN}Details: {Fore.WHITE}{os_info['details']}", 0.02)
    
    # Open Ports Summary
    slow_print(f"\n{Fore.CYAN}🔓 Open Ports Summary:", 0.02)
    slow_print(f"{Fore.GREEN}Total Open Ports: {Fore.WHITE}{len(report['open_ports'])}", 0.02)
    
    if report['open_ports']:
        ports_display = ', '.join(map(str, sorted(report['open_ports'])))
        slow_print(f"{Fore.GREEN}Ports: {Fore.WHITE}{ports_display}", 0.02)
    
    # Vulnerability Summary
    vuln_count = len(report['vulnerabilities'])
    slow_print(f"\n{Fore.CYAN}🚨 Security Assessment:", 0.02)
    slow_print(f"{Fore.GREEN}Vulnerabilities Found: {Fore.WHITE}{vuln_count}", 0.02)
    
    if vuln_count > 0:
        critical = len([v for v in report['vulnerabilities'] if v['severity'] == 'Critical'])
        high = len([v for v in report['vulnerabilities'] if v['severity'] == 'High'])
        medium = len([v for v in report['vulnerabilities'] if v['severity'] == 'Medium'])
        low = len([v for v in report['vulnerabilities'] if v['severity'] == 'Low'])
        
        slow_print(f"{Fore.MAGENTA}Critical: {critical}, {Fore.RED}High: {high}, {Fore.YELLOW}Medium: {medium}, {Fore.GREEN}Low: {low}", 0.02)

def main():
    """Main function"""
    print_header()
    
    scanner = AdvancedScanner()
    
    while True:
        slow_print(f"\n{Fore.CYAN}🔍 DarkScan Menu:", 0.02)
        slow_print(f"{Fore.GREEN}1. {Fore.WHITE}Network Discovery", 0.02)
        slow_print(f"{Fore.GREEN}2. {Fore.WHITE}Port Scanning", 0.02)
        slow_print(f"{Fore.GREEN}3. {Fore.WHITE}Service Detection", 0.02)
        slow_print(f"{Fore.GREEN}4. {Fore.WHITE}Vulnerability Scan", 0.02)
        slow_print(f"{Fore.GREEN}5. {Fore.WHITE}Stealth Scan", 0.02)
        slow_print(f"{Fore.GREEN}6. {Fore.WHITE}OS Fingerprinting", 0.02)
        slow_print(f"{Fore.GREEN}7. {Fore.WHITE}Comprehensive Report", 0.02)
        slow_print(f"{Fore.GREEN}8. {Fore.WHITE}Exit", 0.02)
        
        choice = input(f"\n{Fore.YELLOW}Select option (1-8): ").strip()
        
        if choice == '1':
            network = input(f"{Fore.YELLOW}Enter network (e.g., 192.168.1.0/24): ").strip()
            if network:
                live_hosts = scanner.ping_sweep(network)
                
                slow_print(f"\n{Fore.GREEN}📡 Network Discovery Complete", 0.02)
                slow_print(f"{Fore.CYAN}Live hosts found: {len(live_hosts)}", 0.02)
                
                if live_hosts:
                    slow_print(f"\n{Fore.YELLOW}Discovered Hosts:", 0.02)
                    for host in live_hosts:
                        slow_print(f"  {Fore.GREEN}• {host}", 0.02)
        
        elif choice == '2':
            target = input(f"{Fore.YELLOW}Enter target IP/hostname: ").strip()
            if target:
                port_range = input(f"{Fore.YELLOW}Port range (e.g., 1-1000, common, or specific ports): ").strip()
                
                # Parse port range
                if port_range.lower() == 'common':
                    ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1433, 3306, 3389, 5432, 8080]
                elif '-' in port_range:
                    try:
                        start, end = map(int, port_range.split('-'))
                        ports = list(range(start, min(end + 1, start + 1000)))  # Limit range
                    except ValueError:
                        slow_print(f"{Fore.RED}❌ Invalid port range", 0.02)
                        continue
                else:
                    try:
                        ports = [int(p.strip()) for p in port_range.split(',')]
                    except ValueError:
                        slow_print(f"{Fore.RED}❌ Invalid port format", 0.02)
                        continue
                
                # Select scan technique
                slow_print(f"\n{Fore.YELLOW}Scan Techniques:", 0.02)
                for i, technique in enumerate(scanner.scan_techniques, 1):
                    slow_print(f"{Fore.GREEN}{i}. {technique}", 0.02)
                
                try:
                    technique_choice = int(input(f"\n{Fore.YELLOW}Select technique (1-{len(scanner.scan_techniques)}): ").strip()) - 1
                    if 0 <= technique_choice < len(scanner.scan_techniques):
                        scan_type = scanner.scan_techniques[technique_choice].lower().replace(' ', '_')
                        
                        scan_result = scanner.port_scan(target, ports, scan_type)
                        display_scan_results(scan_result)
                    else:
                        slow_print(f"{Fore.RED}❌ Invalid technique choice", 0.02)
                except ValueError:
                    slow_print(f"{Fore.RED}❌ Invalid input", 0.02)
        
        elif choice == '3':
            target = input(f"{Fore.YELLOW}Enter target for service detection: ").strip()
            if target:
                # Use existing scan results or perform new scan
                scan_key = None
                for key in scanner.scan_results:
                    if target in key:
                        scan_key = key
                        break
                
                if scan_key:
                    scan_result = scanner.scan_results[scan_key]
                    display_scan_results(scan_result)
                else:
                    slow_print(f"{Fore.YELLOW}No existing scan results. Performing quick scan...", 0.02)
                    common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 3389]
                    scan_result = scanner.port_scan(target, common_ports, 'tcp_connect')
                    display_scan_results(scan_result)
        
        elif choice == '4':
            target = input(f"{Fore.YELLOW}Enter target for vulnerability scan: ").strip()
            if target:
                slow_print(f"\n{Fore.YELLOW}🔍 Performing vulnerability assessment...", 0.02)
                time.sleep(2)
                
                vulnerabilities = scanner.vulnerability_scan(target)
                display_vulnerability_report(vulnerabilities)
        
        elif choice == '5':
            target = input(f"{Fore.YELLOW}Enter target for stealth scan: ").strip()
            if target:
                ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 3389]
                
                scan_result = scanner.stealth_scan(target, ports)
                display_scan_results(scan_result)
        
        elif choice == '6':
            target = input(f"{Fore.YELLOW}Enter target for OS fingerprinting: ").strip()
            if target:
                slow_print(f"\n{Fore.YELLOW}🔍 Performing OS fingerprinting...", 0.02)
                time.sleep(2)
                
                os_info = scanner.os_fingerprinting(target)
                
                slow_print(f"\n{Fore.CYAN}🖥️ OS Detection Results:", 0.02)
                slow_print(f"{Fore.YELLOW}{'─'*50}", 0.01)
                slow_print(f"{Fore.GREEN}Operating System: {Fore.WHITE}{os_info['os']}", 0.02)
                slow_print(f"{Fore.GREEN}Confidence: {Fore.WHITE}{os_info['confidence']}%", 0.02)
                slow_print(f"{Fore.GREEN}Details: {Fore.WHITE}{os_info['details']}", 0.02)
        
        elif choice == '7':
            target = input(f"{Fore.YELLOW}Enter target for comprehensive report: ").strip()
            if target:
                slow_print(f"\n{Fore.YELLOW}📊 Generating comprehensive report...", 0.02)
                time.sleep(2)
                
                report = scanner.generate_scan_report(target)
                display_comprehensive_report(report)
        
        elif choice == '8':
            slow_print(f"\n{Fore.YELLOW}👋 Thanks for using DarkScan! Scan responsibly!", 0.03)
            break
        
        else:
            slow_print(f"{Fore.RED}❌ Invalid choice. Please try again.", 0.02)
        
        if choice != '8':
            slow_print(f"\n{Fore.MAGENTA}Press Enter to continue...", 0.02)
            input()
            print_header()

if __name__ == "__main__":
    main()
