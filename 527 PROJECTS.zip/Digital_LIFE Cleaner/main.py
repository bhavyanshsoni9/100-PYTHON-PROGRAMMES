import os
import shutil

def delete_files_in_folder(folder_path):
    try:
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
    except Exception as e:
        print(f'Error: {e}')

def clean_system():
    folders_to_clean = [
        os.getenv('TEMP'),
        os.path.expanduser('~\\AppData\\Local\\Temp'),
        os.path.expanduser('~\\Downloads')
    ]
    for folder in folders_to_clean:
        print(f'Cleaning {folder} ...')
        delete_files_in_folder(folder)
    print("✅ System cleaned successfully!")

if __name__ == "__main__":
    clean_system()