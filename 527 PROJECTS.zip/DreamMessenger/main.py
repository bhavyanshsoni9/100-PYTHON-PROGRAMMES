from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
import random
import json
import os

class DreamMessenger:
    def __init__(self):
        self.console = Console()
        self.dream_elements = {
            "settings": [
                "in a misty forest", "under starlit skies",
                "floating in space", "in ancient ruins",
                "beneath crystal waters", "atop cloudy peaks",
                "in a golden meadow", "through mirror halls",
                "within rainbow clouds", "beside whispering trees"
            ],
            "actions": [
                "dancing", "flying", "floating",
                "transforming", "discovering", "creating",
                "exploring", "awakening", "dreaming",
                "journeying"
            ],
            "objects": [
                "crystal orbs", "ancient books",
                "glowing butterflies", "cosmic doors",
                "ethereal lights", "mystical symbols",
                "floating islands", "sacred keys",
                "dream catchers", "time spirals"
            ],
            "emotions": [
                "wonder", "serenity", "mystery",
                "joy", "curiosity", "harmony",
                "enchantment", "peace", "inspiration",
                "tranquility"
            ]
        }
        self.saved_messages = "dream_messages.json"
        self.load_messages()
        
    def load_messages(self):
        """Load saved dream messages"""
        if os.path.exists(self.saved_messages):
            with open(self.saved_messages, 'r') as f:
                self.messages = json.load(f)
        else:
            self.messages = []
            
    def save_messages(self):
        """Save dream messages to file"""
        with open(self.saved_messages, 'w') as f:
            json.dump(self.messages, f, indent=2)
            
    def generate_message(self):
        """Generate a dream-like message"""
        templates = [
            "I found myself {setting}, where {object} were {action}, filling me with {emotion}.",
            "In the dream, I was {action} {setting}, surrounded by {object}, feeling deep {emotion}.",
            "The vision showed me {object} {setting}, as I felt {emotion} while {action}.",
            "Through the dreamscape, {setting}, I discovered {object} that brought {emotion}.",
            "As I wandered {setting}, {object} began {action}, awakening {emotion}."
        ]
        
        return random.choice(templates).format(
            setting=random.choice(self.dream_elements["settings"]),
            action=random.choice(self.dream_elements["actions"]),
            object=random.choice(self.dream_elements["objects"]),
            emotion=random.choice(self.dream_elements["emotions"])
        )
        
    def view_messages(self):
        """Display saved dream messages"""
        if not self.messages:
            self.console.print("No saved dream messages yet...", style="bold yellow")
            return
            
        for i, msg in enumerate(self.messages, 1):
            self.console.print(Panel(
                msg,
                title=f"✨ Dream {i}",
                border_style="cyan"
            ))
            
    def run(self):
        while True:
            self.console.print("\n🌙 DreamMessenger - Dream-like Message Generator", style="bold purple")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4"],
                default="1"
            )
            
            if choice == "1":
                message = self.generate_message()
                self.console.print(Panel(
                    message,
                    title="✨ Generated Dream Message",
                    border_style="purple"
                ))
                
                if Prompt.ask("Save this dream message?", choices=["y", "n"], default="n") == "y":
                    self.messages.append(message)
                    self.save_messages()
                    self.console.print("Dream message saved!", style="bold green")
                    
            elif choice == "2":
                self.view_messages()
                
            elif choice == "3":
                if self.messages:
                    self.messages.pop()
                    self.save_messages()
                    self.console.print("Last dream message removed.", style="bold yellow")
                else:
                    self.console.print("No messages to remove.", style="bold red")
                    
            elif choice == "4":
                self.console.print("Sweet dreams! 👋", style="bold purple")
                break
                
if __name__ == "__main__":
    messenger = DreamMessenger()
    messenger.run() 