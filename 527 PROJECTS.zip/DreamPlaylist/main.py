from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table
import random
import json
import os

class DreamPlaylist:
    def __init__(self):
        self.console = Console()
        self.dream_themes = {
            "ethereal": {
                "genres": ["Ambient", "Dream Pop", "Space Music"],
                "moods": ["Floating", "Peaceful", "Mystical"],
                "instruments": ["Synthesizer", "Chimes", "Strings"]
            },
            "cosmic": {
                "genres": ["Space Rock", "Electronic", "Progressive"],
                "moods": ["Expansive", "Otherworldly", "Infinite"],
                "instruments": ["Theremin", "Synthesizer", "Echoes"]
            },
            "nature": {
                "genres": ["New Age", "World Music", "Folk"],
                "moods": ["Organic", "Flowing", "Grounded"],
                "instruments": ["Flute", "Wind Chimes", "Acoustic Guitar"]
            },
            "mystic": {
                "genres": ["World Fusion", "Tribal", "Meditation"],
                "moods": ["Ancient", "Spiritual", "Deep"],
                "instruments": ["Singing Bowls", "Drums", "Bells"]
            }
        }
        
        self.songs_database = {
            "ethereal": [
                {"title": "Stardust Dreams", "artist": "Luna Echo", "duration": "5:23"},
                {"title": "Crystal Caves", "artist": "Ethereal Whispers", "duration": "6:15"},
                {"title": "Floating Through Time", "artist": "Dream Weavers", "duration": "4:45"}
            ],
            "cosmic": [
                {"title": "Nebula Dance", "artist": "Cosmic Pulse", "duration": "7:12"},
                {"title": "Solar Winds", "artist": "Star Sailors", "duration": "6:30"},
                {"title": "Galactic Dreams", "artist": "Space Drifters", "duration": "8:15"}
            ],
            "nature": [
                {"title": "Forest Whispers", "artist": "Earth Songs", "duration": "4:55"},
                {"title": "River's Flow", "artist": "Nature's Voice", "duration": "5:40"},
                {"title": "Mountain Dreams", "artist": "Wild Echo", "duration": "6:20"}
            ],
            "mystic": [
                {"title": "Ancient Memories", "artist": "Temple Sounds", "duration": "7:45"},
                {"title": "Sacred Path", "artist": "Spirit Walker", "duration": "6:50"},
                {"title": "Mystic Journey", "artist": "Dream Shamans", "duration": "8:30"}
            ]
        }
        
        self.playlists_file = "dream_playlists.json"
        self.load_playlists()
        
    def load_playlists(self):
        """Load saved playlists"""
        if os.path.exists(self.playlists_file):
            with open(self.playlists_file, 'r') as f:
                self.playlists = json.load(f)
        else:
            self.playlists = {}
            
    def save_playlists(self):
        """Save playlists to file"""
        with open(self.playlists_file, 'w') as f:
            json.dump(self.playlists, f, indent=2)
            
    def generate_playlist(self, theme, length=5):
        """Generate a themed playlist"""
        if theme not in self.dream_themes:
            raise ValueError("Invalid theme")
            
        # Get songs for the theme
        available_songs = self.songs_database[theme]
        
        # Select random songs
        selected_songs = random.sample(
            available_songs,
            min(length, len(available_songs))
        )
        
        # Add some songs from other themes for variety
        other_themes = [t for t in self.dream_themes if t != theme]
        for other_theme in random.sample(other_themes, min(2, len(other_themes))):
            if len(selected_songs) < length:
                selected_songs.append(
                    random.choice(self.songs_database[other_theme])
                )
                
        random.shuffle(selected_songs)
        return selected_songs
        
    def display_playlist(self, name, songs):
        """Display a playlist in a table format"""
        table = Table(title=f"✨ {name}")
        table.add_column("Track", style="cyan")
        table.add_column("Artist", style="magenta")
        table.add_column("Duration", style="green")
        
        for song in songs:
            table.add_row(
                song["title"],
                song["artist"],
                song["duration"]
            )
            
        self.console.print(table)
        
    def run(self):
        while True:
            self.console.print("\n🎵 DreamPlaylist - Dream-themed Music Generator", style="bold blue")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4"],
                default="1"
            )
            
            if choice == "1":
                self.console.print("\nAvailable Themes:")
                for theme in self.dream_themes:
                    self.console.print(f"- {theme.title()}", style="cyan")
                    
                theme = Prompt.ask("\nChoose a theme").lower()
                if theme not in self.dream_themes:
                    self.console.print("Invalid theme!", style="bold red")
                    continue
                    
                name = Prompt.ask("Name your playlist")
                length = int(Prompt.ask("Number of songs (1-10)", default="5"))
                
                try:
                    playlist = self.generate_playlist(theme, length)
                    self.playlists[name] = {
                        "theme": theme,
                        "songs": playlist
                    }
                    self.save_playlists()
                    
                    self.console.print(f"\n✨ Generated Playlist: {name}")
                    self.display_playlist(name, playlist)
                    
                except Exception as e:
                    self.console.print(f"Error: {str(e)}", style="bold red")
                    
            elif choice == "2":
                if not self.playlists:
                    self.console.print("No saved playlists.", style="bold yellow")
                    continue
                    
                self.console.print("\nSaved Playlists:")
                for name in self.playlists:
                    self.console.print(f"- {name}", style="cyan")
                    
                name = Prompt.ask("\nChoose a playlist to view")
                if name in self.playlists:
                    self.display_playlist(
                        name,
                        self.playlists[name]["songs"]
                    )
                else:
                    self.console.print("Playlist not found!", style="bold red")
                    
            elif choice == "3":
                if not self.playlists:
                    self.console.print("No playlists to delete.", style="bold yellow")
                    continue
                    
                name = Prompt.ask("Enter playlist name to delete")
                if name in self.playlists:
                    del self.playlists[name]
                    self.save_playlists()
                    self.console.print(f"Deleted playlist: {name}", style="bold green")
                else:
                    self.console.print("Playlist not found!", style="bold red")
                    
            elif choice == "4":
                self.console.print("Sweet musical dreams! 👋", style="bold blue")
                break
                
if __name__ == "__main__":
    playlist = DreamPlaylist()
    playlist.run() 