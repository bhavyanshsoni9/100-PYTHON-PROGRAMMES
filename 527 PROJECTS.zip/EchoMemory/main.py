from rich.console import Console
from rich.panel import Panel
import random
import time
import os

console = Console()

class EchoMemory:
    def __init__(self):
        self.patterns = []
        self.level = 1
        self.score = 0
        self.colors = ['red', 'blue', 'green', 'yellow', 'magenta', 'cyan']
        self.symbols = ['♦', '♥', '♠', '♣', '★', '⚡']

    def generate_pattern(self):
        """Generate a new pattern"""
        return random.choice(self.symbols), random.choice(self.colors)

    def display_pattern(self, pattern, duration=1):
        """Display the pattern sequence"""
        console.clear()
        for symbol, color in pattern:
            panel = Panel(
                f"[{color}]{symbol * 3}[/]",
                border_style=color
            )
            console.print(panel)
            time.sleep(duration)
            console.clear()
            time.sleep(0.5)

    def get_input(self):
        """Get player input"""
        console.print("\n[bold]Enter the pattern:[/]")
        console.print("Colors: " + ", ".join(self.colors))
        console.print("Symbols: " + ", ".join(self.symbols))
        
        player_pattern = []
        for i in range(len(self.patterns)):
            console.print(f"\nPattern {i+1}:")
            symbol = input("Symbol: ").strip()
            color = input("Color: ").strip().lower()
            player_pattern.append((symbol, color))
        return player_pattern

    def play_round(self):
        """Play one round"""
        new_pattern = self.generate_pattern()
        self.patterns.append(new_pattern)
        
        console.print(f"\n[bold]Level {self.level}[/] - Remember this pattern!")
        time.sleep(2)
        
        self.display_pattern(self.patterns)
        player_pattern = self.get_input()
        
        if player_pattern == self.patterns:
            self.score += len(self.patterns) * 10
            self.level += 1
            return True
        return False

def main():
    console.clear()
    console.print("[bold cyan]🔄 EchoMemory[/]")
    console.print("[cyan]Test Your Memory with Echo Patterns[/]\n")

    game = EchoMemory()
    high_score = 0

    while True:
        console.print("\n[bold cyan]Options:[/]")
        console.print("1. New Game")
        console.print("2. View High Score")
        console.print("3. Exit")

        choice = input("\nSelect option (1-3): ").strip()

        if choice == '3':
            console.print("\n[cyan]Thanks for playing! 👋[/]")
            break

        if choice == '1':
            game = EchoMemory()
            console.print("\n[cyan]Game starting...[/]")
            
            while True:
                if not game.play_round():
                    console.print(f"\n[red]Game Over![/]")
                    console.print(f"[cyan]Final Score: {game.score}[/]")
                    console.print(f"[cyan]Levels Completed: {game.level - 1}[/]")
                    
                    if game.score > high_score:
                        high_score = game.score
                        console.print("[bold cyan]New High Score![/]")
                    break
                
                console.print(f"\n[green]Correct! Score: {game.score}[/]")
                proceed = input("\nContinue to next level? (y/n): ").lower()
                if proceed != 'y':
                    break

        elif choice == '2':
            panel = Panel(
                f"[bold]{high_score}[/]",
                title="[bold cyan]High Score[/]",
                border_style="cyan"
            )
            console.print(panel)

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 