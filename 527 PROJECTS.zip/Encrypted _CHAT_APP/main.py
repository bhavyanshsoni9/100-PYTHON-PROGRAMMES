from cryptography.fernet import Fernet

def generate_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)

def load_key():
    return open("secret.key", "rb").read()

def encrypt_message(message, key):
    return Fernet(key).encrypt(message.encode())

def decrypt_message(encrypted_message, key):
    return Fernet(key).decrypt(encrypted_message).decode()

def main():
    if not os.path.exists("secret.key"):
        generate_key()
    key = load_key()

    while True:
        choice = input("\n1. Encrypt Message\n2. Decrypt Message\n3. Exit\nChoose: ")
        if choice == '1':
            msg = input("Enter message: ")
            enc = encrypt_message(msg, key)
            print(f"Encrypted: {enc}")
        elif choice == '2':
            enc = input("Enter encrypted message: ").encode()
            try:
                dec = decrypt_message(enc, key)
                print(f"Decrypted: {dec}")
            except:
                print("Invalid encrypted message!")
        elif choice == '3':
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()