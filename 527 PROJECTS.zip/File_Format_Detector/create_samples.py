# This script creates sample files with correct headers for testing the file format detector

def create_png():
    with open('sample.png', 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + b'\x00' * 8)

def create_jpg():
    with open('sample.jpg', 'wb') as f:
        f.write(b'\xFF\xD8\xFF' + b'\x00' * 8)

def create_pdf():
    with open('sample.pdf', 'wb') as f:
        f.write(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')

def create_zip():
    with open('sample.zip', 'wb') as f:
        f.write(b'PK\x03\x04' + b'\x00' * 8)

def create_gif():
    with open('sample.gif', 'wb') as f:
        f.write(b'GIF89a' + b'\x00' * 8)

def create_txt():
    with open('sample.txt', 'w') as f:
        f.write('Hello, this is a text file.')

def main():
    create_png()
    create_jpg()
    create_pdf()
    create_zip()
    create_gif()
    create_txt()
    print('Sample files created: sample.png, sample.jpg, sample.pdf, sample.zip, sample.gif, sample.txt')

if __name__ == '__main__':
    main()