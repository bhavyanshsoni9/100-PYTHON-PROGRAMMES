# Terminal File Summarizer 📁📝

A terminal-based Python app that reads `.txt` and `.docx` files from a folder and provides concise summaries with colored headings, emojis, and smooth output display.

## Features
- Reads all `.txt` and (optionally) `.docx` files from a folder
- Summarizes content (first 3 sentences)
- Colorful, emoji-enhanced terminal UI
- Smooth, readable output with delays

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   python summarizer.py
   ```
3. Add your `.txt` or `.docx` files to the `files_to_summarize` folder (created on first run).

## Notes
- For `.docx` support, ensure `python-docx` is installed (included in requirements).
- Summaries are basic (first 3 sentences). You can improve the summarization logic as needed.

Enjoy summarizing your files! 🚀 