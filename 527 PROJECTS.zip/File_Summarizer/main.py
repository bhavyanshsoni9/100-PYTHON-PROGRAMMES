import os
import time
from colorama import Fore, Style, init
from pathlib import Path
import sys

# Optional: For .docx support
try:
    import docx
    DOCX_SUPPORT = True
except ImportError:
    DOCX_SUPPORT = False

init(autoreset=True)

FOLDER = 'files_to_summarize'  # Folder to read files from

def print_slow(text, delay=0.03):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def summarize_text(text, max_sentences=3):
    import re
    sentences = re.split(r'(?<=[.!?]) +', text)
    summary = ' '.join(sentences[:max_sentences])
    return summary if summary else text[:200] + '...'

def read_txt_file(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()

def read_docx_file(filepath):
    if not DOCX_SUPPORT:
        return None
    doc = docx.Document(filepath)
    return '\n'.join([para.text for para in doc.paragraphs])

def main():
    print(Fore.CYAN + Style.BRIGHT + '\n📁 File Summarizer App\n' + Style.RESET_ALL)
    time.sleep(0.5)

    folder = Path(FOLDER)
    if not folder.exists():
        print(Fore.YELLOW + Style.BRIGHT + f'📂 Creating folder: {FOLDER}')
        folder.mkdir()
        print(Fore.YELLOW + '📝 Please add .txt or .docx files to summarize and rerun the app.')
        return

    files = list(folder.glob('*.txt'))
    if DOCX_SUPPORT:
        files += list(folder.glob('*.docx'))

    if not files:
        print(Fore.RED + '❌ No .txt or .docx files found in the folder.')
        return

    for file in files:
        print(Fore.CYAN + f'🔄 Loading file: {file.name} ...')
        time.sleep(0.3)

        if file.suffix == '.txt':
            content = read_txt_file(file)
        elif file.suffix == '.docx' and DOCX_SUPPORT:
            content = read_docx_file(file)
        else:
            print(Fore.YELLOW + '⚠️ Unsupported file type or missing docx module.')
            continue

        if not content or not content.strip():
            print(Fore.RED + '⚠️ File is empty, skipping...')
            continue

        print(Fore.GREEN + f'\n📄 Summarizing: {file.name}')
        time.sleep(0.5)
        summary = summarize_text(content)

        print(Fore.MAGENTA + Style.BRIGHT + '📝 Summary:')
        print_slow(Fore.WHITE + summary)
        print(Fore.BLUE + '-'*40)
        time.sleep(1)

    print(Fore.CYAN + Style.BRIGHT + '\n✅ All files summarized successfully! Thanks for using 📁 File Summarizer App.\n')

if __name__ == '__main__':
    main()
