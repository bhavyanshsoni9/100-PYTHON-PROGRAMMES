import os
import filecmp
import hashlib
import time
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

def get_all_files_and_dirs(root):
    """Recursively get all files and directories relative to root."""
    all_items = set()
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        if rel_dir == ".":
            rel_dir = ""
        for d in dirnames:
            all_items.add(os.path.join(rel_dir, d))
        for f in filenames:
            all_items.add(os.path.join(rel_dir, f))
    return all_items

def file_hash(path, block_size=65536):
    """Return SHA256 hash of a file."""
    sha = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            data = f.read(block_size)
            if not data:
                break
            sha.update(data)
    return sha.hexdigest()

def compare_folders(folder1, folder2):
    items1 = get_all_files_and_dirs(folder1)
    items2 = get_all_files_and_dirs(folder2)

    only_in_1 = items1 - items2
    only_in_2 = items2 - items1
    in_both = items1 & items2

    differences = []

    for item in sorted(only_in_1):
        differences.append((f"{Fore.GREEN}🟢 Only in Folder 1: {item}{Style.RESET_ALL}",))
    for item in sorted(only_in_2):
        differences.append((f"{Fore.RED}🔴 Only in Folder 2: {item}{Style.RESET_ALL}",))
    for item in sorted(in_both):
        path1 = os.path.join(folder1, item)
        path2 = os.path.join(folder2, item)
        if os.path.isdir(path1) and os.path.isdir(path2):
            differences.append((f"{Fore.BLUE}✅ Folder in both: {item}{Style.RESET_ALL}",))
        elif os.path.isfile(path1) and os.path.isfile(path2):
            hash1 = file_hash(path1)
            hash2 = file_hash(path2)
            if hash1 == hash2:
                differences.append((f"{Fore.BLUE}✅ File identical: {item}{Style.RESET_ALL}",))
            else:
                differences.append((f"{Fore.YELLOW}🟡 File differs: {item}{Style.RESET_ALL}",))
        else:
            differences.append((f"{Fore.MAGENTA}🟣 Type mismatch: {item}{Style.RESET_ALL}",))
    return differences

def main():
    print("Folder Comparison Tool 🗂️")
    folder1 = input("Enter path to first folder: ").strip('"')
    folder2 = input("Enter path to second folder: ").strip('"')

    if not os.path.isdir(folder1) or not os.path.isdir(folder2):
        print(f"{Fore.RED}One or both paths are not valid directories.{Style.RESET_ALL}")
        return

    print(f"\nComparing:\n  1️⃣ {folder1}\n  2️⃣ {folder2}\n")
    differences = compare_folders(folder1, folder2)

    if not differences:
        print(f"{Fore.GREEN}✅ The folders are identical!{Style.RESET_ALL}")
        return

    for diff in differences:
        print(diff[0])
        input(f"{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
        # Optional: time.sleep(0.2)

    print(f"\n{Fore.CYAN}Comparison complete!{Style.RESET_ALL}")

if __name__ == "__main__":
    main() 