import os
import time
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

FOLDER_ICON = '📁'
FILE_ICON = '📄'
FOLDER_COLOR = Fore.BLUE + Style.BRIGHT
FILE_COLOR = Fore.GREEN


def print_tree(path, prefix="", is_last=True, level=0, sleep_time=0.5):
    """
    Recursively prints the folder structure as a tree with colors and emojis.
    """
    basename = os.path.basename(path)
    if os.path.isdir(path):
        print(f"{prefix}{FOLDER_COLOR}{FOLDER_ICON} {basename}{Style.RESET_ALL}")
        time.sleep(sleep_time)
        entries = sorted(os.listdir(path))
        for i, entry in enumerate(entries):
            full_path = os.path.join(path, entry)
            is_last_entry = (i == len(entries) - 1)
            new_prefix = prefix + ("    " if is_last else "│   ")
            print_tree(full_path, new_prefix, is_last_entry, level+1, sleep_time)
    else:
        print(f"{prefix}{FILE_COLOR}{FILE_ICON} {basename}{Style.RESET_ALL}")
        time.sleep(sleep_time)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Visualize folder structure as a tree with colors and emojis.")
    parser.add_argument("path", nargs="?", default=None, help="Root folder path (default: prompt user)")
    parser.add_argument("--sleep", type=float, default=0.5, help="Pause duration between steps (seconds)")
    args = parser.parse_args()

    # Prompt for path if not provided
    if args.path is None:
        user_input = input("Enter the folder path (leave blank for current directory): ").strip()
        path = user_input if user_input else "."
    else:
        path = args.path

    print_tree(os.path.abspath(path), sleep_time=args.sleep)


if __name__ == "__main__":
    main() 