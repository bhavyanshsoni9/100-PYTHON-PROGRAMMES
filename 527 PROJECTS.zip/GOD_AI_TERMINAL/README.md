# GOD AI TERMINAL v1.0

This is a terminal-based personal offline AI companion featuring:

- Task manager
- Secure vault (coming soon)
- Games hub (coming soon)
- File tools (coming soon)
- Voice control (coming soon)

Built with Python and Colorama for colored console output.

## Usage

Run `python main.py` and use commands like `tasks`, `vault`, `games`, `files`, `speak`, and `exit`.

## License

MIT License