def run_tools():
    print("\nFile tools module coming soon...")
    input("Press Enter to return to main menu.")