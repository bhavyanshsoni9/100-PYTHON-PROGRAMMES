def listen():
    print("\nVoice control module coming soon...")
    input("Press Enter to return to main menu.")