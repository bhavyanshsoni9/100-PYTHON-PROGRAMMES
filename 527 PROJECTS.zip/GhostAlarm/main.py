import time
import json
import os
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.progress import Progress
from datetime import datetime, timedelta
import threading
from plyer import notification
import random

# Initialize Rich console
console = Console()

# Ghost-themed notification styles
GHOST_EMOJIS = '👻 👽 🌌 🌙 ⭐'
GHOST_MESSAGES = [
    "A whisper from the void...",
    "The spirits have a message...",
    "A ghostly reminder appears...",
    "From the shadows...",
    "The mist brings a message..."
]

class GhostAlarm:
    def __init__(self):
        self.alarms_file = "ghost_alarms.json"
        self.alarms = self.load_alarms()
        self.notification_thread = None
        self.running = False

    def load_alarms(self):
        """Load alarms from the ethereal plane"""
        if os.path.exists(self.alarms_file):
            try:
                with open(self.alarms_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def save_alarms(self):
        """Save alarms to the ethereal plane"""
        with open(self.alarms_file, 'w') as f:
            json.dump(self.alarms, f, indent=2)

    def add_alarm(self, time_str, message, repeat=False):
        """Add a new ghostly alarm"""
        try:
            # Parse time string (HH:MM or MM:SS)
            if ':' in time_str:
                parts = time_str.split(':')
                if len(parts) == 2:
                    hours, minutes = map(int, parts)
                    if hours < 24 and minutes < 60:
                        alarm = {
                            'id': len(self.alarms) + 1,
                            'time': time_str,
                            'message': message,
                            'repeat': repeat,
                            'active': True,
                            'created': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        }
                        self.alarms.append(alarm)
                        self.save_alarms()
                        return True, alarm
            return False, "Invalid time format (use HH:MM)"
        except:
            return False, "Error creating alarm"

    def toggle_alarm(self, alarm_id):
        """Toggle a ghostly alarm"""
        for alarm in self.alarms:
            if alarm['id'] == alarm_id:
                alarm['active'] = not alarm['active']
                self.save_alarms()
                return True
        return False

    def delete_alarm(self, alarm_id):
        """Banish an alarm to the void"""
        self.alarms = [a for a in self.alarms if a['id'] != alarm_id]
        self.save_alarms()

    def check_alarms(self):
        """Check for active alarms in the ethereal plane"""
        while self.running:
            current_time = datetime.now().strftime("%H:%M")
            
            for alarm in self.alarms:
                if alarm['active'] and alarm['time'] == current_time:
                    self.trigger_alarm(alarm)
                    if not alarm['repeat']:
                        alarm['active'] = False
            
            self.save_alarms()
            time.sleep(30)  # Check every 30 seconds

    def trigger_alarm(self, alarm):
        """Trigger a ghostly notification"""
        ghost = random.choice(GHOST_EMOJIS.split())
        title = random.choice(GHOST_MESSAGES)
        
        notification.notify(
            title=f"{ghost} {title}",
            message=alarm['message'],
            app_icon=None,  # You can add a custom icon here
            timeout=10
        )

def type_print(text, delay=0.03):
    """Print text with ghostly effect"""
    for char in text:
        style = random.choice(['bold cyan', 'bold blue', 'bold white'])
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def display_alarms(alarms):
    """Display alarms in a ghostly table"""
    if not alarms:
        console.print(Panel("No alarms in the ethereal plane...",
                          style="dim cyan",
                          title="Ghost Alarms"))
        return
    
    table = Table(title="[bold]Ghostly Alarms[/]")
    table.add_column("ID", style="cyan")
    table.add_column("Time", style="blue")
    table.add_column("Message", style="white")
    table.add_column("Status", style="magenta")
    table.add_column("Repeat", style="green")
    
    for alarm in alarms:
        status = "[green]Active[/]" if alarm['active'] else "[red]Inactive[/]"
        repeat = "🔄" if alarm['repeat'] else "✨"
        
        table.add_row(
            str(alarm['id']),
            alarm['time'],
            alarm['message'],
            status,
            repeat
        )
    
    console.print(table)

def simulate_ghost_effect():
    """Create a ghost animation effect"""
    ghost_frames = ['👻', '👻 ', '👻  ', ' 👻 ', '  👻', ' 👻 ', '👻  ']
    
    with Progress() as progress:
        task = progress.add_task("[cyan]Summoning ghost...[/]", total=100)
        
        for frame in ghost_frames:
            console.print(f"\r{frame}", end='')
            progress.update(task, advance=15)
            time.sleep(0.1)
    print()

def main():
    """Main program with ghostly interface"""
    ghost_alarm = GhostAlarm()
    console.clear()
    
    type_print("👻 Welcome to GhostAlarm", delay=0.05)
    type_print("   Silent Notifications from the Void", delay=0.03)
    print()
    
    # Start the alarm checker thread
    ghost_alarm.running = True
    ghost_alarm.notification_thread = threading.Thread(
        target=ghost_alarm.check_alarms,
        daemon=True
    )
    ghost_alarm.notification_thread.start()
    
    while True:
        try:
            console.print("\n[cyan]Ghostly Operations:[/]")
            console.print("1. [white]Set New Alarm[/]")
            console.print("2. [white]View Alarms[/]")
            console.print("3. [white]Toggle Alarm[/]")
            console.print("4. [white]Delete Alarm[/]")
            console.print("5. [white]Exit[/]")
            
            choice = input("\nSelect operation (1-5): ").strip()
            
            if choice == '1':
                time_str = input("\nEnter alarm time (HH:MM): ").strip()
                message = input("Enter message: ").strip()
                repeat = input("Repeat daily? (y/n): ").strip().lower() == 'y'
                
                simulate_ghost_effect()
                success, result = ghost_alarm.add_alarm(time_str, message, repeat)
                
                if success:
                    type_print("\n👻 Ghostly alarm has been set!", delay=0.03)
                else:
                    console.print(f"\n[red]Error: {result}[/]")
                
            elif choice == '2':
                console.clear()
                type_print("👻 Viewing Ethereal Alarms", delay=0.03)
                print()
                display_alarms(ghost_alarm.alarms)
                input("\nPress Enter to continue...")
                
            elif choice == '3':
                console.clear()
                display_alarms(ghost_alarm.alarms)
                
                alarm_id = input("\nEnter alarm ID to toggle: ").strip()
                try:
                    alarm_id = int(alarm_id)
                    if ghost_alarm.toggle_alarm(alarm_id):
                        simulate_ghost_effect()
                        type_print("\n👻 Alarm state has shifted!", delay=0.03)
                    else:
                        console.print("[red]Alarm not found in the void.[/]")
                except:
                    console.print("[red]Invalid alarm ID.[/]")
                
            elif choice == '4':
                console.clear()
                display_alarms(ghost_alarm.alarms)
                
                alarm_id = input("\nEnter alarm ID to banish: ").strip()
                try:
                    alarm_id = int(alarm_id)
                    ghost_alarm.delete_alarm(alarm_id)
                    simulate_ghost_effect()
                    type_print("\n👻 Alarm has been banished to the void!", delay=0.03)
                except:
                    console.print("[red]Invalid alarm ID.[/]")
                
            elif choice == '5':
                type_print("\n👻 Fading back into the shadows...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("👻 Emergency ethereal exit...", delay=0.05)
            break
    
    ghost_alarm.running = False

if __name__ == "__main__":
    main() 