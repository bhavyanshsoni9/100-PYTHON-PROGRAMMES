#!/usr/bin/env python3
"""
Glitch Art Creator - Advanced Digital Art Generator
A powerful glitch art creation tool with multiple effects and real-time preview.

Features:
- ASCII art generation and manipulation
- Multiple glitch effects and filters
- Real-time preview and editing
- Color palette manipulation
- Pattern generation and distortion
- Export capabilities
"""

import sys
import time
import os
import random
import math
from typing import List, Tuple, Dict

class Colors:
    """ANSI color codes for terminal styling"""
    RESET = '\033'
    BOLD = '\033[1m'
    RED = '\033❌'
    GREEN = '\033✅'
    YELLOW = '\033⚠️'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    DIM = '\033[2m'

class GlitchCanvas:
    """Represents a canvas for glitch art creation"""
    def __init__(self, width: int = 80, height: int = 20):
        self.width = width
        self.height = height
        self.canvas = [[' ' for _ in range(width)] for _ in range(height)]
        self.colors = [[Colors.WHITE for _ in range(width)] for _ in range(height)]
        self.effects_history = []
        
    def clear(self):
        """Clear the canvas"""
        self.canvas = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        self.colors = [[Colors.WHITE for _ in range(self.width)] for _ in range(self.height)]
        
    def set_pixel(self, x: int, y: int, char: str, color: str = Colors.WHITE):
        """Set a pixel on the canvas"""
        if 0 <= x < self.width and 0 <= y < self.height:
            self.canvas[y][x] = char
            self.colors[y][x] = color
            
    def get_pixel(self, x: int, y: int) -> Tuple[str, str]:
        """Get a pixel from the canvas"""
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.canvas[y][x], self.colors[y][x]
        return ' ', Colors.WHITE
        
    def display(self):
        """Display the canvas"""
        print('\033[2J\033[H', end='')  # Clear screen
        for y in range(self.height):
            line = ""
            for x in range(self.width):
                char = self.canvas[y][x]
                color = self.colors[y][x]
                line += f"{color}{char}{Colors.RESET}"
            print(line)

class GlitchEffects:
    """Collection of glitch effects for art creation"""
    
    @staticmethod
    def data_corruption(canvas: GlitchCanvas, intensity: float = 0.1):
        """Simulate data corruption effect"""
        corruption_chars = ['▓', '▒', '░', '█', '▄', '▀', '▬', '▐', '▌']
        corruption_colors = [Colors.BRIGHT_RED, Colors.BRIGHT_GREEN, Colors.BRIGHT_BLUE, 
                           Colors.BRIGHT_MAGENTA, Colors.BRIGHT_CYAN]
        
        for y in range(canvas.height):
            for x in range(canvas.width):
                if random.random() < intensity:
                    char = random.choice(corruption_chars)
                    color = random.choice(corruption_colors)
                    canvas.set_pixel(x, y, char, color)
                    
    @staticmethod
    def rgb_shift(canvas: GlitchCanvas, shift_amount: int = 3):
        """Create RGB color shift effect"""
        new_canvas = [[' ' for _ in range(canvas.width)] for _ in range(canvas.height)]
        new_colors = [[Colors.WHITE for _ in range(canvas.width)] for _ in range(canvas.height)]
        
        # Shift red channel
        for y in range(canvas.height):
            for x in range(canvas.width):
                source_x = max(0, x - shift_amount)
                if canvas.canvas[y][source_x] != ' ':
                    new_canvas[y][x] = canvas.canvas[y][source_x]
                    new_colors[y][x] = Colors.BRIGHT_RED
                    
        # Shift blue channel
        for y in range(canvas.height):
            for x in range(canvas.width):
                source_x = min(canvas.width - 1, x + shift_amount)
                if canvas.canvas[y][source_x] != ' ' and new_canvas[y][x] == ' ':
                    new_canvas[y][x] = canvas.canvas[y][source_x]
                    new_colors[y][x] = Colors.BRIGHT_BLUE
                    
        canvas.canvas = new_canvas
        canvas.colors = new_colors
        
    @staticmethod
    def scan_lines(canvas: GlitchCanvas, line_spacing: int = 3):
        """Add scan line effect"""
        for y in range(0, canvas.height, line_spacing):
            for x in range(canvas.width):
                if canvas.canvas[y][x] == ' ':
                    canvas.set_pixel(x, y, '─', Colors.DIM)
                    
    @staticmethod
    def pixel_sort(canvas: GlitchCanvas, threshold: int = 10):
        """Create pixel sorting effect"""
        for y in range(canvas.height):
            # Get row data
            row_chars = [canvas.canvas[y][x] for x in range(canvas.width)]
            row_colors = [canvas.colors[y][x] for x in range(canvas.width)]
            
            # Find sorting intervals
            intervals = []
            start = 0
            for x in range(canvas.width):
                if x - start > threshold or x == canvas.width - 1:
                    intervals.append((start, x))
                    start = x
                    
            # Sort each interval
            for start, end in intervals:
                segment_chars = row_chars[start:end]
                segment_colors = row_colors[start:end]
                
                # Sort by character ASCII value
                sorted_data = sorted(zip(segment_chars, segment_colors), key=lambda x: ord(x[0]) if x[0] != ' ' else 0)
                
                for i, (char, color) in enumerate(sorted_data):
                    if start + i < canvas.width:
                        canvas.set_pixel(start + i, y, char, color)
                        
    @staticmethod
    def wave_distortion(canvas: GlitchCanvas, amplitude: int = 3, frequency: float = 0.5):
        """Apply wave distortion effect"""
        new_canvas = [[' ' for _ in range(canvas.width)] for _ in range(canvas.height)]
        new_colors = [[Colors.WHITE for _ in range(canvas.width)] for _ in range(canvas.height)]
        
        for y in range(canvas.height):
            offset = int(amplitude * math.sin(y * frequency))
            for x in range(canvas.width):
                source_x = x + offset
                if 0 <= source_x < canvas.width:
                    new_canvas[y][x] = canvas.canvas[y][source_x]
                    new_colors[y][x] = canvas.colors[y][source_x]
                    
        canvas.canvas = new_canvas
        canvas.colors = new_colors

class PatternGenerator:
    """Generates various patterns for glitch art"""
    
    @staticmethod
    def geometric_pattern(canvas: GlitchCanvas, pattern_type: str = 'squares'):
        """Generate geometric patterns"""
        if pattern_type == 'squares':
            for y in range(0, canvas.height, 4):
                for x in range(0, canvas.width, 8):
                    color = random.choice([Colors.BRIGHT_RED, Colors.BRIGHT_GREEN, Colors.BRIGHT_BLUE])
                    for dy in range(min(3, canvas.height - y)):
                        for dx in range(min(6, canvas.width - x)):
                            canvas.set_pixel(x + dx, y + dy, '█', color)
                            
        elif pattern_type == 'lines':
            for i in range(0, canvas.width, 5):
                color = random.choice([Colors.BRIGHT_CYAN, Colors.BRIGHT_MAGENTA, Colors.BRIGHT_YELLOW])
                for y in range(canvas.height):
                    canvas.set_pixel(i, y, '│', color)
                    
        elif pattern_type == 'dots':
            for y in range(2, canvas.height, 4):
                for x in range(2, canvas.width, 6):
                    color = random.choice([Colors.BRIGHT_WHITE, Colors.BRIGHT_RED, Colors.BRIGHT_BLUE])
                    canvas.set_pixel(x, y, '●', color)
                    
    @staticmethod
    def noise_pattern(canvas: GlitchCanvas, density: float = 0.3):
        """Generate random noise pattern"""
        noise_chars = ['·', '░', '▒', '▓', '█']
        noise_colors = [Colors.WHITE, Colors.DIM, Colors.BRIGHT_WHITE]
        
        for y in range(canvas.height):
            for x in range(canvas.width):
                if random.random() < density:
                    char = random.choice(noise_chars)
                    color = random.choice(noise_colors)
                    canvas.set_pixel(x, y, char, color)
                    
    @staticmethod
    def mandala_pattern(canvas: GlitchCanvas):
        """Generate mandala-like pattern"""
        center_x = canvas.width // 2
        center_y = canvas.height // 2
        
        for y in range(canvas.height):
            for x in range(canvas.width):
                dx = x - center_x
                dy = y - center_y
                distance = math.sqrt(dx*dx + dy*dy)
                angle = math.atan2(dy, dx)
                
                # Create pattern based on distance and angle
                pattern_value = math.sin(distance * 0.5) * math.cos(angle * 6)
                
                if pattern_value > 0.3:
                    chars = ['○', '◇', '◈', '◉']
                    colors = [Colors.BRIGHT_MAGENTA, Colors.BRIGHT_CYAN, Colors.BRIGHT_YELLOW]
                    char = chars[int(distance) % len(chars)]
                    color = colors[int(angle * 3) % len(colors)]
                    canvas.set_pixel(x, y, char, color)

class GlitchArtCreator:
    """Main glitch art creation system"""
    
    def __init__(self):
        self.canvas = GlitchCanvas()
        self.effects = GlitchEffects()
        self.patterns = PatternGenerator()
        self.current_tool = "brush"
        
    def display_banner(self):
        """Display glitch art creator banner"""
        banner = [
            "╔══════════════════════════════════════╗",
            "║         GLITCH ART CREATOR           ║",
            "║       Digital Chaos Generator        ║",
            "╚══════════════════════════════════════╝"
        ]
        
        print("\n")
        for line in banner:
            print(f"{Colors.BRIGHT_MAGENTA}{line}{Colors.RESET}")
        print("\n")
        
    def apply_random_glitch(self):
        """Apply a random glitch effect"""
        effects = [
            lambda: self.effects.data_corruption(self.canvas, random.uniform(0.05, 0.2)),
            lambda: self.effects.rgb_shift(self.canvas, random.randint(1, 5)),
            lambda: self.effects.scan_lines(self.canvas, random.randint(2, 5)),
            lambda: self.effects.pixel_sort(self.canvas, random.randint(5, 15)),
            lambda: self.effects.wave_distortion(self.canvas, random.randint(1, 4), random.uniform(0.2, 1.0))
        ]
        
        effect = random.choice(effects)
        effect()
        
    def create_artwork(self, art_type: str):
        """Create different types of glitch artwork"""
        self.canvas.clear()
        
        if art_type == "abstract":
            # Create abstract glitch art
            self.patterns.noise_pattern(self.canvas, 0.4)
            self.effects.rgb_shift(self.canvas, 3)
            self.effects.data_corruption(self.canvas, 0.1)
            
        elif art_type == "geometric":
            # Create geometric glitch art
            self.patterns.geometric_pattern(self.canvas, "squares")
            self.effects.pixel_sort(self.canvas, 8)
            self.effects.scan_lines(self.canvas, 4)
            
        elif art_type == "mandala":
            # Create mandala glitch art
            self.patterns.mandala_pattern(self.canvas)
            self.effects.wave_distortion(self.canvas, 2, 0.3)
            self.effects.data_corruption(self.canvas, 0.05)
            
        elif art_type == "chaos":
            # Create chaotic glitch art
            self.patterns.noise_pattern(self.canvas, 0.6)
            for _ in range(3):
                self.apply_random_glitch()
                
    def interactive_mode(self):
        """Interactive art creation mode"""
        while True:
            self.canvas.display()
            
            print(f"\n{Colors.BRIGHT_CYAN}Glitch Art Studio - Interactive Mode{Colors.RESET}")
            print(f"{Colors.BRIGHT_YELLOW}Commands:{Colors.RESET}")
            print(f"  {Colors.GREEN}1{Colors.RESET} - Data Corruption")
            print(f"  {Colors.GREEN}2{Colors.RESET} - RGB Shift")
            print(f"  {Colors.GREEN}3{Colors.RESET} - Scan Lines")
            print(f"  {Colors.GREEN}4{Colors.RESET} - Pixel Sort")
            print(f"  {Colors.GREEN}5{Colors.RESET} - Wave Distortion")
            print(f"  {Colors.GREEN}6{Colors.RESET} - Add Pattern")
            print(f"  {Colors.GREEN}r{Colors.RESET} - Random Effect")
            print(f"  {Colors.GREEN}c{Colors.RESET} - Clear Canvas")
            print(f"  {Colors.GREEN}q{Colors.RESET} - Quit")
            
            choice = input(f"\n{Colors.BRIGHT_CYAN}Enter command: {Colors.RESET}").strip().lower()
            
            if choice == '1':
                intensity = float(input("Corruption intensity (0.0-1.0): ") or "0.1")
                self.effects.data_corruption(self.canvas, intensity)
                
            elif choice == '2':
                shift = int(input("Shift amount (1-10): ") or "3")
                self.effects.rgb_shift(self.canvas, shift)
                
            elif choice == '3':
                spacing = int(input("Line spacing (1-10): ") or "3")
                self.effects.scan_lines(self.canvas, spacing)
                
            elif choice == '4':
                threshold = int(input("Sort threshold (5-20): ") or "10")
                self.effects.pixel_sort(self.canvas, threshold)
                
            elif choice == '5':
                amplitude = int(input("Wave amplitude (1-5): ") or "2")
                frequency = float(input("Wave frequency (0.1-2.0): ") or "0.5")
                self.effects.wave_distortion(self.canvas, amplitude, frequency)
                
            elif choice == '6':
                print("Pattern types: squares, lines, dots, noise, mandala")
                pattern = input("Enter pattern type: ").strip().lower()
                if pattern in ['squares', 'lines', 'dots']:
                    self.patterns.geometric_pattern(self.canvas, pattern)
                elif pattern == 'noise':
                    density = float(input("Noise density (0.0-1.0): ") or "0.3")
                    self.patterns.noise_pattern(self.canvas, density)
                elif pattern == 'mandala':
                    self.patterns.mandala_pattern(self.canvas)
                    
            elif choice == 'r':
                self.apply_random_glitch()
                
            elif choice == 'c':
                self.canvas.clear()
                
            elif choice == 'q':
                break
                
            time.sleep(0.5)  # Brief pause to see effect

def slow_print(text, delay=0.03, color=Colors.BRIGHT_MAGENTA):
    """Print text with slow typing effect"""
    for char in text:
        sys.stdout.write(color + char + Colors.RESET)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def main():
    """Main application entry point"""
    try:
        creator = GlitchArtCreator()
        
        while True:
            os.system('clear' if os.name == 'posix' else 'cls')
            creator.display_banner()
            
            slow_print("Welcome to Glitch Art Creator!", delay=0.05)
            print()
            
            slow_print("Features:", color=Colors.BRIGHT_CYAN)
            features = [
                "Multiple glitch effects and filters",
                "Real-time ASCII art manipulation",
                "Pattern generation and distortion",
                "Interactive editing mode",
                "Color palette manipulation",
                "Advanced visual effects"
            ]
            
            for i, feature in enumerate(features, 1):
                slow_print(f"  {i}. {feature}", delay=0.01, color=Colors.GREEN)
            print()
            
            print(f"{Colors.BRIGHT_CYAN}Choose an option:{Colors.RESET}")
            print(f"  {Colors.GREEN}1{Colors.RESET} - Create Abstract Art")
            print(f"  {Colors.GREEN}2{Colors.RESET} - Create Geometric Art")
            print(f"  {Colors.GREEN}3{Colors.RESET} - Create Mandala Art")
            print(f"  {Colors.GREEN}4{Colors.RESET} - Create Chaos Art")
            print(f"  {Colors.GREEN}5{Colors.RESET} - Interactive Mode")
            print(f"  {Colors.GREEN}6{Colors.RESET} - Random Generation")
            print(f"  {Colors.GREEN}q{Colors.RESET} - Quit")
            
            choice = input(f"\n{Colors.BRIGHT_CYAN}Enter choice: {Colors.RESET}").strip().lower()
            
            if choice in ['1', '2', '3', '4']:
                art_types = {'1': 'abstract', '2': 'geometric', '3': 'mandala', '4': 'chaos'}
                art_type = art_types[choice]
                
                print(f"{Colors.BRIGHT_GREEN}Creating {art_type} glitch art...{Colors.RESET}")
                creator.create_artwork(art_type)
                creator.canvas.display()
                
                input(f"\n{Colors.BRIGHT_GREEN}Press Enter to continue...{Colors.RESET}")
                
            elif choice == '5':
                creator.interactive_mode()
                
            elif choice == '6':
                print(f"{Colors.BRIGHT_GREEN}Generating random glitch art...{Colors.RESET}")
                creator.canvas.clear()
                creator.patterns.noise_pattern(creator.canvas, random.uniform(0.2, 0.5))
                
                # Apply multiple random effects
                for _ in range(random.randint(2, 5)):
                    creator.apply_random_glitch()
                    time.sleep(0.3)
                    creator.canvas.display()
                    
                input(f"\n{Colors.BRIGHT_GREEN}Press Enter to continue...{Colors.RESET}")
                
            elif choice == 'q':
                slow_print("Keep creating digital chaos!", color=Colors.BRIGHT_GREEN)
                break
                
            else:
                print(f"{Colors.BRIGHT_RED}Invalid choice!{Colors.RESET}")
                time.sleep(1)
                
    except Exception as e:
        print(f"{Colors.BRIGHT_RED}Error: {e}{Colors.RESET}")
        sys.exit(1)

if __name__ == "__main__":
    main()