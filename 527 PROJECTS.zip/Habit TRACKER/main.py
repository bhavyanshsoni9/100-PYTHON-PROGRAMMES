import json
import os
from datetime import datetime

DATA_FILE = "habits.json"

def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r") as file:
        return json.load(file)

def save_data(data):
    with open(DATA_FILE, "w") as file:
        json.dump(data, file, indent=4)

def add_habit(habit):
    data = load_data()
    if habit not in data:
        data[habit] = []
        print(f"Habit '{habit}' added!")
    else:
        print("Habit already exists.")
    save_data(data)

def mark_done(habit):
    data = load_data()
    if habit in data:
        today = datetime.now().strftime("%Y-%m-%d")
        if today not in data[habit]:
            data[habit].append(today)
            print(f"Habit '{habit}' marked as done for today.")
        else:
            print("Already marked for today.")
        save_data(data)
    else:
        print("Habit not found.")

def show_status():
    data = load_data()
    if not data:
        print("No habits found.")
        return
    print("\n----- Habit Status -----")
    for habit, dates in data.items():
        print(f"{habit}: {len(dates)} days completed. Dates: {', '.join(dates)}")

def main():
    while True:
        print("\n------ Habit Tracker ------")
        print("1. Add Habit")
        print("2. Mark Habit as Done")
        print("3. Show Habit Status")
        print("4. Exit")
        choice = input("Enter choice: ")

        if choice == "1":
            habit = input("Enter habit name: ").strip()
            add_habit(habit)
        elif choice == "2":
            habit = input("Enter habit name: ").strip()
            mark_done(habit)
        elif choice == "3":
            show_status()
        elif choice == "4":
            print("Exiting Habit Tracker...")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
