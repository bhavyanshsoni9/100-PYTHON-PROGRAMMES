#!/usr/bin/env python3
"""
Hacker Typer Game - Advanced Code Typing Simulator
A realistic code typing simulation that makes you look like a pro hacker.

Features:
- Multiple programming languages and code styles
- Realistic typing sounds and effects
- Multiple themes and color schemes
- Performance metrics and WPM tracking
- Full-screen terminal interface
- Customizable code libraries
"""

import sys
import time
import os
import random
import threading
from typing import List, Dict

class Colors:
    """ANSI color codes for terminal styling"""
    RESET = '\033'
    BOLD = '\033[1m'
    RED = '\033❌'
    GREEN = '\033✅'
    YELLOW = '\033⚠️'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    DIM = '\033[2m'

class CodeLibrary:
    """Library of realistic code snippets"""
    
    PYTHON_CODE = [
        """import numpy as np
import tensorflow as tf
from sklearn.ensemble import RandomForestClassifier

def neural_network_attack():
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(10, activation='softmax')
    ])
    
    # Compile the model
    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model""",
        
        """import socket
import threading
import hashlib

def penetration_test(target_ip, port_range):
    open_ports = []
    
    def scan_port(ip, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((ip, port))
            if result == 0:
                open_ports.append(port)
                print(f"[+] Port {port} is open")
            sock.close()
        except Exception as e:
            pass
    
    threads = []
    for port in range(port_range[0], port_range[1]):
        thread = threading.Thread(target=scan_port, args=(target_ip, port))
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    return open_ports""",
        
        """class CyberSecurityFramework:
    def __init__(self, target_system):
        self.target = target_system
        self.vulnerabilities = []
        self.exploits = {}
        
    def reconnaissance(self):
        print("[*] Gathering system information...")
        system_info = {
            'os': self.detect_os(),
            'services': self.enumerate_services(),
            'users': self.get_user_accounts(),
            'network': self.map_network()
        }
        return system_info
        
    def vulnerability_scan(self):
        print("[*] Scanning for vulnerabilities...")
        vulns = [
            "CVE-2021-44228",  # Log4j
            "CVE-2021-34527",  # PrintNightmare
            "CVE-2021-26855",  # Exchange Server
        ]
        return vulns"""
    ]
    
    JAVASCRIPT_CODE = [
        """// Advanced JavaScript Hacking Simulation
const cryptoJS = require('crypto-js');
const axios = require('axios');

class AdvancedPenetrationTesting {
    constructor(targetUrl) {
        this.target = targetUrl;
        this.payloads = [
            '<script>alert("XSS")</script>',
            "'; DROP TABLE users; --",
            '../../../etc/passwd',
            '{{7*7}}'
        ];
    }
    
    async sqlInjectionTest() {
        console.log('[*] Testing SQL Injection vulnerabilities...');
        
        for (let payload of this.payloads) {
            try {
                const response = await axios.post(this.target, {
                    username: payload,
                    password: 'test123'
                });
                
                if (response.data.includes('error') || 
                    response.data.includes('mysql') ||
                    response.data.includes('syntax')) {
                    console.log(`[+] SQL Injection found: ${payload}`);
                }
            } catch (error) {
                console.log(`[!] Error testing payload: ${payload}`);
            }
        }
    }""",
        
        """// Blockchain Security Analysis
const Web3 = require('web3');
const ethers = require('ethers');

class SmartContractAuditor {
    constructor(contractAddress) {
        this.contract = contractAddress;
        this.web3 = new Web3('wss://mainnet.infura.io/ws/v3/YOUR-PROJECT-ID');
    }
    
    async analyzeContract() {
        console.log('[*] Analyzing smart contract security...');
        
        const contractCode = await this.web3.eth.getCode(this.contract);
        
        // Check for common vulnerabilities
        const vulnerabilities = {
            reentrancy: this.checkReentrancy(contractCode),
            integerOverflow: this.checkOverflow(contractCode),
            accessControl: this.checkAccessControl(contractCode)
        };
        
        return vulnerabilities;
    }
    
    checkReentrancy(code) {
        // Simplified reentrancy detection
        return code.includes('call.value') && !code.includes('mutex');
    }
}"""
    ]
    
    C_CODE = [
        """#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

typedef struct {
    char buffer[256];
    int (*function_pointer)();
} vulnerable_struct;

// Buffer overflow exploit demonstration
int exploit_function() {
    printf("[+] Shell access gained!\\n");
    system("/bin/bash");
    return 0;
}

int main(int argc, char *argv[]) {
    vulnerable_struct vuln;
    
    printf("[*] Advanced Buffer Overflow Exploit\\n");
    printf("[*] Target: %p\\n", &vuln);
    
    // Vulnerable function - no bounds checking
    strcpy(vuln.buffer, argv[1]);
    
    // Overwrite function pointer
    vuln.function_pointer = exploit_function;
    
    // Trigger the exploit
    vuln.function_pointer();
    
    return 0;
}""",
        
        """// Network packet injection
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>

struct packet_info {
    struct iphdr ip;
    struct tcphdr tcp;
    char payload[1460];
};

void inject_packet(const char* interface, const char* target_ip) {
    pcap_t *handle;
    char errbuf[PCAP_ERRBUF_SIZE];
    
    handle = pcap_open_live(interface, BUFSIZ, 1, 1000, errbuf);
    if (handle == NULL) {
        fprintf(stderr, "Error opening device: %s\\n", errbuf);
        return;
    }
    
    struct packet_info packet;
    memset(&packet, 0, sizeof(packet));
    
    // Craft malicious packet
    packet.ip.version = 4;
    packet.ip.ihl = 5;
    packet.ip.tot_len = htons(sizeof(packet));
    
    printf("[*] Injecting packet to %s\\n", target_ip);
    
    pcap_close(handle);
}"""
    ]

class HackerTyper:
    def __init__(self):
        self.current_code = ""
        self.position = 0
        self.wpm = 0
        self.start_time = 0
        self.chars_typed = 0
        self.language = "python"
        self.theme = "matrix"
        self.auto_mode = False
        self.typing_speed = 3  # characters per keystroke
        
        self.themes = {
            'matrix': {
                'bg': Colors.RESET,
                'text': Colors.BRIGHT_GREEN,
                'comment': Colors.GREEN,
                'keyword': Colors.BRIGHT_CYAN,
                'string': Colors.BRIGHT_YELLOW
            },
            'hacker': {
                'bg': Colors.RESET,
                'text': Colors.BRIGHT_GREEN,
                'comment': Colors.DIM + Colors.GREEN,
                'keyword': Colors.BRIGHT_RED,
                'string': Colors.BRIGHT_MAGENTA
            },
            'terminal': {
                'bg': Colors.RESET,
                'text': Colors.BRIGHT_WHITE,
                'comment': Colors.DIM + Colors.WHITE,
                'keyword': Colors.BRIGHT_BLUE,
                'string': Colors.BRIGHT_CYAN
            }
        }
        
    def load_code(self, language="python"):
        """Load code based on selected language"""
        self.language = language
        
        if language == "python":
            self.current_code = random.choice(CodeLibrary.PYTHON_CODE)
        elif language == "javascript":
            self.current_code = random.choice(CodeLibrary.JAVASCRIPT_CODE)
        elif language == "c":
            self.current_code = random.choice(CodeLibrary.C_CODE)
        else:
            self.current_code = random.choice(CodeLibrary.PYTHON_CODE)
            
        self.position = 0
        
    def get_syntax_color(self, text):
        """Apply syntax highlighting"""
        theme = self.themes[self.theme]
        
        # Simple syntax highlighting
        if text.startswith('#') or text.startswith('//'):
            return theme['comment'] + text + Colors.RESET
        elif text in ['def', 'class', 'import', 'from', 'if', 'else', 'for', 'while', 'try', 'except']:
            return theme['keyword'] + text + Colors.RESET
        elif text.startswith('"') or text.startswith("'"):
            return theme['string'] + text + Colors.RESET
        else:
            return theme['text'] + text + Colors.RESET
            
    def display_banner(self):
        """Display hacker typer banner"""
        banner = [
            "╔══════════════════════════════════════╗",
            "║         HACKER TYPER GAME            ║",
            "║      Professional Code Simulator     ║",
            "╚══════════════════════════════════════╝"
        ]
        
        print("\n")
        for line in banner:
            print(f"{Colors.BRIGHT_GREEN}{line}{Colors.RESET}")
        print("\n")
        
    def display_stats(self):
        """Display typing statistics"""
        if self.start_time > 0:
            elapsed = time.time() - self.start_time
            if elapsed > 0:
                self.wpm = int((self.chars_typed / 5) / (elapsed / 60))
                
        stats = f"WPM: {self.wpm} | Chars: {self.chars_typed} | Language: {self.language.upper()} | Theme: {self.theme.upper()}"
        print(f"\033[H\033[2K{Colors.BRIGHT_CYAN}[STATS] {stats}{Colors.RESET}")
        
    def type_code(self):
        """Main typing simulation"""
        os.system('clear' if os.name == 'posix' else 'cls')
        
        print(f"{Colors.BRIGHT_GREEN}[*] HACKER TERMINAL ACTIVATED{Colors.RESET}")
        print(f"{Colors.BRIGHT_YELLOW}[*] Press any key to type code... ESC to quit{Colors.RESET}")
        print(f"{Colors.DIM}{'=' * 80}{Colors.RESET}\n")
        
        self.start_time = time.time()
        
        while self.position < len(self.current_code):
            try:
                # Display current code with cursor
                current_display = self.current_code[:self.position]
                remaining = self.current_code[self.position:]
                
                # Syntax highlight current display
                lines = current_display.split('\n')
                highlighted_lines = []
                
                for line in lines:
                    words = line.split()
                    highlighted_words = [self.get_syntax_color(word) for word in words]
                    highlighted_lines.append(' '.join(highlighted_words))
                
                # Clear and display
                print('\033[3;0H', end='')  # Move cursor to line 3
                for line in highlighted_lines:
                    print(f"\033[2K{line}")  # Clear line and print
                
                # Show cursor
                if remaining:
                    cursor_char = remaining[0] if remaining[0] != '\n' else ' '
                    print(f"{Colors.BRIGHT_WHITE}{Colors.BOLD}█{Colors.RESET}", end='', flush=True)
                
                # Display stats
                self.display_stats()
                
                # Wait for keypress (simulate typing)
                if self.auto_mode:
                    time.sleep(0.05)  # Auto mode speed
                else:
                    # Wait for any key
                    try:
                        import termios, tty
                        fd = sys.stdin.fileno()
                        old_settings = termios.tcgetattr(fd)
                        tty.setraw(sys.stdin.fileno())
                        ch = sys.stdin.read(1)
                        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                        
                        if ord(ch) == 27:  # ESC key
                            break
                    except:
                        input()  # Fallback for Windows
                
                # Advance position
                self.position += self.typing_speed
                self.chars_typed += self.typing_speed
                
                if self.position > len(self.current_code):
                    self.position = len(self.current_code)
                    
            except KeyboardInterrupt:
                break
                
        print(f"\n\n{Colors.BRIGHT_GREEN}[+] Hacking session completed!{Colors.RESET}")
        print(f"{Colors.BRIGHT_CYAN}Final Stats: {self.wpm} WPM | {self.chars_typed} characters{Colors.RESET}")
        
    def settings_menu(self):
        """Display settings menu"""
        while True:
            print(f"\n{Colors.BRIGHT_CYAN}Settings:{Colors.RESET}")
            print(f"  {Colors.GREEN}1{Colors.RESET} - Language: {self.language}")
            print(f"  {Colors.GREEN}2{Colors.RESET} - Theme: {self.theme}")
            print(f"  {Colors.GREEN}3{Colors.RESET} - Typing Speed: {self.typing_speed}")
            print(f"  {Colors.GREEN}4{Colors.RESET} - Auto Mode: {'ON' if self.auto_mode else 'OFF'}")
            print(f"  {Colors.GREEN}b{Colors.RESET} - Back to main menu")
            
            choice = input(f"\n{Colors.BRIGHT_CYAN}Select option: {Colors.RESET}").strip().lower()
            
            if choice == '1':
                print(f"{Colors.BRIGHT_YELLOW}Languages: python, javascript, c{Colors.RESET}")
                lang = input("Enter language: ").strip().lower()
                if lang in ['python', 'javascript', 'c']:
                    self.language = lang
                    self.load_code(lang)
                    
            elif choice == '2':
                print(f"{Colors.BRIGHT_YELLOW}Themes: matrix, hacker, terminal{Colors.RESET}")
                theme = input("Enter theme: ").strip().lower()
                if theme in self.themes:
                    self.theme = theme
                    
            elif choice == '3':
                try:
                    speed = int(input("Enter typing speed (1-10): "))
                    if 1 <= speed <= 10:
                        self.typing_speed = speed
                except ValueError:
                    print(f"{Colors.BRIGHT_RED}Invalid speed{Colors.RESET}")
                    
            elif choice == '4':
                self.auto_mode = not self.auto_mode
                
            elif choice == 'b':
                break

def slow_print(text, delay=0.03, color=Colors.BRIGHT_GREEN):
    """Print text with slow typing effect"""
    for char in text:
        sys.stdout.write(color + char + Colors.RESET)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def main():
    """Main application entry point"""
    try:
        typer = HackerTyper()
        
        while True:
            os.system('clear' if os.name == 'posix' else 'cls')
            typer.display_banner()
            
            slow_print("Welcome to Hacker Typer Game!", delay=0.05)
            print()
            
            slow_print("Features:", color=Colors.BRIGHT_CYAN)
            features = [
                "Realistic code typing simulation",
                "Multiple programming languages",
                "Syntax highlighting and themes",
                "WPM tracking and statistics",
                "Auto-typing mode available",
                "Full-screen terminal interface"
            ]
            
            for i, feature in enumerate(features, 1):
                slow_print(f"  {i}. {feature}", delay=0.01, color=Colors.GREEN)
            print()
            
            print(f"{Colors.BRIGHT_CYAN}Choose an option:{Colors.RESET}")
            print(f"  {Colors.GREEN}1{Colors.RESET} - Start Hacker Typing")
            print(f"  {Colors.GREEN}2{Colors.RESET} - Settings")
            print(f"  {Colors.GREEN}3{Colors.RESET} - Load New Code")
            print(f"  {Colors.GREEN}4{Colors.RESET} - Demo Mode (Auto)")
            print(f"  {Colors.GREEN}q{Colors.RESET} - Quit")
            
            choice = input(f"\n{Colors.BRIGHT_CYAN}Enter choice: {Colors.RESET}").strip().lower()
            
            if choice == '1':
                typer.load_code(typer.language)
                typer.auto_mode = False
                typer.type_code()
                input(f"\n{Colors.BRIGHT_GREEN}Press Enter to continue...{Colors.RESET}")
                
            elif choice == '2':
                typer.settings_menu()
                
            elif choice == '3':
                print(f"{Colors.BRIGHT_YELLOW}Available languages: python, javascript, c{Colors.RESET}")
                lang = input("Choose language: ").strip().lower()
                if lang in ['python', 'javascript', 'c']:
                    typer.load_code(lang)
                    print(f"{Colors.BRIGHT_GREEN}Loaded {lang} code!{Colors.RESET}")
                else:
                    print(f"{Colors.BRIGHT_RED}Invalid language{Colors.RESET}")
                input("Press Enter to continue...")
                
            elif choice == '4':
                typer.load_code(typer.language)
                typer.auto_mode = True
                print(f"{Colors.BRIGHT_GREEN}Starting demo mode...{Colors.RESET}")
                time.sleep(1)
                typer.type_code()
                input(f"\n{Colors.BRIGHT_GREEN}Press Enter to continue...{Colors.RESET}")
                
            elif choice == 'q':
                slow_print("Happy hacking!", color=Colors.BRIGHT_GREEN)
                break
                
            else:
                print(f"{Colors.BRIGHT_RED}Invalid choice{Colors.RESET}")
                time.sleep(1)
                
    except Exception as e:
        print(f"{Colors.BRIGHT_RED}Error: {e}{Colors.RESET}")
        sys.exit(1)

if __name__ == "__main__":
    main()