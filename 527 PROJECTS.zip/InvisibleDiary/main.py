from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from PIL import Image
import numpy as np
from cryptography.fernet import Fernet
from datetime import datetime
import os
import json
import base64

class InvisibleDiary:
    def __init__(self):
        self.console = Console()
        self.key_file = "diary.key"
        self.index_file = "diary_index.enc"
        self.images_dir = "cover_images"
        self.fernet = self._setup_encryption()
        self._setup_directories()
        self.load_index()
        
    def _setup_encryption(self):
        """Setup encryption key"""
        if not os.path.exists(self.key_file):
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
        else:
            with open(self.key_file, "rb") as f:
                key = f.read()
        return Fernet(key)
        
    def _setup_directories(self):
        """Create necessary directories"""
        if not os.path.exists(self.images_dir):
            os.makedirs(self.images_dir)
            
    def load_index(self):
        """Load diary entry index"""
        if os.path.exists(self.index_file):
            with open(self.index_file, "rb") as f:
                encrypted_data = f.read()
                try:
                    decrypted_data = self.fernet.decrypt(encrypted_data)
                    self.index = json.loads(decrypted_data)
                except:
                    self.index = {}
        else:
            self.index = {}
            
    def save_index(self):
        """Save diary entry index"""
        encrypted_data = self.fernet.encrypt(json.dumps(self.index).encode())
        with open(self.index_file, "wb") as f:
            f.write(encrypted_data)
            
    def text_to_binary(self, text):
        """Convert text to binary string"""
        return ''.join(format(ord(c), '08b') for c in text) + '00000000'
        
    def binary_to_text(self, binary):
        """Convert binary string to text"""
        text = ''
        for i in range(0, len(binary), 8):
            byte = binary[i:i+8]
            if byte == '00000000':
                break
            text += chr(int(byte, 2))
        return text
        
    def hide_entry(self, image_path, entry_text):
        """Hide diary entry in image"""
        # First encrypt the text
        encrypted_text = self.fernet.encrypt(entry_text.encode()).decode()
        
        # Convert to binary
        binary_data = self.text_to_binary(encrypted_text)
        
        # Load and prepare image
        img = Image.open(image_path)
        pixels = np.array(img)
        
        if len(binary_data) > pixels.size:
            raise ValueError("Entry too long for this image")
            
        # Flatten array
        flat_pixels = pixels.flatten()
        
        # Hide data
        for i, bit in enumerate(binary_data):
            flat_pixels[i] = (flat_pixels[i] & ~1) | int(bit)
            
        # Reshape and save
        modified_pixels = flat_pixels.reshape(pixels.shape)
        output_image = Image.fromarray(modified_pixels)
        
        # Save with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = os.path.join(self.images_dir, f"entry_{timestamp}.png")
        output_image.save(output_path)
        
        return output_path
        
    def extract_entry(self, image_path):
        """Extract diary entry from image"""
        # Load image
        img = Image.open(image_path)
        pixels = np.array(img)
        
        # Extract bits
        binary_data = ''
        flat_pixels = pixels.flatten()
        
        for pixel in flat_pixels:
            binary_data += str(pixel & 1)
            if len(binary_data) % 8 == 0:
                if binary_data[-8:] == '00000000':
                    break
                    
        # Convert to text
        encrypted_text = self.binary_to_text(binary_data)
        
        # Decrypt
        try:
            decrypted_text = self.fernet.decrypt(encrypted_text.encode()).decode()
            return decrypted_text
        except:
            raise ValueError("Failed to decrypt entry")
            
    def add_entry(self):
        """Add new diary entry"""
        self.console.print(Panel("✍️ New Diary Entry", style="bold green"))
        
        # Get cover image
        image_path = Prompt.ask("Enter path to cover image (PNG format)")
        if not os.path.exists(image_path) or not image_path.lower().endswith('.png'):
            self.console.print("Invalid image path!", style="bold red")
            return
            
        # Get entry content
        content = Prompt.ask("Write your entry")
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        try:
            # Hide entry in image
            output_path = self.hide_entry(image_path, content)
            
            # Update index
            self.index[timestamp] = {
                "path": output_path,
                "preview": content[:50] + "..." if len(content) > 50 else content
            }
            self.save_index()
            
            self.console.print("✨ Entry saved successfully!", style="bold green")
            
        except Exception as e:
            self.console.print(f"❌ Error: {str(e)}", style="bold red")
            
    def view_entries(self):
        """View all diary entries"""
        if not self.index:
            self.console.print("No entries found.", style="bold yellow")
            return
            
        for timestamp, entry_data in sorted(self.index.items()):
            try:
                content = self.extract_entry(entry_data["path"])
                self.console.print(Panel(
                    f"[bold blue]Date:[/] {timestamp}\n\n{content}",
                    title="📖 Diary Entry",
                    border_style="cyan"
                ))
            except Exception as e:
                self.console.print(f"❌ Error reading entry from {timestamp}: {str(e)}", style="bold red")
                
    def run(self):
        while True:
            self.console.print("\n🔐 InvisibleDiary - Steganographic Diary", style="bold magenta")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4"],
                default="1"
            )
            
            if choice == "1":
                self.add_entry()
            elif choice == "2":
                self.view_entries()
            elif choice == "3":
                if self.index:
                    latest = max(self.index.keys())
                    image_path = self.index[latest]["path"]
                    if os.path.exists(image_path):
                        os.remove(image_path)
                    del self.index[latest]
                    self.save_index()
                    self.console.print("Last entry removed.", style="bold yellow")
                else:
                    self.console.print("No entries to remove.", style="bold red")
            elif choice == "4":
                self.console.print("Goodbye! 👋", style="bold magenta")
                break
                
if __name__ == "__main__":
    diary = InvisibleDiary()
    diary.run() 