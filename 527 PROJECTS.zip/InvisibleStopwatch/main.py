from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table
from datetime import datetime, timedelta
import threading
import json
import os
import time

class InvisibleStopwatch:
    def __init__(self):
        self.console = Console()
        self.timers_file = "timers.json"
        self.timers = {}
        self.load_timers()
        self.running = True
        self.active_timer = None
        self.start_time = None
        self.elapsed_time = timedelta()
        self.paused = False
        
    def load_timers(self):
        """Load saved timers"""
        if os.path.exists(self.timers_file):
            with open(self.timers_file, 'r') as f:
                self.timers = json.load(f)
                
    def save_timers(self):
        """Save timers to file"""
        with open(self.timers_file, 'w') as f:
            json.dump(self.timers, f, indent=2)
            
    def format_time(self, td):
        """Format timedelta to string"""
        total_seconds = int(td.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        
    def update_display(self):
        """Update timer display in background"""
        while self.running:
            if self.active_timer and not self.paused:
                current_time = datetime.now()
                self.elapsed_time = current_time - self.start_time
                time.sleep(0.1)
                
    def start_timer(self, name=None):
        """Start a new timer or resume paused timer"""
        if self.paused:
            self.paused = False
            self.start_time = datetime.now() - self.elapsed_time
        else:
            self.start_time = datetime.now()
            self.elapsed_time = timedelta()
            if name:
                self.active_timer = name
                
    def pause_timer(self):
        """Pause current timer"""
        if self.active_timer and not self.paused:
            self.paused = True
            
    def stop_timer(self):
        """Stop and save current timer"""
        if self.active_timer:
            final_time = self.format_time(self.elapsed_time)
            self.timers[self.active_timer] = {
                "duration": final_time,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            self.save_timers()
            self.active_timer = None
            self.start_time = None
            self.elapsed_time = timedelta()
            self.paused = False
            
    def display_current_timer(self):
        """Display current timer status"""
        if self.active_timer:
            status = "⏸️ PAUSED" if self.paused else "⏱️ RUNNING"
            self.console.print(Panel(
                f"[bold blue]Timer:[/] {self.active_timer}\n"
                f"[bold green]Time:[/] {self.format_time(self.elapsed_time)}\n"
                f"[bold yellow]Status:[/] {status}",
                title="Current Timer",
                border_style="cyan"
            ))
        else:
            self.console.print("No active timer.", style="bold yellow")
            
    def display_saved_timers(self):
        """Display saved timers"""
        if not self.timers:
            self.console.print("No saved timers.", style="bold yellow")
            return
            
        table = Table(title="📊 Saved Timers")
        table.add_column("Name", style="cyan")
        table.add_column("Duration", style="green")
        table.add_column("Timestamp", style="yellow")
        
        for name, data in self.timers.items():
            table.add_row(
                name,
                data["duration"],
                data["timestamp"]
            )
            
        self.console.print(table)
        
    def run(self):
        # Start display update thread
        display_thread = threading.Thread(target=self.update_display)
        display_thread.daemon = True
        display_thread.start()
        
        while True:
            self.console.print("\n⏱️ InvisibleStopwatch - Hidden Timer", style="bold magenta")
            
            if self.active_timer:
                self.display_current_timer()
                
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4", "5", "6", "7"],
                default="1"
            )
            
            if choice == "1":
                # Start new timer
                if not self.active_timer:
                    name = Prompt.ask("Timer name")
                    self.start_timer(name)
                    self.console.print("Timer started!", style="bold green")
                else:
                    self.console.print("Stop current timer first!", style="bold red")
                    
            elif choice == "2":
                # Pause/Resume timer
                if self.active_timer:
                    if self.paused:
                        self.start_timer()
                        self.console.print("Timer resumed!", style="bold green")
                    else:
                        self.pause_timer()
                        self.console.print("Timer paused!", style="bold yellow")
                else:
                    self.console.print("No active timer!", style="bold red")
                    
            elif choice == "3":
                # Stop timer
                if self.active_timer:
                    self.stop_timer()
                    self.console.print("Timer stopped and saved!", style="bold green")
                else:
                    self.console.print("No active timer!", style="bold red")
                    
            elif choice == "4":
                # View current timer
                self.display_current_timer()
                
            elif choice == "5":
                # View saved timers
                self.display_saved_timers()
                
            elif choice == "6":
                # Delete saved timer
                self.display_saved_timers()
                name = Prompt.ask("Enter timer name to delete")
                if name in self.timers:
                    del self.timers[name]
                    self.save_timers()
                    self.console.print("Timer deleted!", style="bold yellow")
                else:
                    self.console.print("Timer not found!", style="bold red")
                    
            elif choice == "7":
                self.running = False
                if self.active_timer:
                    self.stop_timer()
                self.console.print("Goodbye! 👋", style="bold magenta")
                break
                
if __name__ == "__main__":
    stopwatch = InvisibleStopwatch()
    stopwatch.run() 