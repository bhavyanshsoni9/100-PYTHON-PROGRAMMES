from translate import Translator
import json
import os

PHRASEBOOK_FILE = "phrasebook.json"

def load_phrasebook():
    if os.path.exists(PHRASEBOOK_FILE):
        with open(PHRASEBOOK_FILE, "r") as f:
            return json.load(f)
    return {}

def save_phrasebook(pb):
    with open(PHRASEBOOK_FILE, "w") as f:
        json.dump(pb, f, indent=4)

def translate_text(text, from_lang, to_lang):
    translator = Translator(from_lang=from_lang, to_lang=to_lang)
    try:
        translation = translator.translate(text)
        return translation
    except Exception as e:
        return f"Error: {e}"

def main():
    phrasebook = load_phrasebook()
    print("=== Offline Language Translator CLI ===")
    while True:
        print("\n1. Translate Text")
        print("2. View Phrasebook")
        print("3. Exit")
        choice = input("Choose: ")
        if choice == "1":
            from_lang = input("From language (e.g. en): ").strip()
            to_lang = input("To language (e.g. hi): ").strip()
            text = input("Enter text to translate: ").strip()
            translation = translate_text(text, from_lang, to_lang)
            print(f"Translation: {translation}")
            save_choice = input("Save to phrasebook? (y/n): ").lower()
            if save_choice == "y":
                phrasebook[text] = translation
                save_phrasebook(phrasebook)
                print("Saved!")
        elif choice == "2":
            if phrasebook:
                print("\n--- Phrasebook ---")
                for k, v in phrasebook.items():
                    print(f"{k} => {v}")
            else:
                print("Phrasebook empty.")
        elif choice == "3":
            print("Bye!")
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()
