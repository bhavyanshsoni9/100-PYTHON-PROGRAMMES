from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.table import Table
import os
import shutil
import json
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class LazyFileMover:
    def __init__(self):
        self.console = Console()
        self.rules_file = "move_rules.json"
        self.default_rules = {
            "images": [".jpg", ".jpeg", ".png", ".gif", ".bmp"],
            "documents": [".pdf", ".doc", ".docx", ".txt", ".rtf"],
            "music": [".mp3", ".wav", ".flac", ".m4a"],
            "videos": [".mp4", ".avi", ".mkv", ".mov"],
            "archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
            "code": [".py", ".js", ".html", ".css", ".cpp", ".java"]
        }
        self.load_rules()
        self.observer = None
        
    def load_rules(self):
        """Load file organization rules"""
        if os.path.exists(self.rules_file):
            with open(self.rules_file, 'r') as f:
                self.rules = json.load(f)
        else:
            self.rules = self.default_rules.copy()
            self.save_rules()
            
    def save_rules(self):
        """Save file organization rules"""
        with open(self.rules_file, 'w') as f:
            json.dump(self.rules, f, indent=2)
            
    def get_category(self, filename):
        """Determine file category based on extension"""
        ext = os.path.splitext(filename)[1].lower()
        for category, extensions in self.rules.items():
            if ext in extensions:
                return category
        return "misc"
        
    def organize_files(self, source_dir):
        """Organize files in directory"""
        if not os.path.exists(source_dir):
            raise ValueError("Source directory does not exist")
            
        # Create category directories
        categories = list(self.rules.keys()) + ["misc"]
        moved_files = {cat: [] for cat in categories}
        
        for category in categories:
            category_dir = os.path.join(source_dir, category)
            if not os.path.exists(category_dir):
                os.makedirs(category_dir)
                
        # Move files
        for filename in os.listdir(source_dir):
            source_path = os.path.join(source_dir, filename)
            
            # Skip directories and the rules file
            if os.path.isdir(source_path) or filename == self.rules_file:
                continue
                
            category = self.get_category(filename)
            target_dir = os.path.join(source_dir, category)
            target_path = os.path.join(target_dir, filename)
            
            # Handle filename conflicts
            if os.path.exists(target_path):
                base, ext = os.path.splitext(filename)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{base}_{timestamp}{ext}"
                target_path = os.path.join(target_dir, filename)
                
            try:
                shutil.move(source_path, target_path)
                moved_files[category].append(filename)
            except Exception as e:
                self.console.print(f"Error moving {filename}: {str(e)}", style="bold red")
                
        return moved_files
        
class FileHandler(FileSystemEventHandler):
    def __init__(self, mover, watch_dir):
        self.mover = mover
        self.watch_dir = watch_dir
        
    def on_created(self, event):
        if not event.is_directory:
            try:
                filename = os.path.basename(event.src_path)
                category = self.mover.get_category(filename)
                target_dir = os.path.join(self.watch_dir, category)
                
                if not os.path.exists(target_dir):
                    os.makedirs(target_dir)
                    
                target_path = os.path.join(target_dir, filename)
                
                # Handle filename conflicts
                if os.path.exists(target_path):
                    base, ext = os.path.splitext(filename)
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"{base}_{timestamp}{ext}"
                    target_path = os.path.join(target_dir, filename)
                    
                shutil.move(event.src_path, target_path)
                self.mover.console.print(f"Moved {filename} to {category}", style="bold green")
            except Exception as e:
                self.mover.console.print(f"Error moving {filename}: {str(e)}", style="bold red")
                
class LazyFileMoverCLI:
    def __init__(self):
        self.mover = LazyFileMover()
        self.console = self.mover.console
        
    def display_rules(self):
        """Display current organization rules"""
        table = Table(title="📁 File Organization Rules")
        table.add_column("Category", style="cyan")
        table.add_column("Extensions", style="green")
        
        for category, extensions in self.mover.rules.items():
            table.add_row(
                category,
                ", ".join(extensions)
            )
            
        self.console.print(table)
        
    def add_rule(self):
        """Add new organization rule"""
        category = Prompt.ask("Category name").lower()
        extensions = Prompt.ask("Extensions (comma-separated, include dots)")
        
        extensions = [ext.strip() for ext in extensions.split(",")]
        self.mover.rules[category] = extensions
        self.mover.save_rules()
        
        self.console.print(f"✨ Added rule for {category}!", style="bold green")
        
    def remove_rule(self):
        """Remove organization rule"""
        category = Prompt.ask("Category to remove")
        
        if category in self.mover.rules:
            del self.mover.rules[category]
            self.mover.save_rules()
            self.console.print(f"Removed rule for {category}!", style="bold yellow")
        else:
            self.console.print("Category not found!", style="bold red")
            
    def start_monitoring(self, directory):
        """Start monitoring directory for new files"""
        if self.mover.observer:
            self.mover.observer.stop()
            self.mover.observer = None
            
        event_handler = FileHandler(self.mover, directory)
        self.mover.observer = Observer()
        self.mover.observer.schedule(event_handler, directory, recursive=False)
        self.mover.observer.start()
        
        self.console.print(f"🔍 Monitoring {directory} for new files...", style="bold blue")
        
    def stop_monitoring(self):
        """Stop directory monitoring"""
        if self.mover.observer:
            self.mover.observer.stop()
            self.mover.observer.join()
            self.mover.observer = None
            self.console.print("Monitoring stopped!", style="bold yellow")
            
    def run(self):
        while True:
            self.console.print("\n🦥 LazyFileMover - Automatic File Organizer", style="bold blue")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3", "4", "5", "6", "7"],
                default="1"
            )
            
            try:
                if choice == "1":
                    # Organize files
                    directory = Prompt.ask("Enter directory path to organize")
                    moved_files = self.mover.organize_files(directory)
                    
                    self.console.print("\n✨ Organization complete!")
                    for category, files in moved_files.items():
                        if files:
                            self.console.print(f"\n[bold blue]{category}:[/]")
                            for file in files:
                                self.console.print(f"  - {file}")
                                
                elif choice == "2":
                    # View rules
                    self.display_rules()
                    
                elif choice == "3":
                    # Add rule
                    self.add_rule()
                    
                elif choice == "4":
                    # Remove rule
                    self.remove_rule()
                    
                elif choice == "5":
                    # Start monitoring
                    directory = Prompt.ask("Enter directory path to monitor")
                    self.start_monitoring(directory)
                    
                elif choice == "6":
                    # Stop monitoring
                    self.stop_monitoring()
                    
                elif choice == "7":
                    self.stop_monitoring()
                    self.console.print("Goodbye! 👋", style="bold blue")
                    break
                    
            except Exception as e:
                self.console.print(f"Error: {str(e)}", style="bold red")
                
if __name__ == "__main__":
    cli = LazyFileMoverCLI()
    cli.run() 