import time
from http.server import SimpleHTTPRequestHandler, HTTPServer

link_valid_time = int(input("Enter link valid time in seconds: "))

class ExpiringHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if time.time() - start_time > link_valid_time:
            self.send_response(410)
            self.end_headers()
            self.wfile.write(b'Link expired')
        else:
            super().do_GET()

start_time = time.time()
server = HTTPServer(('localhost', 8000), ExpiringHandler)
print("Link is active at http://localhost:8000/")
server.serve_forever()