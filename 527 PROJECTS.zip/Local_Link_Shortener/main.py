import os
import random
import string
import time
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

MAPPING_FILE = 'url_mappings.txt'
SHORT_URL_PREFIX = 'http://localhost:8000/'
SHORT_CODE_LENGTH = 6

# Emojis
SUCCESS_EMOJI = '\U0001F389'  # 🎉
FAILURE_EMOJI = '\U0001F6AB'  # 🚫
INFO_EMOJI = '\U0001F4DD'     # 📝


def load_mappings():
    mappings = {}
    if os.path.exists(MAPPING_FILE):
        with open(MAPPING_FILE, 'r') as f:
            for line in f:
                short, original = line.strip().split(',', 1)
                mappings[short] = original
    return mappings




def save_mapping(short_code, original_url):
    with open(MAPPING_FILE, 'a') as f:
        f.write(f"{short_code},{original_url}\n")


def generate_short_code(existing):
    while True:
        code = ''.join(random.choices(string.ascii_letters + string.digits, k=SHORT_CODE_LENGTH))
        if code not in existing:
            return code


def is_localhost_url(url):
    return url.startswith('http://localhost') or url.startswith('https://localhost')


def main():
    print(f"{Fore.CYAN}{INFO_EMOJI} Welcome to Local Link Shortener!{Style.RESET_ALL}")
    time.sleep(0.7)
    mappings = load_mappings()
    while True:
        url = input(f"{Fore.YELLOW}Enter a localhost URL to shorten (or 'q' to quit): {Style.RESET_ALL}").strip()
        if url.lower() == 'q':
            print(f"{Fore.CYAN}Goodbye!{Style.RESET_ALL}")
            break
        if not is_localhost_url(url):
            print(f"{Fore.RED}{FAILURE_EMOJI} Error: Only localhost URLs are allowed!{Style.RESET_ALL}")
            time.sleep(1)
            continue
        if url in mappings.values():
            # Find existing short code
            short_code = [k for k, v in mappings.items() if v == url][0]
            print(f"{Fore.GREEN}{SUCCESS_EMOJI} Already shortened: {SHORT_URL_PREFIX}{short_code}{Style.RESET_ALL}")
            time.sleep(1)
            continue
        short_code = generate_short_code(mappings)
        mappings[short_code] = url
        save_mapping(short_code, url)
        print(f"{Fore.GREEN}{SUCCESS_EMOJI} Success! Short URL: {Fore.BLUE}{SHORT_URL_PREFIX}{short_code}{Style.RESET_ALL}")
        time.sleep(1)

if __name__ == '__main__':
    main() 