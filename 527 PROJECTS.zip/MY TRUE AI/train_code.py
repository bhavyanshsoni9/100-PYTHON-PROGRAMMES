from langchain.docstore.document import Document
from langchain.vectorstores import Chroma
from langchain.embeddings import SentenceTransformerEmbeddings
import os

def train_code():
    docs = []
    print("[INFO] Loading Code Files...")

    for file in os.listdir('code_files'):
        path = os.path.join('code_files', file)
        if file.endswith(('.py', '.js', '.html', '.cpp', '.java')):
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
                docs.append(Document(page_content=content))
        else:
            print(f"[WARNING] Unsupported file {file}")

    print(f"[INFO] ✅ Loaded {len(docs)} code files.")

    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    vectordb = Chroma.from_documents(docs, embeddings, persist_directory="vector_db")
    vectordb.persist()

    print("[INFO] ✅ Code files trained and stored in vector DB!")

if __name__ == "__main__":
    train_code()
