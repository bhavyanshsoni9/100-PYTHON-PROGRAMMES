import pandas as pd
from langchain.docstore.document import Document
from langchain.vectorstores import Chroma
from langchain.embeddings import SentenceTransformerEmbeddings
import os

def train_datasets():
    docs = []
    print("[INFO] Loading Datasets...")

    for file in os.listdir('datasets'):
        path = os.path.join('datasets', file)
        if file.endswith('.csv'):
            df = pd.read_csv(path)
        elif file.endswith('.json'):
            df = pd.read_json(path)
        else:
            print(f"[WARNING] Unsupported file {file}")
            continue

        for index, row in df.iterrows():
            content = " ".join([str(item) for item in row.values])
            docs.append(Document(page_content=content))

    print(f"[INFO] ✅ Loaded {len(docs)} dataset rows.")

    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    vectordb = Chroma.from_documents(docs, embeddings, persist_directory="vector_db")
    vectordb.persist()

    print("[INFO] ✅ Dataset trained and stored in vector DB!")

if __name__ == "__main__":
    train_datasets()
