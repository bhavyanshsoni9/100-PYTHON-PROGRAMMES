# Sample Markdown

This is a simple Markdown file for testing.

## Features
- Easy to read
- Converts to HTML
- Contains code

### Example Code

```python
print("Hello, world!")
``` 