from PIL import Image
import os
def create_dummy_image(path="dummy.jpg"):
    img = Image.new("RGB", (100, 100), color=(73, 109, 137))
    img.save(path, "PNG")
    print(f"Dummy image saved as {path}")
    os.remove("dummy.jpg")
if __name__ == "__main__":
    create_dummy_image()    