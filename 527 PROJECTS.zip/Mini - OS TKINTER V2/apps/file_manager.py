import streamlit as st
import os
import json
import shutil
from datetime import datetime
from utils import save_user_data, load_user_data, add_recent_activity

def show_file_manager():
    """Display file manager interface"""
    st.markdown("# 📁 File Manager")
    
    # Initialize current path in session state
    if 'current_path' not in st.session_state:
        st.session_state.current_path = f"data/filesystem/{st.session_state.username}"
    
    current_path = st.session_state.current_path
    username = st.session_state.username
    user_root = f"data/filesystem/{username}"
    
    # Navigation bar
    col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
    
    with col1:
        # Breadcrumb navigation
        relative_path = current_path.replace(user_root, "").strip("/")
        if relative_path:
            breadcrumb = f"Home/{relative_path}"
        else:
            breadcrumb = "Home"
        st.markdown(f"**Current Location:** {breadcrumb}")
    
    with col2:
        if st.button("🏠 Home", help="Go to home directory"):
            st.session_state.current_path = user_root
            st.rerun()
    
    with col3:
        if st.button("⬆️ Up", help="Go to parent directory"):
            parent_path = os.path.dirname(current_path)
            if parent_path.startswith(user_root):
                st.session_state.current_path = parent_path
                st.rerun()
    
    with col4:
        if st.button("🔄 Refresh", help="Refresh directory"):
            st.rerun()
    
    st.markdown("---")
    
    # File operations
    col1, col2, col3 = st.columns(3)
    
    with col1:
        with st.expander("📁 New Folder"):
            folder_name = st.text_input("Folder name:")
            if st.button("Create Folder") and folder_name:
                create_folder(current_path, folder_name)
                st.success(f"Folder '{folder_name}' created!")
                st.rerun()
    
    with col2:
        with st.expander("📄 New File"):
            file_name = st.text_input("File name:")
            file_content = st.text_area("File content:")
            if st.button("Create File") and file_name:
                create_file(current_path, file_name, file_content)
                st.success(f"File '{file_name}' created!")
                st.rerun()
    
    with col3:
        with st.expander("📤 Upload File"):
            uploaded_file = st.file_uploader("Choose a file")
            if uploaded_file and st.button("Upload"):
                upload_file(current_path, uploaded_file)
                st.success(f"File '{uploaded_file.name}' uploaded!")
                st.rerun()
    
    st.markdown("---")
    
    # Directory listing
    if os.path.exists(current_path):
        items = list_directory_items(current_path)
        
        if not items:
            st.info("This folder is empty")
        else:
            # Create table for file listing
            col1, col2, col3, col4, col5 = st.columns([3, 1, 1, 1, 1])
            
            with col1:
                st.markdown("**Name**")
            with col2:
                st.markdown("**Type**")
            with col3:
                st.markdown("**Size**")
            with col4:
                st.markdown("**Modified**")
            with col5:
                st.markdown("**Actions**")
            
            st.markdown("---")
            
            for item in items:
                col1, col2, col3, col4, col5 = st.columns([3, 1, 1, 1, 1])
                
                with col1:
                    if item['is_dir']:
                        if st.button(f"📁 {item['name']}", key=f"dir_{item['name']}"):
                            st.session_state.current_path = item['path']
                            st.rerun()
                    else:
                        st.text(f"📄 {item['name']}")
                
                with col2:
                    st.text("Folder" if item['is_dir'] else "File")
                
                with col3:
                    st.text(item['size'])
                
                with col4:
                    st.text(item['modified'])
                
                with col5:
                    if st.button("🗑️", key=f"del_{item['name']}", help="Delete"):
                        if delete_item(item['path']):
                            st.success(f"Deleted {item['name']}")
                            st.rerun()
                        else:
                            st.error("Failed to delete")
    else:
        st.error("Directory not found")

def list_directory_items(path):
    """List items in directory"""
    items = []
    try:
        for item_name in os.listdir(path):
            item_path = os.path.join(path, item_name)
            is_dir = os.path.isdir(item_path)
            
            stat = os.stat(item_path)
            size = format_size(stat.st_size) if not is_dir else "-"
            modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
            
            items.append({
                'name': item_name,
                'path': item_path,
                'is_dir': is_dir,
                'size': size,
                'modified': modified
            })
        
        # Sort directories first, then files
        items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
    except PermissionError:
        st.error("Permission denied")
    
    return items

def format_size(size_bytes):
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    
    return f"{size_bytes:.1f} TB"

def create_folder(parent_path, folder_name):
    """Create a new folder"""
    folder_path = os.path.join(parent_path, folder_name)
    try:
        os.makedirs(folder_path, exist_ok=True)
        add_recent_activity(st.session_state.username, f"Created folder: {folder_name}")
        return True
    except Exception as e:
        st.error(f"Failed to create folder: {e}")
        return False

def create_file(parent_path, file_name, content):
    """Create a new file"""
    file_path = os.path.join(parent_path, file_name)
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        add_recent_activity(st.session_state.username, f"Created file: {file_name}")
        return True
    except Exception as e:
        st.error(f"Failed to create file: {e}")
        return False

def upload_file(parent_path, uploaded_file):
    """Upload a file"""
    file_path = os.path.join(parent_path, uploaded_file.name)
    try:
        with open(file_path, 'wb') as f:
            f.write(uploaded_file.getbuffer())
        add_recent_activity(st.session_state.username, f"Uploaded file: {uploaded_file.name}")
        return True
    except Exception as e:
        st.error(f"Failed to upload file: {e}")
        return False

def delete_item(item_path):
    """Delete a file or folder"""
    try:
        if os.path.isdir(item_path):
            shutil.rmtree(item_path)
        else:
            os.remove(item_path)
        
        item_name = os.path.basename(item_path)
        add_recent_activity(st.session_state.username, f"Deleted: {item_name}")
        return True
    except Exception as e:
        st.error(f"Failed to delete: {e}")
        return False
