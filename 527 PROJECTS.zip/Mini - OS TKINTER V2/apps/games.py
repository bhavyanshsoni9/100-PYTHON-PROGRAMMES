import streamlit as st
import random
import time
from utils import add_recent_activity, load_user_data, save_user_data

def show_games():
    """Display games interface"""
    st.markdown("# 🎮 Games")
    
    # Game selection
    games = {
        "🎯 Tic Tac Toe": "tictactoe",
        "🧠 Memory Game": "memory",
        "🐍 Snake Game": "snake",
        "🎲 Number Guessing": "guessing",
        "🃏 Rock Paper Scissors": "rps",
        "🧩 Word Puzzle": "word_puzzle"
    }
    
    selected_game = st.selectbox("Choose a game:", list(games.keys()))
    game_key = games[selected_game]
    
    st.markdown("---")
    
    # Display selected game
    if game_key == "tictactoe":
        show_tic_tac_toe()
    elif game_key == "memory":
        show_memory_game()
    elif game_key == "snake":
        show_snake_game()
    elif game_key == "guessing":
        show_number_guessing()
    elif game_key == "rps":
        show_rock_paper_scissors()
    elif game_key == "word_puzzle":
        show_word_puzzle()
    
    # Game statistics
    show_game_stats()

def show_tic_tac_toe():
    """Tic Tac Toe game"""
    st.markdown("### 🎯 Tic Tac Toe")
    
    # Initialize game state
    if 'ttt_board' not in st.session_state:
        st.session_state.ttt_board = [' ' for _ in range(9)]
        st.session_state.ttt_current_player = 'X'
        st.session_state.ttt_game_over = False
        st.session_state.ttt_winner = None
    
    board = st.session_state.ttt_board
    
    if not st.session_state.ttt_game_over:
        st.markdown(f"**Current Player: {st.session_state.ttt_current_player}**")
    
    # Display board
    col1, col2, col3 = st.columns(3)
    cols = [col1, col2, col3]
    
    for i in range(3):
        for j in range(3):
            pos = i * 3 + j
            with cols[j]:
                if st.button(board[pos] if board[pos] != ' ' else '⬜', 
                           key=f"ttt_{pos}", 
                           disabled=board[pos] != ' ' or st.session_state.ttt_game_over):
                    make_ttt_move(pos)
    
    # Game status
    if st.session_state.ttt_game_over:
        if st.session_state.ttt_winner:
            st.success(f"🎉 Player {st.session_state.ttt_winner} wins!")
            update_game_stats('tictactoe', 'win' if st.session_state.ttt_winner == 'X' else 'loss')
        else:
            st.info("🤝 It's a tie!")
            update_game_stats('tictactoe', 'tie')
        
        if st.button("🔄 New Game", key="ttt_new"):
            reset_tic_tac_toe()
            st.rerun()

def show_memory_game():
    """Memory matching game"""
    st.markdown("### 🧠 Memory Game")
    
    # Initialize game
    if 'memory_cards' not in st.session_state:
        symbols = ['🎯', '🎮', '🎲', '🎪', '🎨', '🎭', '🎺', '🎸'] * 2
        random.shuffle(symbols)
        st.session_state.memory_cards = symbols
        st.session_state.memory_revealed = [False] * 16
        st.session_state.memory_matched = [False] * 16
        st.session_state.memory_first_card = None
        st.session_state.memory_second_card = None
        st.session_state.memory_moves = 0
        st.session_state.memory_matches = 0
    
    cards = st.session_state.memory_cards
    revealed = st.session_state.memory_revealed
    matched = st.session_state.memory_matched
    
    st.markdown(f"**Moves: {st.session_state.memory_moves} | Matches: {st.session_state.memory_matches}/8**")
    
    # Display cards in 4x4 grid
    for row in range(4):
        cols = st.columns(4)
        for col in range(4):
            pos = row * 4 + col
            with cols[col]:
                if matched[pos] or revealed[pos]:
                    card_text = cards[pos]
                    disabled = True
                else:
                    card_text = '❓'
                    disabled = False
                
                if st.button(card_text, key=f"memory_{pos}", disabled=disabled):
                    handle_memory_card_click(pos)
    
    # Check win condition
    if st.session_state.memory_matches == 8:
        st.success(f"🎉 Congratulations! You won in {st.session_state.memory_moves} moves!")
        update_game_stats('memory', 'win', st.session_state.memory_moves)
        
        if st.button("🔄 New Game", key="memory_new"):
            reset_memory_game()
            st.rerun()

def show_snake_game():
    """Simple Snake game simulation"""
    st.markdown("### 🐍 Snake Game")
    st.info("This is a simplified Snake game. Use the controls below to move!")
    
    # Initialize game
    if 'snake_pos' not in st.session_state:
        st.session_state.snake_pos = [(5, 5)]
        st.session_state.snake_food = (10, 10)
        st.session_state.snake_direction = 'RIGHT'
        st.session_state.snake_score = 0
        st.session_state.snake_game_over = False
    
    if not st.session_state.snake_game_over:
        # Controls
        col1, col2, col3, col4, col5 = st.columns(5)
        with col1:
            if st.button("⬅️ Left", key="snake_left"):
                if st.session_state.snake_direction != 'RIGHT':
                    st.session_state.snake_direction = 'LEFT'
                    move_snake()
        with col2:
            if st.button("⬆️ Up", key="snake_up"):
                if st.session_state.snake_direction != 'DOWN':
                    st.session_state.snake_direction = 'UP'
                    move_snake()
        with col3:
            if st.button("⬇️ Down", key="snake_down"):
                if st.session_state.snake_direction != 'UP':
                    st.session_state.snake_direction = 'DOWN'
                    move_snake()
        with col4:
            if st.button("➡️ Right", key="snake_right"):
                if st.session_state.snake_direction != 'LEFT':
                    st.session_state.snake_direction = 'RIGHT'
                    move_snake()
        with col5:
            if st.button("▶️ Auto Move", key="snake_auto"):
                move_snake()
    
    # Display game state
    st.markdown(f"**Score: {st.session_state.snake_score}**")
    
    # Simple visualization
    grid_display = create_snake_grid()
    st.code(grid_display, language=None)
    
    if st.session_state.snake_game_over:
        st.error("💀 Game Over!")
        update_game_stats('snake', 'loss', st.session_state.snake_score)
        if st.button("🔄 New Game", key="snake_new"):
            reset_snake_game()
            st.rerun()

def show_number_guessing():
    """Number guessing game"""
    st.markdown("### 🎲 Number Guessing Game")
    
    # Initialize game
    if 'guess_number' not in st.session_state:
        st.session_state.guess_number = random.randint(1, 100)
        st.session_state.guess_attempts = 0
        st.session_state.guess_history = []
        st.session_state.guess_won = False
    
    if not st.session_state.guess_won:
        st.markdown("I'm thinking of a number between 1 and 100. Can you guess it?")
        st.markdown(f"**Attempts: {st.session_state.guess_attempts}**")
        
        with st.form("guess_form"):
            user_guess = st.number_input("Your guess:", min_value=1, max_value=100, step=1)
            guess_button = st.form_submit_button("Guess!")
            
            if guess_button:
                st.session_state.guess_attempts += 1
                target = st.session_state.guess_number
                
                if user_guess == target:
                    st.success(f"🎉 Correct! You guessed it in {st.session_state.guess_attempts} attempts!")
                    st.session_state.guess_won = True
                    update_game_stats('guessing', 'win', st.session_state.guess_attempts)
                    add_recent_activity(st.session_state.username, f"Won guessing game in {st.session_state.guess_attempts} attempts")
                elif user_guess < target:
                    st.info("📈 Too low! Try higher.")
                    st.session_state.guess_history.append(f"Guess {st.session_state.guess_attempts}: {user_guess} (too low)")
                else:
                    st.info("📉 Too high! Try lower.")
                    st.session_state.guess_history.append(f"Guess {st.session_state.guess_attempts}: {user_guess} (too high)")
                
                st.rerun()
        
        # Show guess history
        if st.session_state.guess_history:
            st.markdown("**Previous Guesses:**")
            for guess in st.session_state.guess_history[-5:]:  # Show last 5
                st.text(guess)
    
    if st.session_state.guess_won:
        if st.button("🔄 New Game", key="guess_new"):
            reset_guessing_game()
            st.rerun()

def show_rock_paper_scissors():
    """Rock Paper Scissors game"""
    st.markdown("### 🃏 Rock Paper Scissors")
    
    # Initialize scores
    if 'rps_user_score' not in st.session_state:
        st.session_state.rps_user_score = 0
        st.session_state.rps_computer_score = 0
        st.session_state.rps_ties = 0
    
    st.markdown(f"**Score - You: {st.session_state.rps_user_score} | Computer: {st.session_state.rps_computer_score} | Ties: {st.session_state.rps_ties}**")
    
    # Game choices
    col1, col2, col3 = st.columns(3)
    
    choices = ['🪨 Rock', '📄 Paper', '✂️ Scissors']
    choice_values = ['rock', 'paper', 'scissors']
    
    with col1:
        if st.button(choices[0], key="rps_rock"):
            play_rps('rock')
    with col2:
        if st.button(choices[1], key="rps_paper"):
            play_rps('paper')
    with col3:
        if st.button(choices[2], key="rps_scissors"):
            play_rps('scissors')
    
    # Show last result
    if 'rps_last_result' in st.session_state:
        st.markdown("**Last Game:**")
        st.markdown(st.session_state.rps_last_result)
    
    if st.button("🔄 Reset Scores", key="rps_reset"):
        st.session_state.rps_user_score = 0
        st.session_state.rps_computer_score = 0
        st.session_state.rps_ties = 0
        st.rerun()

def show_word_puzzle():
    """Word puzzle game"""
    st.markdown("### 🧩 Word Puzzle")
    
    # Word list
    words = [
        "PYTHON", "STREAMLIT", "COMPUTER", "KEYBOARD", "MONITOR", 
        "INTERNET", "WEBSITE", "PROGRAMMING", "DEVELOPER", "SOFTWARE"
    ]
    
    # Initialize game
    if 'puzzle_word' not in st.session_state:
        st.session_state.puzzle_word = random.choice(words)
        st.session_state.puzzle_guessed = ['_'] * len(st.session_state.puzzle_word)
        st.session_state.puzzle_attempts = 6
        st.session_state.puzzle_used_letters = []
        st.session_state.puzzle_won = False
        st.session_state.puzzle_lost = False
    
    word = st.session_state.puzzle_word
    guessed = st.session_state.puzzle_guessed
    
    st.markdown(f"**Word: {' '.join(guessed)}**")
    st.markdown(f"**Attempts remaining: {st.session_state.puzzle_attempts}**")
    st.markdown(f"**Used letters: {', '.join(st.session_state.puzzle_used_letters)}**")
    
    if not st.session_state.puzzle_won and not st.session_state.puzzle_lost:
        with st.form("puzzle_form"):
            letter_guess = st.text_input("Guess a letter:").upper()
            guess_button = st.form_submit_button("Guess!")
            
            if guess_button and letter_guess and len(letter_guess) == 1:
                handle_word_puzzle_guess(letter_guess)
                st.rerun()
    
    elif st.session_state.puzzle_won:
        st.success(f"🎉 Congratulations! The word was {word}!")
        update_game_stats('word_puzzle', 'win')
        if st.button("🔄 New Game", key="puzzle_new"):
            reset_word_puzzle()
            st.rerun()
    elif st.session_state.puzzle_lost:
        st.error(f"💀 Game Over! The word was {word}")
        update_game_stats('word_puzzle', 'loss')
        if st.button("🔄 New Game", key="puzzle_new_loss"):
            reset_word_puzzle()
            st.rerun()

def show_game_stats():
    """Display game statistics"""
    st.markdown("---")
    st.markdown("### 📊 Game Statistics")
    
    user_data = load_user_data(st.session_state.username)
    game_stats = user_data.get('game_stats', {})
    
    if not game_stats:
        st.info("No game statistics yet. Play some games to see your stats!")
        return
    
    col1, col2, col3, col4 = st.columns(4)
    
    total_games = sum(stats.get('games_played', 0) for stats in game_stats.values())
    total_wins = sum(stats.get('wins', 0) for stats in game_stats.values())
    
    with col1:
        st.metric("Total Games", total_games)
    with col2:
        st.metric("Total Wins", total_wins)
    with col3:
        win_rate = (total_wins / total_games * 100) if total_games > 0 else 0
        st.metric("Win Rate", f"{win_rate:.1f}%")
    with col4:
        best_score = max([stats.get('best_score', 0) for stats in game_stats.values()] + [0])
        st.metric("Best Score", best_score)
    
    # Individual game stats
    for game, stats in game_stats.items():
        with st.expander(f"📈 {game.title()} Stats"):
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Games Played", stats.get('games_played', 0))
            with col2:
                st.metric("Wins", stats.get('wins', 0))
            with col3:
                st.metric("Best Score", stats.get('best_score', 0))

# Game helper functions
def make_ttt_move(pos):
    """Make a move in Tic Tac Toe"""
    st.session_state.ttt_board[pos] = st.session_state.ttt_current_player
    
    # Check for winner
    winner = check_ttt_winner()
    if winner:
        st.session_state.ttt_winner = winner
        st.session_state.ttt_game_over = True
    elif ' ' not in st.session_state.ttt_board:
        st.session_state.ttt_game_over = True
    else:
        # Switch player
        st.session_state.ttt_current_player = 'O' if st.session_state.ttt_current_player == 'X' else 'X'
        
        # Simple AI move for O
        if st.session_state.ttt_current_player == 'O' and not st.session_state.ttt_game_over:
            ai_move = get_ai_move()
            if ai_move is not None:
                st.session_state.ttt_board[ai_move] = 'O'
                winner = check_ttt_winner()
                if winner:
                    st.session_state.ttt_winner = winner
                    st.session_state.ttt_game_over = True
                elif ' ' not in st.session_state.ttt_board:
                    st.session_state.ttt_game_over = True
                else:
                    st.session_state.ttt_current_player = 'X'
    
    st.rerun()

def check_ttt_winner():
    """Check for Tic Tac Toe winner"""
    board = st.session_state.ttt_board
    lines = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # columns
        [0, 4, 8], [2, 4, 6]              # diagonals
    ]
    
    for line in lines:
        if board[line[0]] == board[line[1]] == board[line[2]] != ' ':
            return board[line[0]]
    return None

def get_ai_move():
    """Simple AI for Tic Tac Toe"""
    board = st.session_state.ttt_board
    empty_positions = [i for i, cell in enumerate(board) if cell == ' ']
    
    if empty_positions:
        return random.choice(empty_positions)
    return None

def reset_tic_tac_toe():
    """Reset Tic Tac Toe game"""
    st.session_state.ttt_board = [' ' for _ in range(9)]
    st.session_state.ttt_current_player = 'X'
    st.session_state.ttt_game_over = False
    st.session_state.ttt_winner = None

def handle_memory_card_click(pos):
    """Handle memory game card click"""
    if st.session_state.memory_first_card is None:
        st.session_state.memory_first_card = pos
        st.session_state.memory_revealed[pos] = True
    elif st.session_state.memory_second_card is None and pos != st.session_state.memory_first_card:
        st.session_state.memory_second_card = pos
        st.session_state.memory_revealed[pos] = True
        st.session_state.memory_moves += 1
        
        # Check for match
        if st.session_state.memory_cards[st.session_state.memory_first_card] == st.session_state.memory_cards[st.session_state.memory_second_card]:
            st.session_state.memory_matched[st.session_state.memory_first_card] = True
            st.session_state.memory_matched[st.session_state.memory_second_card] = True
            st.session_state.memory_matches += 1
        else:
            # Hide cards after a delay (simulated by resetting on next interaction)
            time.sleep(0.5)
            st.session_state.memory_revealed[st.session_state.memory_first_card] = False
            st.session_state.memory_revealed[st.session_state.memory_second_card] = False
        
        st.session_state.memory_first_card = None
        st.session_state.memory_second_card = None
    
    st.rerun()

def reset_memory_game():
    """Reset memory game"""
    symbols = ['🎯', '🎮', '🎲', '🎪', '🎨', '🎭', '🎺', '🎸'] * 2
    random.shuffle(symbols)
    st.session_state.memory_cards = symbols
    st.session_state.memory_revealed = [False] * 16
    st.session_state.memory_matched = [False] * 16
    st.session_state.memory_first_card = None
    st.session_state.memory_second_card = None
    st.session_state.memory_moves = 0
    st.session_state.memory_matches = 0

def move_snake():
    """Move snake in current direction"""
    if st.session_state.snake_game_over:
        return
    
    head = st.session_state.snake_pos[0]
    direction = st.session_state.snake_direction
    
    # Calculate new head position
    if direction == 'UP':
        new_head = (head[0] - 1, head[1])
    elif direction == 'DOWN':
        new_head = (head[0] + 1, head[1])
    elif direction == 'LEFT':
        new_head = (head[0], head[1] - 1)
    else:  # RIGHT
        new_head = (head[0], head[1] + 1)
    
    # Check boundaries (15x15 grid)
    if new_head[0] < 0 or new_head[0] >= 15 or new_head[1] < 0 or new_head[1] >= 15:
        st.session_state.snake_game_over = True
        return
    
    # Check self collision
    if new_head in st.session_state.snake_pos:
        st.session_state.snake_game_over = True
        return
    
    # Add new head
    st.session_state.snake_pos.insert(0, new_head)
    
    # Check food collision
    if new_head == st.session_state.snake_food:
        st.session_state.snake_score += 10
        # Generate new food
        while True:
            new_food = (random.randint(0, 14), random.randint(0, 14))
            if new_food not in st.session_state.snake_pos:
                st.session_state.snake_food = new_food
                break
    else:
        # Remove tail
        st.session_state.snake_pos.pop()
    
    st.rerun()

def create_snake_grid():
    """Create visual representation of snake game"""
    grid = [['.' for _ in range(15)] for _ in range(15)]
    
    # Place snake
    for pos in st.session_state.snake_pos:
        if 0 <= pos[0] < 15 and 0 <= pos[1] < 15:
            grid[pos[0]][pos[1]] = 'S'
    
    # Place head
    if st.session_state.snake_pos:
        head = st.session_state.snake_pos[0]
        if 0 <= head[0] < 15 and 0 <= head[1] < 15:
            grid[head[0]][head[1]] = 'H'
    
    # Place food
    food = st.session_state.snake_food
    if 0 <= food[0] < 15 and 0 <= food[1] < 15:
        grid[food[0]][food[1]] = 'F'
    
    return '\n'.join(''.join(row) for row in grid)

def reset_snake_game():
    """Reset snake game"""
    st.session_state.snake_pos = [(5, 5)]
    st.session_state.snake_food = (10, 10)
    st.session_state.snake_direction = 'RIGHT'
    st.session_state.snake_score = 0
    st.session_state.snake_game_over = False

def reset_guessing_game():
    """Reset guessing game"""
    st.session_state.guess_number = random.randint(1, 100)
    st.session_state.guess_attempts = 0
    st.session_state.guess_history = []
    st.session_state.guess_won = False

def play_rps(user_choice):
    """Play Rock Paper Scissors"""
    choices = ['rock', 'paper', 'scissors']
    computer_choice = random.choice(choices)
    
    choice_emojis = {'rock': '🪨', 'paper': '📄', 'scissors': '✂️'}
    
    result_text = f"You: {choice_emojis[user_choice]} vs Computer: {choice_emojis[computer_choice]}\n"
    
    if user_choice == computer_choice:
        result_text += "It's a tie!"
        st.session_state.rps_ties += 1
        update_game_stats('rps', 'tie')
    elif (user_choice == 'rock' and computer_choice == 'scissors') or \
         (user_choice == 'paper' and computer_choice == 'rock') or \
         (user_choice == 'scissors' and computer_choice == 'paper'):
        result_text += "You win!"
        st.session_state.rps_user_score += 1
        update_game_stats('rps', 'win')
    else:
        result_text += "Computer wins!"
        st.session_state.rps_computer_score += 1
        update_game_stats('rps', 'loss')
    
    st.session_state.rps_last_result = result_text
    add_recent_activity(st.session_state.username, f"Played Rock Paper Scissors")
    st.rerun()

def handle_word_puzzle_guess(letter):
    """Handle word puzzle letter guess"""
    word = st.session_state.puzzle_word
    
    if letter in st.session_state.puzzle_used_letters:
        return
    
    st.session_state.puzzle_used_letters.append(letter)
    
    if letter in word:
        for i, char in enumerate(word):
            if char == letter:
                st.session_state.puzzle_guessed[i] = letter
        
        if '_' not in st.session_state.puzzle_guessed:
            st.session_state.puzzle_won = True
    else:
        st.session_state.puzzle_attempts -= 1
        if st.session_state.puzzle_attempts <= 0:
            st.session_state.puzzle_lost = True

def reset_word_puzzle():
    """Reset word puzzle game"""
    words = [
        "PYTHON", "STREAMLIT", "COMPUTER", "KEYBOARD", "MONITOR", 
        "INTERNET", "WEBSITE", "PROGRAMMING", "DEVELOPER", "SOFTWARE"
    ]
    st.session_state.puzzle_word = random.choice(words)
    st.session_state.puzzle_guessed = ['_'] * len(st.session_state.puzzle_word)
    st.session_state.puzzle_attempts = 6
    st.session_state.puzzle_used_letters = []
    st.session_state.puzzle_won = False
    st.session_state.puzzle_lost = False

def update_game_stats(game_name, result, score=0):
    """Update game statistics"""
    user_data = load_user_data(st.session_state.username)
    
    if 'game_stats' not in user_data:
        user_data['game_stats'] = {}
    
    if game_name not in user_data['game_stats']:
        user_data['game_stats'][game_name] = {
            'games_played': 0,
            'wins': 0,
            'losses': 0,
            'ties': 0,
            'best_score': 0
        }
    
    stats = user_data['game_stats'][game_name]
    stats['games_played'] += 1
    
    if result == 'win':
        stats['wins'] += 1
    elif result == 'loss':
        stats['losses'] += 1
    elif result == 'tie':
        stats['ties'] += 1
    
    if score > stats['best_score']:
        stats['best_score'] = score
    
    save_user_data(st.session_state.username, user_data)
