import streamlit as st
import math
from decimal import Decimal, getcontext
from utils import add_recent_activity

# Set decimal precision
getcontext().prec = 15

def show_calculator():
    """Display calculator interface"""
    st.markdown("# 🔢 Calculator")
    
    # Initialize calculator state
    if 'calc_display' not in st.session_state:
        st.session_state.calc_display = "0"
    if 'calc_previous' not in st.session_state:
        st.session_state.calc_previous = None
    if 'calc_operator' not in st.session_state:
        st.session_state.calc_operator = None
    if 'calc_waiting_for_operand' not in st.session_state:
        st.session_state.calc_waiting_for_operand = False
    if 'calc_history' not in st.session_state:
        st.session_state.calc_history = []
    
    # Calculator layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Display
        st.markdown("### Display")
        display_container = st.container()
        with display_container:
            st.markdown(f"<div style='background-color: #f0f0f0; padding: 20px; border-radius: 8px; font-size: 24px; font-family: monospace; text-align: right; border: 2px solid #ddd;'>{st.session_state.calc_display}</div>", unsafe_allow_html=True)
        
        st.markdown("### Keypad")
        
        # Scientific functions row
        col_sci1, col_sci2, col_sci3, col_sci4, col_sci5 = st.columns(5)
        
        with col_sci1:
            if st.button("sin", key="sin", use_container_width=True):
                scientific_operation("sin")
        with col_sci2:
            if st.button("cos", key="cos", use_container_width=True):
                scientific_operation("cos")
        with col_sci3:
            if st.button("tan", key="tan", use_container_width=True):
                scientific_operation("tan")
        with col_sci4:
            if st.button("√", key="sqrt", use_container_width=True):
                scientific_operation("sqrt")
        with col_sci5:
            if st.button("x²", key="square", use_container_width=True):
                scientific_operation("square")
        
        # Memory and clear row
        col_mem1, col_mem2, col_mem3, col_mem4, col_mem5 = st.columns(5)
        
        with col_mem1:
            if st.button("AC", key="clear_all", use_container_width=True):
                clear_all()
        with col_mem2:
            if st.button("C", key="clear", use_container_width=True):
                clear_entry()
        with col_mem3:
            if st.button("±", key="negate", use_container_width=True):
                negate()
        with col_mem4:
            if st.button("%", key="percent", use_container_width=True):
                percent()
        with col_mem5:
            if st.button("÷", key="divide", use_container_width=True):
                input_operator("÷")
        
        # Number pad
        # Row 1: 7, 8, 9, ×
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            if st.button("7", key="num7", use_container_width=True):
                input_digit("7")
        with col2:
            if st.button("8", key="num8", use_container_width=True):
                input_digit("8")
        with col3:
            if st.button("9", key="num9", use_container_width=True):
                input_digit("9")
        with col4:
            if st.button("×", key="multiply", use_container_width=True):
                input_operator("×")
        
        # Row 2: 4, 5, 6, -
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            if st.button("4", key="num4", use_container_width=True):
                input_digit("4")
        with col2:
            if st.button("5", key="num5", use_container_width=True):
                input_digit("5")
        with col3:
            if st.button("6", key="num6", use_container_width=True):
                input_digit("6")
        with col4:
            if st.button("-", key="subtract", use_container_width=True):
                input_operator("-")
        
        # Row 3: 1, 2, 3, +
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            if st.button("1", key="num1", use_container_width=True):
                input_digit("1")
        with col2:
            if st.button("2", key="num2", use_container_width=True):
                input_digit("2")
        with col3:
            if st.button("3", key="num3", use_container_width=True):
                input_digit("3")
        with col4:
            if st.button("+", key="add", use_container_width=True):
                input_operator("+")
        
        # Row 4: 0, ., =
        col1, col2, col3 = st.columns([2, 1, 1])
        with col1:
            if st.button("0", key="num0", use_container_width=True):
                input_digit("0")
        with col2:
            if st.button(".", key="decimal", use_container_width=True):
                input_decimal()
        with col3:
            if st.button("=", key="equals", use_container_width=True):
                calculate()
    
    with col2:
        # History
        st.markdown("### History")
        if st.session_state.calc_history:
            for calculation in reversed(st.session_state.calc_history[-10:]):  # Show last 10
                st.text(calculation)
        else:
            st.info("No calculations yet")
        
        if st.button("Clear History", key="clear_history"):
            st.session_state.calc_history = []
            st.rerun()

def input_digit(digit):
    """Handle digit input"""
    if st.session_state.calc_waiting_for_operand:
        st.session_state.calc_display = digit
        st.session_state.calc_waiting_for_operand = False
    else:
        if st.session_state.calc_display == "0":
            st.session_state.calc_display = digit
        else:
            st.session_state.calc_display += digit
    st.rerun()

def input_decimal():
    """Handle decimal point input"""
    if st.session_state.calc_waiting_for_operand:
        st.session_state.calc_display = "0."
        st.session_state.calc_waiting_for_operand = False
    elif "." not in st.session_state.calc_display:
        st.session_state.calc_display += "."
    st.rerun()

def input_operator(operator):
    """Handle operator input"""
    current_value = float(st.session_state.calc_display)
    
    if st.session_state.calc_previous is None:
        st.session_state.calc_previous = current_value
    elif not st.session_state.calc_waiting_for_operand:
        result = perform_calculation()
        st.session_state.calc_display = str(result)
        st.session_state.calc_previous = result
    
    st.session_state.calc_waiting_for_operand = True
    st.session_state.calc_operator = operator
    st.rerun()

def calculate():
    """Perform calculation and show result"""
    if st.session_state.calc_operator and st.session_state.calc_previous is not None:
        current_value = float(st.session_state.calc_display)
        result = perform_calculation()
        
        # Add to history
        calculation = f"{st.session_state.calc_previous} {st.session_state.calc_operator} {current_value} = {result}"
        st.session_state.calc_history.append(calculation)
        add_recent_activity(st.session_state.username, f"Calculator: {calculation}")
        
        st.session_state.calc_display = str(result)
        st.session_state.calc_previous = None
        st.session_state.calc_operator = None
        st.session_state.calc_waiting_for_operand = True
    st.rerun()

def perform_calculation():
    """Perform the actual calculation"""
    prev = st.session_state.calc_previous
    current = float(st.session_state.calc_display)
    operator = st.session_state.calc_operator
    
    try:
        if operator == "+":
            return prev + current
        elif operator == "-":
            return prev - current
        elif operator == "×":
            return prev * current
        elif operator == "÷":
            if current == 0:
                return "Error: Division by zero"
            return prev / current
        else:
            return current
    except Exception:
        return "Error"

def scientific_operation(operation):
    """Handle scientific calculator operations"""
    try:
        current = float(st.session_state.calc_display)
        
        if operation == "sin":
            result = math.sin(math.radians(current))
        elif operation == "cos":
            result = math.cos(math.radians(current))
        elif operation == "tan":
            result = math.tan(math.radians(current))
        elif operation == "sqrt":
            if current < 0:
                result = "Error: Negative square root"
            else:
                result = math.sqrt(current)
        elif operation == "square":
            result = current ** 2
        else:
            result = current
        
        if isinstance(result, str):  # Error message
            st.session_state.calc_display = result
        else:
            # Add to history
            op_symbol = {"sin": "sin", "cos": "cos", "tan": "tan", "sqrt": "√", "square": "²"}
            calculation = f"{op_symbol.get(operation, operation)}({current}) = {result}"
            st.session_state.calc_history.append(calculation)
            add_recent_activity(st.session_state.username, f"Calculator: {calculation}")
            
            st.session_state.calc_display = str(result)
            st.session_state.calc_waiting_for_operand = True
    
    except Exception as e:
        st.session_state.calc_display = "Error"
    
    st.rerun()

def clear_all():
    """Clear all calculator state"""
    st.session_state.calc_display = "0"
    st.session_state.calc_previous = None
    st.session_state.calc_operator = None
    st.session_state.calc_waiting_for_operand = False
    st.rerun()

def clear_entry():
    """Clear current entry"""
    st.session_state.calc_display = "0"
    st.rerun()

def negate():
    """Negate current number"""
    current = float(st.session_state.calc_display)
    st.session_state.calc_display = str(-current)
    st.rerun()

def percent():
    """Convert to percentage"""
    current = float(st.session_state.calc_display)
    st.session_state.calc_display = str(current / 100)
    st.rerun()
