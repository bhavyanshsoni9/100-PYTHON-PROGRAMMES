import streamlit as st
import random
import string
import hashlib
import secrets
import platform
import psutil
import os
from datetime import datetime
from utils import add_recent_activity

def show_security():
    """Display security tools interface"""
    st.markdown("# 🔐 Security Tools")
    
    tab1, tab2, tab3, tab4 = st.tabs(["Password Generator", "Hash Generator", "System Info", "Security Checker"])
    
    with tab1:
        show_password_generator()
    
    with tab2:
        show_hash_generator()
    
    with tab3:
        show_system_info()
    
    with tab4:
        show_security_checker()

def show_password_generator():
    """Password generator tool"""
    st.markdown("### 🔑 Password Generator")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("**Settings:**")
        length = st.slider("Password Length", min_value=4, max_value=50, value=12)
        
        include_uppercase = st.checkbox("Include Uppercase Letters (A-Z)", value=True)
        include_lowercase = st.checkbox("Include Lowercase Letters (a-z)", value=True)
        include_numbers = st.checkbox("Include Numbers (0-9)", value=True)
        include_symbols = st.checkbox("Include Symbols (!@#$%^&*)", value=True)
        exclude_ambiguous = st.checkbox("Exclude Ambiguous Characters (0, O, l, I)", value=False)
        
        if st.button("🎲 Generate Password", type="primary"):
            password = generate_password(
                length, include_uppercase, include_lowercase, 
                include_numbers, include_symbols, exclude_ambiguous
            )
            if password:
                st.session_state.generated_password = password
                add_recent_activity(st.session_state.username, "Generated a secure password")
            else:
                st.error("Please select at least one character type!")
    
    with col2:
        st.markdown("**Generated Password:**")
        if 'generated_password' in st.session_state:
            password = st.session_state.generated_password
            st.code(password, language=None)
            
            # Password strength analysis
            strength = analyze_password_strength(password)
            st.markdown(f"**Strength:** {strength['level']}")
            st.progress(strength['score'] / 100)
            
            # Security tips
            st.markdown("**Security Score:**")
            for tip in strength['tips']:
                st.text(f"• {tip}")
            
            # Generate multiple passwords
            st.markdown("---")
            if st.button("Generate 5 Passwords"):
                st.markdown("**Multiple Options:**")
                for i in range(5):
                    pwd = generate_password(
                        length, include_uppercase, include_lowercase, 
                        include_numbers, include_symbols, exclude_ambiguous
                    )
                    st.code(f"{i+1}. {pwd}", language=None)
        else:
            st.info("Click 'Generate Password' to create a secure password")

def show_hash_generator():
    """Hash generator tool"""
    st.markdown("### 🔐 Hash Generator")
    
    input_text = st.text_area("Enter text to hash:", height=100)
    
    if input_text:
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**MD5:**")
            md5_hash = hashlib.md5(input_text.encode()).hexdigest()
            st.code(md5_hash, language=None)
            
            st.markdown("**SHA-1:**")
            sha1_hash = hashlib.sha1(input_text.encode()).hexdigest()
            st.code(sha1_hash, language=None)
            
            st.markdown("**SHA-256:**")
            sha256_hash = hashlib.sha256(input_text.encode()).hexdigest()
            st.code(sha256_hash, language=None)
        
        with col2:
            st.markdown("**SHA-512:**")
            sha512_hash = hashlib.sha512(input_text.encode()).hexdigest()
            st.code(sha512_hash, language=None)
            
            st.markdown("**Blake2b:**")
            blake2b_hash = hashlib.blake2b(input_text.encode()).hexdigest()
            st.code(blake2b_hash, language=None)
        
        if st.button("📋 Copy All Hashes"):
            all_hashes = f"""
MD5: {md5_hash}
SHA-1: {sha1_hash}
SHA-256: {sha256_hash}
SHA-512: {sha512_hash}
Blake2b: {blake2b_hash}
"""
            st.code(all_hashes, language=None)
            add_recent_activity(st.session_state.username, "Generated hash values")

def show_system_info():
    """System information display"""
    st.markdown("### 💻 System Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Platform Information:**")
        st.text(f"System: {platform.system()}")
        st.text(f"Release: {platform.release()}")
        st.text(f"Version: {platform.version()}")
        st.text(f"Machine: {platform.machine()}")
        st.text(f"Processor: {platform.processor()}")
        
        st.markdown("**Python Information:**")
        st.text(f"Python Version: {platform.python_version()}")
        st.text(f"Python Implementation: {platform.python_implementation()}")
    
    with col2:
        try:
            st.markdown("**System Resources:**")
            
            # CPU Information
            cpu_percent = psutil.cpu_percent(interval=1)
            st.text(f"CPU Usage: {cpu_percent}%")
            st.progress(cpu_percent / 100)
            
            # Memory Information
            memory = psutil.virtual_memory()
            st.text(f"Memory Usage: {memory.percent}%")
            st.text(f"Available Memory: {memory.available / (1024**3):.1f} GB")
            st.progress(memory.percent / 100)
            
            # Disk Information
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            st.text(f"Disk Usage: {disk_percent:.1f}%")
            st.text(f"Free Space: {disk.free / (1024**3):.1f} GB")
            st.progress(disk_percent / 100)
            
        except Exception as e:
            st.text("System resource information unavailable")
    
    # Network Information (if available)
    try:
        st.markdown("**Network Information:**")
        hostname = platform.node()
        st.text(f"Hostname: {hostname}")
        
        # Get network interfaces
        net_info = psutil.net_if_addrs()
        for interface, addresses in net_info.items():
            if interface != 'lo':  # Skip loopback
                st.text(f"Interface: {interface}")
                for addr in addresses:
                    if addr.family == 2:  # IPv4
                        st.text(f"  IPv4: {addr.address}")
    except:
        st.text("Network information unavailable")

def show_security_checker():
    """Security checker tool"""
    st.markdown("### 🛡️ Security Checker")
    
    tab_a, tab_b, tab_c = st.tabs(["Password Audit", "File Permissions", "Security Tips"])
    
    with tab_a:
        st.markdown("**Password Security Audit**")
        audit_password = st.text_input("Enter password to audit:", type="password")
        
        if audit_password:
            strength = analyze_password_strength(audit_password)
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"**Strength Level:** {strength['level']}")
                if strength['level'] == "Very Strong":
                    st.success("✅ Excellent password!")
                elif strength['level'] == "Strong":
                    st.success("✅ Good password!")
                elif strength['level'] == "Medium":
                    st.warning("⚠️ Could be stronger")
                else:
                    st.error("❌ Weak password")
            
            with col2:
                st.progress(strength['score'] / 100)
                st.text(f"Score: {strength['score']}/100")
            
            st.markdown("**Recommendations:**")
            for tip in strength['tips']:
                st.write(f"• {tip}")
    
    with tab_b:
        st.markdown("**File Permissions Checker**")
        st.info("This shows the security status of your user directory")
        
        try:
            user_dir = f"data/filesystem/{st.session_state.username}"
            if os.path.exists(user_dir):
                # Check directory permissions
                stat = os.stat(user_dir)
                permissions = oct(stat.st_mode)[-3:]
                
                st.text(f"User Directory: {user_dir}")
                st.text(f"Permissions: {permissions}")
                
                if permissions == "755":
                    st.success("✅ Directory permissions are secure")
                else:
                    st.warning("⚠️ Directory permissions may need attention")
                
                # List files with permissions
                files_info = []
                for root, dirs, files in os.walk(user_dir):
                    for file in files[:10]:  # Limit to first 10 files
                        file_path = os.path.join(root, file)
                        try:
                            stat = os.stat(file_path)
                            perm = oct(stat.st_mode)[-3:]
                            size = stat.st_size
                            files_info.append({
                                'name': file,
                                'permissions': perm,
                                'size': size
                            })
                        except:
                            continue
                
                if files_info:
                    st.markdown("**File Permissions:**")
                    for file_info in files_info:
                        st.text(f"{file_info['name']} - {file_info['permissions']} - {file_info['size']} bytes")
            else:
                st.error("User directory not found")
        except Exception as e:
            st.error(f"Cannot check permissions: {e}")
    
    with tab_c:
        st.markdown("**Security Best Practices**")
        
        tips = [
            "🔐 Use unique passwords for each account",
            "🔄 Enable two-factor authentication when available",
            "🔒 Keep your software updated",
            "📱 Be cautious of phishing emails and links",
            "💾 Regularly backup important data",
            "🌐 Use secure networks (avoid public Wi-Fi for sensitive tasks)",
            "🗂️ Regularly review and clean up file permissions",
            "👁️ Monitor account activity for unusual behavior",
            "🔑 Consider using a password manager",
            "🛡️ Use antivirus software and keep it updated"
        ]
        
        for tip in tips:
            st.markdown(f"**{tip}**")
        
        st.markdown("---")
        st.markdown("**Quick Security Check:**")
        if st.button("Run Security Assessment"):
            run_security_assessment()

def generate_password(length, uppercase, lowercase, numbers, symbols, exclude_ambiguous):
    """Generate a secure password"""
    characters = ""
    
    if uppercase:
        chars = string.ascii_uppercase
        if exclude_ambiguous:
            chars = chars.replace('O', '').replace('I', '')
        characters += chars
    
    if lowercase:
        chars = string.ascii_lowercase
        if exclude_ambiguous:
            chars = chars.replace('l', '').replace('o', '')
        characters += chars
    
    if numbers:
        chars = string.digits
        if exclude_ambiguous:
            chars = chars.replace('0', '').replace('1', '')
        characters += chars
    
    if symbols:
        characters += "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    if not characters:
        return None
    
    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password

def analyze_password_strength(password):
    """Analyze password strength"""
    score = 0
    tips = []
    
    # Length check
    if len(password) >= 12:
        score += 25
    elif len(password) >= 8:
        score += 15
        tips.append("Consider using at least 12 characters")
    else:
        tips.append("Use at least 8 characters (12+ recommended)")
    
    # Character variety
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_symbol = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
    
    variety_score = sum([has_upper, has_lower, has_digit, has_symbol])
    score += variety_score * 15
    
    if not has_upper:
        tips.append("Add uppercase letters")
    if not has_lower:
        tips.append("Add lowercase letters")
    if not has_digit:
        tips.append("Add numbers")
    if not has_symbol:
        tips.append("Add special characters")
    
    # Common patterns check
    common_patterns = ['123', 'abc', 'password', 'qwerty', '111', '000']
    has_common = any(pattern in password.lower() for pattern in common_patterns)
    if has_common:
        tips.append("Avoid common patterns or dictionary words")
    else:
        score += 10
    
    # Repetition check
    if len(set(password)) < len(password) * 0.6:
        tips.append("Avoid too many repeated characters")
    else:
        score += 10
    
    # Determine strength level
    if score >= 85:
        level = "Very Strong"
    elif score >= 70:
        level = "Strong"
    elif score >= 50:
        level = "Medium"
    elif score >= 30:
        level = "Weak"
    else:
        level = "Very Weak"
    
    if not tips:
        tips.append("Excellent password security!")
    
    return {
        'score': min(score, 100),
        'level': level,
        'tips': tips
    }

def run_security_assessment():
    """Run a quick security assessment"""
    st.markdown("**Security Assessment Results:**")
    
    checks = [
        ("✅", "User authentication is active"),
        ("✅", "Session management is secure"),
        ("✅", "File system isolation is enabled"),
        ("✅", "Data encryption for passwords"),
        ("⚠️", "Regular security updates recommended"),
        ("✅", "Secure random number generation"),
        ("✅", "Input validation and sanitization"),
        ("ℹ️", "Consider enabling additional security features")
    ]
    
    for status, message in checks:
        st.text(f"{status} {message}")
    
    add_recent_activity(st.session_state.username, "Ran security assessment")
