import json
import hashlib
import os
from datetime import datetime

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users():
    """Load users from JSON file"""
    try:
        with open("data/users.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_users(users):
    """Save users to JSON file"""
    with open("data/users.json", "w") as f:
        json.dump(users, f, indent=2)

def register_user(username, password, email=""):
    """Register a new user"""
    users = load_users()
    
    if username in users:
        return False
    
    users[username] = {
        "password": hash_password(password),
        "email": email,
        "created_at": datetime.now().isoformat(),
        "last_login": None
    }
    
    save_users(users)
    
    # Create user's filesystem directory
    user_dir = f"data/filesystem/{username}"
    os.makedirs(user_dir, exist_ok=True)
    os.makedirs(f"{user_dir}/Documents", exist_ok=True)
    os.makedirs(f"{user_dir}/Desktop", exist_ok=True)
    os.makedirs(f"{user_dir}/Downloads", exist_ok=True)
    
    return True

def authenticate_user(username, password):
    """Authenticate user login"""
    users = load_users()
    
    if username not in users:
        return False
    
    if users[username]["password"] == hash_password(password):
        # Update last login
        users[username]["last_login"] = datetime.now().isoformat()
        save_users(users)
        return True
    
    return False

def logout_user():
    """Logout current user"""
    import streamlit as st
    st.session_state.authenticated = False
    st.session_state.username = None
    st.session_state.current_app = 'desktop'
    st.rerun()
