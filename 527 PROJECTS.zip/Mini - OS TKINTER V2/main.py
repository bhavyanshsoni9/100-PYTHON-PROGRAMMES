import streamlit as st
import json
import os
from auth import authenticate_user, register_user, logout_user
from desktop import show_desktop
from utils import init_user_data, load_user_data

# Configure page
st.set_page_config(
    page_title="WebOS Desktop",
    page_icon="🖥️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Initialize session state
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'username' not in st.session_state:
    st.session_state.username = None
if 'current_app' not in st.session_state:
    st.session_state.current_app = 'desktop'

def show_login():
    """Display login/register interface"""
    st.markdown("# 🖥️ WebOS Desktop")
    st.markdown("---")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        tab1, tab2 = st.tabs(["Login", "Register"])
        
        with tab1:
            st.subheader("Login to your desktop")
            with st.form("login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                submit = st.form_submit_button("Login")
                
                if submit:
                    if authenticate_user(username, password):
                        st.session_state.authenticated = True
                        st.session_state.username = username
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid username or password")
        
        with tab2:
            st.subheader("Create new account")
            with st.form("register_form"):
                new_username = st.text_input("Choose Username")
                new_password = st.text_input("Choose Password", type="password")
                confirm_password = st.text_input("Confirm Password", type="password")
                email = st.text_input("Email (optional)")
                submit_reg = st.form_submit_button("Register")
                
                if submit_reg:
                    if not new_username or not new_password:
                        st.error("Username and password are required")
                    elif new_password != confirm_password:
                        st.error("Passwords do not match")
                    elif register_user(new_username, new_password, email):
                        st.success("Account created successfully! Please login.")
                    else:
                        st.error("Username already exists")

def main():
    """Main application entry point"""
    # Create data directories if they don't exist
    os.makedirs("data", exist_ok=True)
    os.makedirs("data/filesystem", exist_ok=True)
    
    # Initialize users file if it doesn't exist
    if not os.path.exists("data/users.json"):
        with open("data/users.json", "w") as f:
            json.dump({}, f)
    
    if not st.session_state.authenticated:
        show_login()
    else:
        # Initialize user data
        init_user_data(st.session_state.username)
        
        # Show desktop interface
        show_desktop()

if __name__ == "__main__":
    main()
