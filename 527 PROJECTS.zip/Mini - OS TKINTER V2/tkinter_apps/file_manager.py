import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import os
import shutil
from datetime import datetime

class FileManagerApp:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        self.current_path = f"data/filesystem/{parent_app.current_user}"
        self.user_root = self.current_path
        
        # Create window
        self.window = tk.Toplevel(parent_app.root)
        self.window.title("File Manager")
        self.window.geometry("800x600")
        self.window.configure(bg="#F3F2F1")
        
        self.setup_ui()
        self.refresh_directory()
    
    def setup_ui(self):
        """Setup the file manager UI"""
        # Toolbar
        toolbar = ttk.Frame(self.window)
        toolbar.pack(fill='x', padx=10, pady=5)
        
        ttk.Button(toolbar, text="🏠 Home", command=self.go_home).pack(side='left', padx=5)
        ttk.Button(toolbar, text="⬆️ Up", command=self.go_up).pack(side='left', padx=5)
        ttk.Button(toolbar, text="🔄 Refresh", command=self.refresh_directory).pack(side='left', padx=5)
        ttk.Button(toolbar, text="📁 New Folder", command=self.create_folder).pack(side='left', padx=5)
        ttk.Button(toolbar, text="📄 New File", command=self.create_file).pack(side='left', padx=5)
        ttk.Button(toolbar, text="📤 Upload", command=self.upload_file).pack(side='left', padx=5)
        
        # Path display
        self.path_var = tk.StringVar()
        self.path_label = ttk.Label(self.window, textvariable=self.path_var, 
                                  font=('Segoe UI', 10), background="#F3F2F1")
        self.path_label.pack(fill='x', padx=10, pady=5)
        
        # File listing
        list_frame = ttk.Frame(self.window)
        list_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Treeview for file listing
        columns = ('Name', 'Type', 'Size', 'Modified')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='tree headings')
        
        self.tree.heading('#0', text='Icon')
        self.tree.heading('Name', text='Name')
        self.tree.heading('Type', text='Type')
        self.tree.heading('Size', text='Size')
        self.tree.heading('Modified', text='Modified')
        
        self.tree.column('#0', width=50)
        self.tree.column('Name', width=300)
        self.tree.column('Type', width=100)
        self.tree.column('Size', width=100)
        self.tree.column('Modified', width=150)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # Bind double-click
        self.tree.bind('<Double-1>', self.on_double_click)
        self.tree.bind('<Button-3>', self.show_context_menu)  # Right-click
    
    def refresh_directory(self):
        """Refresh the directory listing"""
        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Update path display
        relative_path = self.current_path.replace(self.user_root, "").strip("/")
        display_path = f"Home/{relative_path}" if relative_path else "Home"
        self.path_var.set(f"Location: {display_path}")
        
        if not os.path.exists(self.current_path):
            messagebox.showerror("Error", "Directory not found")
            return
        
        try:
            items = []
            for item_name in os.listdir(self.current_path):
                item_path = os.path.join(self.current_path, item_name)
                is_dir = os.path.isdir(item_path)
                
                stat = os.stat(item_path)
                size = self.format_size(stat.st_size) if not is_dir else "-"
                modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
                
                items.append({
                    'name': item_name,
                    'path': item_path,
                    'is_dir': is_dir,
                    'size': size,
                    'modified': modified
                })
            
            # Sort directories first, then files
            items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
            
            # Insert items
            for item in items:
                icon = '📁' if item['is_dir'] else '📄'
                item_type = 'Folder' if item['is_dir'] else 'File'
                
                self.tree.insert('', 'end', text=icon, 
                               values=(item['name'], item_type, item['size'], item['modified']),
                               tags=(item['path'], 'dir' if item['is_dir'] else 'file'))
        
        except PermissionError:
            messagebox.showerror("Error", "Permission denied")
        except Exception as e:
            messagebox.showerror("Error", f"Error reading directory: {e}")
    
    def format_size(self, size_bytes):
        """Format file size in human readable format"""
        if size_bytes == 0:
            return "0 B"
        
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024
        
        return f"{size_bytes:.1f} TB"
    
    def on_double_click(self, event):
        """Handle double-click on item"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        tags = self.tree.item(selection[0], 'tags')
        
        if not tags:
            return
        
        item_path = tags[0]
        is_dir = 'dir' in tags
        
        if is_dir:
            self.current_path = item_path
            self.refresh_directory()
        else:
            # Open file (simple text display for now)
            self.open_file(item_path)
    
    def open_file(self, file_path):
        """Open file for viewing/editing"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Create file viewer window
            viewer = tk.Toplevel(self.window)
            viewer.title(f"File Viewer - {os.path.basename(file_path)}")
            viewer.geometry("600x400")
            
            text_widget = tk.Text(viewer, wrap='word')
            text_widget.pack(fill='both', expand=True, padx=10, pady=10)
            text_widget.insert('1.0', content)
            
            # Save button
            def save_file():
                new_content = text_widget.get('1.0', tk.END + '-1c')
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(new_content)
                    messagebox.showinfo("Success", "File saved successfully!")
                    self.parent_app.add_recent_activity(f"Edited file: {os.path.basename(file_path)}")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to save file: {e}")
            
            ttk.Button(viewer, text="Save", command=save_file).pack(pady=5)
            
        except UnicodeDecodeError:
            messagebox.showinfo("Info", "Binary file - cannot display content")
        except Exception as e:
            messagebox.showerror("Error", f"Cannot open file: {e}")
    
    def show_context_menu(self, event):
        """Show context menu on right-click"""
        selection = self.tree.selection()
        
        menu = tk.Menu(self.window, tearoff=0)
        
        if selection:
            item = self.tree.item(selection[0])
            tags = self.tree.item(selection[0], 'tags')
            item_path = tags[0] if tags else None
            
            if item_path:
                menu.add_command(label="Delete", command=lambda: self.delete_item(item_path))
                menu.add_separator()
        
        menu.add_command(label="New Folder", command=self.create_folder)
        menu.add_command(label="New File", command=self.create_file)
        menu.add_command(label="Upload File", command=self.upload_file)
        menu.add_separator()
        menu.add_command(label="Refresh", command=self.refresh_directory)
        
        menu.post(event.x_root, event.y_root)
    
    def go_home(self):
        """Go to home directory"""
        self.current_path = self.user_root
        self.refresh_directory()
    
    def go_up(self):
        """Go up one directory"""
        parent_path = os.path.dirname(self.current_path)
        if parent_path.startswith(self.user_root):
            self.current_path = parent_path
            self.refresh_directory()
    
    def create_folder(self):
        """Create a new folder"""
        folder_name = simpledialog.askstring("New Folder", "Enter folder name:")
        if folder_name:
            folder_path = os.path.join(self.current_path, folder_name)
            try:
                os.makedirs(folder_path, exist_ok=True)
                self.refresh_directory()
                self.parent_app.add_recent_activity(f"Created folder: {folder_name}")
                messagebox.showinfo("Success", f"Folder '{folder_name}' created!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create folder: {e}")
    
    def create_file(self):
        """Create a new file"""
        file_name = simpledialog.askstring("New File", "Enter file name:")
        if file_name:
            file_path = os.path.join(self.current_path, file_name)
            try:
                with open(file_path, 'w') as f:
                    f.write("")
                self.refresh_directory()
                self.parent_app.add_recent_activity(f"Created file: {file_name}")
                messagebox.showinfo("Success", f"File '{file_name}' created!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create file: {e}")
    
    def upload_file(self):
        """Upload a file"""
        file_path = filedialog.askopenfilename()
        if file_path:
            try:
                file_name = os.path.basename(file_path)
                dest_path = os.path.join(self.current_path, file_name)
                shutil.copy2(file_path, dest_path)
                self.refresh_directory()
                self.parent_app.add_recent_activity(f"Uploaded file: {file_name}")
                messagebox.showinfo("Success", f"File '{file_name}' uploaded!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to upload file: {e}")
    
    def delete_item(self, item_path):
        """Delete a file or folder"""
        item_name = os.path.basename(item_path)
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete '{item_name}'?"):
            try:
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                else:
                    os.remove(item_path)
                
                self.refresh_directory()
                self.parent_app.add_recent_activity(f"Deleted: {item_name}")
                messagebox.showinfo("Success", f"'{item_name}' deleted!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete: {e}")