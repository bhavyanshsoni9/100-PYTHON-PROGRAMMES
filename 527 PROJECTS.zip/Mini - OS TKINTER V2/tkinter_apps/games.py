import tkinter as tk
from tkinter import ttk, messagebox
import random
import time
from datetime import datetime

class GamesApp:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        
        # Create window
        self.window = tk.Toplevel(parent_app.root)
        self.window.title("Games")
        self.window.geometry("700x600")
        self.window.configure(bg="#F3F2F1")
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the games UI"""
        # Game selection frame
        selection_frame = ttk.Frame(self.window, padding=10)
        selection_frame.pack(fill='x')
        
        ttk.Label(selection_frame, text="Choose a Game:", font=('Segoe UI', 12, 'bold')).pack(side='left')
        
        games = [
            "Tic Tac Toe", "Memory Game", "Number Guessing", 
            "Rock Paper Scissors", "Word Puzzle", "Snake Game"
        ]
        
        self.game_var = tk.StringVar(value=games[0])
        game_combo = ttk.Combobox(selection_frame, textvariable=self.game_var, 
                                values=games, state='readonly', width=20)
        game_combo.pack(side='right', padx=(10, 0))
        game_combo.bind('<<ComboboxSelected>>', self.switch_game)
        
        # Game area frame
        self.game_frame = ttk.Frame(self.window)
        self.game_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Statistics frame
        stats_frame = ttk.LabelFrame(self.window, text="Game Statistics", padding=10)
        stats_frame.pack(fill='x', padx=10, pady=(0, 10))
        
        self.stats_text = tk.Text(stats_frame, height=4, font=('Segoe UI', 9))
        self.stats_text.pack(fill='x')
        
        # Start with first game
        self.current_game = None
        self.switch_game()
        self.update_stats()
    
    def switch_game(self, event=None):
        """Switch to selected game"""
        # Clear current game
        for widget in self.game_frame.winfo_children():
            widget.destroy()
        
        selected_game = self.game_var.get()
        
        if selected_game == "Tic Tac Toe":
            self.setup_tic_tac_toe()
        elif selected_game == "Memory Game":
            self.setup_memory_game()
        elif selected_game == "Number Guessing":
            self.setup_number_guessing()
        elif selected_game == "Rock Paper Scissors":
            self.setup_rock_paper_scissors()
        elif selected_game == "Word Puzzle":
            self.setup_word_puzzle()
        elif selected_game == "Snake Game":
            self.setup_snake_game()
        
        self.current_game = selected_game
    
    def setup_tic_tac_toe(self):
        """Setup Tic Tac Toe game"""
        # Game state
        self.ttt_board = [' ' for _ in range(9)]
        self.ttt_current_player = 'X'
        self.ttt_game_over = False
        self.ttt_winner = None
        
        ttk.Label(self.game_frame, text="Tic Tac Toe", font=('Segoe UI', 14, 'bold')).pack(pady=10)
        
        # Status label
        self.ttt_status = tk.StringVar(value="Player X's turn")
        ttk.Label(self.game_frame, textvariable=self.ttt_status, font=('Segoe UI', 12)).pack(pady=5)
        
        # Game board
        board_frame = ttk.Frame(self.game_frame)
        board_frame.pack(pady=10)
        
        self.ttt_buttons = []
        for i in range(3):
            for j in range(3):
                pos = i * 3 + j
                btn = tk.Button(board_frame, text=' ', font=('Arial', 20, 'bold'),
                              width=3, height=1, command=lambda p=pos: self.ttt_move(p))
                btn.grid(row=i, column=j, padx=2, pady=2)
                self.ttt_buttons.append(btn)
        
        # Reset button
        ttk.Button(self.game_frame, text="New Game", command=self.reset_tic_tac_toe).pack(pady=10)
    
    def setup_memory_game(self):
        """Setup Memory matching game"""
        # Game state
        symbols = ['🎯', '🎮', '🎲', '🎪', '🎨', '🎭', '🎺', '🎸'] * 2
        random.shuffle(symbols)
        self.memory_cards = symbols
        self.memory_revealed = [False] * 16
        self.memory_matched = [False] * 16
        self.memory_first_card = None
        self.memory_second_card = None
        self.memory_moves = 0
        self.memory_matches = 0
        
        ttk.Label(self.game_frame, text="Memory Game", font=('Segoe UI', 14, 'bold')).pack(pady=10)
        
        # Status
        self.memory_status = tk.StringVar(value=f"Moves: {self.memory_moves} | Matches: {self.memory_matches}/8")
        ttk.Label(self.game_frame, textvariable=self.memory_status, font=('Segoe UI', 12)).pack(pady=5)
        
        # Game board
        board_frame = ttk.Frame(self.game_frame)
        board_frame.pack(pady=10)
        
        self.memory_buttons = []
        for i in range(4):
            for j in range(4):
                pos = i * 4 + j
                btn = tk.Button(board_frame, text='❓', font=('Arial', 16),
                              width=4, height=2, command=lambda p=pos: self.memory_click(p))
                btn.grid(row=i, column=j, padx=2, pady=2)
                self.memory_buttons.append(btn)
        
        # Reset button
        ttk.Button(self.game_frame, text="New Game", command=self.setup_memory_game).pack(pady=10)
    
    def setup_number_guessing(self):
        """Setup Number Guessing game"""
        # Game state
        self.guess_number = random.randint(1, 100)
        self.guess_attempts = 0
        self.guess_history = []
        
        ttk.Label(self.game_frame, text="Number Guessing Game", font=('Segoe UI', 14, 'bold')).pack(pady=10)
        ttk.Label(self.game_frame, text="I'm thinking of a number between 1 and 100", 
                 font=('Segoe UI', 11)).pack(pady=5)
        
        # Input frame
        input_frame = ttk.Frame(self.game_frame)
        input_frame.pack(pady=10)
        
        ttk.Label(input_frame, text="Your guess:").pack(side='left')
        self.guess_entry = ttk.Entry(input_frame, width=10)
        self.guess_entry.pack(side='left', padx=(10, 5))
        ttk.Button(input_frame, text="Guess!", command=self.make_guess).pack(side='left')
        
        self.guess_entry.bind('<Return>', lambda e: self.make_guess())
        
        # Status
        self.guess_status = tk.StringVar(value="Make your first guess!")
        ttk.Label(self.game_frame, textvariable=self.guess_status, font=('Segoe UI', 12)).pack(pady=10)
        
        # Attempts
        self.guess_attempts_var = tk.StringVar(value="Attempts: 0")
        ttk.Label(self.game_frame, textvariable=self.guess_attempts_var).pack()
        
        # History
        history_frame = ttk.LabelFrame(self.game_frame, text="Guess History", padding=5)
        history_frame.pack(fill='both', expand=True, pady=10)
        
        self.guess_history_text = tk.Text(history_frame, height=6, font=('Segoe UI', 9))
        self.guess_history_text.pack(fill='both', expand=True)
        
        # Reset button
        ttk.Button(self.game_frame, text="New Game", command=self.setup_number_guessing).pack(pady=5)
    
    def setup_rock_paper_scissors(self):
        """Setup Rock Paper Scissors game"""
        # Game state
        if not hasattr(self, 'rps_user_score'):
            self.rps_user_score = 0
            self.rps_computer_score = 0
            self.rps_ties = 0
        
        ttk.Label(self.game_frame, text="Rock Paper Scissors", font=('Segoe UI', 14, 'bold')).pack(pady=10)
        
        # Score display
        self.rps_score_var = tk.StringVar(value=f"You: {self.rps_user_score} | Computer: {self.rps_computer_score} | Ties: {self.rps_ties}")
        ttk.Label(self.game_frame, textvariable=self.rps_score_var, font=('Segoe UI', 12)).pack(pady=10)
        
        # Choice buttons
        choices_frame = ttk.Frame(self.game_frame)
        choices_frame.pack(pady=20)
        
        choices = [('🪨 Rock', 'rock'), ('📄 Paper', 'paper'), ('✂️ Scissors', 'scissors')]
        
        for text, value in choices:
            btn = tk.Button(choices_frame, text=text, font=('Arial', 14),
                          width=12, height=3, command=lambda v=value: self.play_rps(v))
            btn.pack(side='left', padx=10)
        
        # Last result
        self.rps_result_var = tk.StringVar(value="Make your choice!")
        ttk.Label(self.game_frame, textvariable=self.rps_result_var, font=('Segoe UI', 12)).pack(pady=20)
        
        # Reset scores button
        ttk.Button(self.game_frame, text="Reset Scores", command=self.reset_rps_scores).pack(pady=10)
    
    def setup_word_puzzle(self):
        """Setup Word Puzzle game (Hangman-style)"""
        # Word list
        words = ["PYTHON", "COMPUTER", "KEYBOARD", "MONITOR", "INTERNET", 
                "WEBSITE", "PROGRAMMING", "DEVELOPER", "SOFTWARE", "HARDWARE"]
        
        # Game state
        self.puzzle_word = random.choice(words)
        self.puzzle_guessed = ['_'] * len(self.puzzle_word)
        self.puzzle_attempts = 6
        self.puzzle_used_letters = []
        self.puzzle_won = False
        self.puzzle_lost = False
        
        ttk.Label(self.game_frame, text="Word Puzzle", font=('Segoe UI', 14, 'bold')).pack(pady=10)
        
        # Word display
        self.puzzle_word_var = tk.StringVar(value=' '.join(self.puzzle_guessed))
        word_label = ttk.Label(self.game_frame, textvariable=self.puzzle_word_var, 
                              font=('Courier', 20, 'bold'))
        word_label.pack(pady=10)
        
        # Attempts remaining
        self.puzzle_attempts_var = tk.StringVar(value=f"Attempts remaining: {self.puzzle_attempts}")
        ttk.Label(self.game_frame, textvariable=self.puzzle_attempts_var, font=('Segoe UI', 12)).pack(pady=5)
        
        # Used letters
        self.puzzle_used_var = tk.StringVar(value="Used letters: ")
        ttk.Label(self.game_frame, textvariable=self.puzzle_used_var, font=('Segoe UI', 11)).pack(pady=5)
        
        # Letter input
        input_frame = ttk.Frame(self.game_frame)
        input_frame.pack(pady=10)
        
        ttk.Label(input_frame, text="Guess a letter:").pack(side='left')
        self.puzzle_entry = ttk.Entry(input_frame, width=5, font=('Segoe UI', 12))
        self.puzzle_entry.pack(side='left', padx=(10, 5))
        ttk.Button(input_frame, text="Guess!", command=self.guess_letter).pack(side='left')
        
        self.puzzle_entry.bind('<Return>', lambda e: self.guess_letter())
        
        # Status
        self.puzzle_status_var = tk.StringVar(value="Guess letters to reveal the word!")
        ttk.Label(self.game_frame, textvariable=self.puzzle_status_var, font=('Segoe UI', 12)).pack(pady=10)
        
        # Reset button
        ttk.Button(self.game_frame, text="New Game", command=self.setup_word_puzzle).pack(pady=10)
    
    def setup_snake_game(self):
        """Setup Snake game (simplified)"""
        ttk.Label(self.game_frame, text="Snake Game", font=('Segoe UI', 14, 'bold')).pack(pady=10)
        
        # Game state
        self.snake_pos = [(5, 5)]
        self.snake_food = (10, 10)
        self.snake_direction = 'RIGHT'
        self.snake_score = 0
        self.snake_game_over = False
        
        # Score
        self.snake_score_var = tk.StringVar(value=f"Score: {self.snake_score}")
        ttk.Label(self.game_frame, textvariable=self.snake_score_var, font=('Segoe UI', 12)).pack(pady=5)
        
        # Controls
        controls_frame = ttk.Frame(self.game_frame)
        controls_frame.pack(pady=10)
        
        ttk.Button(controls_frame, text="⬆️ Up", command=lambda: self.snake_move('UP')).grid(row=0, column=1, padx=2, pady=2)
        ttk.Button(controls_frame, text="⬅️ Left", command=lambda: self.snake_move('LEFT')).grid(row=1, column=0, padx=2, pady=2)
        ttk.Button(controls_frame, text="⬇️ Down", command=lambda: self.snake_move('DOWN')).grid(row=1, column=1, padx=2, pady=2)
        ttk.Button(controls_frame, text="➡️ Right", command=lambda: self.snake_move('RIGHT')).grid(row=1, column=2, padx=2, pady=2)
        
        # Game display (simplified)
        self.snake_display = tk.Text(self.game_frame, width=30, height=15, font=('Courier', 8))
        self.snake_display.pack(pady=10)
        
        # Auto move button
        ttk.Button(self.game_frame, text="Auto Move", command=self.snake_auto_move).pack(pady=5)
        
        # Reset button
        ttk.Button(self.game_frame, text="New Game", command=self.setup_snake_game).pack(pady=5)
        
        self.update_snake_display()
    
    # Tic Tac Toe methods
    def ttt_move(self, pos):
        """Make a Tic Tac Toe move"""
        if self.ttt_game_over or self.ttt_board[pos] != ' ':
            return
        
        self.ttt_board[pos] = self.ttt_current_player
        self.ttt_buttons[pos].config(text=self.ttt_current_player, state='disabled')
        
        winner = self.check_ttt_winner()
        if winner:
            self.ttt_winner = winner
            self.ttt_game_over = True
            self.ttt_status.set(f"Player {winner} wins!")
            self.update_game_stats('tictactoe', 'win' if winner == 'X' else 'loss')
        elif ' ' not in self.ttt_board:
            self.ttt_game_over = True
            self.ttt_status.set("It's a tie!")
            self.update_game_stats('tictactoe', 'tie')
        else:
            self.ttt_current_player = 'O' if self.ttt_current_player == 'X' else 'X'
            self.ttt_status.set(f"Player {self.ttt_current_player}'s turn")
            
            # Simple AI for O
            if self.ttt_current_player == 'O' and not self.ttt_game_over:
                self.window.after(500, self.ttt_ai_move)
    
    def ttt_ai_move(self):
        """AI move for Tic Tac Toe"""
        available = [i for i, cell in enumerate(self.ttt_board) if cell == ' ']
        if available:
            pos = random.choice(available)
            self.ttt_move(pos)
    
    def check_ttt_winner(self):
        """Check for Tic Tac Toe winner"""
        lines = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],  # rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8],  # columns
            [0, 4, 8], [2, 4, 6]              # diagonals
        ]
        
        for line in lines:
            if (self.ttt_board[line[0]] == self.ttt_board[line[1]] == 
                self.ttt_board[line[2]] != ' '):
                return self.ttt_board[line[0]]
        return None
    
    def reset_tic_tac_toe(self):
        """Reset Tic Tac Toe game"""
        self.ttt_board = [' ' for _ in range(9)]
        self.ttt_current_player = 'X'
        self.ttt_game_over = False
        self.ttt_winner = None
        self.ttt_status.set("Player X's turn")
        
        for btn in self.ttt_buttons:
            btn.config(text=' ', state='normal')
    
    # Memory Game methods
    def memory_click(self, pos):
        """Handle memory game card click"""
        if (self.memory_matched[pos] or self.memory_revealed[pos] or 
            self.memory_matches == 8):
            return
        
        self.memory_revealed[pos] = True
        self.memory_buttons[pos].config(text=self.memory_cards[pos])
        
        if self.memory_first_card is None:
            self.memory_first_card = pos
        elif self.memory_second_card is None and pos != self.memory_first_card:
            self.memory_second_card = pos
            self.memory_moves += 1
            
            # Check for match after short delay
            self.window.after(1000, self.check_memory_match)
    
    def check_memory_match(self):
        """Check memory game match"""
        if (self.memory_cards[self.memory_first_card] == 
            self.memory_cards[self.memory_second_card]):
            # Match found
            self.memory_matched[self.memory_first_card] = True
            self.memory_matched[self.memory_second_card] = True
            self.memory_matches += 1
            
            if self.memory_matches == 8:
                self.memory_status.set(f"🎉 You won in {self.memory_moves} moves!")
                self.update_game_stats('memory', 'win', self.memory_moves)
        else:
            # No match - hide cards
            self.memory_revealed[self.memory_first_card] = False
            self.memory_revealed[self.memory_second_card] = False
            self.memory_buttons[self.memory_first_card].config(text='❓')
            self.memory_buttons[self.memory_second_card].config(text='❓')
        
        self.memory_first_card = None
        self.memory_second_card = None
        
        if self.memory_matches < 8:
            self.memory_status.set(f"Moves: {self.memory_moves} | Matches: {self.memory_matches}/8")
    
    # Number Guessing methods
    def make_guess(self):
        """Make a number guess"""
        try:
            guess = int(self.guess_entry.get())
            if guess < 1 or guess > 100:
                messagebox.showerror("Error", "Please enter a number between 1 and 100")
                return
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number")
            return
        
        self.guess_attempts += 1
        self.guess_attempts_var.set(f"Attempts: {self.guess_attempts}")
        
        if guess == self.guess_number:
            self.guess_status.set(f"🎉 Correct! You guessed it in {self.guess_attempts} attempts!")
            self.guess_entry.config(state='disabled')
            self.update_game_stats('guessing', 'win', self.guess_attempts)
        elif guess < self.guess_number:
            self.guess_status.set("📈 Too low! Try higher.")
            self.guess_history.append(f"Guess {self.guess_attempts}: {guess} (too low)")
        else:
            self.guess_status.set("📉 Too high! Try lower.")
            self.guess_history.append(f"Guess {self.guess_attempts}: {guess} (too high)")
        
        # Update history
        self.guess_history_text.delete('1.0', tk.END)
        for entry in self.guess_history[-10:]:  # Show last 10
            self.guess_history_text.insert(tk.END, entry + '\n')
        
        self.guess_entry.delete(0, tk.END)
    
    # Rock Paper Scissors methods
    def play_rps(self, user_choice):
        """Play Rock Paper Scissors"""
        choices = ['rock', 'paper', 'scissors']
        computer_choice = random.choice(choices)
        
        choice_display = {'rock': '🪨 Rock', 'paper': '📄 Paper', 'scissors': '✂️ Scissors'}
        
        result_text = f"You: {choice_display[user_choice]} | Computer: {choice_display[computer_choice]}\n"
        
        if user_choice == computer_choice:
            result_text += "It's a tie!"
            self.rps_ties += 1
            result = 'tie'
        elif ((user_choice == 'rock' and computer_choice == 'scissors') or
              (user_choice == 'paper' and computer_choice == 'rock') or
              (user_choice == 'scissors' and computer_choice == 'paper')):
            result_text += "You win!"
            self.rps_user_score += 1
            result = 'win'
        else:
            result_text += "Computer wins!"
            self.rps_computer_score += 1
            result = 'loss'
        
        self.rps_result_var.set(result_text)
        self.rps_score_var.set(f"You: {self.rps_user_score} | Computer: {self.rps_computer_score} | Ties: {self.rps_ties}")
        
        self.update_game_stats('rps', result)
    
    def reset_rps_scores(self):
        """Reset RPS scores"""
        self.rps_user_score = 0
        self.rps_computer_score = 0
        self.rps_ties = 0
        self.rps_score_var.set(f"You: {self.rps_user_score} | Computer: {self.rps_computer_score} | Ties: {self.rps_ties}")
        self.rps_result_var.set("Make your choice!")
    
    # Word Puzzle methods
    def guess_letter(self):
        """Guess a letter in word puzzle"""
        if self.puzzle_won or self.puzzle_lost:
            return
        
        letter = self.puzzle_entry.get().upper().strip()
        self.puzzle_entry.delete(0, tk.END)
        
        if not letter or len(letter) != 1 or not letter.isalpha():
            messagebox.showerror("Error", "Please enter a single letter")
            return
        
        if letter in self.puzzle_used_letters:
            messagebox.showwarning("Warning", "You already guessed that letter")
            return
        
        self.puzzle_used_letters.append(letter)
        self.puzzle_used_var.set(f"Used letters: {', '.join(self.puzzle_used_letters)}")
        
        if letter in self.puzzle_word:
            # Correct guess
            for i, char in enumerate(self.puzzle_word):
                if char == letter:
                    self.puzzle_guessed[i] = letter
            
            self.puzzle_word_var.set(' '.join(self.puzzle_guessed))
            
            if '_' not in self.puzzle_guessed:
                self.puzzle_won = True
                self.puzzle_status_var.set(f"🎉 Congratulations! The word was {self.puzzle_word}!")
                self.update_game_stats('word_puzzle', 'win')
        else:
            # Wrong guess
            self.puzzle_attempts -= 1
            self.puzzle_attempts_var.set(f"Attempts remaining: {self.puzzle_attempts}")
            
            if self.puzzle_attempts == 0:
                self.puzzle_lost = True
                self.puzzle_status_var.set(f"💀 Game Over! The word was {self.puzzle_word}")
                self.update_game_stats('word_puzzle', 'loss')
    
    # Snake Game methods
    def snake_move(self, direction):
        """Move snake in direction"""
        if self.snake_game_over:
            return
        
        # Prevent moving into opposite direction
        opposites = {'UP': 'DOWN', 'DOWN': 'UP', 'LEFT': 'RIGHT', 'RIGHT': 'LEFT'}
        if direction == opposites.get(self.snake_direction):
            return
        
        self.snake_direction = direction
        self.move_snake()
    
    def snake_auto_move(self):
        """Auto move snake"""
        if not self.snake_game_over:
            self.move_snake()
    
    def move_snake(self):
        """Move snake in current direction"""
        if self.snake_game_over:
            return
        
        head_x, head_y = self.snake_pos[0]
        
        # Calculate new head position
        if self.snake_direction == 'UP':
            new_head = (head_x, head_y - 1)
        elif self.snake_direction == 'DOWN':
            new_head = (head_x, head_y + 1)
        elif self.snake_direction == 'LEFT':
            new_head = (head_x - 1, head_y)
        elif self.snake_direction == 'RIGHT':
            new_head = (head_x + 1, head_y)
        
        # Check boundaries (15x15 grid)
        if (new_head[0] < 0 or new_head[0] >= 15 or 
            new_head[1] < 0 or new_head[1] >= 15):
            self.snake_game_over = True
            self.snake_score_var.set(f"💀 Game Over! Final Score: {self.snake_score}")
            self.update_game_stats('snake', 'loss', self.snake_score)
            return
        
        # Check self collision
        if new_head in self.snake_pos:
            self.snake_game_over = True
            self.snake_score_var.set(f"💀 Game Over! Final Score: {self.snake_score}")
            self.update_game_stats('snake', 'loss', self.snake_score)
            return
        
        # Add new head
        self.snake_pos.insert(0, new_head)
        
        # Check food collision
        if new_head == self.snake_food:
            self.snake_score += 1
            self.snake_score_var.set(f"Score: {self.snake_score}")
            # Generate new food
            while True:
                new_food = (random.randint(0, 14), random.randint(0, 14))
                if new_food not in self.snake_pos:
                    self.snake_food = new_food
                    break
        else:
            # Remove tail
            self.snake_pos.pop()
        
        self.update_snake_display()
    
    def update_snake_display(self):
        """Update snake game display"""
        self.snake_display.delete('1.0', tk.END)
        
        grid = [['.' for _ in range(15)] for _ in range(15)]
        
        # Place snake
        for i, (x, y) in enumerate(self.snake_pos):
            if 0 <= x < 15 and 0 <= y < 15:
                grid[y][x] = 'O' if i == 0 else 'o'
        
        # Place food
        if 0 <= self.snake_food[0] < 15 and 0 <= self.snake_food[1] < 15:
            grid[self.snake_food[1]][self.snake_food[0]] = '*'
        
        # Display grid
        for row in grid:
            self.snake_display.insert(tk.END, ''.join(row) + '\n')
    
    # Statistics methods
    def update_game_stats(self, game_name, result, score=0):
        """Update game statistics"""
        if 'game_stats' not in self.parent_app.user_data:
            self.parent_app.user_data['game_stats'] = {}
        
        stats = self.parent_app.user_data['game_stats']
        
        if game_name not in stats:
            stats[game_name] = {'games_played': 0, 'wins': 0, 'losses': 0, 'ties': 0, 'best_score': 0}
        
        game_stats = stats[game_name]
        game_stats['games_played'] += 1
        
        if result == 'win':
            game_stats['wins'] += 1
        elif result == 'loss':
            game_stats['losses'] += 1
        elif result == 'tie':
            game_stats['ties'] += 1
        
        if score > game_stats['best_score']:
            game_stats['best_score'] = score
        
        self.parent_app.save_user_data()
        self.parent_app.add_recent_activity(f"Played {game_name.replace('_', ' ').title()}")
        
        self.update_stats()
    
    def update_stats(self):
        """Update statistics display"""
        stats = self.parent_app.user_data.get('game_stats', {})
        
        if not stats:
            self.stats_text.delete('1.0', tk.END)
            self.stats_text.insert('1.0', "No game statistics yet. Play some games to see your stats!")
            return
        
        total_games = sum(game_stats.get('games_played', 0) for game_stats in stats.values())
        total_wins = sum(game_stats.get('wins', 0) for game_stats in stats.values())
        win_rate = (total_wins / total_games * 100) if total_games > 0 else 0
        
        stats_text = f"Total Games: {total_games} | Total Wins: {total_wins} | Win Rate: {win_rate:.1f}%\n\n"
        
        for game, game_stats in stats.items():
            game_name = game.replace('_', ' ').title()
            played = game_stats.get('games_played', 0)
            wins = game_stats.get('wins', 0)
            best = game_stats.get('best_score', 0)
            stats_text += f"{game_name}: {played} played, {wins} wins, best score: {best}\n"
        
        self.stats_text.delete('1.0', tk.END)
        self.stats_text.insert('1.0', stats_text)