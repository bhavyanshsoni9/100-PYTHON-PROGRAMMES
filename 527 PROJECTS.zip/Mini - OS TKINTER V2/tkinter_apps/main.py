import tkinter as tk
from tkinter import ttk
import math
from decimal import Decimal, getcontext

# Set decimal precision
getcontext().prec = 15

class CalculatorApp:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        
        # Create window
        self.window = tk.Toplevel(parent_app.root)
        self.window.title("Calculator")
        self.window.geometry("400x600")
        self.window.configure(bg="#F3F2F1")
        self.window.resizable(False, False)
        
        # Calculator state
        self.display_var = tk.StringVar(value="0")
        self.previous = None
        self.operator = None
        self.waiting_for_operand = False
        self.history = []
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the calculator UI"""
        # Display
        display_frame = ttk.Frame(self.window, padding=10)
        display_frame.pack(fill='x')
        
        display = ttk.Label(display_frame, textvariable=self.display_var, 
                          font=('Segoe UI', 20, 'bold'), anchor='e',
                          background='white', relief='sunken', padding=10)
        display.pack(fill='x', ipady=10)
        
        # History frame
        history_frame = ttk.LabelFrame(self.window, text="History", padding=5)
        history_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # History listbox
        self.history_listbox = tk.Listbox(history_frame, font=('Segoe UI', 9), height=6)
        history_scrollbar = ttk.Scrollbar(history_frame, orient='vertical', command=self.history_listbox.yview)
        self.history_listbox.configure(yscrollcommand=history_scrollbar.set)
        
        self.history_listbox.pack(side='left', fill='both', expand=True)
        history_scrollbar.pack(side='right', fill='y')
        
        # Clear history button
        ttk.Button(history_frame, text="Clear History", 
                  command=self.clear_history).pack(pady=5)
        
        # Button frame
        button_frame = ttk.Frame(self.window, padding=10)
        button_frame.pack(fill='both')
        
        # Scientific functions row
        sci_buttons = [
            ('sin', lambda: self.scientific_operation('sin')),
            ('cos', lambda: self.scientific_operation('cos')),
            ('tan', lambda: self.scientific_operation('tan')),
            ('√', lambda: self.scientific_operation('sqrt')),
            ('x²', lambda: self.scientific_operation('square'))
        ]
        
        for i, (text, command) in enumerate(sci_buttons):
            btn = ttk.Button(button_frame, text=text, command=command, width=6)
            btn.grid(row=0, column=i, padx=2, pady=2, sticky='ew')
        
        # Memory and clear row
        mem_buttons = [
            ('AC', self.clear_all),
            ('C', self.clear_entry),
            ('±', self.negate),
            ('%', self.percent),
            ('÷', lambda: self.input_operator('÷'))
        ]
        
        for i, (text, command) in enumerate(mem_buttons):
            btn = ttk.Button(button_frame, text=text, command=command, width=6)
            btn.grid(row=1, column=i, padx=2, pady=2, sticky='ew')
        
        # Number pad
        buttons = [
            [('7', lambda: self.input_digit('7')), ('8', lambda: self.input_digit('8')), 
             ('9', lambda: self.input_digit('9')), ('×', lambda: self.input_operator('×'))],
            [('4', lambda: self.input_digit('4')), ('5', lambda: self.input_digit('5')), 
             ('6', lambda: self.input_digit('6')), ('-', lambda: self.input_operator('-'))],
            [('1', lambda: self.input_digit('1')), ('2', lambda: self.input_digit('2')), 
             ('3', lambda: self.input_digit('3')), ('+', lambda: self.input_operator('+'))],
            [('0', lambda: self.input_digit('0')), ('.', self.input_decimal), 
             ('=', self.calculate), ('', None)]
        ]
        
        for row_idx, row in enumerate(buttons, start=2):
            for col_idx, (text, command) in enumerate(row):
                if text:
                    if text == '0':
                        btn = ttk.Button(button_frame, text=text, command=command, width=13)
                        btn.grid(row=row_idx, column=col_idx, columnspan=2, padx=2, pady=2, sticky='ew')
                    elif text == '=':
                        btn = ttk.Button(button_frame, text=text, command=command, width=6)
                        btn.grid(row=row_idx, column=col_idx, rowspan=2, padx=2, pady=2, sticky='nsew')
                    else:
                        btn = ttk.Button(button_frame, text=text, command=command, width=6)
                        btn.grid(row=row_idx, column=col_idx, padx=2, pady=2, sticky='ew')
        
        # Configure grid weights
        for i in range(5):
            button_frame.columnconfigure(i, weight=1)
    
    def input_digit(self, digit):
        """Handle digit input"""
        if self.waiting_for_operand:
            self.display_var.set(digit)
            self.waiting_for_operand = False
        else:
            current = self.display_var.get()
            if current == "0":
                self.display_var.set(digit)
            else:
                self.display_var.set(current + digit)
    
    def input_decimal(self):
        """Handle decimal point input"""
        if self.waiting_for_operand:
            self.display_var.set("0.")
            self.waiting_for_operand = False
        elif "." not in self.display_var.get():
            self.display_var.set(self.display_var.get() + ".")
    
    def input_operator(self, op):
        """Handle operator input"""
        try:
            current_value = float(self.display_var.get())
            
            if self.previous is None:
                self.previous = current_value
            elif not self.waiting_for_operand:
                result = self.perform_calculation()
                self.display_var.set(str(result))
                self.previous = result
            
            self.waiting_for_operand = True
            self.operator = op
        except ValueError:
            self.display_var.set("Error")
    
    def calculate(self):
        """Perform calculation and show result"""
        if self.operator and self.previous is not None:
            try:
                current_value = float(self.display_var.get())
                result = self.perform_calculation()
                
                # Add to history
                calculation = f"{self.previous} {self.operator} {current_value} = {result}"
                self.history.append(calculation)
                self.history_listbox.insert(tk.END, calculation)
                
                # Scroll to bottom
                self.history_listbox.see(tk.END)
                
                self.display_var.set(str(result))
                self.previous = None
                self.operator = None
                self.waiting_for_operand = True
                
                self.parent_app.add_recent_activity(f"Calculator: {calculation}")
            except (ValueError, ZeroDivisionError, OverflowError):
                self.display_var.set("Error")
    
    def perform_calculation(self):
        """Perform the actual calculation"""
        try:
            prev = self.previous
            if prev is None:
                return float(self.display_var.get())
                
            current = float(self.display_var.get())
            op = self.operator
            
            if op == "+":
                return prev + current
            elif op == "-":
                return prev - current
            elif op == "×":
                return prev * current
            elif op == "÷":
                if current == 0:
                    raise ZeroDivisionError
                return prev / current
            else:
                return current
        except:
            return 0
    
    def scientific_operation(self, operation):
        """Handle scientific calculator operations"""
        try:
            current = float(self.display_var.get())
            
            if operation == "sin":
                result = math.sin(math.radians(current))
            elif operation == "cos":
                result = math.cos(math.radians(current))
            elif operation == "tan":
                result = math.tan(math.radians(current))
            elif operation == "sqrt":
                if current < 0:
                    self.display_var.set("Error")
                    return
                result = math.sqrt(current)
            elif operation == "square":
                result = current ** 2
            else:
                result = current
            
            # Add to history
            op_symbol = {"sin": "sin", "cos": "cos", "tan": "tan", "sqrt": "√", "square": "²"}
            calculation = f"{op_symbol.get(operation, operation)}({current}) = {result}"
            self.history.append(calculation)
            self.history_listbox.insert(tk.END, calculation)
            self.history_listbox.see(tk.END)
            
            self.display_var.set(str(result))
            self.waiting_for_operand = True
            
            self.parent_app.add_recent_activity(f"Calculator: {calculation}")
        
        except (ValueError, OverflowError):
            self.display_var.set("Error")
    
    def clear_all(self):
        """Clear all calculator state"""
        self.display_var.set("0")
        self.previous = None
        self.operator = None
        self.waiting_for_operand = False
    
    def clear_entry(self):
        """Clear current entry"""
        self.display_var.set("0")
    
    def negate(self):
        """Negate current number"""
        try:
            current = float(self.display_var.get())
            self.display_var.set(str(-current))
        except ValueError:
            pass
    
    def percent(self):
        """Convert to percentage"""
        try:
            current = float(self.display_var.get())
            self.display_var.set(str(current / 100))
        except ValueError:
            pass
    
    def clear_history(self):
        """Clear calculation history"""
        self.history.clear()
        self.history_listbox.delete(0, tk.END)