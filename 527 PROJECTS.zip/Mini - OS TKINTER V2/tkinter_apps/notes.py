import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime

class NotesApp:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        
        # Create window
        self.window = tk.Toplevel(parent_app.root)
        self.window.title("Notes")
        self.window.geometry("800x600")
        self.window.configure(bg="#F3F2F1")
        
        self.setup_ui()
        self.refresh_notes_list()
    
    def setup_ui(self):
        """Setup the notes UI"""
        # Main paned window
        paned = ttk.PanedWindow(self.window, orient='horizontal')
        paned.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Left panel - Notes list
        left_frame = ttk.Frame(paned)
        paned.add(left_frame, weight=1)
        
        # Notes list header
        list_header = ttk.Frame(left_frame)
        list_header.pack(fill='x', pady=(0, 5))
        
        ttk.Label(list_header, text="My Notes", font=('Segoe UI', 12, 'bold')).pack(side='left')
        ttk.Button(list_header, text="New Note", command=self.new_note).pack(side='right')
        
        # Search
        search_frame = ttk.Frame(left_frame)
        search_frame.pack(fill='x', pady=(0, 5))
        
        ttk.Label(search_frame, text="Search:").pack(side='left')
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self.filter_notes())
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.pack(side='right', fill='x', expand=True, padx=(5, 0))
        
        # Notes listbox
        list_frame = ttk.Frame(left_frame)
        list_frame.pack(fill='both', expand=True)
        
        self.notes_listbox = tk.Listbox(list_frame, font=('Segoe UI', 10))
        notes_scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.notes_listbox.yview)
        self.notes_listbox.configure(yscrollcommand=notes_scrollbar.set)
        
        self.notes_listbox.pack(side='left', fill='both', expand=True)
        notes_scrollbar.pack(side='right', fill='y')
        
        self.notes_listbox.bind('<<ListboxSelect>>', self.on_note_select)
        
        # Right panel - Note editor
        right_frame = ttk.Frame(paned)
        paned.add(right_frame, weight=2)
        
        # Editor header
        editor_header = ttk.Frame(right_frame)
        editor_header.pack(fill='x', pady=(0, 5))
        
        ttk.Label(editor_header, text="Title:").pack(side='left')
        self.title_var = tk.StringVar()
        self.title_entry = ttk.Entry(editor_header, textvariable=self.title_var, font=('Segoe UI', 10))
        self.title_entry.pack(side='right', fill='x', expand=True, padx=(5, 0))
        
        # Editor buttons
        button_frame = ttk.Frame(right_frame)
        button_frame.pack(fill='x', pady=(0, 5))
        
        ttk.Button(button_frame, text="Save", command=self.save_note).pack(side='left', padx=(0, 5))
        ttk.Button(button_frame, text="Delete", command=self.delete_note).pack(side='left', padx=(0, 5))
        ttk.Button(button_frame, text="Clear", command=self.clear_editor).pack(side='left')
        
        # Word count
        self.word_count_var = tk.StringVar(value="Words: 0")
        ttk.Label(button_frame, textvariable=self.word_count_var).pack(side='right')
        
        # Text editor
        editor_frame = ttk.Frame(right_frame)
        editor_frame.pack(fill='both', expand=True)
        
        self.text_editor = tk.Text(editor_frame, wrap='word', font=('Segoe UI', 11))
        editor_scrollbar = ttk.Scrollbar(editor_frame, orient='vertical', command=self.text_editor.yview)
        self.text_editor.configure(yscrollcommand=editor_scrollbar.set)
        
        self.text_editor.pack(side='left', fill='both', expand=True)
        editor_scrollbar.pack(side='right', fill='y')
        
        # Bind text change event for word count
        self.text_editor.bind('<KeyRelease>', self.update_word_count)
        
        # Current note tracking
        self.current_note = None
    
    def refresh_notes_list(self):
        """Refresh the notes list"""
        self.notes_listbox.delete(0, tk.END)
        
        notes = self.parent_app.user_data.get('notes', {})
        self.all_notes = list(notes.keys())
        
        # Sort notes by last modified
        sorted_notes = sorted(notes.items(), 
                            key=lambda x: x[1].get('modified', ''), 
                            reverse=True)
        
        for title, note_data in sorted_notes:
            # Show title and modification date
            modified = note_data.get('modified', 'Unknown')
            if modified != 'Unknown':
                try:
                    mod_date = datetime.fromisoformat(modified)
                    mod_str = mod_date.strftime('%m/%d %H:%M')
                except:
                    mod_str = 'Unknown'
            else:
                mod_str = 'Unknown'
            
            display_text = f"{title} - {mod_str}"
            self.notes_listbox.insert(tk.END, display_text)
    
    def filter_notes(self):
        """Filter notes based on search term"""
        search_term = self.search_var.get().lower()
        
        self.notes_listbox.delete(0, tk.END)
        
        notes = self.parent_app.user_data.get('notes', {})
        
        if not search_term:
            # Show all notes
            sorted_notes = sorted(notes.items(), 
                                key=lambda x: x[1].get('modified', ''), 
                                reverse=True)
        else:
            # Filter notes
            filtered_notes = {}
            for title, note_data in notes.items():
                if (search_term in title.lower() or 
                    search_term in note_data.get('content', '').lower()):
                    filtered_notes[title] = note_data
            
            sorted_notes = sorted(filtered_notes.items(), 
                                key=lambda x: x[1].get('modified', ''), 
                                reverse=True)
        
        for title, note_data in sorted_notes:
            modified = note_data.get('modified', 'Unknown')
            if modified != 'Unknown':
                try:
                    mod_date = datetime.fromisoformat(modified)
                    mod_str = mod_date.strftime('%m/%d %H:%M')
                except:
                    mod_str = 'Unknown'
            else:
                mod_str = 'Unknown'
            
            display_text = f"{title} - {mod_str}"
            self.notes_listbox.insert(tk.END, display_text)
    
    def on_note_select(self, event):
        """Handle note selection"""
        selection = self.notes_listbox.curselection()
        if not selection:
            return
        
        selected_text = self.notes_listbox.get(selection[0])
        # Extract title (everything before the last " - ")
        title = selected_text.rsplit(' - ', 1)[0]
        
        self.load_note(title)
    
    def load_note(self, title):
        """Load a note into the editor"""
        notes = self.parent_app.user_data.get('notes', {})
        if title not in notes:
            return
        
        note_data = notes[title]
        
        self.current_note = title
        self.title_var.set(title)
        
        # Clear and load content
        self.text_editor.delete('1.0', tk.END)
        self.text_editor.insert('1.0', note_data.get('content', ''))
        
        self.update_word_count()
    
    def new_note(self):
        """Create a new note"""
        self.current_note = None
        self.title_var.set("")
        self.text_editor.delete('1.0', tk.END)
        self.update_word_count()
        self.title_entry.focus()
    
    def save_note(self):
        """Save the current note"""
        title = self.title_var.get().strip()
        content = self.text_editor.get('1.0', tk.END + '-1c')
        
        if not title:
            messagebox.showerror("Error", "Please enter a title for the note")
            return
        
        if not content.strip():
            messagebox.showerror("Error", "Please enter some content for the note")
            return
        
        notes = self.parent_app.user_data.get('notes', {})
        current_time = datetime.now().isoformat()
        
        # Check if note exists
        is_new = title not in notes
        
        notes[title] = {
            'content': content,
            'created': notes.get(title, {}).get('created', current_time),
            'modified': current_time
        }
        
        self.parent_app.user_data['notes'] = notes
        self.parent_app.save_user_data()
        
        action = "Created" if is_new else "Updated"
        self.parent_app.add_recent_activity(f"{action} note: {title}")
        
        self.current_note = title
        self.refresh_notes_list()
        
        messagebox.showinfo("Success", f"Note '{title}' saved successfully!")
    
    def delete_note(self):
        """Delete the current note"""
        if not self.current_note:
            messagebox.showwarning("Warning", "No note selected to delete")
            return
        
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete '{self.current_note}'?"):
            notes = self.parent_app.user_data.get('notes', {})
            if self.current_note in notes:
                del notes[self.current_note]
                self.parent_app.user_data['notes'] = notes
                self.parent_app.save_user_data()
                
                self.parent_app.add_recent_activity(f"Deleted note: {self.current_note}")
                
                self.clear_editor()
                self.refresh_notes_list()
                
                messagebox.showinfo("Success", f"Note '{self.current_note}' deleted!")
    
    def clear_editor(self):
        """Clear the editor"""
        self.current_note = None
        self.title_var.set("")
        self.text_editor.delete('1.0', tk.END)
        self.update_word_count()
    
    def update_word_count(self, event=None):
        """Update word count display"""
        content = self.text_editor.get('1.0', tk.END + '-1c')
        word_count = len(content.split()) if content.strip() else 0
        self.word_count_var.set(f"Words: {word_count}")