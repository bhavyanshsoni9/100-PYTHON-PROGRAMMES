import tkinter as tk
from tkinter import ttk, messagebox, colorchooser
import json
import os
import platform
import subprocess
import datetime
import calendar
import random
import math
import time
import threading

class UtilitiesApp:
    def __init__(self, parent_app):
        self.parent_app = parent_app
        
        # Create window
        self.window = tk.Toplevel(parent_app.root)
        self.window.title("Utilities")
        self.window.geometry("800x700")
        self.window.configure(bg="#F3F2F1")
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the utilities UI"""
        # Notebook for tabs
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Calendar tab
        self.setup_calendar_tab(notebook)
        
        # Weather tab
        self.setup_weather_tab(notebook)
        
        # System Tools tab
        self.setup_system_tab(notebook)
        
        # Color Picker tab
        self.setup_color_tab(notebook)
        
        # Unit Converter tab
        self.setup_converter_tab(notebook)
        
        # Timer tab
        self.setup_timer_tab(notebook)
        
        # Text Tools tab
        self.setup_text_tab(notebook)
    
    def setup_calendar_tab(self, notebook):
        """Setup calendar tab"""
        calendar_frame = ttk.Frame(notebook)
        notebook.add(calendar_frame, text="Calendar")
        
        # Date selection
        date_frame = ttk.LabelFrame(calendar_frame, text="Date Selection", padding=10)
        date_frame.pack(fill='x', padx=10, pady=10)
        
        self.selected_date = tk.StringVar(value=datetime.date.today().isoformat())
        
        # Date picker
        date_picker_frame = ttk.Frame(date_frame)
        date_picker_frame.pack(fill='x')
        
        ttk.Label(date_picker_frame, text="Select Date:").pack(side='left')
        
        today = datetime.date.today()
        self.year_var = tk.IntVar(value=today.year)
        self.month_var = tk.IntVar(value=today.month)
        self.day_var = tk.IntVar(value=today.day)
        
        year_spin = tk.Spinbox(date_picker_frame, from_=1900, to=2100, textvariable=self.year_var, width=6)
        year_spin.pack(side='left', padx=(10, 5))
        
        month_spin = tk.Spinbox(date_picker_frame, from_=1, to=12, textvariable=self.month_var, width=4)
        month_spin.pack(side='left', padx=5)
        
        day_spin = tk.Spinbox(date_picker_frame, from_=1, to=31, textvariable=self.day_var, width=4)
        day_spin.pack(side='left', padx=5)
        
        ttk.Button(date_picker_frame, text="Update", command=self.update_calendar).pack(side='left', padx=(10, 0))
        
        # Calendar display
        calendar_display_frame = ttk.LabelFrame(calendar_frame, text="Calendar View", padding=10)
        calendar_display_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.calendar_text = tk.Text(calendar_display_frame, height=15, font=('Courier', 10))
        cal_scrollbar = ttk.Scrollbar(calendar_display_frame, orient='vertical', command=self.calendar_text.yview)
        self.calendar_text.configure(yscrollcommand=cal_scrollbar.set)
        
        self.calendar_text.pack(side='left', fill='both', expand=True)
        cal_scrollbar.pack(side='right', fill='y')
        
        # Date notes
        notes_frame = ttk.LabelFrame(calendar_frame, text="Date Notes", padding=10)
        notes_frame.pack(fill='x', padx=10, pady=(0, 10))
        
        self.date_note_text = tk.Text(notes_frame, height=4)
        self.date_note_text.pack(fill='x', pady=5)
        
        ttk.Button(notes_frame, text="Save Note", command=self.save_date_note).pack(pady=5)
        
        # Initial calendar load
        self.update_calendar()
    
    def setup_weather_tab(self, notebook):
        """Setup weather information tab"""
        weather_frame = ttk.Frame(notebook)
        notebook.add(weather_frame, text="Weather")
        
        ttk.Label(weather_frame, text="Weather Information", font=('Segoe UI', 14, 'bold')).pack(pady=20)
        
        # City selection
        city_frame = ttk.Frame(weather_frame)
        city_frame.pack(pady=10)
        
        ttk.Label(city_frame, text="Select City:").pack(side='left')
        
        cities = ["New York", "London", "Tokyo", "Sydney", "Paris", "Berlin", "Moscow", "Cairo"]
        self.weather_city_var = tk.StringVar(value=cities[0])
        city_combo = ttk.Combobox(city_frame, textvariable=self.weather_city_var, values=cities, state='readonly')
        city_combo.pack(side='left', padx=(10, 0))
        city_combo.bind('<<ComboboxSelected>>', self.update_weather)
        
        # Weather display
        weather_display_frame = ttk.LabelFrame(weather_frame, text="Current Weather", padding=10)
        weather_display_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.weather_text = tk.Text(weather_display_frame, height=15, font=('Segoe UI', 11))
        weather_scrollbar = ttk.Scrollbar(weather_display_frame, orient='vertical', command=self.weather_text.yview)
        self.weather_text.configure(yscrollcommand=weather_scrollbar.set)
        
        self.weather_text.pack(side='left', fill='both', expand=True)
        weather_scrollbar.pack(side='right', fill='y')
        
        # Initial weather load
        self.update_weather()
    
    def setup_system_tab(self, notebook):
        """Setup system tools tab"""
        system_frame = ttk.Frame(notebook)
        notebook.add(system_frame, text="System Tools")
        
        # System info display
        info_frame = ttk.LabelFrame(system_frame, text="System Information", padding=10)
        info_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.system_info_text = tk.Text(info_frame, wrap='word', font=('Courier', 10))
        info_scrollbar = ttk.Scrollbar(info_frame, orient='vertical', command=self.system_info_text.yview)
        self.system_info_text.configure(yscrollcommand=info_scrollbar.set)
        
        self.system_info_text.pack(side='left', fill='both', expand=True)
        info_scrollbar.pack(side='right', fill='y')
        
        # Buttons
        button_frame = ttk.Frame(system_frame)
        button_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Button(button_frame, text="Refresh System Info", command=self.refresh_system_info).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Test Network", command=self.test_network).pack(side='left', padx=5)
        
        # Initial system info load
        self.refresh_system_info()
    
    def setup_color_tab(self, notebook):
        """Setup color picker tab"""
        color_frame = ttk.Frame(notebook)
        notebook.add(color_frame, text="Color Picker")
        
        # Color selection
        selection_frame = ttk.LabelFrame(color_frame, text="Color Selection", padding=10)
        selection_frame.pack(fill='x', padx=10, pady=10)
        
        # Color picker button
        self.selected_color = "#FF0000"
        self.color_display = tk.Label(selection_frame, text="Selected Color", 
                                    bg=self.selected_color, width=20, height=3)
        self.color_display.pack(pady=10)
        
        ttk.Button(selection_frame, text="Pick Color", command=self.pick_color).pack(pady=5)
        
        # Color information
        info_frame = ttk.LabelFrame(color_frame, text="Color Information", padding=10)
        info_frame.pack(fill='x', padx=10, pady=10)
        
        self.color_info_text = tk.Text(info_frame, height=8, font=('Segoe UI', 10))
        self.color_info_text.pack(fill='x')
        
        # Color palette generator
        palette_frame = ttk.LabelFrame(color_frame, text="Color Palette", padding=10)
        palette_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        ttk.Button(palette_frame, text="Generate Random Palette", command=self.generate_palette).pack(pady=5)
        
        self.palette_frame = ttk.Frame(palette_frame)
        self.palette_frame.pack(fill='both', expand=True, pady=10)
        
        # Initial color info
        self.update_color_info()
    
    def setup_converter_tab(self, notebook):
        """Setup unit converter tab"""
        converter_frame = ttk.Frame(notebook)
        notebook.add(converter_frame, text="Unit Converter")
        
        # Conversion type
        type_frame = ttk.Frame(converter_frame)
        type_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(type_frame, text="Conversion Type:").pack(side='left')
        
        conversion_types = ["Length", "Weight", "Temperature", "Volume", "Area"]
        self.conversion_type_var = tk.StringVar(value=conversion_types[0])
        type_combo = ttk.Combobox(type_frame, textvariable=self.conversion_type_var, 
                                values=conversion_types, state='readonly')
        type_combo.pack(side='left', padx=(10, 0))
        type_combo.bind('<<ComboboxSelected>>', self.update_conversion_units)
        
        # Conversion interface
        conversion_interface_frame = ttk.LabelFrame(converter_frame, text="Convert", padding=10)
        conversion_interface_frame.pack(fill='x', padx=10, pady=10)
        
        # From section
        from_frame = ttk.Frame(conversion_interface_frame)
        from_frame.pack(fill='x', pady=5)
        
        ttk.Label(from_frame, text="From:").grid(row=0, column=0, sticky='w')
        self.from_value_var = tk.DoubleVar(value=1.0)
        from_entry = ttk.Entry(from_frame, textvariable=self.from_value_var, width=15)
        from_entry.grid(row=0, column=1, padx=(10, 5))
        from_entry.bind('<KeyRelease>', self.perform_conversion)
        
        self.from_unit_var = tk.StringVar()
        self.from_unit_combo = ttk.Combobox(from_frame, textvariable=self.from_unit_var, state='readonly', width=15)
        self.from_unit_combo.grid(row=0, column=2, padx=5)
        self.from_unit_combo.bind('<<ComboboxSelected>>', self.perform_conversion)
        
        # To section
        to_frame = ttk.Frame(conversion_interface_frame)
        to_frame.pack(fill='x', pady=5)
        
        ttk.Label(to_frame, text="To:").grid(row=0, column=0, sticky='w')
        self.to_value_var = tk.DoubleVar()
        to_entry = ttk.Entry(to_frame, textvariable=self.to_value_var, width=15, state='readonly')
        to_entry.grid(row=0, column=1, padx=(10, 5))
        
        self.to_unit_var = tk.StringVar()
        self.to_unit_combo = ttk.Combobox(to_frame, textvariable=self.to_unit_var, state='readonly', width=15)
        self.to_unit_combo.grid(row=0, column=2, padx=5)
        self.to_unit_combo.bind('<<ComboboxSelected>>', self.perform_conversion)
        
        # Conversion table
        table_frame = ttk.LabelFrame(converter_frame, text="Quick Reference", padding=10)
        table_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.conversion_table = tk.Text(table_frame, height=10, font=('Courier', 9))
        table_scrollbar = ttk.Scrollbar(table_frame, orient='vertical', command=self.conversion_table.yview)
        self.conversion_table.configure(yscrollcommand=table_scrollbar.set)
        
        self.conversion_table.pack(side='left', fill='both', expand=True)
        table_scrollbar.pack(side='right', fill='y')
        
        # Initialize conversion units
        self.update_conversion_units()
    
    def setup_timer_tab(self, notebook):
        """Setup timer and stopwatch tab"""
        timer_frame = ttk.Frame(notebook)
        notebook.add(timer_frame, text="Timer")
        
        # Timer section
        timer_section = ttk.LabelFrame(timer_frame, text="Timer", padding=10)
        timer_section.pack(fill='x', padx=10, pady=10)
        
        # Timer input
        timer_input_frame = ttk.Frame(timer_section)
        timer_input_frame.pack(pady=10)
        
        ttk.Label(timer_input_frame, text="Hours:").grid(row=0, column=0)
        self.timer_hours = tk.IntVar(value=0)
        hours_spin = tk.Spinbox(timer_input_frame, from_=0, to=23, textvariable=self.timer_hours, width=5)
        hours_spin.grid(row=0, column=1, padx=5)
        
        ttk.Label(timer_input_frame, text="Minutes:").grid(row=0, column=2, padx=(20, 0))
        self.timer_minutes = tk.IntVar(value=5)
        minutes_spin = tk.Spinbox(timer_input_frame, from_=0, to=59, textvariable=self.timer_minutes, width=5)
        minutes_spin.grid(row=0, column=3, padx=5)
        
        ttk.Label(timer_input_frame, text="Seconds:").grid(row=0, column=4, padx=(20, 0))
        self.timer_seconds = tk.IntVar(value=0)
        seconds_spin = tk.Spinbox(timer_input_frame, from_=0, to=59, textvariable=self.timer_seconds, width=5)
        seconds_spin.grid(row=0, column=5, padx=5)
        
        # Timer display
        self.timer_display_var = tk.StringVar(value="00:05:00")
        timer_display = ttk.Label(timer_section, textvariable=self.timer_display_var, 
                                font=('Courier', 20, 'bold'))
        timer_display.pack(pady=10)
        
        # Timer controls
        timer_controls = ttk.Frame(timer_section)
        timer_controls.pack(pady=10)
        
        self.timer_start_btn = ttk.Button(timer_controls, text="Start Timer", command=self.start_timer)
        self.timer_start_btn.pack(side='left', padx=5)
        
        self.timer_stop_btn = ttk.Button(timer_controls, text="Stop Timer", command=self.stop_timer, state='disabled')
        self.timer_stop_btn.pack(side='left', padx=5)
        
        # Stopwatch section
        stopwatch_section = ttk.LabelFrame(timer_frame, text="Stopwatch", padding=10)
        stopwatch_section.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Stopwatch display
        self.stopwatch_display_var = tk.StringVar(value="00:00:00")
        stopwatch_display = ttk.Label(stopwatch_section, textvariable=self.stopwatch_display_var, 
                                    font=('Courier', 20, 'bold'))
        stopwatch_display.pack(pady=10)
        
        # Stopwatch controls
        stopwatch_controls = ttk.Frame(stopwatch_section)
        stopwatch_controls.pack(pady=10)
        
        self.stopwatch_start_btn = ttk.Button(stopwatch_controls, text="Start", command=self.start_stopwatch)
        self.stopwatch_start_btn.pack(side='left', padx=5)
        
        self.stopwatch_stop_btn = ttk.Button(stopwatch_controls, text="Stop", command=self.stop_stopwatch, state='disabled')
        self.stopwatch_stop_btn.pack(side='left', padx=5)
        
        self.stopwatch_reset_btn = ttk.Button(stopwatch_controls, text="Reset", command=self.reset_stopwatch)
        self.stopwatch_reset_btn.pack(side='left', padx=5)
        
        # Timer state
        self.timer_running = False
        self.timer_target = None
        self.stopwatch_running = False
        self.stopwatch_start_time = None
        self.stopwatch_elapsed = 0
    
    def setup_text_tab(self, notebook):
        """Setup text tools tab"""
        text_frame = ttk.Frame(notebook)
        notebook.add(text_frame, text="Text Tools")
        
        # Input text
        input_frame = ttk.LabelFrame(text_frame, text="Input Text", padding=10)
        input_frame.pack(fill='x', padx=10, pady=10)
        
        self.text_input = tk.Text(input_frame, height=6, wrap='word')
        input_scrollbar = ttk.Scrollbar(input_frame, orient='vertical', command=self.text_input.yview)
        self.text_input.configure(yscrollcommand=input_scrollbar.set)
        
        self.text_input.pack(side='left', fill='both', expand=True)
        input_scrollbar.pack(side='right', fill='y')
        
        self.text_input.bind('<KeyRelease>', self.analyze_text)
        
        # Text analysis
        analysis_frame = ttk.LabelFrame(text_frame, text="Text Analysis", padding=10)
        analysis_frame.pack(fill='x', padx=10, pady=10)
        
        self.text_analysis = tk.Text(analysis_frame, height=4, font=('Segoe UI', 10))
        self.text_analysis.pack(fill='x')
        
        # Text operations
        operations_frame = ttk.LabelFrame(text_frame, text="Text Operations", padding=10)
        operations_frame.pack(fill='x', padx=10, pady=10)
        
        ops_grid = ttk.Frame(operations_frame)
        ops_grid.pack()
        
        ttk.Button(ops_grid, text="UPPERCASE", command=lambda: self.text_operation('upper')).grid(row=0, column=0, padx=5, pady=2)
        ttk.Button(ops_grid, text="lowercase", command=lambda: self.text_operation('lower')).grid(row=0, column=1, padx=5, pady=2)
        ttk.Button(ops_grid, text="Title Case", command=lambda: self.text_operation('title')).grid(row=0, column=2, padx=5, pady=2)
        ttk.Button(ops_grid, text="Reverse", command=lambda: self.text_operation('reverse')).grid(row=1, column=0, padx=5, pady=2)
        ttk.Button(ops_grid, text="Remove Spaces", command=lambda: self.text_operation('nospace')).grid(row=1, column=1, padx=5, pady=2)
        ttk.Button(ops_grid, text="Sort Lines", command=lambda: self.text_operation('sort')).grid(row=1, column=2, padx=5, pady=2)
        
        # Output text
        output_frame = ttk.LabelFrame(text_frame, text="Output Text", padding=10)
        output_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.text_output = tk.Text(output_frame, height=6, wrap='word')
        output_scrollbar = ttk.Scrollbar(output_frame, orient='vertical', command=self.text_output.yview)
        self.text_output.configure(yscrollcommand=output_scrollbar.set)
        
        self.text_output.pack(side='left', fill='both', expand=True)
        output_scrollbar.pack(side='right', fill='y')
    
    # Calendar methods
    def update_calendar(self):
        """Update calendar display"""
        try:
            year = self.year_var.get()
            month = self.month_var.get()
            day = self.day_var.get()
            
            selected_date = datetime.date(year, month, day)
            self.selected_date.set(selected_date.isoformat())
            
            # Generate calendar
            cal = calendar.monthcalendar(year, month)
            month_name = calendar.month_name[month]
            
            calendar_text = f"{month_name} {year}\n\n"
            calendar_text += "Mo Tu We Th Fr Sa Su\n"
            calendar_text += "-" * 21 + "\n"
            
            for week in cal:
                week_str = ""
                for day_num in week:
                    if day_num == 0:
                        week_str += "   "
                    elif day_num == day:
                        week_str += f"[{day_num:2}]"[:-1] if day_num < 10 else f"[{day_num}]"
                    else:
                        week_str += f"{day_num:2} "
                calendar_text += week_str + "\n"
            
            # Add date info
            calendar_text += f"\nSelected: {selected_date.strftime('%A, %B %d, %Y')}\n"
            calendar_text += f"Day of year: {selected_date.timetuple().tm_yday}\n"
            calendar_text += f"Week number: {selected_date.isocalendar()[1]}\n"
            
            # Days from today
            today = datetime.date.today()
            days_diff = (selected_date - today).days
            if days_diff > 0:
                calendar_text += f"Days until: {days_diff}\n"
            elif days_diff < 0:
                calendar_text += f"Days ago: {abs(days_diff)}\n"
            else:
                calendar_text += "Today!\n"
            
            self.calendar_text.delete('1.0', tk.END)
            self.calendar_text.insert('1.0', calendar_text)
            
            # Load date note
            self.load_date_note()
            
        except ValueError as e:
            messagebox.showerror("Error", f"Invalid date: {e}")
    
    def save_date_note(self):
        """Save note for selected date"""
        date_key = self.selected_date.get()
        note_content = self.date_note_text.get('1.0', tk.END).strip()
        
        if 'date_notes' not in self.parent_app.user_data:
            self.parent_app.user_data['date_notes'] = {}
        
        if note_content:
            self.parent_app.user_data['date_notes'][date_key] = note_content
        elif date_key in self.parent_app.user_data['date_notes']:
            del self.parent_app.user_data['date_notes'][date_key]
        
        self.parent_app.save_user_data()
        self.parent_app.add_recent_activity(f"Added note for {date_key}")
        messagebox.showinfo("Success", "Date note saved!")
    
    def load_date_note(self):
        """Load note for selected date"""
        date_key = self.selected_date.get()
        note_content = self.parent_app.user_data.get('date_notes', {}).get(date_key, "")
        
        self.date_note_text.delete('1.0', tk.END)
        self.date_note_text.insert('1.0', note_content)
    
    # Weather methods
    def update_weather(self, event=None):
        """Update weather information"""
        city = self.weather_city_var.get()
        
        # Sample weather data (in real app, would use weather API)
        weather_data = {
            "New York": {"temp": 22, "condition": "Sunny", "humidity": 65, "wind": 8, "feels_like": 25},
            "London": {"temp": 15, "condition": "Cloudy", "humidity": 78, "wind": 12, "feels_like": 13},
            "Tokyo": {"temp": 28, "condition": "Rainy", "humidity": 82, "wind": 6, "feels_like": 31},
            "Sydney": {"temp": 25, "condition": "Partly Cloudy", "humidity": 60, "wind": 15, "feels_like": 27},
            "Paris": {"temp": 18, "condition": "Overcast", "humidity": 72, "wind": 9, "feels_like": 16},
            "Berlin": {"temp": 12, "condition": "Foggy", "humidity": 85, "wind": 7, "feels_like": 10},
            "Moscow": {"temp": -5, "condition": "Snow", "humidity": 90, "wind": 20, "feels_like": -12},
            "Cairo": {"temp": 35, "condition": "Clear", "humidity": 30, "wind": 5, "feels_like": 40}
        }
        
        if city not in weather_data:
            return
        
        weather = weather_data[city]
        
        weather_text = f"Weather for {city}\n"
        weather_text += "=" * 30 + "\n\n"
        weather_text += f"Temperature: {weather['temp']}°C\n"
        weather_text += f"Feels like: {weather['feels_like']}°C\n"
        weather_text += f"Condition: {weather['condition']}\n"
        weather_text += f"Humidity: {weather['humidity']}%\n"
        weather_text += f"Wind Speed: {weather['wind']} km/h\n\n"
        
        # 5-day forecast
        weather_text += "5-Day Forecast:\n"
        weather_text += "-" * 20 + "\n"
        
        for i in range(5):
            date = datetime.date.today() + datetime.timedelta(days=i)
            temp_variation = random.randint(-5, 5)
            high_temp = weather['temp'] + temp_variation + 3
            low_temp = weather['temp'] + temp_variation - 2
            
            conditions = ["Sunny", "Cloudy", "Rainy", "Partly Cloudy", "Clear"]
            condition = random.choice(conditions)
            
            weather_text += f"{date.strftime('%a %m/%d')}: {high_temp}°/{low_temp}° {condition}\n"
        
        weather_text += "\n" + "Current time: " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        self.weather_text.delete('1.0', tk.END)
        self.weather_text.insert('1.0', weather_text)
    
    # System methods
    def refresh_system_info(self):
        """Refresh system information"""
        info_text = "System Information\n"
        info_text += "=" * 40 + "\n\n"
        
        # Platform info
        info_text += "Platform Information:\n"
        info_text += f"System: {platform.system()}\n"
        info_text += f"Release: {platform.release()}\n"
        info_text += f"Version: {platform.version()}\n"
        info_text += f"Machine: {platform.machine()}\n"
        info_text += f"Processor: {platform.processor()}\n"
        info_text += f"Python Version: {platform.python_version()}\n"
        info_text += f"Host Name: {platform.node()}\n\n"
        
        # Try to get system resources
        try:
            import psutil
            
            info_text += "System Resources:\n"
            cpu_percent = psutil.cpu_percent(interval=1)
            info_text += f"CPU Usage: {cpu_percent}%\n"
            info_text += f"CPU Cores: {psutil.cpu_count()}\n"
            
            memory = psutil.virtual_memory()
            info_text += f"Memory Usage: {memory.percent}%\n"
            info_text += f"Total Memory: {memory.total / (1024**3):.1f} GB\n"
            info_text += f"Available Memory: {memory.available / (1024**3):.1f} GB\n"
            
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            info_text += f"Disk Usage: {disk_percent:.1f}%\n"
            info_text += f"Total Disk: {disk.total / (1024**3):.1f} GB\n"
            info_text += f"Free Disk: {disk.free / (1024**3):.1f} GB\n\n"
            
        except ImportError:
            info_text += "System resource monitoring not available\n\n"
        except Exception as e:
            info_text += f"Error getting system resources: {e}\n\n"
        
        # Network info
        try:
            import socket
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            
            info_text += "Network Information:\n"
            info_text += f"Hostname: {hostname}\n"
            info_text += f"Local IP: {local_ip}\n"
            
        except Exception as e:
            info_text += f"Network information unavailable: {e}\n"
        
        self.system_info_text.delete('1.0', tk.END)
        self.system_info_text.insert('1.0', info_text)
    
    def test_network(self):
        """Test network connectivity"""
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            messagebox.showinfo("Network Test", "Internet connection is working!")
        except OSError:
            messagebox.showerror("Network Test", "No internet connection detected")
        except Exception as e:
            messagebox.showerror("Network Test", f"Network test failed: {e}")
    
    # Color methods
    def pick_color(self):
        """Pick a color using color chooser"""
        color = colorchooser.askcolor(initialcolor=self.selected_color)
        if color[1]:  # If user didn't cancel
            self.selected_color = color[1]
            self.color_display.config(bg=self.selected_color)
            self.update_color_info()
    
    def update_color_info(self):
        """Update color information display"""
        hex_color = self.selected_color.lstrip('#')
        rgb = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        # Convert to HSL
        r, g, b = [x/255.0 for x in rgb]
        max_val = max(r, g, b)
        min_val = min(r, g, b)
        diff = max_val - min_val
        
        # Lightness
        l = (max_val + min_val) / 2
        
        if diff == 0:
            h = s = 0
        else:
            # Saturation
            s = diff / (2 - max_val - min_val) if l > 0.5 else diff / (max_val + min_val)
            
            # Hue
            if max_val == r:
                h = (g - b) / diff + (6 if g < b else 0)
            elif max_val == g:
                h = (b - r) / diff + 2
            else:
                h = (r - g) / diff + 4
            h /= 6
        
        hsl = (int(h * 360), int(s * 100), int(l * 100))
        
        color_info = f"Color Information:\n\n"
        color_info += f"Hex: {self.selected_color}\n"
        color_info += f"RGB: {rgb}\n"
        color_info += f"HSL: {hsl}\n\n"
        color_info += f"Red: {rgb[0]}\n"
        color_info += f"Green: {rgb[1]}\n"
        color_info += f"Blue: {rgb[2]}\n\n"
        color_info += f"Hue: {hsl[0]}°\n"
        color_info += f"Saturation: {hsl[1]}%\n"
        color_info += f"Lightness: {hsl[2]}%"
        
        self.color_info_text.delete('1.0', tk.END)
        self.color_info_text.insert('1.0', color_info)
    
    def generate_palette(self):
        """Generate random color palette"""
        # Clear existing palette
        for widget in self.palette_frame.winfo_children():
            widget.destroy()
        
        colors = []
        for i in range(5):
            color = f"#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}"
            colors.append(color)
            
            color_frame = tk.Frame(self.palette_frame, bg=color, width=80, height=80)
            color_frame.pack(side='left', padx=5, pady=5)
            color_frame.pack_propagate(False)
            
            color_label = tk.Label(color_frame, text=color, bg=color, 
                                 fg='white' if sum(int(color[i:i+2], 16) for i in (1, 3, 5)) < 384 else 'black',
                                 font=('Courier', 8))
            color_label.pack(expand=True)
    
    # Unit converter methods
    def update_conversion_units(self, event=None):
        """Update available units for conversion"""
        conversion_type = self.conversion_type_var.get()
        
        units = {}
        if conversion_type == "Length":
            units = {
                "Meters": 1, "Kilometers": 1000, "Centimeters": 0.01,
                "Millimeters": 0.001, "Inches": 0.0254, "Feet": 0.3048,
                "Yards": 0.9144, "Miles": 1609.34
            }
        elif conversion_type == "Weight":
            units = {
                "Kilograms": 1, "Grams": 0.001, "Pounds": 0.453592,
                "Ounces": 0.0283495, "Tons": 1000, "Stones": 6.35029
            }
        elif conversion_type == "Temperature":
            units = {"Celsius": 1, "Fahrenheit": 1, "Kelvin": 1}
        elif conversion_type == "Volume":
            units = {
                "Liters": 1, "Milliliters": 0.001, "Gallons (US)": 3.78541,
                "Quarts": 0.946353, "Pints": 0.473176, "Cups": 0.236588
            }
        elif conversion_type == "Area":
            units = {
                "Square Meters": 1, "Square Kilometers": 1000000,
                "Square Feet": 0.092903, "Square Inches": 0.00064516,
                "Acres": 4046.86, "Hectares": 10000
            }
        
        self.conversion_units = units
        unit_names = list(units.keys())
        
        self.from_unit_combo['values'] = unit_names
        self.to_unit_combo['values'] = unit_names
        
        if unit_names:
            self.from_unit_var.set(unit_names[0])
            self.to_unit_var.set(unit_names[1] if len(unit_names) > 1 else unit_names[0])
        
        self.update_conversion_table()
        self.perform_conversion()
    
    def perform_conversion(self, event=None):
        """Perform unit conversion"""
        try:
            from_value = self.from_value_var.get()
            from_unit = self.from_unit_var.get()
            to_unit = self.to_unit_var.get()
            
            if not from_unit or not to_unit:
                return
            
            conversion_type = self.conversion_type_var.get()
            
            if conversion_type == "Temperature":
                result = self.convert_temperature(from_value, from_unit, to_unit)
            else:
                if from_unit == to_unit:
                    result = from_value
                else:
                    # Convert to base unit first, then to target unit
                    base_value = from_value * self.conversion_units[from_unit]
                    result = base_value / self.conversion_units[to_unit]
            
            self.to_value_var.set(round(result, 6))
            
        except (ValueError, KeyError, ZeroDivisionError):
            self.to_value_var.set(0)
    
    def convert_temperature(self, value, from_scale, to_scale):
        """Convert temperature between scales"""
        if from_scale == to_scale:
            return value
        
        # Convert to Celsius first
        if from_scale == "Fahrenheit":
            celsius = (value - 32) * 5/9
        elif from_scale == "Kelvin":
            celsius = value - 273.15
        else:
            celsius = value
        
        # Convert from Celsius to target
        if to_scale == "Fahrenheit":
            return celsius * 9/5 + 32
        elif to_scale == "Kelvin":
            return celsius + 273.15
        else:
            return celsius
    
    def update_conversion_table(self):
        """Update conversion reference table"""
        conversion_type = self.conversion_type_var.get()
        
        table_text = f"{conversion_type} Conversion Reference\n"
        table_text += "=" * 40 + "\n\n"
        
        if conversion_type == "Temperature":
            table_text += "Common Temperature Conversions:\n"
            table_text += "0°C = 32°F = 273.15K\n"
            table_text += "100°C = 212°F = 373.15K\n"
            table_text += "20°C = 68°F = 293.15K\n"
            table_text += "-40°C = -40°F = 233.15K\n"
        else:
            # Show some common conversions
            units = list(self.conversion_units.keys())
            if len(units) >= 2:
                base_unit = units[0]
                table_text += f"1 {base_unit} equals:\n"
                for unit, factor in self.conversion_units.items():
                    if unit != base_unit:
                        converted = 1 / factor
                        table_text += f"{converted:.6g} {unit}\n"
        
        self.conversion_table.delete('1.0', tk.END)
        self.conversion_table.insert('1.0', table_text)
    
    # Timer methods
    def start_timer(self):
        """Start countdown timer"""
        hours = self.timer_hours.get()
        minutes = self.timer_minutes.get()
        seconds = self.timer_seconds.get()
        
        total_seconds = hours * 3600 + minutes * 60 + seconds
        
        if total_seconds <= 0:
            messagebox.showerror("Error", "Please set a time greater than 0")
            return
        
        self.timer_target = time.time() + total_seconds
        self.timer_running = True
        
        self.timer_start_btn.config(state='disabled')
        self.timer_stop_btn.config(state='normal')
        
        self.update_timer()
        self.parent_app.add_recent_activity(f"Started timer for {total_seconds} seconds")
    
    def stop_timer(self):
        """Stop countdown timer"""
        self.timer_running = False
        self.timer_start_btn.config(state='normal')
        self.timer_stop_btn.config(state='disabled')
    
    def update_timer(self):
        """Update timer display"""
        if not self.timer_running:
            return
        
        remaining = self.timer_target - time.time()
        
        if remaining <= 0:
            self.timer_display_var.set("00:00:00")
            self.timer_running = False
            self.timer_start_btn.config(state='normal')
            self.timer_stop_btn.config(state='disabled')
            messagebox.showinfo("Timer", "Time's up!")
            self.parent_app.add_recent_activity("Timer finished")
            return
        
        hours = int(remaining // 3600)
        minutes = int((remaining % 3600) // 60)
        seconds = int(remaining % 60)
        
        self.timer_display_var.set(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
        
        # Schedule next update
        self.window.after(1000, self.update_timer)
    
    def start_stopwatch(self):
        """Start stopwatch"""
        if not self.stopwatch_running:
            self.stopwatch_start_time = time.time() - self.stopwatch_elapsed
            self.stopwatch_running = True
            
            self.stopwatch_start_btn.config(state='disabled')
            self.stopwatch_stop_btn.config(state='normal')
            
            self.update_stopwatch()
    
    def stop_stopwatch(self):
        """Stop stopwatch"""
        self.stopwatch_running = False
        self.stopwatch_start_btn.config(state='normal')
        self.stopwatch_stop_btn.config(state='disabled')
    
    def reset_stopwatch(self):
        """Reset stopwatch"""
        self.stopwatch_running = False
        self.stopwatch_elapsed = 0
        self.stopwatch_display_var.set("00:00:00")
        
        self.stopwatch_start_btn.config(state='normal')
        self.stopwatch_stop_btn.config(state='disabled')
    
    def update_stopwatch(self):
        """Update stopwatch display"""
        if not self.stopwatch_running:
            return
        
        self.stopwatch_elapsed = time.time() - self.stopwatch_start_time
        
        hours = int(self.stopwatch_elapsed // 3600)
        minutes = int((self.stopwatch_elapsed % 3600) // 60)
        seconds = int(self.stopwatch_elapsed % 60)
        
        self.stopwatch_display_var.set(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
        
        # Schedule next update
        self.window.after(100, self.update_stopwatch)
    
    # Text tools methods
    def analyze_text(self, event=None):
        """Analyze input text"""
        text = self.text_input.get('1.0', tk.END).strip()
        
        if not text:
            self.text_analysis.delete('1.0', tk.END)
            return
        
        # Count statistics
        char_count = len(text)
        char_count_no_spaces = len(text.replace(' ', ''))
        word_count = len(text.split())
        line_count = len(text.splitlines())
        paragraph_count = len([p for p in text.split('\n\n') if p.strip()])
        
        analysis = f"Characters: {char_count}\n"
        analysis += f"Characters (no spaces): {char_count_no_spaces}\n"
        analysis += f"Words: {word_count}\n"
        analysis += f"Lines: {line_count}\n"
        analysis += f"Paragraphs: {paragraph_count}"
        
        self.text_analysis.delete('1.0', tk.END)
        self.text_analysis.insert('1.0', analysis)
    
    def text_operation(self, operation):
        """Perform text operation"""
        text = self.text_input.get('1.0', tk.END).strip()
        
        if not text:
            return
        
        if operation == 'upper':
            result = text.upper()
        elif operation == 'lower':
            result = text.lower()
        elif operation == 'title':
            result = text.title()
        elif operation == 'reverse':
            result = text[::-1]
        elif operation == 'nospace':
            result = text.replace(' ', '')
        elif operation == 'sort':
            lines = text.splitlines()
            lines.sort()
            result = '\n'.join(lines)
        else:
            result = text
        
        self.text_output.delete('1.0', tk.END)
        self.text_output.insert('1.0', result)