import json
import os
from datetime import datetime

def init_user_data(username):
    """Initialize user data structure"""
    user_data_file = f"data/user_data_{username}.json"
    
    if not os.path.exists(user_data_file):
        default_data = {
            "notes": {},
            "recent_activity": [],
            "game_stats": {},
            "date_notes": {},
            "settings": {
                "theme": "light",
                "created_at": datetime.now().isoformat()
            }
        }
        
        with open(user_data_file, "w") as f:
            json.dump(default_data, f, indent=2)

def load_user_data(username):
    """Load user data from JSON file"""
    user_data_file = f"data/user_data_{username}.json"
    
    try:
        with open(user_data_file, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # Initialize if file doesn't exist or is corrupted
        init_user_data(username)
        with open(user_data_file, "r") as f:
            return json.load(f)

def save_user_data(username, data):
    """Save user data to JSON file"""
    user_data_file = f"data/user_data_{username}.json"
    
    # Add timestamp for last update
    data["last_updated"] = datetime.now().isoformat()
    
    with open(user_data_file, "w") as f:
        json.dump(data, f, indent=2)

def add_recent_activity(username, activity):
    """Add activity to user's recent activity log"""
    user_data = load_user_data(username)
    
    if "recent_activity" not in user_data:
        user_data["recent_activity"] = []
    
    # Add timestamp to activity
    timestamped_activity = f"{datetime.now().strftime('%H:%M')} - {activity}"
    
    # Add to beginning of list
    user_data["recent_activity"].insert(0, timestamped_activity)
    
    # Keep only last 20 activities
    user_data["recent_activity"] = user_data["recent_activity"][:20]
    
    save_user_data(username, user_data)

def get_user_stats(username):
    """Get user statistics"""
    user_data = load_user_data(username)
    
    stats = {
        "total_notes": len(user_data.get("notes", {})),
        "total_activities": len(user_data.get("recent_activity", [])),
        "games_played": sum(
            game_stats.get("games_played", 0) 
            for game_stats in user_data.get("game_stats", {}).values()
        ),
        "account_created": user_data.get("settings", {}).get("created_at", "Unknown")
    }
    
    return stats

def cleanup_old_data(username, days_old=30):
    """Clean up old user data (optional maintenance function)"""
    user_data = load_user_data(username)
    
    # Remove old recent activities (keep last 20)
    if "recent_activity" in user_data:
        user_data["recent_activity"] = user_data["recent_activity"][:20]
    
    save_user_data(username, user_data)

def export_user_data(username):
    """Export user data for backup"""
    user_data = load_user_data(username)
    
    export_data = {
        "username": username,
        "export_date": datetime.now().isoformat(),
        "data": user_data
    }
    
    return json.dumps(export_data, indent=2)

def import_user_data(username, import_json):
    """Import user data from backup"""
    try:
        import_data = json.loads(import_json)
        
        if "data" in import_data:
            user_data = import_data["data"]
            save_user_data(username, user_data)
            return True
        else:
            return False
    except json.JSONDecodeError:
        return False
