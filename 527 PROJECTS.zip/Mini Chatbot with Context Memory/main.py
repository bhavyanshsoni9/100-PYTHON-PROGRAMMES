responses = {
    "hello": "Hello! Kaise ho?",
    "how are you": "Main theek hoon, tum batao?",
    "bye": "Alvida! Phir milenge.",
    "joke": "Kyoon math ke teacher bahut achhe hote hain? Kyunki unka sense of humor high hota hai!"
}

memory = []

def chatbot(input_text):
    memory.append(input_text.lower())
    for key in responses:
        if key in input_text.lower():
            return responses[key]
    return "Sorry, main samajh nahi paaya."

print("Chatbot started (type 'bye' to exit)")
while True:
    user_input = input("You: ")
    answer = chatbot(user_input)
    print("Bot:", answer)
    if "bye" in user_input.lower():
        break
