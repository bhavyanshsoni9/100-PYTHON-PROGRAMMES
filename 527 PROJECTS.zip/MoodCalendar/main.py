from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import json
import os
from datetime import datetime, timedelta
import calendar

console = Console()

class MoodCalendar:
    def __init__(self):
        self.data_file = "moods.json"
        self.moods = self._load_moods()
        self.mood_colors = {
            'happy': 'green',
            'calm': 'blue',
            'energetic': 'yellow',
            'tired': 'red',
            'stressed': 'magenta',
            'neutral': 'white'
        }
        self.mood_emojis = {
            'happy': '😊',
            'calm': '😌',
            'energetic': '⚡',
            'tired': '😴',
            'stressed': '😰',
            'neutral': '😐'
        }

    def _load_moods(self):
        """Load mood data from file"""
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r') as f:
                return json.load(f)
        return {}

    def _save_moods(self):
        """Save mood data to file"""
        with open(self.data_file, 'w') as f:
            json.dump(self.moods, f)

    def add_mood(self, date, mood, notes=""):
        """Add a mood entry"""
        self.moods[date] = {
            'mood': mood,
            'notes': notes,
            'timestamp': datetime.now().strftime('%H:%M:%S')
        }
        self._save_moods()

    def get_month_calendar(self, year, month):
        """Generate calendar for specified month"""
        table = Table(title=f"[bold]{calendar.month_name[month]} {year}[/]")
        
        # Add day headers
        for day in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]:
            table.add_column(day, justify="center")

        # Get calendar weeks
        cal = calendar.monthcalendar(year, month)
        
        # Add rows
        for week in cal:
            row = []
            for day in week:
                if day == 0:
                    row.append("")
                else:
                    date = f"{year}-{month:02d}-{day:02d}"
                    if date in self.moods:
                        mood = self.moods[date]['mood']
                        color = self.mood_colors[mood]
                        emoji = self.mood_emojis[mood]
                        row.append(f"[{color}]{day}\n{emoji}[/]")
                    else:
                        row.append(str(day))
            table.add_row(*row)
        
        return table

def main():
    console.clear()
    console.print("[bold cyan]📅 MoodCalendar[/]")
    console.print("[cyan]Track Your Daily Moods[/]\n")

    calendar = MoodCalendar()

    while True:
        console.print("\n[bold cyan]Options:[/]")
        console.print("1. Add Today's Mood")
        console.print("2. View Calendar")
        console.print("3. View Mood Stats")
        console.print("4. Exit")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == '4':
            console.print("\n[cyan]Keep tracking those moods! 😊[/]")
            break

        if choice == '1':
            console.print("\n[bold]Available Moods:[/]")
            for mood, emoji in calendar.mood_emojis.items():
                console.print(f"{emoji} - {mood}")
            
            mood = input("\nEnter mood: ").strip().lower()
            if mood in calendar.mood_colors:
                notes = input("Add notes (optional): ").strip()
                date = datetime.now().strftime('%Y-%m-%d')
                calendar.add_mood(date, mood, notes)
                console.print("\n[green]Mood recorded![/]")
            else:
                console.print("\n[red]Invalid mood![/]")

        elif choice == '2':
            now = datetime.now()
            table = calendar.get_month_calendar(now.year, now.month)
            console.print(table)

        elif choice == '3':
            if calendar.moods:
                mood_counts = {}
                for entry in calendar.moods.values():
                    mood = entry['mood']
                    mood_counts[mood] = mood_counts.get(mood, 0) + 1

                panel = Panel(
                    "\n".join([
                        f"{calendar.mood_emojis[mood]} {mood}: {count} days"
                        for mood, count in mood_counts.items()
                    ]),
                    title="[bold cyan]Mood Statistics[/]",
                    border_style="cyan"
                )
                console.print(panel)
            else:
                console.print("\n[yellow]No mood data yet![/]")

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 