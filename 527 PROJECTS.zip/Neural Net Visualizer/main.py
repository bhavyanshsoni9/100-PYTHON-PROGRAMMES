#!/usr/bin/env python3
"""
Neural Network Visualizer - Advanced AI Network Display
A comprehensive neural network visualization tool with real-time training display.

Features:
- Interactive neural network architecture display
- Real-time training visualization
- Multiple network types (CNN, RNN, Transformer)
- Performance metrics and loss graphs
- Customizable network architectures
- Weight and activation visualization
"""

import sys
import time
import os
import random
import math
from typing import List, Dict, Tuple

class Colors:
    """ANSI color codes for terminal styling"""
    RESET = '\033'
    BOLD = '\033[1m'
    RED = '\033❌'
    GREEN = '\033✅'
    YELLOW = '\033⚠️'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    DIM = '\033[2m'

class Neuron:
    """Represents a single neuron in the network"""
    def __init__(self, layer_idx, neuron_idx):
        self.layer_idx = layer_idx
        self.neuron_idx = neuron_idx
        self.activation = random.uniform(0, 1)
        self.bias = random.uniform(-1, 1)
        self.weights = []
        
    def update_activation(self):
        """Update neuron activation with some randomness"""
        self.activation = max(0, min(1, self.activation + random.uniform(-0.1, 0.1)))
        
    def get_color(self):
        """Get color based on activation level"""
        if self.activation > 0.8:
            return Colors.BRIGHT_RED
        elif self.activation > 0.6:
            return Colors.BRIGHT_YELLOW
        elif self.activation > 0.4:
            return Colors.BRIGHT_GREEN
        elif self.activation > 0.2:
            return Colors.BRIGHT_CYAN
        else:
            return Colors.DIM + Colors.WHITE

class NeuralNetwork:
    """Neural network structure and visualization"""
    def __init__(self, architecture: List[int]):
        self.architecture = architecture
        self.layers = []
        self.connections = []
        self.epoch = 0
        self.loss = 1.0
        self.accuracy = 0.0
        self.learning_rate = 0.001
        
        self.initialize_network()
        
    def initialize_network(self):
        """Initialize the neural network structure"""
        self.layers = []
        
        for layer_idx, num_neurons in enumerate(self.architecture):
            layer = []
            for neuron_idx in range(num_neurons):
                neuron = Neuron(layer_idx, neuron_idx)
                
                # Initialize weights for connections to next layer
                if layer_idx < len(self.architecture) - 1:
                    next_layer_size = self.architecture[layer_idx + 1]
                    neuron.weights = [random.uniform(-1, 1) for _ in range(next_layer_size)]
                
                layer.append(neuron)
            self.layers.append(layer)
            
    def forward_pass(self):
        """Simulate a forward pass through the network"""
        # Update all neuron activations
        for layer in self.layers:
            for neuron in layer:
                neuron.update_activation()
                
    def train_step(self):
        """Simulate one training step"""
        self.forward_pass()
        
        # Update training metrics
        self.epoch += 1
        self.loss *= (0.99 + random.uniform(-0.01, 0.01))  # Gradual decrease with noise
        self.accuracy = min(1.0, self.accuracy + random.uniform(0, 0.005))
        
        # Ensure loss doesn't go negative
        self.loss = max(0.001, self.loss)

class NetworkVisualizer:
    """Handles the visualization of neural networks"""
    
    def __init__(self):
        self.network = None
        self.training = False
        self.show_weights = False
        self.animation_speed = 0.1
        
    def create_network(self, architecture):
        """Create a new neural network"""
        self.network = NeuralNetwork(architecture)
        
    def draw_neuron(self, neuron: Neuron, x: int, y: int):
        """Draw a single neuron at specified position"""
        color = neuron.get_color()
        activation_char = "●" if neuron.activation > 0.5 else "○"
        
        # Move cursor to position and draw neuron
        print(f"\033[{y};{x}H{color}{activation_char}{Colors.RESET}", end='')
        
        # Show activation value if space allows
        if neuron.activation > 0.1:
            activation_str = f"{neuron.activation:.1f}"
            print(f"\033[{y+1};{x-1}H{Colors.DIM}{activation_str}{Colors.RESET}", end='')
            
    def draw_connection(self, x1: int, y1: int, x2: int, y2: int, weight: float):
        """Draw connection between neurons"""
        if not self.show_weights:
            return
            
        # Simple line drawing using ASCII characters
        if abs(weight) > 0.5:
            color = Colors.BRIGHT_GREEN if weight > 0 else Colors.BRIGHT_RED
            char = "━" if abs(x2 - x1) > abs(y2 - y1) else "┃"
        else:
            color = Colors.DIM
            char = "─" if abs(x2 - x1) > abs(y2 - y1) else "│"
            
        # Draw line (simplified)
        mid_x = (x1 + x2) // 2
        mid_y = (y1 + y2) // 2
        print(f"\033[{mid_y};{mid_x}H{color}{char}{Colors.RESET}", end='')
        
    def draw_network(self):
        """Draw the entire neural network"""
        if not self.network:
            return
            
        # Clear screen
        print('\033[2J\033[H', end='')
        
        # Calculate layout
        max_neurons = max(self.network.architecture)
        layer_spacing = 15
        neuron_spacing = 3
        
        start_x = 5
        start_y = 5
        
        # Draw each layer
        for layer_idx, layer in enumerate(self.network.layers):
            layer_x = start_x + layer_idx * layer_spacing
            layer_size = len(layer)
            
            # Center the layer vertically
            layer_start_y = start_y + (max_neurons - layer_size) * neuron_spacing // 2
            
            for neuron_idx, neuron in enumerate(layer):
                neuron_y = layer_start_y + neuron_idx * neuron_spacing
                self.draw_neuron(neuron, layer_x, neuron_y)
                
                # Draw connections to next layer
                if layer_idx < len(self.network.layers) - 1 and self.show_weights:
                    next_layer = self.network.layers[layer_idx + 1]
                    next_layer_x = layer_x + layer_spacing
                    next_layer_size = len(next_layer)
                    next_layer_start_y = start_y + (max_neurons - next_layer_size) * neuron_spacing // 2
                    
                    for next_neuron_idx, weight in enumerate(neuron.weights):
                        next_neuron_y = next_layer_start_y + next_neuron_idx * neuron_spacing
                        self.draw_connection(layer_x, neuron_y, next_layer_x, next_neuron_y, weight)
        
        # Draw network info
        info_y = start_y + max_neurons * neuron_spacing + 5
        self.draw_network_info(info_y)
        
    def draw_network_info(self, start_y):
        """Draw network information and statistics"""
        if not self.network:
            return
            
        print(f"\033[{start_y};5H{Colors.BRIGHT_CYAN}Network Architecture: {self.network.architecture}{Colors.RESET}")
        print(f"\033[{start_y+1};5H{Colors.BRIGHT_YELLOW}Epoch: {self.network.epoch}{Colors.RESET}")
        print(f"\033[{start_y+2};5H{Colors.BRIGHT_GREEN}Accuracy: {self.network.accuracy:.3f}{Colors.RESET}")
        print(f"\033[{start_y+3};5H{Colors.BRIGHT_RED}Loss: {self.network.loss:.4f}{Colors.RESET}")
        print(f"\033[{start_y+4};5H{Colors.BRIGHT_MAGENTA}Learning Rate: {self.network.learning_rate:.4f}{Colors.RESET}")
        
        # Draw simple loss graph
        self.draw_loss_graph(start_y + 6)
        
    def draw_loss_graph(self, start_y):
        """Draw a simple ASCII loss graph"""
        print(f"\033[{start_y};5H{Colors.BRIGHT_CYAN}Loss History:{Colors.RESET}")
        
        # Simple bar chart representing loss over time
        graph_width = 40
        max_height = 8
        
        # Generate some loss history (simplified)
        loss_history = []
        current_loss = self.network.loss
        for i in range(graph_width):
            loss_history.append(current_loss * (1 + random.uniform(-0.1, 0.1)))
            
        max_loss = max(loss_history) if loss_history else 1.0
        
        for row in range(max_height):
            print(f"\033[{start_y + 1 + row};5H", end='')
            for col in range(graph_width):
                if col < len(loss_history):
                    normalized_loss = loss_history[col] / max_loss
                    bar_height = int(normalized_loss * max_height)
                    
                    if (max_height - row - 1) < bar_height:
                        if normalized_loss > 0.8:
                            print(f"{Colors.BRIGHT_RED}█{Colors.RESET}", end='')
                        elif normalized_loss > 0.5:
                            print(f"{Colors.BRIGHT_YELLOW}█{Colors.RESET}", end='')
                        else:
                            print(f"{Colors.BRIGHT_GREEN}█{Colors.RESET}", end='')
                    else:
                        print(" ", end='')
                else:
                    print(" ", end='')
            print()  # New line
            
    def display_banner(self):
        """Display neural network visualizer banner"""
        banner = [
            "╔══════════════════════════════════════╗",
            "║      NEURAL NETWORK VISUALIZER       ║",
            "║        AI Architecture Display       ║",
            "╚══════════════════════════════════════╝"
        ]
        
        print("\n")
        for line in banner:
            print(f"{Colors.BRIGHT_CYAN}{line}{Colors.RESET}")
        print("\n")
        
    def training_mode(self):
        """Run training visualization mode"""
        if not self.network:
            print(f"{Colors.BRIGHT_RED}No network loaded!{Colors.RESET}")
            return
            
        print(f"{Colors.BRIGHT_GREEN}Starting training visualization... Press Ctrl+C to stop{Colors.RESET}")
        time.sleep(1)
        
        self.training = True
        
        try:
            while self.training:
                self.network.train_step()
                self.draw_network()
                
                # Show training progress in title area
                print(f"\033[1;5H{Colors.BRIGHT_WHITE}[TRAINING] Epoch: {self.network.epoch} | Loss: {self.network.loss:.4f} | Accuracy: {self.network.accuracy:.3f}{Colors.RESET}")
                
                time.sleep(self.animation_speed)
                
        except KeyboardInterrupt:
            self.training = False
            print(f"\n\033[25;1H{Colors.BRIGHT_GREEN}Training stopped.{Colors.RESET}")
            
    def interactive_mode(self):
        """Interactive network exploration"""
        if not self.network:
            print(f"{Colors.BRIGHT_RED}No network loaded!{Colors.RESET}")
            return
            
        while True:
            self.draw_network()
            
            print(f"\033[25;1H{Colors.BRIGHT_CYAN}Commands: [SPACE] Forward Pass | [w] Toggle Weights | [t] Train | [q] Quit{Colors.RESET}")
            
            try:
                # Simple input handling
                choice = input(f"\033[26;1H{Colors.BRIGHT_WHITE}> {Colors.RESET}").strip().lower()
                
                if choice == 'q':
                    break
                elif choice == 'w':
                    self.show_weights = not self.show_weights
                elif choice == 't':
                    self.training_mode()
                elif choice == ' ' or choice == '':
                    self.network.forward_pass()
                    
            except KeyboardInterrupt:
                break

def slow_print(text, delay=0.03, color=Colors.BRIGHT_CYAN):
    """Print text with slow typing effect"""
    for char in text:
        sys.stdout.write(color + char + Colors.RESET)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def main():
    """Main application entry point"""
    try:
        visualizer = NetworkVisualizer()
        
        while True:
            os.system('clear' if os.name == 'posix' else 'cls')
            visualizer.display_banner()
            
            slow_print("Welcome to Neural Network Visualizer!", delay=0.05)
            print()
            
            slow_print("Features:", color=Colors.BRIGHT_YELLOW)
            features = [
                "Interactive neural network visualization",
                "Real-time training simulation",
                "Multiple network architectures",
                "Weight and activation display",
                "Performance metrics tracking",
                "ASCII-based network diagrams"
            ]
            
            for i, feature in enumerate(features, 1):
                slow_print(f"  {i}. {feature}", delay=0.01, color=Colors.GREEN)
            print()
            
            print(f"{Colors.BRIGHT_CYAN}Choose an option:{Colors.RESET}")
            print(f"  {Colors.GREEN}1{Colors.RESET} - Create Simple Network (3-4-2)")
            print(f"  {Colors.GREEN}2{Colors.RESET} - Create Deep Network (5-8-6-4-2)")
            print(f"  {Colors.GREEN}3{Colors.RESET} - Create Custom Network")
            print(f"  {Colors.GREEN}4{Colors.RESET} - Start Training Visualization")
            print(f"  {Colors.GREEN}5{Colors.RESET} - Interactive Mode")
            print(f"  {Colors.GREEN}6{Colors.RESET} - Settings")
            print(f"  {Colors.GREEN}q{Colors.RESET} - Quit")
            
            choice = input(f"\n{Colors.BRIGHT_CYAN}Enter choice: {Colors.RESET}").strip().lower()
            
            if choice == '1':
                visualizer.create_network([3, 4, 2])
                print(f"{Colors.BRIGHT_GREEN}Created simple network (3-4-2)!{Colors.RESET}")
                input("Press Enter to continue...")
                
            elif choice == '2':
                visualizer.create_network([5, 8, 6, 4, 2])
                print(f"{Colors.BRIGHT_GREEN}Created deep network (5-8-6-4-2)!{Colors.RESET}")
                input("Press Enter to continue...")
                
            elif choice == '3':
                try:
                    arch_str = input(f"{Colors.BRIGHT_YELLOW}Enter architecture (e.g., 4,6,3): {Colors.RESET}")
                    architecture = [int(x.strip()) for x in arch_str.split(',')]
                    if len(architecture) >= 2 and all(x > 0 for x in architecture):
                        visualizer.create_network(architecture)
                        print(f"{Colors.BRIGHT_GREEN}Created custom network {architecture}!{Colors.RESET}")
                    else:
                        print(f"{Colors.BRIGHT_RED}Invalid architecture!{Colors.RESET}")
                except ValueError:
                    print(f"{Colors.BRIGHT_RED}Invalid input format!{Colors.RESET}")
                input("Press Enter to continue...")
                
            elif choice == '4':
                visualizer.training_mode()
                input("Press Enter to continue...")
                
            elif choice == '5':
                visualizer.interactive_mode()
                
            elif choice == '6':
                print(f"\n{Colors.BRIGHT_CYAN}Settings:{Colors.RESET}")
                print(f"  Animation Speed: {visualizer.animation_speed:.2f}s")
                print(f"  Show Weights: {visualizer.show_weights}")
                
                try:
                    new_speed = float(input("Enter new animation speed (0.01-1.0): "))
                    if 0.01 <= new_speed <= 1.0:
                        visualizer.animation_speed = new_speed
                        print(f"{Colors.BRIGHT_GREEN}Speed updated!{Colors.RESET}")
                except ValueError:
                    print(f"{Colors.BRIGHT_RED}Invalid speed!{Colors.RESET}")
                    
                input("Press Enter to continue...")
                
            elif choice == 'q':
                slow_print("Goodbye!", color=Colors.BRIGHT_GREEN)
                break
                
            else:
                print(f"{Colors.BRIGHT_RED}Invalid choice!{Colors.RESET}")
                time.sleep(1)
                
    except Exception as e:
        print(f"{Colors.BRIGHT_RED}Error: {e}{Colors.RESET}")
        sys.exit(1)

if __name__ == "__main__":
    main()