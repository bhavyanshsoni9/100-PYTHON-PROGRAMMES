import os

NOTES_FOLDER = "NOTES"

def welcome_screen():
    print("=" * 50)
    print("📒 Welcome To The Notes Saver App")
    print("---> Made By 'Bhavyansh Soni'")
    print("In This APP, You Can Save, Edit, View, and Search Your Notes!")
    print("=" * 50)

# Create notes folder if not exists
if not os.path.exists(NOTES_FOLDER):
    os.makedirs(NOTES_FOLDER)

def save(title, note):
    print(f"📝 Saving Note with title '{title}' in '{NOTES_FOLDER}' folder.")
    note_path = os.path.join(NOTES_FOLDER, f"{title}.txt")
    with open(note_path, "w", encoding="utf-8") as f:
        f.write(note)
    print("✅ Note saved successfully.")

def view(title):
    note_path = os.path.join(NOTES_FOLDER, f"{title}.txt")
    if os.path.exists(note_path):
        with open(note_path, "r", encoding="utf-8") as f:
            note = f.read()
        print(f"\n📖 Note '{title}':\n" + "-" * 30)
        print(note)
    else:
        print(f"❌ Note '{title}' does not exist.")

def edit(title):
    note_path = os.path.join(NOTES_FOLDER, f"{title}.txt")
    if os.path.exists(note_path):
        with open(note_path, "r", encoding="utf-8") as f:
            old_note = f.read()
        print(f"\n✏️ Current note:\n" + "-" * 30)
        print(old_note)
        print("-" * 30)
        new_note = input("Enter new note content:\n")
        with open(note_path, "w", encoding="utf-8") as f:
            f.write(new_note)
        print("✅ Note updated successfully.")
    else:
        print(f"❌ Note '{title}' does not exist.")

def delete(title):
    note_path = os.path.join(NOTES_FOLDER, f"{title}.txt")
    if os.path.exists(note_path):
        os.remove(note_path)
        print(f"🗑️ Note '{title}' deleted.")
    else:
        print(f"❌ Note '{title}' does not exist.")

def list_notes():
    print("\n📚 All Saved Notes:")
    files = os.listdir(NOTES_FOLDER)
    if not files:
        print("⚠️ No notes found.")
    else:
        for file in files:
            print("•", file.replace(".txt", ""))

def search_notes(keyword):
    print(f"\n🔍 Searching for '{keyword}' in all notes...")
    found = False
    for filename in os.listdir(NOTES_FOLDER):
        path = os.path.join(NOTES_FOLDER, filename)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
            if keyword.lower() in content.lower():
                print(f"✔ Found in: {filename.replace('.txt', '')}")
                found = True
    if not found:
        print("❌ No matching notes found.")

def Menu():
    while True:
        print("\n========= 📋 MENU =========")
        print("1. Save Note")
        print("2. View Note")
        print("3. Edit Note")
        print("4. Delete Note")
        print("5. List All Notes")
        print("6. Search in Notes")
        print("7. Exit")
        print("===========================\n")
        choice = input("🔷 Enter your choice: ")
        
        if choice == "1":
            title = input("Enter note title: ")
            note = input("Enter note content: ")
            save(title, note)

        elif choice == "2":
            list_notes()
            title = input("👁️ Enter note title to view: ")
            view(title)

        elif choice == "3":
            list_notes()
            title = input("✏️ Enter note title to edit: ")
            edit(title)

        elif choice == "4":
            list_notes()
            title = input("🗑️ Enter note title to delete: ")
            delete(title)

        elif choice == "5":
            list_notes()

        elif choice == "6":
            keyword = input("Enter keyword to search: ")
            search_notes(keyword)

        elif choice == "7":
            print("👋 Exiting... Have a great day!")
            break
        else:
            print("⚠️ Invalid choice. Please try again.")

# Start App
welcome_screen()
Menu()
