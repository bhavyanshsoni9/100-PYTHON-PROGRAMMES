import os

def search_files(keyword, start_path):
    for root, dirs, files in os.walk(start_path):
        for file in files:
            if keyword.lower() in file.lower():
                print(os.path.join(root, file))

if __name__ == "__main__":
    keyword = input("Enter keyword to search: ")
    start_path = input("Enter start directory (e.g., C:/Users/): ")
    print("\nSearching...\n")
    search_files(keyword, start_path)