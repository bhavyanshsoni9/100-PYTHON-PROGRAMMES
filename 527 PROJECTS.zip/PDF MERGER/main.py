import os

if __name__ == "__main__":
    x = input("Enter: ")
    command = f"speak {x}"
    os.system(command)
