import fitz  # PyMuPDF
import os

def extract_text_images(pdf_path, output_folder):
    pdf_name = os.path.basename(pdf_path).replace(".pdf", "")
    os.makedirs(f"{output_folder}/{pdf_name}/images", exist_ok=True)
    os.makedirs(f"{output_folder}/{pdf_name}/text", exist_ok=True)

    doc = fitz.open(pdf_path)

    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        text = page.get_text()

        # Save text
        with open(f"{output_folder}/{pdf_name}/text/page_{page_num + 1}.txt", "w", encoding="utf-8") as f:
            f.write(text)

        # Extract images
        image_list = page.get_images(full=True)
        for img_index, img in enumerate(image_list):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image_ext = base_image["ext"]
            with open(f"{output_folder}/{pdf_name}/images/page{page_num + 1}_{img_index + 1}.{image_ext}", "wb") as img_file:
                img_file.write(image_bytes)

    doc.close()
    print(f"[✓] Extracted from {pdf_name}")

def scan_folder(pdf_folder, output_folder="output"):
    os.makedirs(output_folder, exist_ok=True)
    for file in os.listdir(pdf_folder):
        if file.lower().endswith(".pdf"):
            extract_text_images(os.path.join(pdf_folder, file), output_folder)

# ---------- RUN HERE ----------
pdf_folder_path = input("Enter folder path containing PDFs: ")
scan_folder(pdf_folder_path)
