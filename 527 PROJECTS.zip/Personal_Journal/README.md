# Personal Journal (Offline Terminal Diary App)

A simple offline terminal diary app with password protection, colored prompts, emojis for entries, and smooth animations.

## Features
- Password protection (set on first run)
- Colored prompts and output (using colorama)
- Emojis to mark entries
- Smooth typing and saving animations
- All data stored locally (offline)

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the app:
   ```bash
   python diary_app.py
   ```

## Usage
- On first run, set your password.
- Choose to add or view entries from the menu.
- Entries are saved in `journal_entries.json` in the same folder.

Enjoy journaling! ✍️ 