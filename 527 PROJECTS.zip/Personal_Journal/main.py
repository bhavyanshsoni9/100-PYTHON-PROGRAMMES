import os
import sys
import json
import time
import getpass
from datetime import datetime
from colorama import init, Fore, Style

init(autoreset=True)

DATA_FILE = 'journal_entries.json'
PASS_FILE = 'journal_pass.txt'
EMOJIS = ['😊', '😢', '🚀', '❤️', '😡', '🎉', '🌟', '😴']

# --- Helper Functions ---
def slow_print(text, delay=0.03):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def save_animation():
    slow_print(Fore.YELLOW + 'Saving', 0.1)
    for _ in range(3):
        print(Fore.YELLOW + '.', end='', flush=True)
        time.sleep(0.4)
    print(Fore.GREEN + ' Done!')

def load_password():
    if not os.path.exists(PASS_FILE):
        return None
    with open(PASS_FILE, 'r') as f:
        return f.read().strip()

def set_password():
    slow_print(Fore.CYAN + 'Set a password for your diary:')
    while True:
        pwd1 = getpass.getpass('New Password: ')
        pwd2 = getpass.getpass('Confirm Password: ')
        if pwd1 == pwd2 and pwd1:
            with open(PASS_FILE, 'w') as f:
                f.write(pwd1)
            slow_print(Fore.GREEN + 'Password set successfully!')
            break
        else:
            slow_print(Fore.RED + 'Passwords do not match or empty. Try again.')

def authenticate():
    saved_pwd = load_password()
    if saved_pwd is None:
        set_password()
        return True
    for _ in range(3):
        pwd = getpass.getpass(Fore.CYAN + 'Enter your diary password: ')
        if pwd == saved_pwd:
            slow_print(Fore.GREEN + 'Access granted!')
            return True
        else:
            slow_print(Fore.RED + 'Incorrect password.')
    slow_print(Fore.RED + 'Too many failed attempts. Exiting.')
    sys.exit(1)

def load_entries():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_entries(entries):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)
    save_animation()

def add_entry():
    slow_print(Fore.MAGENTA + '\nChoose an emoji for your entry:')
    for idx, emoji in enumerate(EMOJIS):
        print(Fore.YELLOW + f'[{idx+1}] {emoji}', end='  ')
    print()
    while True:
        try:
            choice = int(input(Fore.CYAN + 'Enter emoji number: '))
            if 1 <= choice <= len(EMOJIS):
                emoji = EMOJIS[choice-1]
                break
            else:
                slow_print(Fore.RED + 'Invalid choice. Try again.')
        except ValueError:
            slow_print(Fore.RED + 'Please enter a number.')
    slow_print(Fore.CYAN + 'Type your diary entry. Press Enter when done.')
    entry = input(Fore.WHITE + 'Entry: ')
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
    entries = load_entries()
    entries.append({'time': timestamp, 'emoji': emoji, 'text': entry})
    save_entries(entries)
    slow_print(Fore.GREEN + 'Entry saved!')

def view_entries():
    entries = load_entries()
    if not entries:
        slow_print(Fore.YELLOW + 'No entries yet.')
        return
    slow_print(Fore.BLUE + '\nYour Diary Entries:')
    for e in entries:
        print(Fore.YELLOW + f"[{e['time']}] {e['emoji']} {Fore.WHITE}{e['text']}")
        time.sleep(0.2)

def main_menu():
    while True:
        print(Fore.CYAN + '\n--- Personal Journal ---')
        print(Fore.GREEN + '[1] Add Entry')
        print(Fore.YELLOW + '[2] View Entries')
        print(Fore.RED + '[3] Exit')
        choice = input(Fore.CYAN + 'Choose an option: ')
        if choice == '1':
            add_entry()
        elif choice == '2':
            view_entries()
        elif choice == '3':
            slow_print(Fore.MAGENTA + 'Goodbye!')
            break
        else:
            slow_print(Fore.RED + 'Invalid option. Try again.')

if __name__ == '__main__':
    authenticate()
    main_menu() 