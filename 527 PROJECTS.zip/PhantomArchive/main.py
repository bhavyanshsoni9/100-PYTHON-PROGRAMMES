import os
import time
import shutil
import json
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress
from rich.text import Text
from rich.table import Table
from datetime import datetime
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

# Initialize Rich console
console = Console()

class PhantomArchive:
    def __init__(self):
        self.archive_dir = ".phantom"
        self.index_file = os.path.join(self.archive_dir, "index.enc")
        self.salt_file = os.path.join(self.archive_dir, "salt.bin")
        self.initialize_archive()

    def initialize_archive(self):
        """Initialize the phantom archive"""
        if not os.path.exists(self.archive_dir):
            os.makedirs(self.archive_dir, exist_ok=True)
        
        # Initialize encryption
        if os.path.exists(self.salt_file):
            with open(self.salt_file, 'rb') as f:
                self.salt = f.read()
        else:
            self.salt = os.urandom(16)
            with open(self.salt_file, 'wb') as f:
                f.write(self.salt)

    def generate_key(self, password):
        """Generate encryption key from password"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=self.salt,
            iterations=480000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return Fernet(key)

    def load_index(self, password):
        """Load encrypted archive index"""
        if not os.path.exists(self.index_file):
            return {}
            
        try:
            f = self.generate_key(password)
            with open(self.index_file, 'rb') as file:
                encrypted_data = file.read()
            decrypted_data = f.decrypt(encrypted_data)
            return json.loads(decrypted_data)
        except:
            return {}

    def save_index(self, index, password):
        """Save encrypted archive index"""
        f = self.generate_key(password)
        encrypted_data = f.encrypt(json.dumps(index).encode())
        with open(self.index_file, 'wb') as file:
            file.write(encrypted_data)

    def archive_file(self, file_path, password):
        """Archive and encrypt a file"""
        if not os.path.exists(file_path):
            return False, "File not found"
            
        try:
            # Generate unique phantom name
            phantom_name = base64.urlsafe_b64encode(os.urandom(8)).decode()
            phantom_path = os.path.join(self.archive_dir, phantom_name)
            
            # Load index
            index = self.load_index(password)
            
            # Copy file to archive
            shutil.copy2(file_path, phantom_path)
            
            # Encrypt file
            f = self.generate_key(password)
            with open(phantom_path, 'rb') as file:
                file_data = file.read()
            encrypted_data = f.encrypt(file_data)
            with open(phantom_path, 'wb') as file:
                file.write(encrypted_data)
            
            # Update index
            index[phantom_name] = {
                'original_path': file_path,
                'original_name': os.path.basename(file_path),
                'size': os.path.getsize(file_path),
                'archived_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            self.save_index(index, password)
            return True, phantom_name
            
        except Exception as e:
            return False, str(e)

    def extract_file(self, phantom_name, password, output_path=None):
        """Extract and decrypt a file from the archive"""
        try:
            # Load index
            index = self.load_index(password)
            if phantom_name not in index:
                return False, "File not found in archive"
            
            file_info = index[phantom_name]
            phantom_path = os.path.join(self.archive_dir, phantom_name)
            
            if not output_path:
                output_path = file_info['original_path']
            
            # Decrypt file
            f = self.generate_key(password)
            with open(phantom_path, 'rb') as file:
                encrypted_data = file.read()
            decrypted_data = f.decrypt(encrypted_data)
            
            # Write decrypted file
            with open(output_path, 'wb') as file:
                file.write(decrypted_data)
                
            return True, output_path
            
        except Exception as e:
            return False, str(e)

def type_print(text, delay=0.03):
    """Print text with ghost effect"""
    for char in text:
        style = random.choice(['bold cyan', 'bold blue', 'bold white'])
        console.print(char, end='', style=style)
        time.sleep(delay)
    print()

def display_archive_contents(archive, password):
    """Display archived files in a table"""
    index = archive.load_index(password)
    
    if not index:
        console.print(Panel("No files in the phantom archive...",
                          style="dim cyan",
                          title="Phantom Archive"))
        return
    
    table = Table(title="[bold]Phantom Archive Contents[/]")
    table.add_column("Original Name", style="cyan")
    table.add_column("Size", style="blue")
    table.add_column("Archived Date", style="white")
    table.add_column("Phantom ID", style="dim")
    
    for phantom_name, info in index.items():
        table.add_row(
            info['original_name'],
            f"{info['size']:,} bytes",
            info['archived_date'],
            phantom_name
        )
    
    console.print(table)

def simulate_operation(description):
    """Simulate an operation with ghost-themed progress"""
    with Progress() as progress:
        task = progress.add_task(f"[cyan]{description}[/]", total=100)
        
        while not progress.finished:
            progress.update(task, advance=1)
            time.sleep(0.02)

def main():
    """Main program with ghost-themed interface"""
    import random  # For random styling
    
    archive = PhantomArchive()
    console.clear()
    
    type_print("👻 Welcome to PhantomArchive", delay=0.05)
    type_print("   Your files vanish into the shadows...", delay=0.03)
    print()
    
    # Get master password
    master_password = Prompt.ask("[bold cyan]Enter master password[/]", password=True)
    
    while True:
        try:
            console.print("\n[cyan]Phantom Operations:[/]")
            console.print("1. [white]Archive File[/]")
            console.print("2. [white]Extract File[/]")
            console.print("3. [white]View Archive[/]")
            console.print("4. [white]Exit[/]")
            
            choice = input("\nSelect operation (1-4): ").strip()
            
            if choice == '1':
                file_path = input("\nEnter path to file: ").strip()
                
                type_print("\n👻 Preparing to phantom-ize file...", delay=0.03)
                simulate_operation("Creating phantom copy")
                
                success, result = archive.archive_file(file_path, master_password)
                
                if success:
                    type_print(f"\n✨ File has vanished into the phantom zone!", delay=0.03)
                    console.print(f"[dim]Phantom ID: {result}[/]")
                else:
                    console.print(f"\n[red]Error: {result}[/]")
                
            elif choice == '2':
                console.clear()
                display_archive_contents(archive, master_password)
                
                phantom_name = input("\nEnter Phantom ID to extract: ").strip()
                output_path = input("Enter output path (or press Enter for original location): ").strip()
                
                type_print("\n👻 Summoning file from the phantom zone...", delay=0.03)
                simulate_operation("Materializing file")
                
                success, result = archive.extract_file(phantom_name, master_password, output_path if output_path else None)
                
                if success:
                    type_print(f"\n✨ File has materialized at: {result}", delay=0.03)
                else:
                    console.print(f"\n[red]Error: {result}[/]")
                
            elif choice == '3':
                console.clear()
                type_print("👻 Peering into the phantom zone...", delay=0.03)
                print()
                display_archive_contents(archive, master_password)
                input("\nPress Enter to continue...")
                
            elif choice == '4':
                type_print("\n👻 Fading back into the shadows...", delay=0.05)
                break
                
        except KeyboardInterrupt:
            print("\n")
            type_print("👻 Emergency dematerialization...", delay=0.05)
            break

if __name__ == "__main__":
    from rich.prompt import Prompt  # For secure password input
    main() 