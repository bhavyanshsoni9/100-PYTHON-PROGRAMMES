from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress
import os
import shutil
import json
from datetime import datetime
import mimetypes
import hashlib

console = Console()

class PhantomSorter:
    def __init__(self):
        self.config_file = "phantom_config.json"
        self.config = self._load_config()
        self.categories = {
            'images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'],
            'documents': ['.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt'],
            'audio': ['.mp3', '.wav', '.flac', '.m4a', '.ogg'],
            'video': ['.mp4', '.avi', '.mkv', '.mov', '.wmv'],
            'archives': ['.zip', '.rar', '.7z', '.tar', '.gz'],
            'code': ['.py', '.js', '.html', '.css', '.java', '.cpp']
        }

    def _load_config(self):
        """Load sorting configuration"""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                return json.load(f)
        return {'history': [], 'rules': {}}

    def _save_config(self):
        """Save sorting configuration"""
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)

    def _get_file_hash(self, file_path):
        """Calculate file hash"""
        hasher = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hasher.update(chunk)
        return hasher.hexdigest()

    def _get_category(self, file_path):
        """Determine file category"""
        ext = os.path.splitext(file_path)[1].lower()
        for category, extensions in self.categories.items():
            if ext in extensions:
                return category
        return 'misc'

    def add_rule(self, pattern, destination, category=None):
        """Add a sorting rule"""
        self.config['rules'][pattern] = {
            'destination': destination,
            'category': category,
            'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self._save_config()

    def sort_files(self, source_dir, organize_by='ext', create_duplicates_folder=True):
        """Sort files according to rules"""
        if not os.path.exists(source_dir):
            return False, "Source directory does not exist"

        duplicates = set()
        processed = 0
        errors = []

        with Progress() as progress:
            # Count files
            task1 = progress.add_task("[cyan]Scanning...", total=None)
            files = []
            for root, _, filenames in os.walk(source_dir):
                for filename in filenames:
                    files.append(os.path.join(root, filename))
                    progress.update(task1, advance=1)

            # Process files
            task2 = progress.add_task("[green]Sorting...", total=len(files))
            
            for file_path in files:
                try:
                    # Skip hidden files
                    if os.path.basename(file_path).startswith('.'):
                        continue

                    # Determine destination
                    category = self._get_category(file_path)
                    
                    if organize_by == 'ext':
                        dest_dir = os.path.join(source_dir, category)
                    elif organize_by == 'date':
                        date = datetime.fromtimestamp(os.path.getmtime(file_path))
                        dest_dir = os.path.join(source_dir, date.strftime('%Y-%m'))
                    else:
                        dest_dir = os.path.join(source_dir, 'sorted')

                    os.makedirs(dest_dir, exist_ok=True)

                    # Check for duplicates
                    file_hash = self._get_file_hash(file_path)
                    if file_hash in duplicates:
                        if create_duplicates_folder:
                            dup_dir = os.path.join(source_dir, 'duplicates')
                            os.makedirs(dup_dir, exist_ok=True)
                            dest_dir = dup_dir
                    else:
                        duplicates.add(file_hash)

                    # Move file
                    filename = os.path.basename(file_path)
                    dest_path = os.path.join(dest_dir, filename)
                    
                    if os.path.exists(dest_path):
                        base, ext = os.path.splitext(filename)
                        counter = 1
                        while os.path.exists(dest_path):
                            dest_path = os.path.join(dest_dir, f"{base}_{counter}{ext}")
                            counter += 1

                    shutil.move(file_path, dest_path)
                    processed += 1

                except Exception as e:
                    errors.append(f"{file_path}: {str(e)}")

                progress.update(task2, advance=1)

        # Save history
        self.config['history'].append({
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'source': source_dir,
            'processed': processed,
            'errors': len(errors)
        })
        self._save_config()

        return True, f"Processed {processed} files with {len(errors)} errors"

def main():
    console.clear()
    console.print("[bold blue]👻 PhantomSorter[/]")
    console.print("[blue]Stealth File Organization System[/]\n")

    sorter = PhantomSorter()

    while True:
        console.print("\n[bold blue]Options:[/]")
        console.print("1. Sort Files")
        console.print("2. Add Sorting Rule")
        console.print("3. View History")
        console.print("4. Exit")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == '4':
            console.print("\n[blue]Your files are organized! 👻[/]")
            break

        if choice == '1':
            source = input("\nEnter directory to sort: ").strip()
            console.print("\nOrganize by:")
            console.print("1. Extension")
            console.print("2. Date")
            console.print("3. Simple")
            
            org_choice = input("Select organization method (1-3): ").strip()
            org_method = 'ext' if org_choice == '1' else 'date' if org_choice == '2' else 'simple'
            
            duplicates = input("Create duplicates folder? (y/n): ").lower() == 'y'
            
            success, message = sorter.sort_files(source, org_method, duplicates)
            if success:
                console.print(f"\n[green]{message}[/]")
            else:
                console.print(f"\n[red]{message}[/]")

        elif choice == '2':
            pattern = input("\nFile pattern (e.g., *.pdf): ").strip()
            destination = input("Destination folder: ").strip()
            category = input("Category (optional): ").strip() or None
            
            sorter.add_rule(pattern, destination, category)
            console.print("\n[green]Rule added successfully![/]")

        elif choice == '3':
            if sorter.config['history']:
                for entry in sorter.config['history']:
                    panel = Panel(
                        f"[bold]Time:[/] {entry['timestamp']}\n"
                        f"[bold]Source:[/] {entry['source']}\n"
                        f"[bold]Files Processed:[/] {entry['processed']}\n"
                        f"[bold]Errors:[/] {entry['errors']}",
                        title="[bold blue]Sorting Operation[/]",
                        border_style="blue"
                    )
                    console.print(panel)
            else:
                console.print("\n[yellow]No sorting history yet![/]")

        input("\nPress Enter to continue...")

if __name__ == "__main__":
    main() 