from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from PIL import Image
import numpy as np
import os

class PixelEncryptor:
    def __init__(self):
        self.console = Console()
        
    def text_to_binary(self, text):
        """Convert text to binary string"""
        binary = ''.join(format(ord(char), '08b') for char in text)
        return binary + '00000000'  # Add terminator
        
    def binary_to_text(self, binary):
        """Convert binary string to text"""
        text = ''
        for i in range(0, len(binary), 8):
            byte = binary[i:i+8]
            if byte == '00000000':  # Check for terminator
                break
            text += chr(int(byte, 2))
        return text
        
    def encode_message(self, image_path, message, output_path):
        """Hide a message in an image"""
        # Load image
        img = Image.open(image_path)
        pixels = np.array(img)
        
        # Convert message to binary
        binary_message = self.text_to_binary(message)
        if len(binary_message) > pixels.size:
            raise ValueError("Message too long for this image")
            
        # Flatten the pixel array
        flat_pixels = pixels.flatten()
        
        # Encode message
        for i, bit in enumerate(binary_message):
            # Clear the least significant bit
            flat_pixels[i] = flat_pixels[i] & ~1
            # Set the least significant bit to the message bit
            flat_pixels[i] = flat_pixels[i] | int(bit)
            
        # Reshape and save
        encoded_pixels = flat_pixels.reshape(pixels.shape)
        encoded_image = Image.fromarray(encoded_pixels)
        encoded_image.save(output_path)
        
    def decode_message(self, image_path):
        """Extract hidden message from image"""
        # Load image
        img = Image.open(image_path)
        pixels = np.array(img)
        
        # Extract bits
        binary_message = ''
        flat_pixels = pixels.flatten()
        
        for pixel in flat_pixels:
            binary_message += str(pixel & 1)
            if len(binary_message) % 8 == 0:
                if binary_message[-8:] == '00000000':
                    break
                    
        return self.binary_to_text(binary_message)
        
    def run(self):
        while True:
            self.console.print("\n🖼️ PixelEncryptor - Image Steganography Tool", style="bold magenta")
            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "3"],
                default="1"
            )
            
            if choice == "1":
                try:
                    image_path = Prompt.ask("Enter path to source image")
                    if not os.path.exists(image_path):
                        raise FileNotFoundError("Image not found")
                        
                    message = Prompt.ask("Enter message to hide")
                    output_path = Prompt.ask("Enter output image path")
                    
                    self.encode_message(image_path, message, output_path)
                    self.console.print("✨ Message hidden successfully!", style="bold green")
                    
                except Exception as e:
                    self.console.print(f"❌ Error: {str(e)}", style="bold red")
                    
            elif choice == "2":
                try:
                    image_path = Prompt.ask("Enter path to image with hidden message")
                    if not os.path.exists(image_path):
                        raise FileNotFoundError("Image not found")
                        
                    message = self.decode_message(image_path)
                    self.console.print(Panel(
                        f"[bold green]Hidden Message:[/]\n{message}",
                        title="🔍 Decoded Message",
                        border_style="green"
                    ))
                    
                except Exception as e:
                    self.console.print(f"❌ Error: {str(e)}", style="bold red")
                    
            elif choice == "3":
                self.console.print("👋 Goodbye!", style="bold magenta")
                break
                
if __name__ == "__main__":
    encryptor = PixelEncryptor()
    encryptor.run() 