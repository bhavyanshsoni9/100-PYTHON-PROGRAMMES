#!/usr/bin/env python3

"""
Pomodoro Timer
A productivity tool implementing the Pomodoro Technique with customizable work/break intervals
and notification support.

Author: Bhavyansh Soni
"""

import time
import os
import json
from datetime import datetime, timedelta
import threading
import platform
from typing import Optional, Dict, List
from colorama import init, Fore, Style, Back
import keyboard
from plyer import notification

# Initialize colorama for Windows compatibility
init()

# Type aliases
TimerConfig = Dict[str, int]
TimerStats = Dict[str, int]

class PomodoroTimer:
    """Main Pomodoro Timer class implementing the timer functionality and statistics tracking"""
    
    def __init__(self):
        """Initialize the Pomodoro Timer with default settings and load configurations"""
        # Default timer settings (in minutes)
        self.default_config: TimerConfig = {
            "work_duration": 25,
            "short_break": 5,
            "long_break": 15,
            "pomodoros_until_long_break": 4
        }
        
        # Statistics tracking
        self.stats: TimerStats = {
            "completed_pomodoros": 0,
            "completed_short_breaks": 0,
            "completed_long_breaks": 0,
            "total_work_time": 0  # in minutes
        }
        
        # File paths
        self.CONFIG_FILE = "pomodoro_config.json"
        self.STATS_FILE = "pomodoro_stats.json"
        
        # Load saved configurations and stats
        self.config = self.load_config()
        self.load_stats()
        
        # State variables
        self.running = False
        self.paused = False
        self.current_timer = None

    def load_config(self) -> TimerConfig:
        """Load timer configuration from file or create with defaults if not exists"""
        try:
            if os.path.exists(self.CONFIG_FILE):
                with open(self.CONFIG_FILE, 'r') as f:
                    return json.load(f)
        except Exception as e:
            print(f"{Fore.RED}Error loading config: {e}{Style.RESET_ALL}")
        return self.default_config.copy()

    def save_config(self) -> None:
        """Save current timer configuration to file"""
        try:
            with open(self.CONFIG_FILE, 'w') as f:
                json.dump(self.config, f, indent=4)
        except Exception as e:
            print(f"{Fore.RED}Error saving config: {e}{Style.RESET_ALL}")

    def load_stats(self) -> None:
        """Load timer statistics from file"""
        try:
            if os.path.exists(self.STATS_FILE):
                with open(self.STATS_FILE, 'r') as f:
                    self.stats = json.load(f)
        except Exception as e:
            print(f"{Fore.RED}Error loading stats: {e}{Style.RESET_ALL}")

    def save_stats(self) -> None:
        """Save current timer statistics to file"""
        try:
            with open(self.STATS_FILE, 'w') as f:
                json.dump(self.stats, f, indent=4)
        except Exception as e:
            print(f"{Fore.RED}Error saving stats: {e}{Style.RESET_ALL}")

    def format_time(self, seconds: int) -> str:
        """Convert seconds to MM:SS format
        
        Args:
            seconds (int): Number of seconds to format
            
        Returns:
            str: Formatted time string in MM:SS format
        """
        return f"{seconds // 60:02d}:{seconds % 60:02d}"

    def show_notification(self, title: str, message: str) -> None:
        """Display a system notification
        
        Args:
            title (str): Notification title
            message (str): Notification message
        """
        try:
            notification.notify(
                title=title,
                message=message,
                app_icon=None,
                timeout=10,
            )
        except Exception as e:
            print(f"{Fore.RED}Error showing notification: {e}{Style.RESET_ALL}")

    def start_timer(self, duration: int, timer_type: str) -> None:
        """Start a timer for the specified duration
        
        Args:
            duration (int): Timer duration in minutes
            timer_type (str): Type of timer (work/short break/long break)
        """
        self.running = True
        self.paused = False
        end_time = datetime.now() + timedelta(minutes=duration)
        
        print(f"\n{Fore.CYAN}Starting {timer_type} timer for {duration} minutes{Style.RESET_ALL}")
        print("Press 'p' to pause/resume, 'q' to quit")
        
        while datetime.now() < end_time and self.running:
            if not self.paused:
                remaining = (end_time - datetime.now()).total_seconds()
                if remaining <= 0:
                    break
                
                # Clear line and update timer display
                print(f"\r{Fore.GREEN}⏰ {self.format_time(int(remaining))}{Style.RESET_ALL}", end="")
                time.sleep(1)
            else:
                end_time = datetime.now() + timedelta(seconds=int((end_time - datetime.now()).total_seconds()))
                time.sleep(0.1)
        
        if self.running:
            print(f"\n\n{Fore.GREEN}✓ {timer_type.title()} session completed!{Style.RESET_ALL}")
            self.show_notification("Pomodoro Timer", f"{timer_type.title()} session completed!")
            
            # Update statistics
            if timer_type == "work":
                self.stats["completed_pomodoros"] += 1
                self.stats["total_work_time"] += duration
            elif timer_type == "short break":
                self.stats["completed_short_breaks"] += 1
            else:
                self.stats["completed_long_breaks"] += 1
            
            self.save_stats()

    def keyboard_handler(self) -> None:
        """Handle keyboard input for timer control"""
        while self.running:
            if keyboard.is_pressed('p'):
                self.paused = not self.paused
                status = "paused" if self.paused else "resumed"
                print(f"\n{Fore.YELLOW}Timer {status}{Style.RESET_ALL}")
                time.sleep(0.3)  # Prevent multiple triggers
            elif keyboard.is_pressed('q'):
                self.running = False
                print(f"\n{Fore.RED}Timer stopped{Style.RESET_ALL}")
                time.sleep(0.3)

    def show_stats(self) -> None:
        """Display current Pomodoro statistics"""
        print("\n" + "=" * 40)
        print(f"{Fore.CYAN}📊 Pomodoro Statistics{Style.RESET_ALL}")
        print("=" * 40)
        print(f"Completed Pomodoros: {self.stats['completed_pomodoros']}")
        print(f"Short Breaks Taken: {self.stats['completed_short_breaks']}")
        print(f"Long Breaks Taken: {self.stats['completed_long_breaks']}")
        print(f"Total Work Time: {self.stats['total_work_time']} minutes")
        print("=" * 40)

    def configure_timer(self) -> None:
        """Configure timer settings through user input"""
        print("\n" + "=" * 40)
        print(f"{Fore.CYAN}⚙️  Timer Configuration{Style.RESET_ALL}")
        print("=" * 40)
        
        try:
            self.config["work_duration"] = int(input(f"Work duration (current: {self.config['work_duration']} min): ") or self.config["work_duration"])
            self.config["short_break"] = int(input(f"Short break duration (current: {self.config['short_break']} min): ") or self.config["short_break"])
            self.config["long_break"] = int(input(f"Long break duration (current: {self.config['long_break']} min): ") or self.config["long_break"])
            self.config["pomodoros_until_long_break"] = int(input(f"Pomodoros until long break (current: {self.config['pomodoros_until_long_break']}): ") or self.config["pomodoros_until_long_break"])
            
            self.save_config()
            print(f"\n{Fore.GREEN}Configuration saved successfully!{Style.RESET_ALL}")
        
        except ValueError:
            print(f"\n{Fore.RED}Invalid input! Using previous configuration.{Style.RESET_ALL}")

    def run(self) -> None:
        """Main program loop"""
        while True:
            print("\n" + "=" * 40)
            print(f"{Fore.CYAN}🍅 Pomodoro Timer{Style.RESET_ALL}")
            print("=" * 40)
            print("1. Start Pomodoro")
            print("2. View Statistics")
            print("3. Configure Timer")
            print("4. Exit")
            
            choice = input(f"\n{Fore.GREEN}Choose an option (1-4): {Style.RESET_ALL}")
            
            if choice == "1":
                pomodoro_count = 0
                
                while True:
                    # Start work timer
                    keyboard_thread = threading.Thread(target=self.keyboard_handler)
                    keyboard_thread.daemon = True
                    keyboard_thread.start()
                    
                    self.start_timer(self.config["work_duration"], "work")
                    
                    if not self.running:
                        break
                    
                    pomodoro_count += 1
                    
                    # Determine break type
                    if pomodoro_count % self.config["pomodoros_until_long_break"] == 0:
                        self.start_timer(self.config["long_break"], "long break")
                    else:
                        self.start_timer(self.config["short_break"], "short break")
                    
                    if not self.running:
                        break
                    
                    # Ask to continue
                    if input(f"\n{Fore.YELLOW}Start next Pomodoro? (y/n): {Style.RESET_ALL}").lower() != 'y':
                        break
            
            elif choice == "2":
                self.show_stats()
            
            elif choice == "3":
                self.configure_timer()
            
            elif choice == "4":
                print(f"\n{Fore.YELLOW}Thank you for using Pomodoro Timer!{Style.RESET_ALL}")
                break
            
            else:
                print(f"\n{Fore.RED}Invalid choice! Please try again.{Style.RESET_ALL}")

def main():
    """Program entry point"""
    try:
        timer = PomodoroTimer()
        timer.run()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Program terminated by user. Goodbye!{Style.RESET_ALL}")
    except Exception as e:
        print(f"\n{Fore.RED}An error occurred: {str(e)}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()