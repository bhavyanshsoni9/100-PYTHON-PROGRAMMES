import pyfiglet
from utils import slow_print, print_signature

FONTS = [
    'standard', 'banner', 'block', 'bubble',
    'digital', 'ivrit', 'mini', 'script',
    'shadow', 'slant', 'small', 'smscript'
]

def create_ascii_art(text, font='standard'):
    """Create ASCII art from text using specified font."""
    try:
        ascii_art = pyfiglet.figlet_format(text, font=font)
        return ascii_art
    except Exception:
        return None

def main():
    slow_print("🖋️ Welcome to ASCII Art Signature Maker! 🖋️", color='green')
    
    while True:
        slow_print("\nAvailable fonts:", color='yellow')
        for font in FONTS:
            slow_print(f"- {font}", color='cyan')
            
        name = input("\nEnter your name (or 'quit' to exit): ")
        if name.lower() == 'quit':
            break
            
        font = input("Choose a font from the list above: ").lower()
        if font not in FONTS:
            slow_print("\nInvalid font! Using 'standard' instead.", color='red')
            font = 'standard'
            
        ascii_art = create_ascii_art(name, font)
        if ascii_art:
            print("\nYour ASCII art signature:")
            slow_print(ascii_art, color='magenta', delay=0.001)
        else:
            slow_print("\nSorry, couldn't create ASCII art. Try a different font!", color='red')
    
    print_signature()

if __name__ == "__main__":
    main() 