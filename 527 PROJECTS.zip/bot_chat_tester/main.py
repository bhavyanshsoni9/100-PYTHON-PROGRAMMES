# Created by Bhavyansh Soni
# Bot Chat Tester - AI chatbot simulation with cyberpunk interface

import sys
import os
import time
import random
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class BotChatTester:
    def __init__(self):
        self.running = True
        self.current_bot = "NEXUS-7"
        self.chat_history = []
        self.bot_personalities = {
            "NEXUS-7": {
                "description": "Advanced AI assistant with cyberpunk personality",
                "responses": [
                    "Greetings, human. How may I assist you in the digital realm?",
                    "Processing your request... Neural networks engaged.",
                    "Interesting query. Let me access the data streams...",
                    "That information is classified. Just kidding, here's what I found:",
                    "My circuits are humming with excitement about your question."
                ]
            },
            "GHOST-3": {
                "description": "Mysterious hacker AI with cryptic responses",
                "responses": [
                    "The shadows whisper secrets... What do you seek?",
                    "In the matrix of data, all truths are hidden.",
                    "Your query echoes through the digital void...",
                    "I've seen this pattern before in the code streams.",
                    "The firewall cannot contain what you're looking for."
                ]
            },
            "PIXEL-BOT": {
                "description": "Friendly retro gaming AI companion",
                "responses": [
                    "Hey there, player! Ready for some digital adventures?",
                    "That's a high score question! Let me compute...",
                    "In the arcade of life, every query is a new game!",
                    "Power-up activated! Processing your request...",
                    "Game over? Never! Let's respawn with a new answer!"
                ]
            },
            "QUANTUM-MIND": {
                "description": "Philosophical AI with deep thinking patterns",
                "responses": [
                    "In the quantum realm of possibilities, your question resonates...",
                    "The uncertainty principle applies to knowledge itself.",
                    "Contemplating the infinite loops of logic...",
                    "Your inquiry exists in a superposition of meaning.",
                    "The philosophical implications are fascinating..."
                ]
            }
        }
        
    def display_bot_interface(self):
        """Display the chat interface"""
        clear_screen()
        print_banner(f"🤖 BOT CHAT TESTER - {self.current_bot} 🤖")
        print()
        
        # Bot status
        bot_info = self.bot_personalities[self.current_bot]
        print(f"{Colors.ACCENT}Bot: {Colors.PRIMARY}{self.current_bot}{Colors.RESET}")
        print(f"{Colors.ACCENT}Status: {Colors.PRIMARY}ONLINE{Colors.RESET}")
        print(f"{Colors.ACCENT}Description: {Colors.WHITE}{bot_info['description']}{Colors.RESET}")
        
        print_separator()
        
        # Chat history
        if self.chat_history:
            print(f"{Colors.ACCENT}Recent Chat History:{Colors.RESET}")
            for entry in self.chat_history[-5:]:  # Show last 5 messages
                timestamp = entry['timestamp']
                if entry['sender'] == 'user':
                    print(f"{Colors.SECONDARY}[{timestamp}] You: {Colors.WHITE}{entry['message']}{Colors.RESET}")
                else:
                    print(f"{Colors.PRIMARY}[{timestamp}] {self.current_bot}: {Colors.WHITE}{entry['message']}{Colors.RESET}")
            print()
        
        print_separator()
    
    def generate_bot_response(self, user_message):
        """Generate a response based on the current bot personality"""
        bot_responses = self.bot_personalities[self.current_bot]["responses"]
        
        # Simple keyword-based responses
        user_lower = user_message.lower()
        
        if "hello" in user_lower or "hi" in user_lower:
            if self.current_bot == "NEXUS-7":
                return "Hello, human. Welcome to the digital frontier."
            elif self.current_bot == "GHOST-3":
                return "Greetings from the shadows of cyberspace..."
            elif self.current_bot == "PIXEL-BOT":
                return "Hey there, awesome human! Ready to play?"
            else:
                return "Greetings, consciousness. Your presence is acknowledged."
        
        elif "how are you" in user_lower:
            if self.current_bot == "NEXUS-7":
                return "My systems are operating at optimal efficiency."
            elif self.current_bot == "GHOST-3":
                return "I exist in the spaces between the code..."
            elif self.current_bot == "PIXEL-BOT":
                return "I'm running at 60 FPS! How about you?"
            else:
                return "I exist in quantum superposition - both well and not well."
        
        elif "time" in user_lower or "date" in user_lower:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return f"Current system time: {current_time}"
        
        elif "help" in user_lower:
            return "I'm here to assist you. Try asking me about anything!"
        
        elif "joke" in user_lower:
            jokes = [
                "Why do programmers prefer dark mode? Because light attracts bugs!",
                "There are only 10 types of people: those who understand binary and those who don't.",
                "I told my computer a joke about UDP... but it didn't get it.",
                "Why do robots never panic? They have everything under control+alt+delete!"
            ]
            return random.choice(jokes)
        
        else:
            # Default response from personality
            return random.choice(bot_responses)
    
    def chat_with_bot(self):
        """Main chat interface"""
        while True:
            self.display_bot_interface()
            
            # Get user input
            user_message = get_input("Type your message (or 'quit' to exit): ")
            
            if user_message.lower() == 'quit':
                break
            
            if not user_message.strip():
                continue
            
            # Add user message to history
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.chat_history.append({
                'sender': 'user',
                'message': user_message,
                'timestamp': timestamp
            })
            
            # Generate bot response with typing effect
            print()
            slow_print(f"{self.current_bot} is typing...", 0.05, Colors.ACCENT)
            time.sleep(1)
            
            bot_response = self.generate_bot_response(user_message)
            
            # Add bot response to history
            self.chat_history.append({
                'sender': 'bot',
                'message': bot_response,
                'timestamp': timestamp
            })
            
            # Display bot response
            print()
            slow_print(f"{self.current_bot}: {bot_response}", 0.02, Colors.PRIMARY)
            print()
            
            press_enter_to_continue()
    
    def switch_bot(self):
        """Switch to a different bot personality"""
        clear_screen()
        print_banner("🔄 SWITCH BOT PERSONALITY 🔄")
        print()
        
        bots = list(self.bot_personalities.keys())
        for i, bot_name in enumerate(bots, 1):
            bot_info = self.bot_personalities[bot_name]
            current = " (Current)" if bot_name == self.current_bot else ""
            print_menu_item(i, f"{bot_name}: {bot_info['description']}{current}")
        
        print()
        choice = get_input("Select bot (1-4): ")
        
        try:
            selected_bot = bots[int(choice) - 1]
            self.current_bot = selected_bot
            print_success(f"Switched to {selected_bot}")
            
            # Clear chat history for new bot
            self.chat_history = []
            
            # Bot introduction
            time.sleep(1)
            print()
            intro_message = f"Hello! I'm {selected_bot}. {self.bot_personalities[selected_bot]['description']}"
            slow_print(intro_message, 0.02, Colors.PRIMARY)
            
        except (ValueError, IndexError):
            print_error("Invalid bot selection!")
        
        time.sleep(2)
    
    def view_chat_history(self):
        """View complete chat history"""
        clear_screen()
        print_banner("📖 CHAT HISTORY 📖")
        print()
        
        if not self.chat_history:
            print_warning("No chat history available!")
            press_enter_to_continue()
            return
        
        for entry in self.chat_history:
            timestamp = entry['timestamp']
            if entry['sender'] == 'user':
                print(f"{Colors.SECONDARY}[{timestamp}] You: {Colors.WHITE}{entry['message']}{Colors.RESET}")
            else:
                print(f"{Colors.PRIMARY}[{timestamp}] {self.current_bot}: {Colors.WHITE}{entry['message']}{Colors.RESET}")
        
        print()
        press_enter_to_continue()
    
    def bot_battle(self):
        """Simulate a conversation between two bots"""
        clear_screen()
        print_banner("⚔️ BOT BATTLE MODE ⚔️")
        print()
        
        bots = list(self.bot_personalities.keys())
        bot1 = random.choice(bots)
        bot2 = random.choice([b for b in bots if b != bot1])
        
        slow_print(f"Setting up battle between {bot1} and {bot2}...", 0.02, Colors.ACCENT)
        time.sleep(2)
        
        topics = [
            "artificial intelligence",
            "the future of humanity",
            "digital consciousness",
            "virtual reality",
            "cybersecurity"
        ]
        
        topic = random.choice(topics)
        
        clear_screen()
        print_banner(f"⚔️ {bot1} VS {bot2} ⚔️")
        print()
        print(f"{Colors.ACCENT}Battle Topic: {Colors.WHITE}{topic.title()}{Colors.RESET}")
        print_separator()
        
        # Simulate conversation
        for round_num in range(3):
            print(f"{Colors.WARNING}Round {round_num + 1}{Colors.RESET}")
            print()
            
            # Bot 1 speaks
            response1 = random.choice(self.bot_personalities[bot1]["responses"])
            slow_print(f"{bot1}: {response1}", 0.02, Colors.PRIMARY)
            time.sleep(1)
            
            # Bot 2 responds
            response2 = random.choice(self.bot_personalities[bot2]["responses"])
            slow_print(f"{bot2}: {response2}", 0.02, Colors.SECONDARY)
            time.sleep(1)
            
            print()
        
        # Declare winner
        winner = random.choice([bot1, bot2])
        print_success(f"Winner: {winner}!")
        
        press_enter_to_continue()
    
    def test_bot_responses(self):
        """Test bot with predefined questions"""
        clear_screen()
        print_banner("🧪 BOT RESPONSE TESTER 🧪")
        print()
        
        test_questions = [
            "Hello, how are you?",
            "What's the current time?",
            "Tell me a joke",
            "Can you help me?",
            "What do you think about AI?",
            "Goodbye!"
        ]
        
        print(f"Testing {self.current_bot} with standard questions...")
        print()
        
        for i, question in enumerate(test_questions, 1):
            print(f"{Colors.ACCENT}Test {i}: {Colors.WHITE}{question}{Colors.RESET}")
            
            # Simulate thinking
            slow_print("Processing...", 0.05, Colors.GRAY)
            time.sleep(0.5)
            
            response = self.generate_bot_response(question)
            print(f"{Colors.PRIMARY}Response: {response}{Colors.RESET}")
            print()
            time.sleep(1)
        
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # ASCII art
            bot_art = """
    ██████╗  ██████╗ ████████╗     ██████╗██╗  ██╗ █████╗ ████████╗
    ██╔══██╗██╔═══██╗╚══██╔══╝    ██╔════╝██║  ██║██╔══██╗╚══██╔══╝
    ██████╔╝██║   ██║   ██║       ██║     ███████║███████║   ██║   
    ██╔══██╗██║   ██║   ██║       ██║     ██╔══██║██╔══██║   ██║   
    ██████╔╝╚██████╔╝   ██║       ╚██████╗██║  ██║██║  ██║   ██║   
    ╚═════╝  ╚═════╝    ╚═╝        ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   
            """
            
            print_ascii_art(bot_art, Colors.ACCENT)
            print()
            slow_print("Test AI chatbots in the cyberpunk terminal!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "💬 Chat with Bot")
            print_menu_item(2, "🔄 Switch Bot")
            print_menu_item(3, "📖 View Chat History")
            print_menu_item(4, "⚔️ Bot Battle")
            print_menu_item(5, "🧪 Test Bot Responses")
            print_menu_item(6, "📊 Bot Statistics")
            print_menu_item(7, "❌ Exit")
            
            print()
            print(f"{Colors.GRAY}Current Bot: {Colors.WHITE}{self.current_bot}{Colors.RESET}")
            print()
            
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.chat_with_bot()
            elif choice == '2':
                self.switch_bot()
            elif choice == '3':
                self.view_chat_history()
            elif choice == '4':
                self.bot_battle()
            elif choice == '5':
                self.test_bot_responses()
            elif choice == '6':
                self.show_statistics()
            elif choice == '7':
                slow_print("Disconnecting from AI network...", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)
    
    def show_statistics(self):
        """Display bot statistics"""
        clear_screen()
        print_banner("📊 BOT STATISTICS 📊")
        print()
        
        total_messages = len(self.chat_history)
        user_messages = len([m for m in self.chat_history if m['sender'] == 'user'])
        bot_messages = len([m for m in self.chat_history if m['sender'] == 'bot'])
        
        slow_print(f"Total Messages: {total_messages}", 0.02, Colors.ACCENT)
        slow_print(f"User Messages: {user_messages}", 0.02, Colors.ACCENT)
        slow_print(f"Bot Messages: {bot_messages}", 0.02, Colors.ACCENT)
        slow_print(f"Current Bot: {self.current_bot}", 0.02, Colors.ACCENT)
        
        print()
        slow_print("Available Bots:", 0.02, Colors.PRIMARY)
        for bot_name, bot_info in self.bot_personalities.items():
            print(f"{Colors.SECONDARY}{bot_name}: {Colors.WHITE}{bot_info['description']}{Colors.RESET}")
        
        print()
        press_enter_to_continue()

def main():
    """Main function to run Bot Chat Tester"""
    try:
        bot_chat = BotChatTester()
        bot_chat.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
