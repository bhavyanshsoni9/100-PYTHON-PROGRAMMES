# Created by Bhavyansh Soni
# Brain Teaser - A collection of mind-bending puzzles and riddles

import sys
import os
import time
import random
import json
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class BrainTeaser:
    def __init__(self):
        self.running = True
        self.score = 0
        self.total_questions = 0
        self.current_category = None
        
        # Brain teasers database
        self.teasers = {
            "logic": [
                {
                    "question": "I have cities, but no houses. I have mountains, but no trees. I have water, but no fish. What am I?",
                    "answer": "map",
                    "hint": "You might use me to navigate"
                },
                {
                    "question": "What gets wetter the more it dries?",
                    "answer": "towel",
                    "hint": "You use it after a shower"
                },
                {
                    "question": "I'm tall when I'm young and short when I'm old. What am I?",
                    "answer": "candle",
                    "hint": "I give light and melt away"
                }
            ],
            "math": [
                {
                    "question": "If you multiply me by any number, the result will always be the same. What number am I?",
                    "answer": "0",
                    "hint": "Think about multiplication properties"
                },
                {
                    "question": "I am an odd number. Take away one letter and I become even. What am I?",
                    "answer": "seven",
                    "hint": "Remove the 's' from my name"
                },
                {
                    "question": "What comes next in this sequence: 1, 1, 2, 3, 5, 8, 13, ?",
                    "answer": "21",
                    "hint": "Each number is the sum of the previous two"
                }
            ],
            "wordplay": [
                {
                    "question": "What word becomes shorter when you add two letters to it?",
                    "answer": "short",
                    "hint": "Add 'er' to the end"
                },
                {
                    "question": "I'm a 5-letter word. If you remove my first letter, I'm a crime. Remove my first two letters, I'm an animal. What am I?",
                    "answer": "grape",
                    "hint": "Crime = rape, Animal = ape"
                },
                {
                    "question": "What word is spelled incorrectly in every dictionary?",
                    "answer": "incorrectly",
                    "hint": "The word itself"
                }
            ]
        }
    
    def display_brain_animation(self):
        """Display animated brain ASCII art"""
        brain_frames = [
            """
    ⠀⠀⠀⠀⠀⢀⣠⠤⠖⠚⠛⠉⠉⠉⠉⠛⠓⠦⢤⡀⠀⠀⠀⠀⠀
    ⠀⠀⠀⢀⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⡄⠀⠀⠀
    ⠀⠀⢠⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢧⠀⠀
    ⠀⢠⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡆⠀
    ⠀⡞⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀
    ⢰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀
    ⠸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡜⠀
    ⠀⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼⠀⠀
    ⠀⠀⠳⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠀⠀⠀
    ⠀⠀⠀⠀⠉⠲⠤⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⡠⠤⠒⠉⠀⠀⠀⠀
            """,
            """
    ⠀⠀⠀⠀⠀⢀⣠⠤⠖⠚⠛⠉⠉⠉⠉⠛⠓⠦⢤⡀⠀⠀⠀⠀⠀
    ⠀⠀⠀⢀⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⡄⠀⠀⠀
    ⠀⠀⢠⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢧⠀⠀
    ⠀⢠⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⡆⠀
    ⠀⡞⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀
    ⢰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀
    ⠸⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡜⠀
    ⠀⢳⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼⠀⠀
    ⠀⠀⠳⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠀⠀⠀
    ⠀⠀⠀⠀⠉⠲⠤⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⡠⠤⠒⠉⠀⠀⠀⠀
            """
        ]
        
        for frame in brain_frames:
            clear_screen()
            print_ascii_art(frame, Colors.ACCENT)
            time.sleep(0.5)
    
    def ask_question(self, category):
        """Ask a random question from the specified category"""
        if category not in self.teasers:
            print_error("Invalid category!")
            return False
        
        question_data = random.choice(self.teasers[category])
        question = question_data["question"]
        correct_answer = question_data["answer"].lower()
        hint = question_data["hint"]
        
        print_banner(f"🧠 {category.upper()} BRAIN TEASER 🧠")
        print()
        slow_print(question, 0.02, Colors.PRIMARY)
        print()
        
        attempts = 3
        while attempts > 0:
            user_answer = get_input(f"Your answer ({attempts} attempts left): ").lower().strip()
            
            if user_answer == correct_answer:
                print_success("Correct! Well done!")
                self.score += 1
                return True
            else:
                attempts -= 1
                if attempts > 0:
                    print_error("Incorrect! Try again.")
                    if attempts == 1:
                        print_warning(f"Hint: {hint}")
                else:
                    print_error(f"Sorry! The correct answer was: {correct_answer}")
                    return False
        
        return False
    
    def quiz_mode(self):
        """Run a quiz with multiple questions"""
        clear_screen()
        print_banner("🧠 BRAIN TEASER QUIZ MODE 🧠")
        print()
        
        categories = list(self.teasers.keys())
        slow_print("Available categories:", 0.02, Colors.ACCENT)
        for i, category in enumerate(categories, 1):
            print_menu_item(i, category.title())
        
        print()
        choice = get_input("Select category (1-3) or 'all' for mixed: ").lower()
        
        if choice in ['1', '2', '3']:
            selected_category = categories[int(choice) - 1]
            questions_pool = self.teasers[selected_category]
        elif choice == 'all':
            questions_pool = []
            for category in self.teasers.values():
                questions_pool.extend(category)
            selected_category = "mixed"
        else:
            print_error("Invalid choice!")
            return
        
        num_questions = min(5, len(questions_pool))
        selected_questions = random.sample(questions_pool, num_questions)
        
        self.score = 0
        self.total_questions = num_questions
        
        for i, question_data in enumerate(selected_questions, 1):
            clear_screen()
            print(f"{Colors.ACCENT}Question {i}/{num_questions}{Colors.RESET}")
            print_separator()
            
            slow_print(question_data["question"], 0.02, Colors.PRIMARY)
            print()
            
            attempts = 3
            while attempts > 0:
                user_answer = get_input(f"Your answer ({attempts} attempts left): ").lower().strip()
                
                if user_answer == question_data["answer"].lower():
                    print_success("Correct! Well done!")
                    self.score += 1
                    break
                else:
                    attempts -= 1
                    if attempts > 0:
                        print_error("Incorrect! Try again.")
                        if attempts == 1:
                            print_warning(f"Hint: {question_data['hint']}")
                    else:
                        print_error(f"Sorry! The correct answer was: {question_data['answer']}")
            
            if i < num_questions:
                press_enter_to_continue()
        
        # Show final score
        self.show_quiz_results()
    
    def show_quiz_results(self):
        """Display quiz results with animations"""
        clear_screen()
        print_banner("🧠 QUIZ RESULTS 🧠")
        print()
        
        percentage = (self.score / self.total_questions) * 100
        
        slow_print(f"Final Score: {self.score}/{self.total_questions}", 0.02, Colors.ACCENT)
        slow_print(f"Percentage: {percentage:.1f}%", 0.02, Colors.ACCENT)
        print()
        
        if percentage >= 80:
            slow_print("🎉 EXCELLENT! You're a brain teaser master!", 0.02, Colors.PRIMARY)
        elif percentage >= 60:
            slow_print("👍 GOOD JOB! You've got a sharp mind!", 0.02, Colors.WARNING)
        elif percentage >= 40:
            slow_print("🤔 NOT BAD! Keep practicing!", 0.02, Colors.SECONDARY)
        else:
            slow_print("💪 KEEP TRYING! Everyone starts somewhere!", 0.02, Colors.ERROR)
        
        print()
        press_enter_to_continue()
    
    def random_teaser(self):
        """Show a random brain teaser"""
        clear_screen()
        category = random.choice(list(self.teasers.keys()))
        self.ask_question(category)
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            self.display_brain_animation()
            
            print_banner("🧠 BRAIN TEASER COLLECTION 🧠")
            print()
            slow_print("Exercise your mind with challenging puzzles!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🎯 Quiz Mode")
            print_menu_item(2, "🎲 Random Teaser")
            print_menu_item(3, "📚 Browse Categories")
            print_menu_item(4, "📊 Statistics")
            print_menu_item(5, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-5): ")
            
            if choice == '1':
                self.quiz_mode()
            elif choice == '2':
                self.random_teaser()
            elif choice == '3':
                self.browse_categories()
            elif choice == '4':
                self.show_statistics()
            elif choice == '5':
                slow_print("Thanks for exercising your brain!", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-5.")
                time.sleep(1)
    
    def browse_categories(self):
        """Browse questions by category"""
        clear_screen()
        print_banner("📚 BROWSE CATEGORIES 📚")
        print()
        
        categories = list(self.teasers.keys())
        for i, category in enumerate(categories, 1):
            count = len(self.teasers[category])
            print_menu_item(i, f"{category.title()} ({count} questions)")
        
        print()
        choice = get_input("Select category (1-3): ")
        
        if choice in ['1', '2', '3']:
            selected_category = categories[int(choice) - 1]
            self.ask_question(selected_category)
        else:
            print_error("Invalid choice!")
        
        press_enter_to_continue()
    
    def show_statistics(self):
        """Show game statistics"""
        clear_screen()
        print_banner("📊 STATISTICS 📊")
        print()
        
        total_questions = sum(len(questions) for questions in self.teasers.values())
        
        slow_print(f"Total Available Questions: {total_questions}", 0.02, Colors.ACCENT)
        slow_print(f"Categories: {len(self.teasers)}", 0.02, Colors.ACCENT)
        print()
        
        for category, questions in self.teasers.items():
            slow_print(f"{category.title()}: {len(questions)} questions", 0.02, Colors.PRIMARY)
        
        print()
        press_enter_to_continue()

def main():
    """Main function to run Brain Teaser"""
    try:
        brain_teaser = BrainTeaser()
        brain_teaser.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
