# Created by Bhavyansh Soni
# Color Splash - Advanced color palette generator and viewer with cyberpunk aesthetics

import sys
import os
import time
import random
import colorsys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class ColorSplash:
    def __init__(self):
        self.running = True
        self.saved_palettes = []
        self.color_history = []
        
        # Predefined color schemes
        self.color_schemes = {
            "cyberpunk": {
                "colors": ["#00FF41", "#FF6B35", "#00D4FF", "#FFD23F", "#FF073A"],
                "description": "Matrix-inspired neon colors"
            },
            "neon_night": {
                "colors": ["#FF00FF", "#00FFFF", "#FFFF00", "#FF4500", "#9400D3"],
                "description": "Vibrant neon street colors"
            },
            "ocean_deep": {
                "colors": ["#003366", "#0066CC", "#3399FF", "#66CCFF", "#99E6FF"],
                "description": "Deep ocean blue tones"
            },
            "sunset_fire": {
                "colors": ["#FF4500", "#FF6347", "#FF7F50", "#FFA500", "#FFD700"],
                "description": "Warm sunset and fire colors"
            },
            "forest_tech": {
                "colors": ["#228B22", "#32CD32", "#90EE90", "#ADFF2F", "#7FFF00"],
                "description": "Technology meets nature"
            }
        }
    
    def hex_to_rgb(self, hex_color):
        """Convert hex color to RGB"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def rgb_to_hex(self, rgb):
        """Convert RGB to hex"""
        return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"
    
    def display_color_block(self, hex_color, width=20):
        """Display a color block using ANSI codes"""
        r, g, b = self.hex_to_rgb(hex_color)
        # Create colored block using ANSI escape codes
        color_code = f"\033[48;2;{r};{g};{b}m"
        reset_code = "\033[0m"
        return f"{color_code}{' ' * width}{reset_code}"
    
    def generate_random_palette(self):
        """Generate a random color palette"""
        clear_screen()
        print_banner("🎨 RANDOM COLOR PALETTE 🎨")
        print()
        
        slow_print("Generating random color harmony...", 0.02, Colors.ACCENT)
        animate_loading("Creating palette", 2)
        
        # Generate base color
        base_hue = random.random()
        saturation = random.uniform(0.7, 1.0)
        value = random.uniform(0.8, 1.0)
        
        # Generate color harmony
        harmony_type = random.choice(["monochromatic", "analogous", "complementary", "triadic", "tetradic"])
        
        colors = []
        
        if harmony_type == "monochromatic":
            for i in range(5):
                sat = saturation * (0.6 + i * 0.1)
                val = value * (0.7 + i * 0.06)
                rgb = colorsys.hsv_to_rgb(base_hue, sat, val)
                hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
                colors.append(hex_color)
        
        elif harmony_type == "analogous":
            for i in range(5):
                hue = (base_hue + i * 0.08) % 1.0
                rgb = colorsys.hsv_to_rgb(hue, saturation, value)
                hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
                colors.append(hex_color)
        
        elif harmony_type == "complementary":
            colors.append(self.rgb_to_hex(tuple(int(c * 255) for c in colorsys.hsv_to_rgb(base_hue, saturation, value))))
            colors.append(self.rgb_to_hex(tuple(int(c * 255) for c in colorsys.hsv_to_rgb((base_hue + 0.5) % 1.0, saturation, value))))
            # Add variations
            for i in range(3):
                hue = base_hue + random.uniform(-0.1, 0.1)
                rgb = colorsys.hsv_to_rgb(hue % 1.0, saturation * 0.8, value * 0.9)
                hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
                colors.append(hex_color)
        
        elif harmony_type == "triadic":
            for i in range(3):
                hue = (base_hue + i * 0.333) % 1.0
                rgb = colorsys.hsv_to_rgb(hue, saturation, value)
                hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
                colors.append(hex_color)
            # Add two more variations
            for i in range(2):
                hue = base_hue + random.uniform(-0.05, 0.05)
                rgb = colorsys.hsv_to_rgb(hue % 1.0, saturation * 0.9, value * 0.8)
                hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
                colors.append(hex_color)
        
        else:  # tetradic
            for i in range(4):
                hue = (base_hue + i * 0.25) % 1.0
                rgb = colorsys.hsv_to_rgb(hue, saturation, value)
                hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
                colors.append(hex_color)
            # Add one more
            hue = base_hue + 0.1
            rgb = colorsys.hsv_to_rgb(hue % 1.0, saturation, value)
            hex_color = self.rgb_to_hex(tuple(int(c * 255) for c in rgb))
            colors.append(hex_color)
        
        self.display_palette(colors, harmony_type)
        
        # Save to history
        palette = {
            "colors": colors,
            "type": harmony_type,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        self.color_history.append(palette)
        
        print()
        save_choice = get_input("Save this palette? (y/N): ").lower()
        if save_choice == 'y':
            name = get_input("Enter palette name: ")
            if name:
                palette["name"] = name
                self.saved_palettes.append(palette)
                print_success("Palette saved!")
        
        press_enter_to_continue()
    
    def display_palette(self, colors, harmony_type=None):
        """Display a color palette"""
        clear_screen()
        if harmony_type:
            print_banner(f"🎨 {harmony_type.upper()} PALETTE 🎨")
        else:
            print_banner("🎨 COLOR PALETTE 🎨")
        print()
        
        # Display color blocks
        for i, color in enumerate(colors, 1):
            color_block = self.display_color_block(color)
            r, g, b = self.hex_to_rgb(color)
            
            print(f"{Colors.ACCENT}{i}. {color_block} {Colors.WHITE}{color.upper()}{Colors.RESET}")
            print(f"   RGB: ({r}, {g}, {b})")
            print(f"   HSV: {self.rgb_to_hsv(r, g, b)}")
            print()
    
    def rgb_to_hsv(self, r, g, b):
        """Convert RGB to HSV for display"""
        h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        return f"({h*360:.0f}°, {s*100:.0f}%, {v*100:.0f}%)"
    
    def browse_color_schemes(self):
        """Browse predefined color schemes"""
        clear_screen()
        print_banner("🌈 COLOR SCHEMES 🌈")
        print()
        
        schemes = list(self.color_schemes.keys())
        for i, scheme_name in enumerate(schemes, 1):
            scheme = self.color_schemes[scheme_name]
            print_menu_item(i, f"{scheme_name.title()}: {scheme['description']}")
        
        print()
        choice = get_input(f"Select scheme (1-{len(schemes)}): ")
        
        try:
            scheme_name = schemes[int(choice) - 1]
            scheme = self.color_schemes[scheme_name]
            self.display_palette(scheme["colors"])
            
            print()
            print(f"{Colors.ACCENT}Description: {Colors.WHITE}{scheme['description']}{Colors.RESET}")
            
            print()
            save_choice = get_input("Save this scheme? (y/N): ").lower()
            if save_choice == 'y':
                palette = {
                    "name": scheme_name,
                    "colors": scheme["colors"],
                    "type": "predefined",
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                }
                self.saved_palettes.append(palette)
                print_success("Scheme saved!")
            
        except (ValueError, IndexError):
            print_error("Invalid scheme selection!")
        
        press_enter_to_continue()
    
    def color_mixer(self):
        """Interactive color mixing tool"""
        clear_screen()
        print_banner("🧪 COLOR MIXER 🧪")
        print()
        
        slow_print("Mix colors to create new shades!", 0.02, Colors.ACCENT)
        print()
        
        # Get first color
        color1 = get_input("Enter first color (hex, e.g., #FF0000): ").strip()
        if not color1.startswith('#') or len(color1) != 7:
            print_error("Invalid hex color format!")
            time.sleep(1)
            return
        
        color2 = get_input("Enter second color (hex, e.g., #0000FF): ").strip()
        if not color2.startswith('#') or len(color2) != 7:
            print_error("Invalid hex color format!")
            time.sleep(1)
            return
        
        print()
        print("Mixing ratios:")
        ratios = [0.1, 0.25, 0.5, 0.75, 0.9]
        
        try:
            r1, g1, b1 = self.hex_to_rgb(color1)
            r2, g2, b2 = self.hex_to_rgb(color2)
            
            mixed_colors = []
            
            for ratio in ratios:
                # Mix colors
                r_mix = int(r1 * (1 - ratio) + r2 * ratio)
                g_mix = int(g1 * (1 - ratio) + g2 * ratio)
                b_mix = int(b1 * (1 - ratio) + b2 * ratio)
                
                mixed_color = self.rgb_to_hex((r_mix, g_mix, b_mix))
                mixed_colors.append(mixed_color)
            
            # Display original colors
            print(f"{Colors.ACCENT}Color 1: {self.display_color_block(color1)} {color1.upper()}{Colors.RESET}")
            print(f"{Colors.ACCENT}Color 2: {self.display_color_block(color2)} {color2.upper()}{Colors.RESET}")
            print()
            
            # Display mixed results
            print("Mixed Results:")
            for i, (ratio, mixed_color) in enumerate(zip(ratios, mixed_colors)):
                percentage = int(ratio * 100)
                print(f"{percentage:2d}% Mix: {self.display_color_block(mixed_color)} {mixed_color.upper()}")
            
        except ValueError:
            print_error("Invalid color values!")
        
        press_enter_to_continue()
    
    def color_analyzer(self):
        """Analyze color properties"""
        clear_screen()
        print_banner("🔬 COLOR ANALYZER 🔬")
        print()
        
        color = get_input("Enter color to analyze (hex, e.g., #FF5733): ").strip()
        if not color.startswith('#') or len(color) != 7:
            print_error("Invalid hex color format!")
            time.sleep(1)
            return
        
        try:
            r, g, b = self.hex_to_rgb(color)
            h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
            
            clear_screen()
            print_banner(f"🔬 ANALYZING {color.upper()} 🔬")
            print()
            
            # Display color
            color_block = self.display_color_block(color, 40)
            print(f"{color_block}")
            print()
            
            # Color information
            print(f"{Colors.ACCENT}Hex: {Colors.WHITE}{color.upper()}{Colors.RESET}")
            print(f"{Colors.ACCENT}RGB: {Colors.WHITE}({r}, {g}, {b}){Colors.RESET}")
            print(f"{Colors.ACCENT}HSV: {Colors.WHITE}({h*360:.0f}°, {s*100:.0f}%, {v*100:.0f}%){Colors.RESET}")
            
            print()
            
            # Color properties
            brightness = (r + g + b) / 3
            print(f"{Colors.ACCENT}Brightness: {Colors.WHITE}{brightness:.1f}/255{Colors.RESET}")
            
            if brightness > 128:
                print(f"{Colors.ACCENT}Category: {Colors.WHITE}Light color{Colors.RESET}")
                print(f"{Colors.ACCENT}Text Color: {Colors.WHITE}Use dark text{Colors.RESET}")
            else:
                print(f"{Colors.ACCENT}Category: {Colors.WHITE}Dark color{Colors.RESET}")
                print(f"{Colors.ACCENT}Text Color: {Colors.WHITE}Use light text{Colors.RESET}")
            
            # Dominant channel
            channels = [('Red', r), ('Green', g), ('Blue', b)]
            dominant = max(channels, key=lambda x: x[1])
            print(f"{Colors.ACCENT}Dominant: {Colors.WHITE}{dominant[0]} ({dominant[1]}){Colors.RESET}")
            
            # Generate complementary color
            comp_h = (h + 0.5) % 1.0
            comp_rgb = colorsys.hsv_to_rgb(comp_h, s, v)
            comp_hex = self.rgb_to_hex(tuple(int(c * 255) for c in comp_rgb))
            
            print()
            print(f"{Colors.ACCENT}Complementary: {self.display_color_block(comp_hex)} {comp_hex.upper()}{Colors.RESET}")
            
        except ValueError:
            print_error("Invalid color value!")
        
        press_enter_to_continue()
    
    def view_saved_palettes(self):
        """View saved color palettes"""
        clear_screen()
        print_banner("💾 SAVED PALETTES 💾")
        print()
        
        if not self.saved_palettes:
            print_warning("No saved palettes!")
            press_enter_to_continue()
            return
        
        for i, palette in enumerate(self.saved_palettes, 1):
            name = palette.get("name", f"Palette {i}")
            palette_type = palette.get("type", "custom")
            timestamp = palette.get("timestamp", "Unknown")
            
            print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{name}{Colors.RESET}")
            print(f"     Type: {palette_type.title()} | Created: {timestamp}")
            
            # Show color preview
            preview = ""
            for color in palette["colors"][:5]:  # Show first 5 colors
                preview += self.display_color_block(color, 5)
            print(f"     {preview}")
            print()
        
        choice = get_input("Enter palette number to view details (or press Enter to return): ")
        
        if choice.isdigit():
            try:
                palette_index = int(choice) - 1
                if 0 <= palette_index < len(self.saved_palettes):
                    palette = self.saved_palettes[palette_index]
                    self.display_palette(palette["colors"])
                    press_enter_to_continue()
            except ValueError:
                pass
    
    def gradient_generator(self):
        """Generate color gradients"""
        clear_screen()
        print_banner("🌈 GRADIENT GENERATOR 🌈")
        print()
        
        start_color = get_input("Enter start color (hex, e.g., #FF0000): ").strip()
        if not start_color.startswith('#') or len(start_color) != 7:
            print_error("Invalid start color format!")
            time.sleep(1)
            return
        
        end_color = get_input("Enter end color (hex, e.g., #0000FF): ").strip()
        if not end_color.startswith('#') or len(end_color) != 7:
            print_error("Invalid end color format!")
            time.sleep(1)
            return
        
        try:
            steps = int(get_input("Number of steps (5-20): "))
            if steps < 5 or steps > 20:
                print_error("Steps must be between 5 and 20!")
                time.sleep(1)
                return
        except ValueError:
            print_error("Invalid number of steps!")
            time.sleep(1)
            return
        
        try:
            r1, g1, b1 = self.hex_to_rgb(start_color)
            r2, g2, b2 = self.hex_to_rgb(end_color)
            
            clear_screen()
            print_banner("🌈 COLOR GRADIENT 🌈")
            print()
            
            gradient_colors = []
            
            for i in range(steps):
                ratio = i / (steps - 1)
                
                r = int(r1 + (r2 - r1) * ratio)
                g = int(g1 + (g2 - g1) * ratio)
                b = int(b1 + (b2 - b1) * ratio)
                
                gradient_color = self.rgb_to_hex((r, g, b))
                gradient_colors.append(gradient_color)
                
                step_block = self.display_color_block(gradient_color, 30)
                print(f"Step {i+1:2d}: {step_block} {gradient_color.upper()}")
            
            print()
            save_choice = get_input("Save this gradient as palette? (y/N): ").lower()
            if save_choice == 'y':
                name = get_input("Enter gradient name: ")
                if name:
                    palette = {
                        "name": name,
                        "colors": gradient_colors,
                        "type": "gradient",
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                    }
                    self.saved_palettes.append(palette)
                    print_success("Gradient saved as palette!")
            
        except ValueError:
            print_error("Invalid color values!")
        
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Color splash ASCII art
            splash_art = """
     ██████╗ ██████╗ ██╗      ██████╗ ██████╗     ███████╗██████╗ ██╗      █████╗ ███████╗██╗  ██╗
    ██╔════╝██╔═══██╗██║     ██╔═══██╗██╔══██╗    ██╔════╝██╔══██╗██║     ██╔══██╗██╔════╝██║  ██║
    ██║     ██║   ██║██║     ██║   ██║██████╔╝    ███████╗██████╔╝██║     ███████║███████╗███████║
    ██║     ██║   ██║██║     ██║   ██║██╔══██╗    ╚════██║██╔═══╝ ██║     ██╔══██║╚════██║██╔══██║
    ╚██████╗╚██████╔╝███████╗╚██████╔╝██║  ██║    ███████║██║     ███████╗██║  ██║███████║██║  ██║
     ╚═════╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚═╝  ╚═╝    ╚══════╝╚═╝     ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
            """
            
            print_ascii_art(splash_art, Colors.ACCENT)
            print()
            slow_print("Create stunning color palettes in the digital realm!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🎨 Generate Random Palette")
            print_menu_item(2, "🌈 Browse Color Schemes")
            print_menu_item(3, "🧪 Color Mixer")
            print_menu_item(4, "🔬 Color Analyzer")
            print_menu_item(5, "🌈 Gradient Generator")
            print_menu_item(6, "💾 View Saved Palettes")
            print_menu_item(7, "📊 Color Statistics")
            print_menu_item(8, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-8): ")
            
            if choice == '1':
                self.generate_random_palette()
            elif choice == '2':
                self.browse_color_schemes()
            elif choice == '3':
                self.color_mixer()
            elif choice == '4':
                self.color_analyzer()
            elif choice == '5':
                self.gradient_generator()
            elif choice == '6':
                self.view_saved_palettes()
            elif choice == '7':
                self.show_statistics()
            elif choice == '8':
                slow_print("Keep creating beautiful colors! 🎨", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-8.")
                time.sleep(1)
    
    def show_statistics(self):
        """Show color palette statistics"""
        clear_screen()
        print_banner("📊 COLOR STATISTICS 📊")
        print()
        
        total_palettes = len(self.saved_palettes)
        total_history = len(self.color_history)
        
        slow_print(f"Saved Palettes: {total_palettes}", 0.02, Colors.ACCENT)
        slow_print(f"Generated Palettes: {total_history}", 0.02, Colors.ACCENT)
        
        if self.saved_palettes:
            # Palette type distribution
            type_counts = {}
            for palette in self.saved_palettes:
                palette_type = palette.get("type", "custom")
                type_counts[palette_type] = type_counts.get(palette_type, 0) + 1
            
            print()
            slow_print("Palette Types:", 0.02, Colors.PRIMARY)
            for palette_type, count in type_counts.items():
                print(f"{Colors.SECONDARY}{palette_type.title()}: {Colors.WHITE}{count}{Colors.RESET}")
        
        press_enter_to_continue()

def main():
    """Main function to run Color Splash"""
    try:
        color_splash = ColorSplash()
        color_splash.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
