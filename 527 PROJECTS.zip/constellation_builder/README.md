# ⭐ Constellation Builder

**Created by Bhavyansh Soni**

## Description
A mystical celestial puzzle game where players become cosmic architects, connecting stars to form legendary constellations. Each pattern unlocks ancient powers and reveals forgotten stories written in the night sky. Master the art of stellar weaving to build your cosmic legend!

## Gameplay Features
- ⭐ **10 Legendary Constellations**: Each with unique patterns and mythical powers
- 🌌 **Interactive Star Field**: Connect stars by coordinates to form patterns
- ⚡ **Cosmic Energy System**: Manage your stellar power wisely
- 📜 **Ancient Lore**: Unlock stories and powers with each constellation
- 🎯 **Pattern Recognition**: Follow hints to discover the correct star connections
- 🌟 **Progressive Difficulty**: More complex patterns as you advance

## The Ten Legendary Constellations

### Beginner Constellations (1-3)
1. **✨ The Dreamer** - Maps paths between dreams and reality
2. **🦋 The Butterfly** - Transforms obstacles into opportunities  
3. **🌊 The Wave** - Brings flow and rhythm to chaotic energies

### Intermediate Constellations (4-6)
4. **🗝️ The Key** - Opens doors to forbidden knowledge
5. **🌺 The Bloom** - Nurtures growth in barren cosmic soil
6. **⚖️ The Balance** - Harmonizes opposing forces

### Advanced Constellations (7-10)
7. **🎭 The Mirror** - Reveals hidden truths and illusions
8. **🌀 The Spiral** - Creates pathways between worlds
9. **👁️ The Watcher** - Grants cosmic wisdom and foresight
10. **♾️ The Infinite** - Transcends all limitations and boundaries

## Controls & Commands
- **x y**: Select star at coordinates (e.g., "3 5")
- **done**: Complete current constellation attempt
- **clear**: Clear all selections and start over
- **hint**: Show target coordinates for current constellation
- **quit**: Exit to main menu

## Star Field Elements
- 🌟 **Bright Target Stars**: Key stars needed for constellation patterns
- ✨ **Dim Background Stars**: Decorative stars that add cosmic ambiance
- ⭐ **Selected Stars**: Highlighted stars in your current pattern
- ─ **Connection Lines**: Magical links between connected stars

## Scoring System
- **Base Points**: Each constellation has a base point value (50-300)
- **Energy Bonus**: Remaining cosmic energy adds to your score
- **Legend Points**: Cumulative score across all constellations
- **Efficiency Reward**: Complete constellations with minimal energy use

## Cosmic Energy Management
- Start each level with 100% cosmic energy
- Selecting stars costs 2% energy per action
- Completing constellations restores 25% energy
- Energy slowly regenerates (1% per turn)
- Game ends if energy reaches 0%

## Strategic Elements
1. **Pattern Analysis**: Study star positions before making connections
2. **Energy Conservation**: Use hints wisely to avoid wasted selections
3. **Coordinate Planning**: Plan your path through the star field
4. **Error Recovery**: Use "clear" command to restart without penalty
5. **Hint Usage**: Balance guidance with discovery for optimal scoring

## Achievement Levels
- 🌌 **Cosmic Architect**: Complete all 10 constellations
- ⭐ **Stellar Master**: Complete 7+ constellations  
- 🌟 **Star Weaver**: Complete 5+ constellations
- ✨ **Cosmic Student**: Complete 3+ constellations
- 🌱 **Stargazer Apprentice**: Complete 1-2 constellations

## Educational Value
- **Spatial Reasoning**: Develops coordinate understanding and pattern recognition
- **Mythology & Storytelling**: Each constellation includes rich lore
- **Problem Solving**: Requires logical thinking and planning
- **Patience & Persistence**: Teaches careful observation and methodical approach
- **Astronomy Interest**: Builds fascination with stars and constellations

## Tips for Stellar Success
1. **Study the Hint**: Use "hint" command to see target coordinates
2. **Plan Your Path**: Connect stars in a logical sequence
3. **Manage Energy**: Don't waste selections on wrong stars
4. **Clear When Stuck**: Start over rather than continuing with errors
5. **Read the Lore**: Each constellation's story provides clues about its pattern
6. **Practice Coordinates**: Get familiar with the x,y coordinate system

## Mystical Powers Unlocked
Each completed constellation grants thematic powers that enhance your cosmic abilities:
- 🔮 **Insight Powers**: See hidden connections and patterns
- 🌊 **Flow Powers**: Navigate challenges with grace and rhythm  
- 🗝️ **Knowledge Powers**: Access forbidden stellar wisdom
- ⚖️ **Balance Powers**: Harmonize chaotic cosmic forces
- 👁️ **Vision Powers**: Gain foresight and cosmic awareness

## Constellation Crafting Philosophy
"The stars are not random dots of light, but a cosmic alphabet waiting to be read. Each constellation is a word in the universe's grand story, and you are learning to speak the language of infinity."

## Technical Features
- ASCII art star field with dynamic brightness levels
- Real-time connection visualization with line drawing
- Interactive coordinate-based star selection
- Progressive difficulty with increasing pattern complexity
- Rich storytelling integration with gameplay mechanics
- Energy management adds strategic depth to puzzle solving

