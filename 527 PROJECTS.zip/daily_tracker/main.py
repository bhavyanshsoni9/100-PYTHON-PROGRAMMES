# Created by Bhavyansh Soni
# Daily Tracker - Personal habit and activity tracking system

import sys
import os
import time
from datetime import datetime, timedelta

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class DailyTracker:
    def __init__(self):
        self.running = True
        self.habits = []
        self.daily_logs = {}
        self.goals = []
        
        # Default habits
        self.default_habits = [
            {"name": "Drink Water", "unit": "glasses", "target": 8},
            {"name": "Exercise", "unit": "minutes", "target": 30},
            {"name": "Read", "unit": "pages", "target": 10},
            {"name": "Meditate", "unit": "minutes", "target": 15},
            {"name": "Sleep", "unit": "hours", "target": 8}
        ]
        
    def initialize_habits(self):
        """Initialize with default habits if none exist"""
        if not self.habits:
            self.habits = self.default_habits.copy()
            print_info("Initialized with default habits!")
    
    def add_habit(self):
        """Add a new habit to track"""
        clear_screen()
        print_banner("➕ ADD NEW HABIT ➕")
        print()
        
        name = get_input("Habit name: ")
        if not name:
            print_error("Habit name cannot be empty!")
            time.sleep(1)
            return
        
        unit = get_input("Unit of measurement (e.g., minutes, pages, glasses): ")
        if not unit:
            unit = "times"
        
        try:
            target = int(get_input("Daily target: "))
            if target <= 0:
                print_error("Target must be positive!")
                time.sleep(1)
                return
        except ValueError:
            print_error("Invalid target number!")
            time.sleep(1)
            return
        
        habit_data = {
            "name": name,
            "unit": unit,
            "target": target,
            "created_date": datetime.now().strftime("%Y-%m-%d")
        }
        
        self.habits.append(habit_data)
        print_success(f"Habit '{name}' added successfully!")
        time.sleep(1)
    
    def log_daily_activity(self):
        """Log today's activities"""
        clear_screen()
        print_banner("📊 LOG TODAY'S ACTIVITIES 📊")
        print()
        
        if not self.habits:
            self.initialize_habits()
        
        today = datetime.now().strftime("%Y-%m-%d")
        
        if today not in self.daily_logs:
            self.daily_logs[today] = {}
        
        print(f"Logging activities for {today}")
        print_separator()
        
        for habit in self.habits:
            current_value = self.daily_logs[today].get(habit["name"], 0)
            
            print(f"{Colors.ACCENT}Habit: {Colors.PRIMARY}{habit['name']}{Colors.RESET}")
            print(f"Target: {habit['target']} {habit['unit']}")
            print(f"Current: {current_value} {habit['unit']}")
            
            # Progress bar
            progress = min(100, (current_value / habit['target']) * 100)
            bar = self.create_progress_bar(progress)
            print(f"Progress: {bar} {progress:.1f}%")
            
            print()
            action = get_input("(a)dd, (s)et specific value, or (n)ext: ").lower()
            
            if action == 'a':
                try:
                    add_value = int(get_input(f"Add how many {habit['unit']}? "))
                    self.daily_logs[today][habit["name"]] = current_value + add_value
                    print_success(f"Added {add_value} {habit['unit']}!")
                except ValueError:
                    print_error("Invalid number!")
            elif action == 's':
                try:
                    set_value = int(get_input(f"Set to how many {habit['unit']}? "))
                    self.daily_logs[today][habit["name"]] = set_value
                    print_success(f"Set to {set_value} {habit['unit']}!")
                except ValueError:
                    print_error("Invalid number!")
            
            print()
        
        # Show daily summary
        self.show_daily_summary(today)
        press_enter_to_continue()
    
    def create_progress_bar(self, percentage, width=20):
        """Create a colored progress bar"""
        filled = int(width * percentage / 100)
        bar = "█" * filled + "░" * (width - filled)
        
        if percentage >= 100:
            color = Colors.PRIMARY
        elif percentage >= 75:
            color = Colors.WARNING
        elif percentage >= 50:
            color = Colors.SECONDARY
        else:
            color = Colors.ERROR
            
        return f"{color}{bar}{Colors.RESET}"
    
    def show_daily_summary(self, date):
        """Show summary for a specific date"""
        clear_screen()
        print_banner(f"📈 DAILY SUMMARY - {date} 📈")
        print()
        
        if date not in self.daily_logs:
            print_warning("No data logged for this date!")
            return
        
        total_habits = len(self.habits)
        completed_habits = 0
        overall_progress = 0
        
        for habit in self.habits:
            logged_value = self.daily_logs[date].get(habit["name"], 0)
            progress = min(100, (logged_value / habit['target']) * 100)
            overall_progress += progress
            
            if logged_value >= habit['target']:
                completed_habits += 1
                status_icon = "✅"
                status_color = Colors.PRIMARY
            elif logged_value >= habit['target'] * 0.75:
                status_icon = "⚠️"
                status_color = Colors.WARNING
            else:
                status_icon = "❌"
                status_color = Colors.ERROR
            
            bar = self.create_progress_bar(progress)
            print(f"{status_icon} {status_color}{habit['name']:<15}{Colors.RESET} {bar} {logged_value}/{habit['target']} {habit['unit']}")
        
        # Overall statistics
        print()
        print_separator()
        overall_percentage = overall_progress / total_habits if total_habits > 0 else 0
        completion_rate = (completed_habits / total_habits) * 100 if total_habits > 0 else 0
        
        print(f"{Colors.ACCENT}Habits Completed: {Colors.PRIMARY}{completed_habits}/{total_habits} ({completion_rate:.1f}%){Colors.RESET}")
        print(f"{Colors.ACCENT}Overall Progress: {Colors.PRIMARY}{overall_percentage:.1f}%{Colors.RESET}")
        
        # Achievement badges
        if completion_rate == 100:
            print(f"{Colors.PRIMARY}🏆 PERFECT DAY! All habits completed!{Colors.RESET}")
        elif completion_rate >= 75:
            print(f"{Colors.WARNING}🥈 GREAT JOB! Most habits completed!{Colors.RESET}")
        elif completion_rate >= 50:
            print(f"{Colors.SECONDARY}🥉 GOOD EFFORT! Keep it up!{Colors.RESET}")
    
    def view_habit_history(self):
        """View habit tracking history"""
        clear_screen()
        print_banner("📅 HABIT HISTORY 📅")
        print()
        
        if not self.daily_logs:
            print_warning("No tracking history found!")
            press_enter_to_continue()
            return
        
        # Show last 7 days
        today = datetime.now()
        last_7_days = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(6, -1, -1)]
        
        print("Last 7 days habit tracking:")
        print_separator()
        
        # Header
        header = f"{'Date':<12}"
        for habit in self.habits[:5]:  # Show first 5 habits to fit screen
            header += f"{habit['name'][:8]:<10}"
        print(f"{Colors.ACCENT}{header}{Colors.RESET}")
        
        # Data rows
        for date in last_7_days:
            row = f"{date:<12}"
            for habit in self.habits[:5]:
                if date in self.daily_logs:
                    value = self.daily_logs[date].get(habit["name"], 0)
                    target = habit['target']
                    
                    if value >= target:
                        status = f"{Colors.PRIMARY}✓{Colors.RESET}"
                    elif value >= target * 0.5:
                        status = f"{Colors.WARNING}~{Colors.RESET}"
                    else:
                        status = f"{Colors.ERROR}✗{Colors.RESET}"
                    
                    row += f"{status}({value:<3}){' ':<3}"
                else:
                    row += f"{Colors.GRAY}-{' ':<9}{Colors.RESET}"
            
            print(row)
        
        print()
        print_separator()
        
        # Weekly statistics
        self.show_weekly_stats(last_7_days)
        press_enter_to_continue()
    
    def show_weekly_stats(self, dates):
        """Show weekly statistics"""
        print(f"{Colors.ACCENT}Weekly Statistics:{Colors.RESET}")
        print()
        
        for habit in self.habits:
            total_logged = 0
            days_completed = 0
            days_with_data = 0
            
            for date in dates:
                if date in self.daily_logs and habit["name"] in self.daily_logs[date]:
                    value = self.daily_logs[date][habit["name"]]
                    total_logged += value
                    days_with_data += 1
                    
                    if value >= habit['target']:
                        days_completed += 1
            
            if days_with_data > 0:
                avg_per_day = total_logged / days_with_data
                completion_rate = (days_completed / len(dates)) * 100
                
                print(f"{Colors.SECONDARY}{habit['name']:<15}{Colors.RESET}")
                print(f"  Average: {avg_per_day:.1f} {habit['unit']}/day")
                print(f"  Completion: {days_completed}/{len(dates)} days ({completion_rate:.1f}%)")
                print()
    
    def set_goals(self):
        """Set weekly/monthly goals"""
        clear_screen()
        print_banner("🎯 SET GOALS 🎯")
        print()
        
        print("Goal types:")
        print_menu_item(1, "Weekly Goal")
        print_menu_item(2, "Monthly Goal")
        print_menu_item(3, "View Current Goals")
        print_menu_item(4, "Delete Goal")
        
        print()
        choice = get_input("Select option (1-4): ")
        
        if choice in ['1', '2']:
            goal_type = "Weekly" if choice == '1' else "Monthly"
            
            print()
            print("Available habits:")
            for i, habit in enumerate(self.habits, 1):
                print_menu_item(i, f"{habit['name']} (Target: {habit['target']} {habit['unit']}/day)")
            
            print()
            habit_choice = get_input("Select habit: ")
            
            if habit_choice.isdigit() and 1 <= int(habit_choice) <= len(self.habits):
                selected_habit = self.habits[int(habit_choice) - 1]
                
                try:
                    target = int(get_input(f"{goal_type} target for {selected_habit['name']}: "))
                    
                    goal_data = {
                        "type": goal_type,
                        "habit": selected_habit['name'],
                        "target": target,
                        "unit": selected_habit['unit'],
                        "created_date": datetime.now().strftime("%Y-%m-%d")
                    }
                    
                    self.goals.append(goal_data)
                    print_success(f"{goal_type} goal set for {selected_habit['name']}!")
                    
                except ValueError:
                    print_error("Invalid target number!")
            else:
                print_error("Invalid habit selection!")
        
        elif choice == '3':
            self.view_goals()
        
        elif choice == '4':
            self.delete_goal()
        
        time.sleep(1)
    
    def view_goals(self):
        """View current goals and progress"""
        clear_screen()
        print_banner("🎯 CURRENT GOALS 🎯")
        print()
        
        if not self.goals:
            print_warning("No goals set!")
            return
        
        today = datetime.now()
        
        for i, goal in enumerate(self.goals, 1):
            print(f"{Colors.ACCENT}{i}. {goal['type']} Goal: {Colors.PRIMARY}{goal['habit']}{Colors.RESET}")
            print(f"   Target: {goal['target']} {goal['unit']}")
            
            # Calculate progress
            if goal['type'] == "Weekly":
                start_date = today - timedelta(days=today.weekday())
                period_days = [(start_date + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
            else:  # Monthly
                start_date = today.replace(day=1)
                period_days = []
                current_date = start_date
                while current_date.month == today.month:
                    period_days.append(current_date.strftime("%Y-%m-%d"))
                    current_date += timedelta(days=1)
            
            total_logged = 0
            for date in period_days:
                if date in self.daily_logs:
                    total_logged += self.daily_logs[date].get(goal['habit'], 0)
            
            progress_percentage = (total_logged / goal['target']) * 100
            bar = self.create_progress_bar(progress_percentage)
            
            print(f"   Progress: {bar} {total_logged}/{goal['target']} ({progress_percentage:.1f}%)")
            print()
    
    def delete_goal(self):
        """Delete a goal"""
        if not self.goals:
            print_warning("No goals to delete!")
            return
        
        print()
        print("Current goals:")
        for i, goal in enumerate(self.goals, 1):
            print(f"{i}. {goal['type']} - {goal['habit']}")
        
        try:
            choice = int(get_input("Enter goal number to delete: ")) - 1
            if 0 <= choice < len(self.goals):
                deleted_goal = self.goals.pop(choice)
                print_success(f"Deleted goal: {deleted_goal['habit']}")
            else:
                print_error("Invalid goal number!")
        except ValueError:
            print_error("Invalid input!")
    
    def analytics_dashboard(self):
        """Show analytics and insights"""
        clear_screen()
        print_banner("📈 ANALYTICS DASHBOARD 📈")
        print()
        
        if not self.daily_logs:
            print_warning("No data to analyze!")
            press_enter_to_continue()
            return
        
        # Overall statistics
        total_days_logged = len(self.daily_logs)
        slow_print(f"Total Days Logged: {total_days_logged}", 0.02, Colors.ACCENT)
        
        # Best and worst days
        best_day = None
        worst_day = None
        best_score = -1
        worst_score = float('inf')
        
        for date, logs in self.daily_logs.items():
            day_score = 0
            for habit in self.habits:
                if habit['name'] in logs:
                    completion = min(100, (logs[habit['name']] / habit['target']) * 100)
                    day_score += completion
            
            avg_score = day_score / len(self.habits) if self.habits else 0
            
            if avg_score > best_score:
                best_score = avg_score
                best_day = date
            
            if avg_score < worst_score:
                worst_score = avg_score
                worst_day = date
        
        print()
        if best_day:
            slow_print(f"Best Day: {best_day} ({best_score:.1f}% average completion)", 0.02, Colors.PRIMARY)
        if worst_day:
            slow_print(f"Worst Day: {worst_day} ({worst_score:.1f}% average completion)", 0.02, Colors.ERROR)
        
        # Streak information
        print()
        slow_print("Current Streaks:", 0.02, Colors.ACCENT)
        for habit in self.habits:
            streak = self.calculate_streak(habit['name'])
            if streak > 0:
                print(f"{Colors.SECONDARY}{habit['name']}: {Colors.PRIMARY}{streak} days{Colors.RESET}")
            else:
                print(f"{Colors.SECONDARY}{habit['name']}: {Colors.GRAY}No current streak{Colors.RESET}")
        
        press_enter_to_continue()
    
    def calculate_streak(self, habit_name):
        """Calculate current streak for a habit"""
        if not self.daily_logs:
            return 0
        
        # Get habit target
        habit_target = None
        for habit in self.habits:
            if habit['name'] == habit_name:
                habit_target = habit['target']
                break
        
        if not habit_target:
            return 0
        
        # Check streak from today backwards
        streak = 0
        today = datetime.now()
        
        for i in range(len(self.daily_logs)):
            check_date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
            
            if check_date in self.daily_logs:
                logged_value = self.daily_logs[check_date].get(habit_name, 0)
                if logged_value >= habit_target:
                    streak += 1
                else:
                    break
            else:
                break
        
        return streak
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Tracker ASCII art
            tracker_art = """
    ████████╗██████╗  █████╗  ██████╗██╗  ██╗███████╗██████╗ 
    ╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
       ██║   ██████╔╝███████║██║     █████╔╝ █████╗  ██████╔╝
       ██║   ██╔══██╗██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗
       ██║   ██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║
       ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
            """
            
            print_ascii_art(tracker_art, Colors.ACCENT)
            print()
            slow_print("Track your daily habits and achieve your goals!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "📊 Log Today's Activities")
            print_menu_item(2, "➕ Add New Habit")
            print_menu_item(3, "📅 View History")
            print_menu_item(4, "🎯 Goals")
            print_menu_item(5, "📈 Analytics")
            print_menu_item(6, "⚙️ Manage Habits")
            print_menu_item(7, "❌ Exit")
            
            print()
            # Show today's quick status
            today = datetime.now().strftime("%Y-%m-%d")
            if today in self.daily_logs and self.habits:
                completed = sum(1 for habit in self.habits 
                              if self.daily_logs[today].get(habit['name'], 0) >= habit['target'])
                print(f"{Colors.GRAY}Today: {completed}/{len(self.habits)} habits completed{Colors.RESET}")
            print()
            
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.log_daily_activity()
            elif choice == '2':
                self.add_habit()
            elif choice == '3':
                self.view_habit_history()
            elif choice == '4':
                self.set_goals()
            elif choice == '5':
                self.analytics_dashboard()
            elif choice == '6':
                self.manage_habits()
            elif choice == '7':
                slow_print("Keep building those healthy habits! 💪", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)
    
    def manage_habits(self):
        """Manage existing habits"""
        clear_screen()
        print_banner("⚙️ MANAGE HABITS ⚙️")
        print()
        
        if not self.habits:
            print_warning("No habits to manage!")
            print_info("Add some habits first!")
            time.sleep(2)
            return
        
        print("Current habits:")
        for i, habit in enumerate(self.habits, 1):
            print(f"{i}. {habit['name']} (Target: {habit['target']} {habit['unit']}/day)")
        
        print()
        print_menu_item(1, "Edit Habit")
        print_menu_item(2, "Delete Habit")
        print_menu_item(3, "Reset to Defaults")
        print_menu_item(4, "Back to Main Menu")
        
        print()
        choice = get_input("Select option (1-4): ")
        
        if choice == '1':
            self.edit_habit()
        elif choice == '2':
            self.delete_habit()
        elif choice == '3':
            confirm = get_input("Reset to default habits? (y/N): ").lower()
            if confirm == 'y':
                self.habits = self.default_habits.copy()
                print_success("Habits reset to defaults!")
        elif choice == '4':
            return
        else:
            print_error("Invalid choice!")
        
        time.sleep(1)
    
    def edit_habit(self):
        """Edit an existing habit"""
        try:
            habit_num = int(get_input("Enter habit number to edit: ")) - 1
            if 0 <= habit_num < len(self.habits):
                habit = self.habits[habit_num]
                
                print(f"Editing: {habit['name']}")
                new_name = get_input(f"New name (current: {habit['name']}): ")
                if new_name:
                    habit['name'] = new_name
                
                new_target = get_input(f"New target (current: {habit['target']}): ")
                if new_target.isdigit():
                    habit['target'] = int(new_target)
                
                print_success("Habit updated!")
            else:
                print_error("Invalid habit number!")
        except ValueError:
            print_error("Invalid input!")
    
    def delete_habit(self):
        """Delete a habit"""
        try:
            habit_num = int(get_input("Enter habit number to delete: ")) - 1
            if 0 <= habit_num < len(self.habits):
                deleted_habit = self.habits.pop(habit_num)
                print_success(f"Deleted habit: {deleted_habit['name']}")
            else:
                print_error("Invalid habit number!")
        except ValueError:
            print_error("Invalid input!")

def main():
    """Main function to run Daily Tracker"""
    try:
        tracker = DailyTracker()
        tracker.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
