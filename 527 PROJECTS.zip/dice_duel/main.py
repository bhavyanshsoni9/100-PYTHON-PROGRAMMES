# Created by Bhavyansh Soni
# Dice Duel - Cyberpunk dice game with multiple game modes

import sys
import os
import time
import random
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class DiceDuel:
    def __init__(self):
        self.running = True
        self.player_score = 0
        self.ai_score = 0
        self.rounds_played = 0
        self.wins = 0
        self.losses = 0
        self.draws = 0
        self.game_mode = "classic"
        
        # Dice faces for visual representation
        self.dice_faces = {
            1: [
                "┌─────────┐",
                "│         │",
                "│    ●    │",
                "│         │",
                "└─────────┘"
            ],
            2: [
                "┌─────────┐",
                "│  ●      │",
                "│         │",
                "│      ●  │",
                "└─────────┘"
            ],
            3: [
                "┌─────────┐",
                "│  ●      │",
                "│    ●    │",
                "│      ●  │",
                "└─────────┘"
            ],
            4: [
                "┌─────────┐",
                "│  ●   ●  │",
                "│         │",
                "│  ●   ●  │",
                "└─────────┘"
            ],
            5: [
                "┌─────────┐",
                "│  ●   ●  │",
                "│    ●    │",
                "│  ●   ●  │",
                "└─────────┘"
            ],
            6: [
                "┌─────────┐",
                "│  ●   ●  │",
                "│  ●   ●  │",
                "│  ●   ●  │",
                "└─────────┘"
            ]
        }
    
    def roll_dice(self, num_dice=1):
        """Roll specified number of dice"""
        return [random.randint(1, 6) for _ in range(num_dice)]
    
    def display_dice(self, dice_values, title="DICE ROLL"):
        """Display dice with ASCII art"""
        print(f"{Colors.ACCENT}{title}:{Colors.RESET}")
        
        # Display dice side by side
        for line_num in range(5):
            line = ""
            for dice_value in dice_values:
                line += self.dice_faces[dice_value][line_num] + "  "
            print(f"{Colors.PRIMARY}{line}{Colors.RESET}")
        
        print()
    
    def animate_dice_roll(self, num_dice=1):
        """Animate dice rolling"""
        for _ in range(10):
            clear_screen()
            random_values = [random.randint(1, 6) for _ in range(num_dice)]
            self.display_dice(random_values, "ROLLING...")
            time.sleep(0.1)
        
        # Final roll
        final_values = self.roll_dice(num_dice)
        clear_screen()
        self.display_dice(final_values, "RESULT")
        return final_values
    
    def classic_duel(self):
        """Classic dice duel - highest roll wins"""
        clear_screen()
        print_banner("🎲 CLASSIC DICE DUEL 🎲")
        print()
        
        slow_print("Rolling dice for the duel...", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        # Player roll
        print(f"{Colors.SECONDARY}Your turn:{Colors.RESET}")
        player_roll = self.animate_dice_roll(1)
        player_value = player_roll[0]
        
        time.sleep(1)
        
        # AI roll
        print(f"{Colors.ERROR}AI's turn:{Colors.RESET}")
        ai_roll = self.animate_dice_roll(1)
        ai_value = ai_roll[0]
        
        # Determine winner
        print_separator()
        if player_value > ai_value:
            print_success(f"🎉 YOU WIN! ({player_value} vs {ai_value})")
            self.wins += 1
            self.player_score += 1
        elif ai_value > player_value:
            print_error(f"💀 AI WINS! ({ai_value} vs {player_value})")
            self.losses += 1
            self.ai_score += 1
        else:
            print_warning(f"🤝 IT'S A DRAW! ({player_value} vs {ai_value})")
            self.draws += 1
        
        self.rounds_played += 1
        
        print()
        print(f"{Colors.ACCENT}Score: You {self.player_score} - {self.ai_score} AI{Colors.RESET}")
        
        press_enter_to_continue()
    
    def sum_challenge(self):
        """Sum challenge - roll 3 dice, highest sum wins"""
        clear_screen()
        print_banner("🎯 SUM CHALLENGE 🎯")
        print()
        
        slow_print("Rolling 3 dice each... Highest sum wins!", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        # Player roll
        print(f"{Colors.SECONDARY}Your 3 dice:{Colors.RESET}")
        player_rolls = self.animate_dice_roll(3)
        player_sum = sum(player_rolls)
        
        time.sleep(1)
        
        # AI roll
        print(f"{Colors.ERROR}AI's 3 dice:{Colors.RESET}")
        ai_rolls = self.animate_dice_roll(3)
        ai_sum = sum(ai_rolls)
        
        # Results
        print_separator()
        print(f"{Colors.ACCENT}Your sum: {Colors.WHITE}{player_sum}{Colors.RESET}")
        print(f"{Colors.ACCENT}AI sum: {Colors.WHITE}{ai_sum}{Colors.RESET}")
        print()
        
        if player_sum > ai_sum:
            print_success(f"🎉 YOU WIN! ({player_sum} vs {ai_sum})")
            self.wins += 1
            self.player_score += 1
        elif ai_sum > player_sum:
            print_error(f"💀 AI WINS! ({ai_sum} vs {player_sum})")
            self.losses += 1
            self.ai_score += 1
        else:
            print_warning(f"🤝 IT'S A DRAW! ({player_sum} vs {ai_sum})")
            self.draws += 1
        
        self.rounds_played += 1
        
        press_enter_to_continue()
    
    def lucky_seven(self):
        """Lucky Seven - try to get closest to 7 without going over"""
        clear_screen()
        print_banner("🍀 LUCKY SEVEN 🍀")
        print()
        
        slow_print("Get as close to 7 as possible without going over!", 0.02, Colors.ACCENT)
        print()
        
        # Player turn
        player_total = 0
        player_rolls = []
        
        while player_total < 7:
            choice = get_input("Press Enter to roll dice (or 'stop' to stop): ")
            if choice.lower() == 'stop':
                break
            
            roll = self.roll_dice(1)[0]
            player_rolls.append(roll)
            player_total += roll
            
            print(f"{Colors.PRIMARY}You rolled: {roll} (Total: {player_total}){Colors.RESET}")
            
            if player_total > 7:
                print_error("BUST! You went over 7!")
                break
            elif player_total == 7:
                print_success("PERFECT! You got exactly 7!")
                break
        
        # AI turn
        print()
        print(f"{Colors.ERROR}AI's turn:{Colors.RESET}")
        ai_total = 0
        ai_rolls = []
        
        while ai_total < 7:
            # AI strategy: stop if total is 5 or 6
            if ai_total >= 5:
                print(f"{Colors.GRAY}AI decides to stop at {ai_total}{Colors.RESET}")
                break
            
            roll = self.roll_dice(1)[0]
            ai_rolls.append(roll)
            ai_total += roll
            
            print(f"{Colors.ERROR}AI rolled: {roll} (Total: {ai_total}){Colors.RESET}")
            time.sleep(1)
            
            if ai_total > 7:
                print_error("AI BUST! AI went over 7!")
                break
        
        # Determine winner
        print_separator()
        if player_total > 7 and ai_total > 7:
            print_warning("🤝 Both players bust! It's a draw!")
            self.draws += 1
        elif player_total > 7:
            print_error("💀 AI WINS! You went bust!")
            self.losses += 1
            self.ai_score += 1
        elif ai_total > 7:
            print_success("🎉 YOU WIN! AI went bust!")
            self.wins += 1
            self.player_score += 1
        elif player_total == ai_total:
            print_warning(f"🤝 IT'S A DRAW! Both got {player_total}")
            self.draws += 1
        elif player_total > ai_total:
            print_success(f"🎉 YOU WIN! ({player_total} vs {ai_total})")
            self.wins += 1
            self.player_score += 1
        else:
            print_error(f"💀 AI WINS! ({ai_total} vs {player_total})")
            self.losses += 1
            self.ai_score += 1
        
        self.rounds_played += 1
        
        press_enter_to_continue()
    
    def dice_poker(self):
        """Dice poker - roll 5 dice and find the best hand"""
        clear_screen()
        print_banner("🃏 DICE POKER 🃏")
        print()
        
        slow_print("Roll 5 dice and find the best poker hand!", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        # Player roll
        print(f"{Colors.SECONDARY}Your dice:{Colors.RESET}")
        player_rolls = self.animate_dice_roll(5)
        player_hand = self.evaluate_poker_hand(player_rolls)
        
        time.sleep(1)
        
        # AI roll
        print(f"{Colors.ERROR}AI's dice:{Colors.RESET}")
        ai_rolls = self.animate_dice_roll(5)
        ai_hand = self.evaluate_poker_hand(ai_rolls)
        
        # Results
        print_separator()
        print(f"{Colors.ACCENT}Your hand: {Colors.WHITE}{player_hand['name']}{Colors.RESET}")
        print(f"{Colors.ACCENT}AI hand: {Colors.WHITE}{ai_hand['name']}{Colors.RESET}")
        print()
        
        if player_hand['rank'] > ai_hand['rank']:
            print_success(f"🎉 YOU WIN! {player_hand['name']} beats {ai_hand['name']}")
            self.wins += 1
            self.player_score += 1
        elif ai_hand['rank'] > player_hand['rank']:
            print_error(f"💀 AI WINS! {ai_hand['name']} beats {player_hand['name']}")
            self.losses += 1
            self.ai_score += 1
        else:
            print_warning(f"🤝 IT'S A DRAW! Both have {player_hand['name']}")
            self.draws += 1
        
        self.rounds_played += 1
        
        press_enter_to_continue()
    
    def evaluate_poker_hand(self, dice):
        """Evaluate poker hand from dice rolls"""
        counts = {}
        for die in dice:
            counts[die] = counts.get(die, 0) + 1
        
        count_values = sorted(counts.values(), reverse=True)
        
        # Check for different hands
        if count_values == [5]:
            return {"name": "Five of a Kind", "rank": 7}
        elif count_values == [4, 1]:
            return {"name": "Four of a Kind", "rank": 6}
        elif count_values == [3, 2]:
            return {"name": "Full House", "rank": 5}
        elif count_values == [3, 1, 1]:
            return {"name": "Three of a Kind", "rank": 4}
        elif count_values == [2, 2, 1]:
            return {"name": "Two Pair", "rank": 3}
        elif count_values == [2, 1, 1, 1]:
            return {"name": "One Pair", "rank": 2}
        elif sorted(dice) == [1, 2, 3, 4, 5] or sorted(dice) == [2, 3, 4, 5, 6]:
            return {"name": "Straight", "rank": 4}
        else:
            return {"name": "High Card", "rank": 1}
    
    def tournament_mode(self):
        """Tournament mode - first to 5 wins"""
        clear_screen()
        print_banner("🏆 TOURNAMENT MODE 🏆")
        print()
        
        slow_print("First to 5 wins becomes the champion!", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        tournament_wins = 0
        tournament_losses = 0
        
        while tournament_wins < 5 and tournament_losses < 5:
            clear_screen()
            print_banner(f"🏆 TOURNAMENT - MATCH {tournament_wins + tournament_losses + 1} 🏆")
            print()
            print(f"{Colors.ACCENT}Score: You {tournament_wins} - {tournament_losses} AI{Colors.RESET}")
            print()
            
            # Play a classic duel
            player_roll = self.roll_dice(1)[0]
            ai_roll = self.roll_dice(1)[0]
            
            self.display_dice([player_roll], "YOUR ROLL")
            self.display_dice([ai_roll], "AI'S ROLL")
            
            if player_roll > ai_roll:
                print_success(f"🎉 YOU WIN THIS MATCH! ({player_roll} vs {ai_roll})")
                tournament_wins += 1
            elif ai_roll > player_roll:
                print_error(f"💀 AI WINS THIS MATCH! ({ai_roll} vs {player_roll})")
                tournament_losses += 1
            else:
                print_warning(f"🤝 DRAW! Rolling again... ({player_roll} vs {ai_roll})")
            
            time.sleep(2)
        
        # Tournament results
        clear_screen()
        print_banner("🏆 TOURNAMENT RESULTS 🏆")
        print()
        
        if tournament_wins == 5:
            print_success("🎉 CONGRATULATIONS! YOU ARE THE CHAMPION!")
            self.wins += 1
        else:
            print_error("💀 AI WINS THE TOURNAMENT!")
            self.losses += 1
        
        press_enter_to_continue()
    
    def show_statistics(self):
        """Display game statistics"""
        clear_screen()
        print_banner("📊 DICE DUEL STATISTICS 📊")
        print()
        
        total_games = self.wins + self.losses + self.draws
        win_rate = (self.wins / max(1, total_games)) * 100
        
        slow_print(f"Total Games: {total_games}", 0.02, Colors.ACCENT)
        slow_print(f"Wins: {self.wins}", 0.02, Colors.PRIMARY)
        slow_print(f"Losses: {self.losses}", 0.02, Colors.ERROR)
        slow_print(f"Draws: {self.draws}", 0.02, Colors.WARNING)
        slow_print(f"Win Rate: {win_rate:.1f}%", 0.02, Colors.ACCENT)
        slow_print(f"Rounds Played: {self.rounds_played}", 0.02, Colors.ACCENT)
        
        print()
        
        # Performance rating
        if win_rate >= 70:
            rating = "🥇 Dice Master"
            rating_color = Colors.PRIMARY
        elif win_rate >= 50:
            rating = "🥈 Skilled Player"
            rating_color = Colors.SECONDARY
        elif win_rate >= 30:
            rating = "🥉 Casual Player"
            rating_color = Colors.WARNING
        else:
            rating = "🎲 Beginner"
            rating_color = Colors.GRAY
        
        print(f"{Colors.ACCENT}Rating: {rating_color}{rating}{Colors.RESET}")
        
        print()
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # ASCII art
            dice_art = """
    ██████╗ ██╗ ██████╗███████╗    ██████╗ ██╗   ██╗███████╗██╗     
    ██╔══██╗██║██╔════╝██╔════╝    ██╔══██╗██║   ██║██╔════╝██║     
    ██║  ██║██║██║     █████╗      ██║  ██║██║   ██║█████╗  ██║     
    ██║  ██║██║██║     ██╔══╝      ██║  ██║██║   ██║██╔══╝  ██║     
    ██████╔╝██║╚██████╗███████╗    ██████╔╝╚██████╔╝███████╗███████╗
    ╚═════╝ ╚═╝ ╚═════╝╚══════╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
            """
            
            print_ascii_art(dice_art, Colors.ACCENT)
            print()
            slow_print("Roll the dice in the cyberpunk arena!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🎲 Classic Duel")
            print_menu_item(2, "🎯 Sum Challenge")
            print_menu_item(3, "🍀 Lucky Seven")
            print_menu_item(4, "🃏 Dice Poker")
            print_menu_item(5, "🏆 Tournament Mode")
            print_menu_item(6, "📊 Statistics")
            print_menu_item(7, "🎯 Practice Mode")
            print_menu_item(8, "❌ Exit")
            
            print()
            print(f"{Colors.GRAY}Current Score: You {self.player_score} - {self.ai_score} AI{Colors.RESET}")
            print()
            
            choice = get_input("Enter your choice (1-8): ")
            
            if choice == '1':
                self.classic_duel()
            elif choice == '2':
                self.sum_challenge()
            elif choice == '3':
                self.lucky_seven()
            elif choice == '4':
                self.dice_poker()
            elif choice == '5':
                self.tournament_mode()
            elif choice == '6':
                self.show_statistics()
            elif choice == '7':
                self.practice_mode()
            elif choice == '8':
                slow_print("Thanks for playing Dice Duel!", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-8.")
                time.sleep(1)
    
    def practice_mode(self):
        """Practice mode - just roll dice"""
        clear_screen()
        print_banner("🎯 PRACTICE MODE 🎯")
        print()
        
        while True:
            num_dice = get_input("How many dice to roll? (1-6, or 'quit'): ")
            
            if num_dice.lower() == 'quit':
                break
            
            try:
                num_dice = int(num_dice)
                if 1 <= num_dice <= 6:
                    dice_values = self.animate_dice_roll(num_dice)
                    total = sum(dice_values)
                    print(f"{Colors.ACCENT}Total: {Colors.WHITE}{total}{Colors.RESET}")
                    print()
                else:
                    print_error("Please enter a number between 1 and 6!")
            except ValueError:
                print_error("Please enter a valid number!")

def main():
    """Main function to run Dice Duel"""
    try:
        dice_duel = DiceDuel()
        dice_duel.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
