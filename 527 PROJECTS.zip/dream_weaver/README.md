# 💭 Dream Weaver

**Created by Bhavyansh Soni**

## Description
A surreal storytelling adventure where players craft narratives from bizarre dream fragments! Journey through 7 mystical dream realms, collect ethereal story elements, and weave them into coherent dreams that blur the line between logic and imagination. Master the art of lucid dreaming while creating beautiful, otherworldly narratives.

## Core Concept
"In the realm of dreams, logic is merely a suggestion. Your task is to collect the scattered fragments of the subconscious and weave them into stories that capture the beauty of surreal imagination."

## Gameplay Features
- 🌌 **7 Mystical Dream Realms**: Each with unique themes and atmospheric moods
- 🧩 **5 Fragment Categories**: Characters, settings, objects, actions, and emotions
- 💫 **Lucidity System**: Higher awareness creates more vivid and valuable dreams
- ⚡ **Dream Energy**: Manage your creative storytelling power
- 📝 **Story Crafting**: Combine fragments into coherent dream narratives
- 🌟 **Quality Scoring**: Dreams rated on coherence and creativity

## The Seven Dream Realms

### 🌙 **Realm 1: The Twilight Garden**
- **Theme**: Where day and night blend into eternal twilight
- **Mood**: Peaceful and contemplative
- **Fragments Needed**: 3
- **Atmosphere**: Gentle, introspective exploration

### 🎪 **Realm 2: The Circus of Impossibilities**
- **Theme**: Where logic performs death-defying acts  
- **Mood**: Whimsical and chaotic
- **Fragments Needed**: 4
- **Atmosphere**: Playful surrealism and wonder

### 🌊 **Realm 3: The Ocean of Memories**
- **Theme**: Vast waters filled with floating recollections
- **Mood**: Nostalgic and emotional
- **Fragments Needed**: 4
- **Atmosphere**: Deep reflection and remembrance

### 🏰 **Realm 4: The Architecture of Thoughts**
- **Theme**: Buildings constructed from pure imagination
- **Mood**: Mysterious and intellectual
- **Fragments Needed**: 5
- **Atmosphere**: Complex mental constructs

### 🌈 **Realm 5: The Spectrum Between Worlds**
- **Theme**: A bridge realm connecting all possibilities
- **Mood**: Transcendent and ethereal
- **Fragments Needed**: 5
- **Atmosphere**: Infinite potential and transformation

### ⏰ **Realm 6: The Clockwork of Destiny**
- **Theme**: Where time itself can be rewound and reshaped
- **Mood**: Profound and temporal
- **Fragments Needed**: 6
- **Atmosphere**: Time manipulation and fate

### ✨ **Realm 7: The Core of All Dreams**
- **Theme**: The nexus where all dreams converge and begin
- **Mood**: Ultimate transcendence
- **Fragments Needed**: 7
- **Atmosphere**: Pure creative consciousness

## Fragment Categories

### 👤 **Characters**
Surreal beings that inhabit dream narratives:
- "A talking clock with butterfly wings"
- "A melting businessman made of cheese"
- "Your childhood pet as a wise sage"
- "A dancing tree with human emotions"

### 🏰 **Settings**
Impossible locations where dreams unfold:
- "A library where books grow on trees"
- "An upside-down city floating in tea"
- "A beach made of broken memories"
- "A school where gravity flows sideways"

### 🗝️ **Objects**
Mystical items with dream-like properties:
- "Keys that unlock forgotten memories"
- "A phone that calls your past self"
- "Balloons filled with liquid starlight"
- "A compass pointing to lost dreams"

### 🏃 **Actions**
Impossible activities that defy reality:
- "Flying through clouds of forgotten words"
- "Painting with liquid moonbeams"
- "Dancing until reality dissolves"
- "Speaking in colors and tasting sounds"

### 😊 **Emotions**
Feelings given physical form and presence:
- "Nostalgia thick enough to swim through"
- "Joy that tastes like childhood summers"
- "Fear that manifests as purple fog"
- "Wonder that makes flowers grow in footsteps"

## Lucidity System
Your dream awareness affects the entire experience:

### **High Lucidity (70-100%)**
- **Vivid Fragments**: Crystal-clear dream elements
- **Strong Coherence**: 80-100% story cohesion
- **Enhanced Control**: Better story crafting ability
- **Quality Bonus**: Multiplies final dream scores

### **Medium Lucidity (40-69%)**
- **Clear Fragments**: Well-defined but flexible elements
- **Good Coherence**: 60-85% story cohesion
- **Balanced Experience**: Mix of control and surprise
- **Standard Scoring**: Normal point calculation

### **Low Lucidity (0-39%)**
- **Hazy Fragments**: Blurry, shifting dream elements
- **Wild Coherence**: 30-65% story cohesion
- **Chaotic Beauty**: Unpredictable but potentially brilliant
- **Surreal Bonus**: Sometimes creates unexpected masterpieces

## Dream Energy Management
- **Starting Energy**: 100% per realm
- **Collection Cost**: 5-15% per fragment (varies by quality)
- **Story Weaving**: Free when you have enough fragments
- **Energy Recovery**: +20% after completing a dream, +2% passive regeneration
- **Depletion Effects**: Lower energy reduces fragment quality

## Story Crafting Process
1. **Explore Realm**: Discover available dream fragments
2. **Collect Elements**: Choose fragments that inspire you
3. **Weave Dream**: Select and combine fragments into narrative
4. **Generate Story**: Watch your dream unfold with surreal logic
5. **Receive Rating**: Get quality score based on coherence and creativity

## Scoring System
- **Fragment Coherence**: Base quality of story elements
- **Lucidity Bonus**: Multiplier based on dream awareness
- **Length Bonus**: More fragments = higher potential scores
- **Quality Ratings**:
  - 🌟 **MASTERPIECE** (80%+): Perfect crystalline clarity
  - ✅ **EXCELLENT** (65-79%): Beautiful coherent flow
  - 👍 **GOOD** (50-64%): Memorable dream experience
  - 🌀 **SURREAL** (Below 50%): Chaotic but beautiful

## Strategy Tips
1. **Balance Fragment Types**: Include diverse story elements
2. **Manage Energy Wisely**: Don't collect every fragment you see
3. **Consider Lucidity**: Sometimes embrace chaos for unique results
4. **Theme Awareness**: Match fragments to realm atmosphere
5. **Quality vs Quantity**: Fewer high-quality fragments often work better
6. **Creative Combinations**: Unexpected pairings create interesting stories

## Achievement Levels
- 🌌 **Lucid Dream Master**: Average quality 80%+ (Master of consciousness)
- ✨ **Surreal Storyteller**: Average quality 65%+ (Weaver of wonders)
- 🌙 **Dream Artisan**: Average quality 50%+ (Skilled creator)
- 💭 **Dreaming Student**: Average quality 35%+ (Learning the craft)
- 🌱 **Sleepy Apprentice**: Below 35% (Journey just beginning)

## Educational Benefits
- **Creative Writing**: Develops narrative construction skills
- **Imagination Training**: Expands creative thinking abilities
- **Pattern Recognition**: Learns story structure and coherence
- **Resource Management**: Balances energy and fragment collection
- **Surreal Logic**: Explores non-linear thinking patterns
- **Emotional Intelligence**: Works with feelings as story elements

## Philosophical Themes
The game explores deep concepts through playful mechanics:
- **Consciousness vs Subconsciousness**: Lucidity as awareness level
- **Narrative Construction**: How stories emerge from fragments
- **Logic vs Intuition**: Balancing coherence with creativity
- **Memory and Time**: Dreams as non-linear experiences
- **Transformation**: How raw experience becomes meaningful story

## Technical Features
- Dynamic fragment generation based on lucidity level
- Adaptive story creation algorithms
- Progressive difficulty through realm complexity
- Multiple narrative pathway possibilities
- Coherence calculation system for quality scoring
- Atmospheric text presentation matching realm themes

