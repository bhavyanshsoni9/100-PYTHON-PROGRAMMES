#!/usr/bin/env python3
"""
💭 DREAM WEAVER 💭
Created by Bhavyansh Soni

An original surreal storytelling game where players craft narratives from dream fragments!
Collect bizarre dream elements, weave them into coherent stories, and explore the
mysterious realm where logic bends and imagination reigns supreme!
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class DreamWeaver:
    def __init__(self):
        self.dream_fragments = []
        self.collected_fragments = []
        self.woven_dreams = []
        self.lucidity_level = 50
        self.creativity_score = 0
        self.dream_energy = 100
        self.current_dream_realm = 1
        self.max_realms = 7
        
        # Dream fragment categories with surreal elements
        self.fragment_categories = {
            "characters": {
                "emojis": ["👤", "👻", "🤖", "🧚", "🐉", "👽", "🎭", "🦄"],
                "descriptors": [
                    "a talking clock with butterfly wings",
                    "a melting businessman made of cheese",
                    "your childhood pet as a wise sage",
                    "a dancing tree with human emotions",
                    "a mirror that shows different people",
                    "a floating librarian made of books",
                    "a singing cloud with golden eyes",
                    "a mechanical bird that speaks in colors"
                ]
            },
            "settings": {
                "emojis": ["🏰", "🌙", "🌊", "🎪", "🚀", "🏛️", "🌈", "🔮"],
                "descriptors": [
                    "a library where books grow on trees",
                    "an upside-down city floating in tea",
                    "a beach made of broken memories",
                    "a school where gravity flows sideways",
                    "a house built inside a giant seashell",
                    "a market selling bottled emotions",
                    "a garden where flowers sing lullabies",
                    "a train station between dimensions"
                ]
            },
            "objects": {
                "emojis": ["🗝️", "📱", "🎈", "🔑", "💎", "📚", "🎵", "⏰"],
                "descriptors": [
                    "keys that unlock forgotten memories",
                    "a phone that calls your past self",
                    "balloons filled with liquid starlight",
                    "a compass pointing to lost dreams",
                    "mirrors that reflect your fears",
                    "books that rewrite themselves",
                    "music boxes playing tomorrow's songs",
                    "clocks that tick backwards through time"
                ]
            },
            "actions": {
                "emojis": ["🏃", "💃", "🎨", "🎭", "🎪", "✨", "🌀", "🎯"],
                "descriptors": [
                    "flying through clouds of forgotten words",
                    "painting with liquid moonbeams",
                    "dancing until reality dissolves",
                    "speaking in colors and tasting sounds",
                    "swimming through an ocean of thoughts",
                    "building castles from crystallized time",
                    "chasing shadows that lead to revelations",
                    "weaving stories from spider silk and stardust"
                ]
            },
            "emotions": {
                "emojis": ["😊", "😢", "😱", "🤔", "😍", "🤯", "😌", "🥺"],
                "descriptors": [
                    "nostalgia thick enough to swim through",
                    "joy that tastes like childhood summers",
                    "fear that manifests as purple fog",
                    "wonder that makes flowers grow in footsteps",
                    "love that sounds like orchestral thunder",
                    "confusion that turns words into butterflies",
                    "peace that glows like gentle aurora",
                    "curiosity that opens doors in empty walls"
                ]
            }
        }
        
        # Dream realm themes
        self.dream_realms = {
            1: {
                "name": "🌙 The Twilight Garden",
                "theme": "A realm where day and night blend into eternal twilight",
                "mood": "peaceful",
                "color": Fore.BLUE,
                "fragments_needed": 3
            },
            2: {
                "name": "🎪 The Circus of Impossibilities", 
                "theme": "Where logic performs death-defying acts",
                "mood": "whimsical",
                "color": Fore.MAGENTA,
                "fragments_needed": 4
            },
            3: {
                "name": "🌊 The Ocean of Memories",
                "theme": "Vast waters filled with floating recollections",
                "mood": "nostalgic",
                "color": Fore.CYAN,
                "fragments_needed": 4
            },
            4: {
                "name": "🏰 The Architecture of Thoughts",
                "theme": "Buildings constructed from pure imagination",
                "mood": "mysterious",
                "color": Fore.YELLOW,
                "fragments_needed": 5
            },
            5: {
                "name": "🌈 The Spectrum Between Worlds",
                "theme": "A bridge realm connecting all possibilities",
                "mood": "transcendent",
                "color": Fore.GREEN,
                "fragments_needed": 5
            },
            6: {
                "name": "⏰ The Clockwork of Destiny",
                "theme": "Where time itself can be rewound and reshaped",
                "mood": "profound",
                "color": Fore.RED,
                "fragments_needed": 6
            },
            7: {
                "name": "✨ The Core of All Dreams",
                "theme": "The nexus where all dreams converge and begin",
                "mood": "transcendent",
                "color": Fore.WHITE,
                "fragments_needed": 7
            }
        }
        
    def show_intro(self):
        """Display game introduction and dream philosophy"""
        clear_screen()
        
        intro_banner = create_banner("DREAM WEAVER", color=Fore.MAGENTA)
        print(intro_banner)
        
        slow_print(rainbow_text("💭 Welcome to the infinite tapestry of dreams and possibilities! 💭"), delay=0.03)
        time.sleep(1)
        
        philosophy = [
            "\n🌙 DREAM PHILOSOPHY:",
            "In the realm of dreams, logic is merely a suggestion.",
            "Every fragment holds a piece of universal story.",
            "Your task is to weave these pieces into coherent dreams",
            "that capture the beauty of surreal imagination.",
            "",
            "🎭 HOW TO WEAVE DREAMS:",
            "💫 Explore dream realms to collect fragments",
            "🧩 Gather characters, settings, objects, actions, and emotions",
            "📝 Craft stories by combining fragments creatively",
            "✨ Higher lucidity creates more vivid and valuable dreams",
            "🌟 Each realm requires different numbers of fragments",
            "🎯 Complete all 7 realms to become a Master Dream Weaver!",
            "",
            "🔮 LUCIDITY MECHANICS:",
            "High lucidity = More control over dream elements",
            "Low lucidity = More surreal but chaotic experiences",
            "Dream energy fuels your creative storytelling power!",
        ]
        
        for text in philosophy:
            if text.startswith("🌙") or text.startswith("🎭") or text.startswith("🔮"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.CYAN + "\n💭 Ready to enter the dream realm? Press ENTER to begin!", delay=0.03)
        input()
    
    def show_dream_realm(self):
        """Display current dream realm information"""
        clear_screen()
        
        realm_info = self.dream_realms[self.current_dream_realm]
        color = realm_info["color"]
        
        realm_banner = create_banner(f"REALM {self.current_dream_realm}", color=color)
        print(realm_banner)
        
        slow_print(f"{color}🌌 Entering: {realm_info['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}📜 Realm Theme:", delay=0.02)
        slow_print(f"{color}   {realm_info['theme']}", delay=0.02)
        
        slow_print(f"\n{Fore.WHITE}🎭 Mood: {realm_info['mood']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🧩 Fragments needed: {realm_info['fragments_needed']}", delay=0.02)
        slow_print(f"{Fore.WHITE}💫 Current lucidity: {self.lucidity_level}%", delay=0.02)
        slow_print(f"{Fore.WHITE}⚡ Dream energy: {self.dream_energy}%", delay=0.02)
        
        time.sleep(2)
    
    def generate_dream_fragments(self):
        """Generate random dream fragments for collection"""
        self.dream_fragments = []
        
        realm_info = self.dream_realms[self.current_dream_realm]
        fragments_count = realm_info["fragments_needed"] + 3  # Extra fragments for choice
        
        categories = list(self.fragment_categories.keys())
        
        for _ in range(fragments_count):
            category = random.choice(categories)
            category_data = self.fragment_categories[category]
            
            emoji = random.choice(category_data["emojis"])
            descriptor = random.choice(category_data["descriptors"])
            
            # Lucidity affects fragment quality and coherence
            if self.lucidity_level > 70:
                quality = "vivid"
                coherence = random.randint(80, 100)
            elif self.lucidity_level > 40:
                quality = "clear"
                coherence = random.randint(60, 85)
            else:
                quality = "hazy"
                coherence = random.randint(30, 65)
            
            fragment = {
                "category": category,
                "emoji": emoji,
                "description": descriptor,
                "quality": quality,
                "coherence": coherence,
                "energy_cost": random.randint(5, 15)
            }
            
            self.dream_fragments.append(fragment)
    
    def show_fragment_collection(self):
        """Display available fragments for collection"""
        clear_screen()
        
        slow_print(Fore.CYAN + "💫 DREAM FRAGMENT COLLECTION", delay=0.03)
        slow_print(Fore.WHITE + f"💭 Lucidity: {self.lucidity_level}% | ⚡ Energy: {self.dream_energy}%", delay=0.02)
        print()
        
        slow_print(Fore.YELLOW + "🧩 Available Dream Fragments:", delay=0.02)
        
        for i, fragment in enumerate(self.dream_fragments, 1):
            quality_color = {
                "vivid": Fore.GREEN,
                "clear": Fore.YELLOW, 
                "hazy": Fore.RED
            }[fragment["quality"]]
            
            coherence_bar = "█" * (fragment["coherence"] // 10) + "░" * (10 - fragment["coherence"] // 10)
            
            print(f"{quality_color}[{i}] {fragment['emoji']} {fragment['category'].title()}")
            print(f"    {Fore.WHITE}{fragment['description']}")
            print(f"    {Fore.CYAN}Quality: {fragment['quality']} | Coherence: [{coherence_bar}] | Energy: {fragment['energy_cost']}")
            print()
        
        print(f"{Fore.WHITE}[0] 🌟 Begin weaving dream")
        print(f"{Fore.WHITE}[99] 🚪 Exit realm")
        
        slow_print(Fore.GREEN + "\n💫 Your choice: ", delay=0.02, end="")
        
        try:
            choice = input().strip()
            
            if choice == "0":
                return self.weave_dream()
            elif choice == "99":
                return False
            elif choice.isdigit() and 1 <= int(choice) <= len(self.dream_fragments):
                return self.collect_fragment(int(choice) - 1)
            else:
                slow_print(Fore.RED + "❌ Invalid choice! Try again.", delay=0.02)
                time.sleep(1.5)
                return True
        except Exception as e:
            slow_print(Fore.RED + f"❌ Error: {e}", delay=0.02)
            time.sleep(1.5)
            return True
    
    def collect_fragment(self, fragment_index):
        """Collect a specific dream fragment"""
        fragment = self.dream_fragments[fragment_index]
        
        if self.dream_energy < fragment["energy_cost"]:
            slow_print(Fore.RED + "⚡ Insufficient dream energy!", delay=0.02)
            time.sleep(1.5)
            return True
        
        self.dream_energy -= fragment["energy_cost"]
        self.collected_fragments.append(fragment)
        self.dream_fragments.remove(fragment)
        
        # Lucidity changes based on fragment quality
        if fragment["quality"] == "vivid":
            self.lucidity_level = min(100, self.lucidity_level + 3)
        elif fragment["quality"] == "hazy":
            self.lucidity_level = max(0, self.lucidity_level - 2)
        
        slow_print(f"{Fore.GREEN}✨ Collected: {fragment['emoji']} {fragment['description'][:50]}...", delay=0.02)
        slow_print(f"{Fore.CYAN}💫 Lucidity: {self.lucidity_level}% | ⚡ Energy: {self.dream_energy}%", delay=0.02)
        time.sleep(1.5)
        
        return True
    
    def weave_dream(self):
        """Weave collected fragments into a coherent dream story"""
        if len(self.collected_fragments) < self.dream_realms[self.current_dream_realm]["fragments_needed"]:
            slow_print(Fore.RED + f"❌ Need {self.dream_realms[self.current_dream_realm]['fragments_needed']} fragments to weave a dream!", delay=0.02)
            time.sleep(1.5)
            return True
        
        clear_screen()
        
        slow_print(Fore.MAGENTA + "✨ WEAVING YOUR DREAM ✨", delay=0.03)
        time.sleep(1)
        
        # Show collected fragments
        slow_print(Fore.WHITE + "🧩 Your collected fragments:", delay=0.02)
        for i, fragment in enumerate(self.collected_fragments, 1):
            print(f"{Fore.CYAN}[{i}] {fragment['emoji']} {fragment['description']}")
        
        slow_print(Fore.YELLOW + "\n📝 Select fragments to weave (enter numbers separated by spaces): ", delay=0.02, end="")
        
        try:
            choices = input().strip().split()
            selected_indices = [int(choice) - 1 for choice in choices if choice.isdigit()]
            
            if not selected_indices:
                slow_print(Fore.RED + "❌ No fragments selected!", delay=0.02)
                time.sleep(1.5)
                return True
            
            selected_fragments = [self.collected_fragments[i] for i in selected_indices 
                                if 0 <= i < len(self.collected_fragments)]
            
            if len(selected_fragments) < self.dream_realms[self.current_dream_realm]["fragments_needed"]:
                slow_print(Fore.RED + f"❌ Need at least {self.dream_realms[self.current_dream_realm]['fragments_needed']} fragments!", delay=0.02)
                time.sleep(1.5)
                return True
            
            return self.create_dream_story(selected_fragments)
            
        except ValueError:
            slow_print(Fore.RED + "❌ Please enter valid numbers!", delay=0.02)
            time.sleep(1.5)
            return True
    
    def create_dream_story(self, fragments):
        """Create a dream story from selected fragments"""
        clear_screen()
        
        slow_print(Fore.MAGENTA + "🌟 CRAFTING YOUR DREAM STORY 🌟", delay=0.03)
        time.sleep(1)
        
        # Calculate dream quality based on fragments
        total_coherence = sum(f["coherence"] for f in fragments)
        avg_coherence = total_coherence / len(fragments)
        
        lucidity_bonus = self.lucidity_level / 100
        final_quality = int(avg_coherence * (1 + lucidity_bonus))
        
        # Generate story structure
        story_elements = {
            "character": [f for f in fragments if f["category"] == "characters"],
            "setting": [f for f in fragments if f["category"] == "settings"],
            "object": [f for f in fragments if f["category"] == "objects"],
            "action": [f for f in fragments if f["category"] == "actions"],
            "emotion": [f for f in fragments if f["category"] == "emotions"]
        }
        
        # Create the dream narrative
        realm_info = self.dream_realms[self.current_dream_realm]
        
        slow_print(f"\n{realm_info['color']}📖 DREAM STORY: {realm_info['name']}", delay=0.03)
        time.sleep(1)
        
        # Generate narrative
        narrative_parts = []
        
        if story_elements["setting"]:
            setting = random.choice(story_elements["setting"])
            narrative_parts.append(f"In {setting['description']}")
        
        if story_elements["character"]:
            character = random.choice(story_elements["character"])
            narrative_parts.append(f"you encounter {character['description']}")
        
        if story_elements["object"]:
            obj = random.choice(story_elements["object"])
            narrative_parts.append(f"who presents you with {obj['description']}")
        
        if story_elements["action"]:
            action = random.choice(story_elements["action"])
            narrative_parts.append(f"Together, you begin {action['description']}")
        
        if story_elements["emotion"]:
            emotion = random.choice(story_elements["emotion"])
            narrative_parts.append(f"filling the dream with {emotion['description']}")
        
        # Display the story
        for part in narrative_parts:
            slow_print(f"{Fore.WHITE}   {part}...", delay=0.02)
            time.sleep(1)
        
        # Dream conclusion
        if final_quality >= 80:
            conclusion = "The dream crystallizes into perfect clarity, becoming a masterpiece of the subconscious mind."
            quality_desc = "MASTERPIECE"
            quality_color = Fore.MAGENTA
        elif final_quality >= 65:
            conclusion = "The dream flows with beautiful coherence, touching the depths of imagination."
            quality_desc = "EXCELLENT"
            quality_color = Fore.GREEN
        elif final_quality >= 50:
            conclusion = "The dream weaves together nicely, creating a memorable experience."
            quality_desc = "GOOD"
            quality_color = Fore.YELLOW
        else:
            conclusion = "The dream shifts and morphs, beautiful in its chaotic uncertainty."
            quality_desc = "SURREAL"
            quality_color = Fore.BLUE
        
        slow_print(f"\n{Fore.WHITE}   {conclusion}", delay=0.02)
        time.sleep(2)
        
        # Score the dream
        points = final_quality * len(fragments)
        self.creativity_score += points
        
        # Save the dream
        dream_record = {
            "realm": self.current_dream_realm,
            "fragments": fragments,
            "narrative": narrative_parts,
            "quality": final_quality,
            "quality_desc": quality_desc,
            "points": points
        }
        self.woven_dreams.append(dream_record)
        
        # Display results
        slow_print(f"\n{quality_color}🌟 DREAM QUALITY: {quality_desc} ({final_quality}%)", delay=0.03)
        slow_print(f"{Fore.YELLOW}💰 Points earned: {points}", delay=0.02)
        slow_print(f"{Fore.CYAN}🏆 Total creativity: {self.creativity_score}", delay=0.02)
        
        # Remove used fragments
        for fragment in fragments:
            if fragment in self.collected_fragments:
                self.collected_fragments.remove(fragment)
        
        # Restore some energy
        self.dream_energy = min(100, self.dream_energy + 20)
        
        time.sleep(3)
        
        # Check if realm is complete
        if len(self.woven_dreams) >= 1:  # One dream per realm
            return self.complete_realm()
        
        return True
    
    def complete_realm(self):
        """Complete current realm and advance"""
        clear_screen()
        
        realm_info = self.dream_realms[self.current_dream_realm]
        
        completion_banner = create_banner("REALM COMPLETE", color=realm_info["color"])
        print(completion_banner)
        
        slow_print(f"{realm_info['color']}🌟 {realm_info['name']} mastered!", delay=0.03)
        time.sleep(1)
        
        # Show dream created in this realm
        latest_dream = self.woven_dreams[-1]
        slow_print(f"\n{Fore.WHITE}📜 Your Dream Creation:", delay=0.02)
        slow_print(f"{realm_info['color']}   Quality: {latest_dream['quality_desc']} ({latest_dream['quality']}%)", delay=0.02)
        slow_print(f"{Fore.YELLOW}   Points: {latest_dream['points']}", delay=0.02)
        
        time.sleep(2)
        
        if self.current_dream_realm < self.max_realms:
            slow_print(f"\n{Fore.CYAN}🌌 Preparing to enter realm {self.current_dream_realm + 1}...", delay=0.03)
            self.current_dream_realm += 1
            self.lucidity_level = min(100, self.lucidity_level + 10)  # Realm completion bonus
            time.sleep(2)
            return True
        else:
            return False  # All realms complete
    
    def show_final_dreamscape(self):
        """Show the final collection of woven dreams"""
        clear_screen()
        
        master_banner = create_banner("MASTER DREAM WEAVER", color=Fore.MAGENTA)
        print(master_banner)
        
        slow_print(rainbow_text("💭 You have mastered the art of dream weaving! 💭"), delay=0.05)
        time.sleep(2)
        
        # Show all woven dreams
        slow_print(f"\n{Fore.YELLOW}🌟 YOUR DREAM COLLECTION:", delay=0.03)
        
        for i, dream in enumerate(self.woven_dreams, 1):
            realm_info = self.dream_realms[dream["realm"]]
            slow_print(f"{realm_info['color']}   {i}. {realm_info['name']} - {dream['quality_desc']}", delay=0.02)
            time.sleep(0.3)
        
        # Final statistics
        total_dreams = len(self.woven_dreams)
        avg_quality = sum(dream["quality"] for dream in self.woven_dreams) / total_dreams if total_dreams > 0 else 0
        
        stats = [
            f"\n📊 DREAM WEAVER STATISTICS:",
            f"🌟 Dreams woven: {total_dreams}",
            f"🎭 Realms mastered: {self.current_dream_realm}/{self.max_realms}",
            f"💫 Average quality: {avg_quality:.1f}%",
            f"🏆 Total creativity: {self.creativity_score}",
            f"💭 Final lucidity: {self.lucidity_level}%",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Dream mastery evaluation
        if avg_quality >= 80:
            slow_print(rainbow_text("🌌 LUCID DREAM MASTER! 🌌"), delay=0.05)
            evaluation = "Your dreams transcend reality itself!"
        elif avg_quality >= 65:
            slow_print(Fore.MAGENTA + "✨ Surreal Storyteller! ✨", delay=0.03)
            evaluation = "You weave dreams of extraordinary beauty!"
        elif avg_quality >= 50:
            slow_print(Fore.YELLOW + "🌙 Dream Artisan! 🌙", delay=0.03)
            evaluation = "Your imagination creates wonderful dreamscapes!"
        elif avg_quality >= 35:
            slow_print(Fore.BLUE + "💭 Dreaming Student! 💭", delay=0.03)
            evaluation = "You're learning to shape the realm of dreams!"
        else:
            slow_print(Fore.WHITE + "🌱 Sleepy Apprentice! 🌱", delay=0.03)
            evaluation = "Your journey into dreams has just begun!"
        
        slow_print(f"\n{Fore.WHITE}💫 {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def regenerate_energy(self):
        """Slowly regenerate dream energy"""
        if self.dream_energy < 100:
            self.dream_energy = min(100, self.dream_energy + 2)
    
    def game_loop(self):
        """Main game loop"""
        while self.current_dream_realm <= self.max_realms:
            # Show current realm
            self.show_dream_realm()
            
            # Generate fragments for this realm
            self.generate_dream_fragments()
            
            # Realm exploration loop
            while True:
                # Regenerate energy
                self.regenerate_energy()
                
                # Show fragment collection interface
                continue_realm = self.show_fragment_collection()
                
                if not continue_realm:
                    break  # Exit realm or advance to next
            
            # Check if all realms completed
            if self.current_dream_realm > self.max_realms:
                break
        
        # Show final results
        self.show_final_dreamscape()

def main():
    """Main game entry point"""
    try:
        game = DreamWeaver()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your dreams await your return, master weaver!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Dream error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
