# 🔊 Echo Chamber

**Created by Bhavyansh Soni**

## Description
An innovative sound wave puzzle game where players solve acoustic challenges using wave physics! Visualize sound waves as colorful terminal patterns, manipulate frequency and amplitude, and explore the fascinating science of acoustics through interactive experimentation and musical harmony.

## Core Concept
Sound is vibration traveling through air as waves. In Echo Chamber, you become an acoustic scientist, controlling wave properties to solve puzzles that demonstrate real physics principles. Each challenge teaches fundamental concepts while creating beautiful visualizations of invisible sound phenomena.

## Gameplay Features
- 🌊 **Wave Physics Simulation**: Realistic frequency, amplitude, and wave type control
- 🎵 **Musical Integration**: Work with actual musical notes and frequencies
- 〰️ **5 Wave Types**: Sine, square, triangle, sawtooth, and noise waves
- 🔬 **Scientific Accuracy**: Based on real acoustic physics principles
- 🎯 **10 Progressive Challenges**: From basic waves to complex acoustic mastery
- 🎼 **Harmonic Analysis**: Explore overtones, chords, and interference patterns

## Wave Physics Fundamentals

### **Frequency (Hz)**
- **Definition**: Number of wave cycles per second
- **Effect**: Determines pitch - higher frequency = higher pitch
- **Range**: 20 Hz (deep bass) to 2000 Hz (high treble)
- **Musical Notes**: A4 = 440 Hz (standard tuning reference)

### **Amplitude (0.1-1.0)**
- **Definition**: Height of the wave pattern
- **Effect**: Controls volume/loudness
- **Physics**: Higher amplitude = more acoustic energy
- **Visualization**: Taller waves in the chamber display

### **Wave Types & Characteristics**

#### 〰️ **Sine Wave**
- **Shape**: Smooth, curved oscillation
- **Sound**: Pure, fundamental tone
- **Physics**: Most basic wave form, single frequency
- **Use**: Musical instruments, tuning forks

#### ⬜ **Square Wave**
- **Shape**: Sharp on/off pulses
- **Sound**: Hollow, digital tone
- **Physics**: Contains odd harmonics (3f, 5f, 7f...)
- **Use**: Electronic music, synthesizers

#### 📐 **Triangle Wave**
- **Shape**: Linear ascending/descending
- **Sound**: Softer than square, fuller than sine
- **Physics**: Contains odd harmonics with lower amplitude
- **Use**: Flute-like tones, smooth synthesis

#### 🪚 **Sawtooth Wave**
- **Shape**: Sharp rise, rapid fall
- **Sound**: Bright, buzzing tone
- **Physics**: Contains all harmonics (2f, 3f, 4f...)
- **Use**: String instruments, brass-like sounds

#### 📡 **Noise Wave**
- **Shape**: Random, chaotic pattern
- **Sound**: Static, hissing texture
- **Physics**: All frequencies at random amplitudes
- **Use**: Percussion, sound effects, masking

## Musical Note Frequencies
The game includes standard musical notes with precise frequencies:

- **C**: 261.63 Hz (Do)
- **D**: 293.66 Hz (Re)
- **E**: 329.63 Hz (Mi)
- **F**: 349.23 Hz (Fa)
- **G**: 392.00 Hz (Sol)
- **A**: 440.00 Hz (La) - Concert pitch
- **B**: 493.88 Hz (Ti)

Plus sharps/flats: C#, D#, F#, G#, A#

## The Ten Acoustic Challenges

### 🎵 **Level 1: First Resonance**
- **Goal**: Create a perfect sine wave at A4 (440 Hz)
- **Learning**: Basic wave generation and control
- **Physics**: Pure tone fundamentals
- **Success**: Match frequency, amplitude, and wave type exactly

### 🎼 **Level 2: Harmonic Interval**
- **Goal**: Create harmonic frequencies (440 Hz + 880 Hz octave)
- **Learning**: Harmonic series and musical intervals
- **Physics**: Frequency doubling creates octaves
- **Success**: Generate frequencies in harmonic relationship

### ⚡ **Level 3: Digital Pulse**
- **Goal**: Master square wave generation
- **Learning**: Non-sinusoidal wave properties
- **Physics**: Harmonic content in complex waveforms
- **Success**: Create stable square wave pattern

### 🔺 **Level 4: Triangle Echo**
- **Goal**: Sustain triangle wave with controlled amplitude
- **Learning**: Wave shape affects timbre
- **Physics**: Linear wave transitions and harmonic content
- **Success**: Maintain consistent triangle wave output

### 🌊 **Level 5: Wave Interference**
- **Goal**: Combine waves to create interference patterns
- **Learning**: Constructive and destructive interference
- **Physics**: Wave superposition principle
- **Success**: Generate beating patterns from close frequencies

### 🎯 **Level 6: Frequency Hunt**
- **Goal**: Match a mystery frequency by ear
- **Learning**: Frequency discrimination and tuning
- **Physics**: Critical listening and pitch recognition
- **Success**: Match target frequency within 3 Hz

### 📡 **Level 7: Noise Cancellation**
- **Goal**: Use destructive interference to cancel noise
- **Learning**: Active noise control principles
- **Physics**: Phase relationships and cancellation
- **Success**: Generate appropriate anti-phase signals

### 🎶 **Level 8: Perfect Chord**
- **Goal**: Create a major triad (C-E-G: 261-329-392 Hz)
- **Learning**: Musical harmony and chord theory
- **Physics**: Consonant frequency relationships
- **Success**: Generate chord tones in proper ratios

### 🌀 **Level 9: Standing Wave**
- **Goal**: Create stable standing wave pattern
- **Learning**: Resonance and wave reflection
- **Physics**: Node and antinode formation
- **Success**: Achieve resonant frequency with high amplitude

### 🎼 **Level 10: Acoustic Mastery**
- **Goal**: Demonstrate mastery of all wave principles
- **Learning**: Integration of all acoustic concepts
- **Physics**: Complete understanding of wave behavior
- **Success**: Show proficiency across all wave types and frequencies

## Acoustic Control Commands

### **Wave Parameter Control**
- `freq <hz>` - Set frequency (20-2000 Hz)
- `amp <val>` - Set amplitude (0.1-1.0)
- `wave <type>` - Set wave type (sine/square/triangle/sawtooth/noise)
- `note <note>` - Set to musical note (C, D, E, F, G, A, B, C#, etc.)

### **Wave Generation & Analysis**
- `play` - Generate and "play" current wave (costs 10% energy)
- `harmonize` - Add harmonic frequencies (costs 20% energy)
- `analyze` - Detailed wave analysis including RMS, peak values
- `solve` - Attempt to solve current challenge

### **Navigation**
- `quit` - Exit to main menu

## Wave Visualization System
The chamber displays waves as emoji patterns across a 32×12 grid:
- **Horizontal axis**: Time progression through wave cycle
- **Vertical axis**: Amplitude (wave height)
- **Center line**: Zero amplitude reference
- **Wave emoji**: Changes based on current wave type
- **Color coding**: Each wave type has unique color

## Scoring & Evaluation

### **Challenge Scoring**
- **Frequency Control**: Precision in hitting target frequencies
- **Amplitude Control**: Accuracy in setting wave amplitude
- **Energy Efficiency**: Conservation of acoustic energy
- **Total Score**: Average of all control metrics

### **Acoustic Analysis Metrics**
- **Peak Value**: Maximum wave amplitude
- **Trough Value**: Minimum wave amplitude
- **RMS Value**: Root mean square (average energy)
- **Dynamic Range**: Difference between peak and trough
- **Musical Tuning**: Cents deviation from nearest note

## Achievement Levels
- 🌟 **Sound Wave Scientist**: Complete all 10 levels with high scores
- 🔊 **Acoustic Engineer**: Complete 8+ levels with expertise
- 🎵 **Wave Pattern Expert**: Complete 6+ levels successfully
- 🎼 **Sound Explorer**: Complete 4+ levels while learning
- 🌱 **Audio Apprentice**: Beginning the acoustic journey

## Real-World Applications
Echo Chamber teaches concepts used in:
- **Audio Engineering**: Recording, mixing, mastering
- **Musical Instrument Design**: Understanding harmonics and timbre
- **Noise Control**: Active cancellation systems
- **Medical Ultrasonics**: Frequency-based imaging
- **Architectural Acoustics**: Room resonance and echo control
- **Digital Signal Processing**: Wave manipulation algorithms

## Educational Value
- **Physics Understanding**: Wave mechanics, frequency, amplitude
- **Mathematical Concepts**: Trigonometry, harmonic series
- **Musical Theory**: Notes, intervals, chords, tuning
- **Scientific Method**: Hypothesis testing through experimentation
- **Pattern Recognition**: Visual wave analysis and interpretation
- **Critical Listening**: Developing acoustic sensitivity

## Advanced Concepts Explored
- **Harmonic Series**: How complex tones contain multiple frequencies
- **Wave Interference**: Constructive and destructive combinations
- **Standing Waves**: Resonance phenomena in enclosed spaces
- **Fourier Analysis**: Breaking complex waves into simple components
- **Psychoacoustics**: How humans perceive different wave shapes
- **Digital Audio**: Sampling and quantization effects

## Tips for Acoustic Mastery
1. **Start with Sine Waves**: Master pure tones before complex shapes
2. **Learn Musical Notes**: Memorize standard frequencies
3. **Experiment with Harmonics**: Understand octave relationships
4. **Practice Precision**: Small frequency changes have big effects
5. **Visualize Patterns**: Learn to read wave shapes in the display
6. **Energy Management**: Conservation leads to higher scores
7. **Scientific Approach**: Form hypotheses and test systematically

## The Science Behind Sound
"Sound is invisible sculpture in air - waves of pressure that carry information, emotion, and beauty. Echo Chamber reveals the hidden mathematics of music, the physics of hearing, and the profound connection between mathematical ratios and aesthetic pleasure. Every frequency tells a story, every amplitude carries energy, and every wave shape paints a unique sonic landscape."


