#!/usr/bin/env python3
"""
🔊 ECHO CHAMBER 🔊
Created by Bhavyansh Soni

An original sound wave puzzle game where players solve challenges using audio patterns!
Visualize sound waves as colorful patterns, manipulate frequency and amplitude,
and create harmony through the science of acoustics and wave physics!
"""

import random
import time
import sys
import os
import math
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class EchoChamber:
    def __init__(self):
        self.chamber_width = 32
        self.chamber_height = 12
        self.sound_waves = []
        self.echo_patterns = []
        self.current_frequency = 440.0  # A4 note
        self.current_amplitude = 0.8
        self.wave_type = "sine"
        self.resonance_level = 1
        self.max_levels = 10
        self.acoustic_energy = 100
        self.harmony_score = 0
        
        # Sound wave types with visual patterns
        self.wave_types = {
            "sine": {
                "emoji": "〰️", "color": Fore.CYAN, "description": "Smooth flowing waves",
                "pattern": lambda x, freq, amp: amp * math.sin(2 * math.pi * freq * x / 100)
            },
            "square": {
                "emoji": "⬜", "color": Fore.YELLOW, "description": "Sharp digital pulses",
                "pattern": lambda x, freq, amp: amp * (1 if math.sin(2 * math.pi * freq * x / 100) > 0 else -1)
            },
            "triangle": {
                "emoji": "📐", "color": Fore.GREEN, "description": "Linear ascending waves",
                "pattern": lambda x, freq, amp: amp * (2 * abs((freq * x / 100) % 1 - 0.5) - 0.5) * 2
            },
            "sawtooth": {
                "emoji": "🪚", "color": Fore.RED, "description": "Jagged cutting waves",
                "pattern": lambda x, freq, amp: amp * (2 * ((freq * x / 100) % 1) - 1)
            },
            "noise": {
                "emoji": "📡", "color": Fore.WHITE, "description": "Random chaotic patterns",
                "pattern": lambda x, freq, amp: amp * (random.random() * 2 - 1)
            }
        }
        
        # Musical frequencies (in Hz)
        self.musical_notes = {
            "C": 261.63, "C#": 277.18, "D": 293.66, "D#": 311.13,
            "E": 329.63, "F": 349.23, "F#": 369.99, "G": 392.00,
            "G#": 415.30, "A": 440.00, "A#": 466.16, "B": 493.88
        }
        
        # Echo challenges with acoustic puzzles
        self.echo_challenges = {
            1: {
                "name": "🎵 First Resonance",
                "description": "Learn to create a simple sine wave",
                "target_frequency": 440.0, "target_amplitude": 0.8, "target_wave": "sine",
                "success_criteria": "match_wave_exactly"
            },
            2: {
                "name": "🎼 Harmonic Interval",
                "description": "Create two waves in harmony (octave)",
                "target_frequency": [440.0, 880.0], "target_amplitude": 0.7, "target_wave": "sine",
                "success_criteria": "create_harmony"
            },
            3: {
                "name": "⚡ Digital Pulse",
                "description": "Master the square wave pattern",
                "target_frequency": 330.0, "target_amplitude": 0.9, "target_wave": "square",
                "success_criteria": "match_wave_type"
            },
            4: {
                "name": "🔺 Triangle Echo",
                "description": "Create smooth triangle wave echoes",
                "target_frequency": 523.25, "target_amplitude": 0.6, "target_wave": "triangle",
                "success_criteria": "sustain_echo"
            },
            5: {
                "name": "🌊 Wave Interference",
                "description": "Combine waves to create interference patterns",
                "target_frequency": [440.0, 466.16], "target_amplitude": 0.5, "target_wave": "sine",
                "success_criteria": "interference_pattern"
            },
            6: {
                "name": "🎯 Frequency Hunt",
                "description": "Match a mystery frequency by ear",
                "target_frequency": random.choice(list(self.musical_notes.values())),
                "target_amplitude": 0.8, "target_wave": "sine",
                "success_criteria": "frequency_match"
            },
            7: {
                "name": "📡 Noise Cancellation",
                "description": "Use destructive interference to cancel noise",
                "target_frequency": 350.0, "target_amplitude": 0.7, "target_wave": "noise",
                "success_criteria": "noise_cancellation"
            },
            8: {
                "name": "🎶 Perfect Chord",
                "description": "Create a three-note major chord",
                "target_frequency": [261.63, 329.63, 392.00], "target_amplitude": 0.6, "target_wave": "sine",
                "success_criteria": "major_chord"
            },
            9: {
                "name": "🌀 Standing Wave",
                "description": "Create a stable standing wave pattern",
                "target_frequency": 440.0, "target_amplitude": 1.0, "target_wave": "sine",
                "success_criteria": "standing_wave"
            },
            10: {
                "name": "🎼 Acoustic Mastery",
                "description": "Demonstrate mastery of all wave types",
                "target_frequency": [220.0, 440.0, 880.0], "target_amplitude": 0.8, "target_wave": "all",
                "success_criteria": "acoustic_mastery"
            }
        }
        
    def show_intro(self):
        """Display game introduction and acoustic science concepts"""
        clear_screen()
        
        intro_banner = create_banner("ECHO CHAMBER", color=Fore.CYAN)
        print(intro_banner)
        
        slow_print(rainbow_text("🔊 Welcome to the fascinating world of sound wave science! 🔊"), delay=0.03)
        time.sleep(1)
        
        acoustic_intro = [
            "\n🌊 WAVE PHYSICS FUNDAMENTALS:",
            "Sound is vibration traveling through air as waves.",
            "Frequency determines pitch - how high or low a sound is.",
            "Amplitude controls volume - how loud or quiet a sound is.",
            "Different wave shapes create unique timbres and textures.",
            "Waves can combine, interfere, and create complex patterns!",
            "",
            "🔬 ACOUSTIC PHENOMENA:",
            "🎵 Resonance: When waves amplify each other",
            "🌊 Interference: When waves combine constructively or destructively",
            "📡 Echo: Sound waves bouncing back from surfaces",
            "🎼 Harmony: Multiple frequencies that sound pleasant together",
            "⚡ Beats: Rhythmic volume changes from close frequencies",
            "",
            "🎯 ECHO CHAMBER MECHANICS:",
            "🎛️ Control frequency, amplitude, and wave type",
            "🔊 Visualize sound waves as colorful patterns",
            "🎵 Solve acoustic puzzles using wave science",
            "🏆 Master 10 levels of sound wave challenges!",
        ]
        
        for text in acoustic_intro:
            if text.startswith("🌊") or text.startswith("🔬") or text.startswith("🎯"):
                slow_print(Fore.YELLOW + text, delay=0.02)
            elif text == "":
                print()
            else:
                slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.GREEN + "\n🔊 Ready to explore the science of sound? Press ENTER to begin!", delay=0.03)
        input()
    
    def show_level_intro(self):
        """Display introduction for current echo challenge"""
        clear_screen()
        
        challenge = self.echo_challenges[self.resonance_level]
        
        level_banner = create_banner(f"LEVEL {self.resonance_level}", color=Fore.CYAN)
        print(level_banner)
        
        slow_print(f"{Fore.CYAN}🔊 {challenge['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"\n{Fore.WHITE}📝 Challenge: {challenge['description']}", delay=0.02)
        
        # Show target parameters
        if isinstance(challenge["target_frequency"], list):
            freqs = ", ".join([f"{f:.1f}Hz" for f in challenge["target_frequency"]])
            slow_print(f"{Fore.WHITE}🎵 Target Frequencies: {freqs}", delay=0.02)
        else:
            slow_print(f"{Fore.WHITE}🎵 Target Frequency: {challenge['target_frequency']:.1f}Hz", delay=0.02)
        
        slow_print(f"{Fore.WHITE}📈 Target Amplitude: {challenge['target_amplitude']:.1f}", delay=0.02)
        slow_print(f"{Fore.WHITE}〰️ Target Wave Type: {challenge['target_wave']}", delay=0.02)
        slow_print(f"{Fore.WHITE}🔊 Acoustic Energy: {self.acoustic_energy}%", delay=0.02)
        
        time.sleep(2)
        slow_print(Fore.GREEN + "\n🎛️ Initialize acoustic chamber? Press ENTER...", delay=0.03)
        input()
    
    def draw_wave_chamber(self):
        """Draw the acoustic chamber with sound wave visualizations"""
        clear_screen()
        
        challenge = self.echo_challenges[self.resonance_level]
        
        # Header
        energy_color = Fore.GREEN if self.acoustic_energy > 60 else Fore.YELLOW if self.acoustic_energy > 30 else Fore.RED
        header = f"🔊 ECHO CHAMBER | Level {self.resonance_level}: {challenge['name']} | Harmony: {self.harmony_score}"
        print(Fore.CYAN + header)
        
        wave_info = f"🎵 Freq: {self.current_frequency:.1f}Hz | 📈 Amp: {self.current_amplitude:.1f} | 〰️ Type: {self.wave_type} | Energy: {energy_color}{self.acoustic_energy}%"
        print(Fore.WHITE + wave_info)
        print(Fore.WHITE + "─" * 80)
        
        # Create wave visualization
        wave_pattern = self.generate_wave_pattern()
        
        # Draw wave chamber
        for y in range(self.chamber_height):
            row = ""
            for x in range(self.chamber_width):
                # Calculate wave amplitude at this position
                wave_value = wave_pattern[x] if x < len(wave_pattern) else 0
                
                # Convert wave value to visual representation
                normalized_y = int((wave_value + 1) * (self.chamber_height - 1) / 2)
                
                if y == normalized_y:
                    wave_info = self.wave_types[self.wave_type]
                    row += wave_info["color"] + wave_info["emoji"]
                elif y == self.chamber_height // 2:  # Center line
                    row += Fore.WHITE + "─"
                else:
                    row += " "
            
            print(f"{y%10} {row}")
        
        print(Fore.WHITE + "─" * 80)
        
        # Show current wave properties
        current_wave = self.wave_types[self.wave_type]
        print(f"{current_wave['color']}🔊 Current Wave: {current_wave['emoji']} {self.wave_type.title()} - {current_wave['description']}")
        
        # Show musical note if applicable
        closest_note = self.get_closest_musical_note(self.current_frequency)
        if closest_note:
            print(f"{Fore.YELLOW}🎵 Musical Note: {closest_note}")
    
    def generate_wave_pattern(self):
        """Generate wave pattern based on current parameters"""
        pattern = []
        wave_func = self.wave_types[self.wave_type]["pattern"]
        
        for x in range(self.chamber_width):
            # Calculate wave value
            if self.wave_type == "noise":
                # Noise needs fresh random values
                value = wave_func(x, self.current_frequency, self.current_amplitude)
            else:
                value = wave_func(x, self.current_frequency, self.current_amplitude)
            
            # Clamp to [-1, 1] range
            value = max(-1, min(1, value))
            pattern.append(value)
        
        return pattern
    
    def get_closest_musical_note(self, frequency):
        """Find the closest musical note to the given frequency"""
        closest_note = None
        min_difference = float('inf')
        
        for note, freq in self.musical_notes.items():
            difference = abs(frequency - freq)
            if difference < min_difference:
                min_difference = difference
                closest_note = note
        
        # Only return if reasonably close (within 10 Hz)
        if min_difference < 10:
            return closest_note
        return None
    
    def show_acoustic_menu(self):
        """Show acoustic control interface"""
        print(f"\n{Fore.GREEN}🔊 Acoustic Controls:")
        print(f"{Fore.WHITE}freq <hz> - Set frequency (20-2000 Hz)")
        print(f"{Fore.WHITE}amp <val> - Set amplitude (0.1-1.0)")
        print(f"{Fore.WHITE}wave <type> - Set wave type (sine/square/triangle/sawtooth/noise)")
        print(f"{Fore.WHITE}note <note> - Set to musical note (C, D, E, F, G, A, B)")
        print(f"{Fore.WHITE}play - Generate and play current wave")
        print(f"{Fore.WHITE}harmonize - Add harmonic frequencies")
        print(f"{Fore.WHITE}analyze - Analyze current wave properties")
        print(f"{Fore.WHITE}solve - Attempt to solve current challenge")
        print(f"{Fore.WHITE}quit - Exit to main menu")
        
        slow_print(Fore.CYAN + "\n🎛️ Your command: ", delay=0.02, end="")
        
        try:
            command = input().strip().lower()
            return command
        except:
            return ""
    
    def process_acoustic_command(self, command):
        """Process acoustic control commands"""
        parts = command.split()
        
        if not parts:
            return True
        
        action = parts[0]
        
        if action == "freq" and len(parts) >= 2:
            try:
                frequency = float(parts[1])
                return self.set_frequency(frequency)
            except ValueError:
                slow_print(Fore.RED + "❌ Please use: freq <number>", delay=0.02)
                time.sleep(1.5)
        
        elif action == "amp" and len(parts) >= 2:
            try:
                amplitude = float(parts[1])
                return self.set_amplitude(amplitude)
            except ValueError:
                slow_print(Fore.RED + "❌ Please use: amp <0.1-1.0>", delay=0.02)
                time.sleep(1.5)
        
        elif action == "wave" and len(parts) >= 2:
            wave_type = parts[1]
            return self.set_wave_type(wave_type)
        
        elif action == "note" and len(parts) >= 2:
            note = parts[1].upper()
            return self.set_musical_note(note)
        
        elif action == "play":
            return self.play_wave()
        
        elif action == "harmonize":
            return self.add_harmonics()
        
        elif action == "analyze":
            return self.analyze_wave()
        
        elif action == "solve":
            return self.solve_challenge()
        
        elif action == "quit":
            return False
        
        else:
            slow_print(Fore.RED + "❌ Unknown command! See menu above.", delay=0.02)
            time.sleep(1.5)
        
        return True
    
    def set_frequency(self, frequency):
        """Set the current frequency"""
        if 20 <= frequency <= 2000:
            self.current_frequency = frequency
            slow_print(f"{Fore.GREEN}🎵 Frequency set to {frequency:.1f}Hz", delay=0.02)
            
            # Show musical note if applicable
            note = self.get_closest_musical_note(frequency)
            if note:
                slow_print(f"{Fore.YELLOW}🎵 Near musical note: {note}", delay=0.02)
        else:
            slow_print(Fore.RED + "❌ Frequency must be between 20 and 2000 Hz", delay=0.02)
        
        time.sleep(1)
        return True
    
    def set_amplitude(self, amplitude):
        """Set the current amplitude"""
        if 0.1 <= amplitude <= 1.0:
            self.current_amplitude = amplitude
            slow_print(f"{Fore.GREEN}📈 Amplitude set to {amplitude:.1f}", delay=0.02)
        else:
            slow_print(Fore.RED + "❌ Amplitude must be between 0.1 and 1.0", delay=0.02)
        
        time.sleep(1)
        return True
    
    def set_wave_type(self, wave_type):
        """Set the current wave type"""
        if wave_type in self.wave_types:
            self.wave_type = wave_type
            wave_info = self.wave_types[wave_type]
            slow_print(f"{wave_info['color']}〰️ Wave type set to {wave_type} ({wave_info['description']})", delay=0.02)
        else:
            available_types = ", ".join(self.wave_types.keys())
            slow_print(Fore.RED + f"❌ Available wave types: {available_types}", delay=0.02)
        
        time.sleep(1)
        return True
    
    def set_musical_note(self, note):
        """Set frequency to a musical note"""
        if note in self.musical_notes:
            frequency = self.musical_notes[note]
            self.current_frequency = frequency
            slow_print(f"{Fore.YELLOW}🎵 Set to note {note} ({frequency:.2f}Hz)", delay=0.02)
        else:
            available_notes = ", ".join(self.musical_notes.keys())
            slow_print(Fore.RED + f"❌ Available notes: {available_notes}", delay=0.02)
        
        time.sleep(1)
        return True
    
    def play_wave(self):
        """Simulate playing the current wave"""
        if self.acoustic_energy < 10:
            slow_print(Fore.RED + "🔊 Insufficient acoustic energy!", delay=0.02)
            time.sleep(1.5)
            return True
        
        self.acoustic_energy -= 10
        
        wave_info = self.wave_types[self.wave_type]
        
        slow_print(f"{wave_info['color']}🔊 Playing {self.wave_type} wave...", delay=0.03)
        
        # Simulate wave playback with visual effects
        for i in range(5):
            frequency_indicator = "♪" * (int(self.current_frequency / 100) + 1)
            amplitude_indicator = "█" * int(self.current_amplitude * 10)
            
            print(f"\r{wave_info['color']}{frequency_indicator} Vol: {amplitude_indicator}", end='', flush=True)
            time.sleep(0.3)
        
        print()
        slow_print(f"{Fore.GREEN}✅ Wave playback complete!", delay=0.02)
        time.sleep(1)
        
        return True
    
    def add_harmonics(self):
        """Add harmonic frequencies to create rich tones"""
        if self.acoustic_energy < 20:
            slow_print(Fore.RED + "🔊 Insufficient energy for harmonics!", delay=0.02)
            time.sleep(1.5)
            return True
        
        self.acoustic_energy -= 20
        
        slow_print(Fore.MAGENTA + "🎼 Adding harmonic frequencies...", delay=0.03)
        
        # Calculate harmonic frequencies (octaves)
        harmonics = [
            self.current_frequency * 2,  # First octave
            self.current_frequency * 3,  # Fifth above octave
            self.current_frequency * 4   # Second octave
        ]
        
        slow_print(f"{Fore.CYAN}🎵 Fundamental: {self.current_frequency:.1f}Hz", delay=0.02)
        
        for i, harmonic in enumerate(harmonics, 2):
            if harmonic <= 2000:  # Within audible range
                slow_print(f"{Fore.YELLOW}🎵 Harmonic {i}: {harmonic:.1f}Hz", delay=0.02)
                time.sleep(0.5)
        
        slow_print(f"{Fore.GREEN}✨ Harmonic series generated!", delay=0.02)
        time.sleep(1.5)
        
        return True
    
    def analyze_wave(self):
        """Analyze current wave properties in detail"""
        clear_screen()
        
        slow_print(Fore.CYAN + "🔬 WAVE ANALYSIS", delay=0.03)
        time.sleep(1)
        
        wave_info = self.wave_types[self.wave_type]
        
        # Basic properties
        analysis = [
            f"🎵 Frequency: {self.current_frequency:.2f} Hz",
            f"📈 Amplitude: {self.current_amplitude:.2f}",
            f"〰️ Wave Type: {self.wave_type.title()}",
            f"🎨 Visual: {wave_info['emoji']} {wave_info['description']}",
        ]
        
        for item in analysis:
            slow_print(Fore.WHITE + item, delay=0.02)
            time.sleep(0.3)
        
        # Musical analysis
        note = self.get_closest_musical_note(self.current_frequency)
        if note:
            note_freq = self.musical_notes[note]
            cents_off = 1200 * math.log2(self.current_frequency / note_freq)
            slow_print(f"\n{Fore.YELLOW}🎵 Closest Note: {note} ({note_freq:.2f}Hz)", delay=0.02)
            slow_print(f"{Fore.WHITE}🎯 Tuning: {cents_off:+.1f} cents", delay=0.02)
        
        # Wave shape analysis
        pattern = self.generate_wave_pattern()
        peak_value = max(pattern)
        trough_value = min(pattern)
        rms_value = math.sqrt(sum(x*x for x in pattern) / len(pattern))
        
        wave_analysis = [
            f"\n📊 WAVE SHAPE ANALYSIS:",
            f"📈 Peak Value: {peak_value:.3f}",
            f"📉 Trough Value: {trough_value:.3f}",
            f"📊 RMS Value: {rms_value:.3f}",
            f"⚖️ Dynamic Range: {peak_value - trough_value:.3f}",
        ]
        
        for item in wave_analysis:
            slow_print(Fore.CYAN + item, delay=0.02)
            time.sleep(0.3)
        
        slow_print(Fore.WHITE + "\nPress ENTER to continue...", delay=0.02)
        input()
        return True
    
    def solve_challenge(self):
        """Attempt to solve the current acoustic challenge"""
        challenge = self.echo_challenges[self.resonance_level]
        success_criteria = challenge["success_criteria"]
        
        clear_screen()
        slow_print(Fore.YELLOW + "🎯 SOLVING ACOUSTIC CHALLENGE", delay=0.03)
        time.sleep(1)
        
        success = False
        
        if success_criteria == "match_wave_exactly":
            success = self.check_exact_match(challenge)
        elif success_criteria == "create_harmony":
            success = self.check_harmony(challenge)
        elif success_criteria == "match_wave_type":
            success = self.check_wave_type(challenge)
        elif success_criteria == "sustain_echo":
            success = self.check_echo_sustain(challenge)
        elif success_criteria == "interference_pattern":
            success = self.check_interference(challenge)
        elif success_criteria == "frequency_match":
            success = self.check_frequency_match(challenge)
        elif success_criteria == "noise_cancellation":
            success = self.check_noise_cancellation(challenge)
        elif success_criteria == "major_chord":
            success = self.check_major_chord(challenge)
        elif success_criteria == "standing_wave":
            success = self.check_standing_wave(challenge)
        elif success_criteria == "acoustic_mastery":
            success = self.check_acoustic_mastery(challenge)
        
        if success:
            return self.complete_level()
        else:
            slow_print(Fore.RED + "❌ Challenge requirements not met. Keep experimenting!", delay=0.02)
            time.sleep(2)
            return True
    
    def check_exact_match(self, challenge):
        """Check for exact parameter match"""
        freq_match = abs(self.current_frequency - challenge["target_frequency"]) < 5
        amp_match = abs(self.current_amplitude - challenge["target_amplitude"]) < 0.1
        wave_match = self.wave_type == challenge["target_wave"]
        
        return freq_match and amp_match and wave_match
    
    def check_harmony(self, challenge):
        """Check for harmonic frequencies"""
        target_freqs = challenge["target_frequency"]
        # Simplified: check if current frequency matches one of the targets
        return any(abs(self.current_frequency - freq) < 10 for freq in target_freqs)
    
    def check_wave_type(self, challenge):
        """Check for correct wave type"""
        return self.wave_type == challenge["target_wave"]
    
    def check_echo_sustain(self, challenge):
        """Check for sustained wave with proper amplitude"""
        wave_match = self.wave_type == challenge["target_wave"]
        amp_match = abs(self.current_amplitude - challenge["target_amplitude"]) < 0.2
        return wave_match and amp_match
    
    def check_interference(self, challenge):
        """Check for interference pattern creation"""
        # Simplified: check if using sine waves with close frequencies
        target_freqs = challenge["target_frequency"]
        freq_close = any(abs(self.current_frequency - freq) < 50 for freq in target_freqs)
        return self.wave_type == "sine" and freq_close
    
    def check_frequency_match(self, challenge):
        """Check for precise frequency matching"""
        return abs(self.current_frequency - challenge["target_frequency"]) < 3
    
    def check_noise_cancellation(self, challenge):
        """Check for noise cancellation setup"""
        return self.wave_type == "noise" and self.current_amplitude > 0.5
    
    def check_major_chord(self, challenge):
        """Check for major chord frequencies"""
        target_freqs = challenge["target_frequency"]
        # Check if frequency is one of the chord tones
        return any(abs(self.current_frequency - freq) < 5 for freq in target_freqs)
    
    def check_standing_wave(self, challenge):
        """Check for standing wave conditions"""
        freq_match = abs(self.current_frequency - challenge["target_frequency"]) < 5
        amp_high = self.current_amplitude >= 0.8
        return freq_match and amp_high
    
    def check_acoustic_mastery(self, challenge):
        """Check for demonstration of multiple wave types"""
        # Simplified: accept any wave with reasonable parameters
        return self.current_amplitude > 0.5 and 200 <= self.current_frequency <= 1000
    
    def complete_level(self):
        """Complete current level and advance"""
        clear_screen()
        
        challenge = self.echo_challenges[self.resonance_level]
        
        completion_banner = create_banner("ACOUSTIC SUCCESS", color=Fore.GREEN)
        print(completion_banner)
        
        slow_print(f"{Fore.GREEN}🔊 {challenge['name']} mastered!", delay=0.03)
        time.sleep(1)
        
        # Calculate acoustic mastery score
        frequency_precision = max(0, 100 - abs(self.current_frequency - 440) / 10)
        amplitude_control = self.current_amplitude * 100
        energy_efficiency = self.acoustic_energy
        
        level_score = int((frequency_precision + amplitude_control + energy_efficiency) / 3)
        self.harmony_score += level_score
        
        # Show scoring
        score_info = [
            f"\n📊 ACOUSTIC MASTERY:",
            f"🎵 Frequency Control: {frequency_precision:.1f}%",
            f"📈 Amplitude Control: {amplitude_control:.1f}%",
            f"⚡ Energy Efficiency: {energy_efficiency}%",
            f"🏆 Level Score: {level_score}",
            f"🌟 Total Harmony: {self.harmony_score}",
        ]
        
        for info in score_info:
            slow_print(Fore.CYAN + info, delay=0.02)
            time.sleep(0.5)
        
        # Restore energy
        self.acoustic_energy = min(100, self.acoustic_energy + 40)
        
        time.sleep(2)
        
        if self.resonance_level < self.max_levels:
            slow_print(f"\n{Fore.YELLOW}🔊 Preparing acoustic level {self.resonance_level + 1}...", delay=0.03)
            self.resonance_level += 1
            time.sleep(2)
            return True
        else:
            return False  # All levels complete
    
    def regenerate_energy(self):
        """Slowly regenerate acoustic energy"""
        if self.acoustic_energy < 100:
            self.acoustic_energy = min(100, self.acoustic_energy + 1)
    
    def show_final_acoustic_mastery(self):
        """Show final acoustic mastery results"""
        clear_screen()
        
        mastery_banner = create_banner("ACOUSTIC MASTER", color=Fore.MAGENTA)
        print(mastery_banner)
        
        slow_print(rainbow_text("🔊 You have mastered the science of sound waves! 🔊"), delay=0.05)
        time.sleep(2)
        
        # Show all completed challenges
        slow_print(f"\n{Fore.YELLOW}🎼 YOUR ACOUSTIC JOURNEY:", delay=0.03)
        
        for i in range(1, self.resonance_level):
            challenge = self.echo_challenges[i]
            slow_print(f"{Fore.CYAN}   {i}. {challenge['name']}", delay=0.02)
            time.sleep(0.3)
        
        # Final statistics
        avg_score = self.harmony_score // (self.resonance_level - 1) if self.resonance_level > 1 else 0
        
        stats = [
            f"\n📊 ACOUSTIC MASTERY STATISTICS:",
            f"🔊 Challenges Completed: {self.resonance_level - 1}/{self.max_levels}",
            f"🎵 Total Harmony Score: {self.harmony_score}",
            f"📈 Average Challenge Score: {avg_score}",
            f"⚡ Final Energy: {self.acoustic_energy}%",
        ]
        
        for stat in stats:
            slow_print(Fore.WHITE + stat, delay=0.02)
            time.sleep(0.5)
        
        # Acoustic mastery evaluation
        completion_rate = ((self.resonance_level - 1) / self.max_levels) * 100
        
        if completion_rate == 100 and avg_score >= 80:
            slow_print(rainbow_text("🌟 SOUND WAVE SCIENTIST! 🌟"), delay=0.05)
            evaluation = "You have unlocked the secrets of acoustic physics!"
        elif completion_rate >= 80:
            slow_print(Fore.MAGENTA + "🔊 Acoustic Engineer! 🔊", delay=0.03)
            evaluation = "Your mastery of sound waves is extraordinary!"
        elif completion_rate >= 60:
            slow_print(Fore.YELLOW + "🎵 Wave Pattern Expert! 🎵", delay=0.03)
            evaluation = "You understand the language of frequencies!"
        elif completion_rate >= 40:
            slow_print(Fore.GREEN + "🎼 Sound Explorer! 🎼", delay=0.03)
            evaluation = "You're learning to control acoustic forces!"
        else:
            slow_print(Fore.BLUE + "🌱 Audio Apprentice! 🌱", delay=0.03)
            evaluation = "Your journey into sound science has begun!"
        
        slow_print(f"\n{Fore.CYAN}🔊 {evaluation}", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.resonance_level <= self.max_levels:
            # Show level introduction
            self.show_level_intro()
            
            # Acoustic control loop
            while True:
                # Regenerate energy slowly
                self.regenerate_energy()
                
                # Draw and interact
                self.draw_wave_chamber()
                command = self.show_acoustic_menu()
                
                continue_level = self.process_acoustic_command(command)
                
                if not continue_level:
                    if self.resonance_level > self.max_levels:
                        # All levels completed
                        self.show_final_acoustic_mastery()
                    return
                elif self.resonance_level > self.max_levels:
                    # Completed all levels
                    self.show_final_acoustic_mastery()
                    return
                else:
                    # Continue level or advance
                    if command == "solve" and self.resonance_level > self.max_levels:
                        break
        
        # Show final results
        self.show_final_acoustic_mastery()

def main():
    """Main game entry point"""
    try:
        game = EchoChamber()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 The acoustic chamber awaits your return!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Acoustic error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
