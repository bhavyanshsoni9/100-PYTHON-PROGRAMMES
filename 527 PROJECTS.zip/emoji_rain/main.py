#!/usr/bin/env python3
"""
🌧️ EMOJI RAIN 🌧️
Created by Bhavyansh Soni

An original terminal game where players catch falling emojis in a colorful storm!
Use arrow keys to move your catcher and collect as many emojis as possible
before they hit the ground. Different emojis have different point values!
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style
import threading
import keyboard

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner

# Initialize colorama
init(autoreset=True)

class EmojiRain:
    def __init__(self):
        self.width = 60
        self.height = 20
        self.player_pos = self.width // 2
        self.score = 0
        self.level = 1
        self.lives = 3
        self.running = True
        self.game_speed = 0.5
        
        # Different emoji types with point values
        self.emoji_types = {
            "💎": {"points": 50, "rarity": 0.05, "color": Fore.CYAN},
            "🌟": {"points": 30, "rarity": 0.1, "color": Fore.YELLOW},
            "💰": {"points": 25, "rarity": 0.15, "color": Fore.GREEN},
            "🎁": {"points": 20, "rarity": 0.2, "color": Fore.MAGENTA},
            "🍕": {"points": 15, "rarity": 0.25, "color": Fore.RED},
            "🎈": {"points": 10, "rarity": 0.3, "color": Fore.BLUE},
            "⚡": {"points": -10, "rarity": 0.1, "color": Fore.RED},  # Penalty emoji
            "☁️": {"points": 5, "rarity": 0.4, "color": Fore.WHITE}
        }
        
        self.falling_emojis = []
        self.catcher = "🎯"
        
    def show_intro(self):
        """Display game introduction and rules"""
        clear_screen()
        
        intro_banner = create_banner("EMOJI RAIN", color=Fore.CYAN)
        print(intro_banner)
        
        slow_print(rainbow_text("🌧️ Welcome to the most EPIC emoji catching game! 🌧️"), delay=0.03)
        time.sleep(1)
        
        rules = [
            "\n📋 GAME RULES:",
            "🎯 Use A/D or ←/→ keys to move your catcher",
            "🌟 Catch falling emojis to score points",
            "💎 Rare emojis give more points!",
            "⚡ Avoid lightning bolts - they reduce your score!",
            "❤️ You have 3 lives - don't let emojis hit the ground!",
            "🚀 Speed increases with each level!",
            "\n🏆 EMOJI VALUES:",
        ]
        
        for rule in rules:
            slow_print(Fore.WHITE + rule, delay=0.02)
            time.sleep(0.3)
        
        # Show emoji values
        for emoji, data in self.emoji_types.items():
            color = data["color"]
            points = data["points"]
            if points > 0:
                slow_print(f"{color}  {emoji} = +{points} points", delay=0.02)
            else:
                slow_print(f"{color}  {emoji} = {points} points", delay=0.02)
            time.sleep(0.2)
        
        slow_print(Fore.GREEN + "\n🎮 Press ENTER to start the storm!", delay=0.03)
        input()
    
    def spawn_emoji(self):
        """Spawn a new falling emoji based on rarity"""
        # Determine which emoji to spawn based on rarity
        rand = random.random()
        cumulative_rarity = 0
        
        for emoji, data in self.emoji_types.items():
            cumulative_rarity += data["rarity"]
            if rand <= cumulative_rarity:
                x_pos = random.randint(1, self.width - 2)
                self.falling_emojis.append({
                    "emoji": emoji,
                    "x": x_pos,
                    "y": 0,
                    "data": data
                })
                break
    
    def update_emojis(self):
        """Update positions of falling emojis"""
        for emoji_obj in self.falling_emojis[:]:
            emoji_obj["y"] += 1
            
            # Check if emoji hit the ground
            if emoji_obj["y"] >= self.height - 1:
                self.falling_emojis.remove(emoji_obj)
                if emoji_obj["data"]["points"] > 0:  # Only lose life for positive emojis
                    self.lives -= 1
                    self.show_life_lost()
            
            # Check if emoji was caught
            elif (emoji_obj["y"] == self.height - 2 and 
                  abs(emoji_obj["x"] - self.player_pos) <= 1):
                self.falling_emojis.remove(emoji_obj)
                self.score += emoji_obj["data"]["points"]
                self.show_catch_effect(emoji_obj)
    
    def show_catch_effect(self, emoji_obj):
        """Show visual effect when catching an emoji"""
        points = emoji_obj["data"]["points"]
        if points > 0:
            print(f"\r{Fore.GREEN}✨ +{points} points! ✨", end='', flush=True)
        else:
            print(f"\r{Fore.RED}💥 {points} points! 💥", end='', flush=True)
    
    def show_life_lost(self):
        """Show effect when life is lost"""
        print(f"\r{Fore.RED}💔 Life lost! Lives remaining: {self.lives}", end='', flush=True)
    
    def handle_input(self):
        """Handle player input for movement"""
        try:
            while self.running:
                if keyboard.is_pressed('left') or keyboard.is_pressed('a'):
                    if self.player_pos > 1:
                        self.player_pos -= 1
                elif keyboard.is_pressed('right') or keyboard.is_pressed('d'):
                    if self.player_pos < self.width - 2:
                        self.player_pos += 1
                elif keyboard.is_pressed('q'):
                    self.running = False
                
                time.sleep(0.1)
        except:
            # Fallback input method
            pass
    
    def draw_game(self):
        """Draw the current game state"""
        # Clear screen and move cursor to top
        print('\033[H', end='')
        
        # Draw game info
        info_line = f"🌧️ EMOJI RAIN | Score: {self.score} | Level: {self.level} | Lives: {'❤️' * self.lives} | Speed: {self.game_speed:.1f}"
        print(Fore.YELLOW + info_line)
        print(Fore.WHITE + "─" * self.width)
        
        # Create game field
        field = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        
        # Place falling emojis
        for emoji_obj in self.falling_emojis:
            if 0 <= emoji_obj["y"] < self.height and 0 <= emoji_obj["x"] < self.width:
                field[emoji_obj["y"]][emoji_obj["x"]] = emoji_obj["emoji"]
        
        # Place player catcher
        if 0 <= self.player_pos < self.width:
            field[self.height - 1][self.player_pos] = self.catcher
        
        # Draw the field
        for row in field:
            print(Fore.WHITE + "│" + "".join(row) + "│")
        
        print(Fore.WHITE + "─" * self.width)
        print(Fore.CYAN + "Controls: A/D or ←/→ to move | Q to quit")
    
    def update_level(self):
        """Update game level and difficulty"""
        new_level = (self.score // 100) + 1
        if new_level > self.level:
            self.level = new_level
            self.game_speed = max(0.1, self.game_speed - 0.05)
            slow_print(Fore.MAGENTA + f"\n🚀 LEVEL UP! Level {self.level} - Speed increased!", delay=0.03)
            time.sleep(1)
    
    def game_loop(self):
        """Main game loop"""
        # Start input handler in separate thread
        input_thread = threading.Thread(target=self.handle_input, daemon=True)
        input_thread.start()
        
        frame_count = 0
        spawn_rate = 0.3
        
        while self.running and self.lives > 0:
            # Spawn emojis
            if random.random() < spawn_rate:
                self.spawn_emoji()
            
            # Update game state
            self.update_emojis()
            self.update_level()
            
            # Draw game
            self.draw_game()
            
            # Game timing
            time.sleep(self.game_speed)
            frame_count += 1
            
            # Increase spawn rate over time
            if frame_count % 50 == 0:
                spawn_rate = min(0.8, spawn_rate + 0.05)
        
        self.show_game_over()
    
    def show_game_over(self):
        """Display game over screen"""
        clear_screen()
        
        if self.lives <= 0:
            game_over_banner = create_banner("GAME OVER", color=Fore.RED)
            print(game_over_banner)
            
            slow_print(Fore.RED + "💔 You ran out of lives! The emoji storm was too strong! 💔", delay=0.03)
        else:
            quit_banner = create_banner("THANKS FOR PLAYING", color=Fore.YELLOW)
            print(quit_banner)
        
        time.sleep(1)
        
        # Show final statistics
        stats = [
            f"\n📊 FINAL STATISTICS:",
            f"🏆 Final Score: {self.score}",
            f"🚀 Highest Level: {self.level}",
            f"❤️ Lives Remaining: {self.lives}",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Score evaluation
        if self.score >= 500:
            slow_print(rainbow_text("🌟 LEGENDARY EMOJI CATCHER! 🌟"), delay=0.05)
        elif self.score >= 300:
            slow_print(Fore.YELLOW + "🎯 Excellent Storm Survivor! 🎯", delay=0.03)
        elif self.score >= 150:
            slow_print(Fore.GREEN + "👍 Good Emoji Hunter! 👍", delay=0.03)
        else:
            slow_print(Fore.BLUE + "🌱 Keep practicing, future emoji master! 🌱", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()

def main():
    """Main game entry point"""
    try:
        game = EmojiRain()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Thanks for playing Emoji Rain!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Game error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
