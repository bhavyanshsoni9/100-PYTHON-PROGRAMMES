import emoji
from utils import slow_print, print_signature

# Dictionary mapping words to emojis
WORD_TO_EMOJI = {
    'love': ':heart:',
    'pizza': ':pizza:',
    'happy': ':smile:',
    'sad': ':cry:',
    'dog': ':dog:',
    'cat': ':cat:',
    'sun': ':sun:',
    'moon': ':moon:',
    'star': ':star:',
    'heart': ':heart:',
    'food': ':hamburger:',
    'music': ':musical_note:',
    'book': ':book:',
    'computer': ':computer:',
    'phone': ':mobile_phone:',
}

def translate_to_emoji(text):
    """Translate words to emojis where possible."""
    words = text.lower().split()
    translated = []
    
    for word in words:
        if word in WORD_TO_EMOJI:
            translated.append(emoji.emojize(WORD_TO_EMOJI[word]))
        else:
            translated.append(word)
    
    return ' '.join(translated)

def main():
    slow_print("🎯 Welcome to the Emoji Translator! 🎯", color='green')
    slow_print("Type 'quit' to exit", color='yellow')
    
    while True:
        text = input("\nEnter a sentence to translate: ")
        if text.lower() == 'quit':
            break
            
        translated = translate_to_emoji(text)
        slow_print("\nTranslated text:", color='cyan')
        slow_print(translated, color='magenta')
    
    print_signature()

if __name__ == "__main__":
    main() 