# 🌸 Emotion Garden

**Created by Bhavyansh Soni**

## Description
A therapeutic and nurturing game where players cultivate their emotional landscape by growing feelings into beautiful emoji flowers. Over 21 days, tend to your garden with care, water emotions with experiences, and watch your inner world bloom into a harmonious display of human complexity.

## Core Philosophy
"Every emotion is a seed waiting to bloom into something beautiful. Nurture your feelings with experiences and watch them grow into wisdom, beauty, and inner harmony."

## Gameplay Features
- 🌱 **10 Unique Emotions**: Each with distinct growth patterns and needs
- 💧 **Experience-Based Care**: Water plants with meaningful life experiences
- ☀️ **Activity Sunlight**: Provide emotional sunlight through activities
- 🌸 **Harvest System**: Mature flowers yield harmony points
- 📈 **21-Day Journey**: Three weeks of emotional growth and discovery
- 🌿 **Garden Health**: Maintain balance for optimal emotional well-being

## Emotional Flora
### Primary Emotions
1. **😊 Joy** → 🌻 (3 days) - Water with laughter, sunlight with friendship
2. **💕 Love** → 🌹 (4 days) - Water with compassion, sunlight with connection
3. **😌 Peace** → 🌸 (5 days) - Water with meditation, sunlight with solitude
4. **😤 Courage** → 🦁 (3 days) - Water with challenge, sunlight with confidence
5. **🤔 Wisdom** → 🧠 (6 days) - Water with reflection, sunlight with experience

### Advanced Emotions
6. **💡 Creativity** → 🌈 (4 days) - Water with inspiration, sunlight with freedom
7. **🙏 Gratitude** → 🌺 (3 days) - Water with appreciation, sunlight with awareness
8. **🌱 Hope** → 🌅 (5 days) - Water with belief, sunlight with optimism
9. **😊 Serenity** → 🌊 (7 days) - Water with calm, sunlight with balance
10. **😯 Wonder** → 🌌 (4 days) - Water with curiosity, sunlight with discovery

## Growth Mechanics
- **Planting**: Choose emotion seeds and place them in your 12×8 garden
- **Watering**: Provide specific experiences each emotion needs to thrive
- **Sunlight**: Give activities that nurture emotional development
- **Time**: Emotions take different amounts of time to fully mature
- **Health**: Neglected plants lose vitality and produce less harmony
- **Harvesting**: Mature flowers provide harmony points based on health

## Experience Categories
Each emotion requires specific types of experiences:
- 😂 **Laughter**: Comedy, play, humor, entertainment
- 🤗 **Compassion**: Kindness, empathy, helping others
- 🧘 **Meditation**: Mindfulness, quiet reflection, inner peace
- 🏔️ **Challenge**: Overcoming obstacles, pushing limits
- 📖 **Reflection**: Learning, contemplation, wisdom-seeking
- 🎨 **Inspiration**: Creativity, art, music, beauty
- 🙏 **Appreciation**: Gratitude practices, counting blessings
- 🕯️ **Belief**: Faith, hope, positive thinking
- 🌊 **Calm**: Relaxation, tranquility, stress relief
- 🔍 **Curiosity**: Exploration, learning, discovery

## Daily Activities
1. **🌱 Plant Emotions**: Add new emotional seeds to empty plots
2. **💧 Water Plants**: Provide necessary experiences for growth
3. **☀️ Give Sunlight**: Offer activities that support development
4. **🌸 Harvest Flowers**: Collect harmony points from mature emotions
5. **📊 Check Status**: Monitor garden health and statistics
6. **⏰ End Day**: Advance time and let emotions grow

## Scoring System
- **Harmony Points**: Primary score from harvested flowers
- **Diversity Bonus**: Points for growing different emotion types
- **Health Bonus**: Points for maintaining garden vitality
- **Achievement Levels**:
  - 🌟 **Master Emotional Gardener** (800+ points)
  - 🌸 **Skilled Emotion Cultivator** (600+ points)
  - 🌱 **Growing Garden Tender** (400+ points)
  - 🌿 **Budding Emotional Gardener** (200+ points)
  - 🌱 **Novice Garden Keeper** (Below 200 points)

## Therapeutic Benefits
- **Emotional Awareness**: Learn to identify and name feelings
- **Self-Care Practice**: Understand what emotions need to thrive
- **Mindfulness Training**: Develop attention to emotional states
- **Growth Mindset**: See emotions as developmental opportunities
- **Balance Skills**: Practice maintaining emotional equilibrium
- **Patience Cultivation**: Learn that emotional growth takes time

## Garden Events
Random events add life to your garden:
- 🌧️ **Gentle Rain**: Natural watering boosts all plants
- ☀️ **Perfect Sunshine**: Ideal conditions enhance growth
- 🦋 **Butterfly Visits**: Bring natural joy and pollination
- 🐛 **Garden Pests**: Challenge unhealthy plants
- 🌙 **Peaceful Nights**: Restore harmony and balance

## Tips for Emotional Gardening
1. **Diversify**: Plant many different emotion types for bonus points
2. **Daily Care**: Water and provide sunlight regularly for best health
3. **Balance**: Don't neglect any planted emotions
4. **Patience**: Some emotions take longer to mature but give more harmony
5. **Harvest Timing**: Collect mature flowers promptly for maximum points
6. **Health Focus**: Healthy plants produce more harmony than neglected ones

## Educational Value
- Teaches emotional intelligence and self-awareness
- Provides vocabulary for describing complex feelings
- Demonstrates the importance of emotional self-care
- Shows how different experiences nurture different emotions
- Creates understanding of emotional growth as a process
- Builds appreciation for the full spectrum of human feelings

## Reflection Questions
The game encourages players to consider:
- What experiences truly nourish different emotions?
- How do I maintain emotional balance in my life?
- Which emotions do I tend to neglect or over-cultivate?
- What does a healthy emotional landscape look like?
- How can I be more intentional about emotional growth?
