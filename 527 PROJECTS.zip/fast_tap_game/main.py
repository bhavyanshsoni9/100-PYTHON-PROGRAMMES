# Created by Bhavyansh Soni
# Fast Tap Game - Speed and reaction based cyberpunk game

import sys
import os
import time
import random
import threading
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class FastTapGame:
    def __init__(self):
        self.running = True
        self.game_active = False
        self.score = 0
        self.high_scores = []
        self.reaction_times = []
        self.current_challenge = None
        self.challenge_start_time = None
        
        # Game modes
        self.game_modes = {
            "speed": "Speed Tapping - Tap as fast as possible",
            "reaction": "Reaction Time - Respond when prompted",
            "sequence": "Sequence Memory - Remember and repeat patterns",
            "precision": "Precision Timing - Hit exact timing windows"
        }
        
        # Challenge types
        self.challenges = {
            "tap_space": "Press SPACE when you see GO!",
            "tap_enter": "Press ENTER when the signal appears",
            "type_word": "Type the displayed word quickly",
            "math_solve": "Solve the math problem fast"
        }
    
    def speed_tapping_game(self):
        """Speed tapping challenge"""
        clear_screen()
        print_banner("⚡ SPEED TAPPING CHALLENGE ⚡")
        print()
        
        duration = 10  # seconds
        slow_print(f"Tap SPACE as many times as possible in {duration} seconds!", 0.02, Colors.ACCENT)
        print_info("Press any key to start...")
        input()
        
        clear_screen()
        print_banner("⚡ SPEED TAPPING - GET READY! ⚡")
        print()
        
        # Countdown
        for i in range(3, 0, -1):
            print(f"\r{Colors.WARNING}{i}...{Colors.RESET}", end="")
            time.sleep(1)
        
        print(f"\r{Colors.PRIMARY}GO! TAP SPACE!{Colors.RESET}")
        
        start_time = time.time()
        taps = 0
        
        # Simple simulation - in real terminal this would capture actual keypresses
        while time.time() - start_time < duration:
            remaining = duration - (time.time() - start_time)
            print(f"\r{Colors.ACCENT}Time: {remaining:.1f}s | Taps: {Colors.PRIMARY}{taps}{Colors.RESET}", end="")
            
            # Simulate user input
            user_input = input(" Press Enter to tap: ")
            taps += 1
            
            if remaining <= 0:
                break
        
        # Calculate results
        taps_per_second = taps / duration
        score = int(taps * 10 + taps_per_second * 50)
        
        clear_screen()
        print_banner("⚡ SPEED TAPPING RESULTS ⚡")
        print()
        
        print(f"{Colors.ACCENT}Total Taps: {Colors.PRIMARY}{taps}{Colors.RESET}")
        print(f"{Colors.ACCENT}Taps per Second: {Colors.PRIMARY}{taps_per_second:.2f}{Colors.RESET}")
        print(f"{Colors.ACCENT}Score: {Colors.PRIMARY}{score}{Colors.RESET}")
        
        # Performance rating
        if taps_per_second >= 5:
            rating = "🔥 LIGHTNING FAST!"
            rating_color = Colors.PRIMARY
        elif taps_per_second >= 3:
            rating = "⚡ VERY FAST!"
            rating_color = Colors.WARNING
        elif taps_per_second >= 2:
            rating = "💨 FAST!"
            rating_color = Colors.SECONDARY
        else:
            rating = "🐌 NEEDS PRACTICE"
            rating_color = Colors.GRAY
        
        print()
        print(f"{Colors.ACCENT}Rating: {rating_color}{rating}{Colors.RESET}")
        
        self.update_high_score("Speed Tapping", score)
        press_enter_to_continue()
    
    def reaction_time_game(self):
        """Reaction time challenge"""
        clear_screen()
        print_banner("⚡ REACTION TIME TEST ⚡")
        print()
        
        slow_print("Wait for the signal, then press ENTER as fast as possible!", 0.02, Colors.ACCENT)
        print_warning("Don't press too early or you'll be penalized!")
        print()
        input("Press Enter to start...")
        
        total_tests = 5
        reaction_times = []
        
        for test_num in range(1, total_tests + 1):
            clear_screen()
            print_banner(f"⚡ REACTION TEST {test_num}/{total_tests} ⚡")
            print()
            
            print(f"{Colors.GRAY}Wait for the signal...{Colors.RESET}")
            
            # Random wait time between 2-6 seconds
            wait_time = random.uniform(2, 6)
            time.sleep(wait_time)
            
            # Show signal
            signal_time = time.time()
            print(f"\r{Colors.ERROR}🚨 GO! PRESS ENTER NOW! 🚨{Colors.RESET}")
            
            # Get response time
            input()
            response_time = time.time()
            
            reaction_ms = (response_time - signal_time) * 1000
            reaction_times.append(reaction_ms)
            
            if reaction_ms < 200:
                performance = "⚡ LIGHTNING FAST!"
                color = Colors.PRIMARY
            elif reaction_ms < 300:
                performance = "🔥 EXCELLENT!"
                color = Colors.WARNING
            elif reaction_ms < 500:
                performance = "👍 GOOD!"
                color = Colors.SECONDARY
            else:
                performance = "🐌 SLOW..."
                color = Colors.GRAY
            
            print(f"{Colors.ACCENT}Reaction Time: {color}{reaction_ms:.0f}ms - {performance}{Colors.RESET}")
            time.sleep(1.5)
        
        # Calculate average and show results
        avg_reaction = sum(reaction_times) / len(reaction_times)
        best_reaction = min(reaction_times)
        
        clear_screen()
        print_banner("⚡ REACTION TIME RESULTS ⚡")
        print()
        
        print(f"{Colors.ACCENT}Tests Completed: {Colors.WHITE}{total_tests}{Colors.RESET}")
        print(f"{Colors.ACCENT}Average Reaction: {Colors.PRIMARY}{avg_reaction:.0f}ms{Colors.RESET}")
        print(f"{Colors.ACCENT}Best Reaction: {Colors.PRIMARY}{best_reaction:.0f}ms{Colors.RESET}")
        
        print()
        print("Individual Results:")
        for i, rt in enumerate(reaction_times, 1):
            print(f"  Test {i}: {rt:.0f}ms")
        
        score = max(0, int(1000 - avg_reaction))
        self.update_high_score("Reaction Time", score)
        
        press_enter_to_continue()
    
    def sequence_memory_game(self):
        """Sequence memory challenge"""
        clear_screen()
        print_banner("🧠 SEQUENCE MEMORY CHALLENGE 🧠")
        print()
        
        slow_print("Watch the sequence and repeat it exactly!", 0.02, Colors.ACCENT)
        print()
        input("Press Enter to start...")
        
        sequence = []
        level = 1
        max_level = 10
        symbols = ["🔴", "🟢", "🔵", "🟡"]
        
        while level <= max_level:
            # Add new element to sequence
            sequence.append(random.choice(symbols))
            
            clear_screen()
            print_banner(f"🧠 LEVEL {level} - MEMORIZE 🧠")
            print()
            
            # Show sequence
            print("Watch this sequence:")
            print()
            for i, symbol in enumerate(sequence):
                print(f"{symbol} ", end="", flush=True)
                time.sleep(0.8)
            
            print("\n")
            time.sleep(1)
            
            # Get user input
            clear_screen()
            print_banner(f"🧠 LEVEL {level} - REPEAT 🧠")
            print()
            
            print("Available symbols: 1=🔴  2=🟢  3=🔵  4=🟡")
            print()
            print("Enter the sequence (e.g., 1234):")
            
            user_input = get_input("Sequence: ")
            
            # Convert user input to symbols
            symbol_map = {"1": "🔴", "2": "🟢", "3": "🔵", "4": "🟡"}
            user_sequence = []
            
            for char in user_input:
                if char in symbol_map:
                    user_sequence.append(symbol_map[char])
            
            # Check if correct
            if user_sequence == sequence:
                print_success(f"🎉 Correct! Level {level} completed!")
                level += 1
                score = level * 100
            else:
                print_error("❌ Wrong sequence! Game over!")
                print(f"Correct sequence was: {' '.join(sequence)}")
                score = (level - 1) * 100
                break
            
            time.sleep(1.5)
        
        if level > max_level:
            print_success("🏆 PERFECT! You completed all levels!")
            score += 1000  # Bonus for perfect completion
        
        self.update_high_score("Sequence Memory", score)
        press_enter_to_continue()
    
    def precision_timing_game(self):
        """Precision timing challenge"""
        clear_screen()
        print_banner("🎯 PRECISION TIMING CHALLENGE 🎯")
        print()
        
        slow_print("Hit ENTER exactly when the bar reaches the target!", 0.02, Colors.ACCENT)
        print()
        input("Press Enter to start...")
        
        rounds = 5
        total_score = 0
        
        for round_num in range(1, rounds + 1):
            clear_screen()
            print_banner(f"🎯 ROUND {round_num}/{rounds} 🎯")
            print()
            
            bar_length = 30
            target_position = bar_length // 2  # Target in the middle
            current_position = 0
            direction = 1
            speed = 0.1
            
            print("Hit ENTER when the cursor (█) reaches the target (🎯)!")
            print()
            
            # Animate the timing bar
            start_time = time.time()
            user_pressed = False
            press_time = None
            
            while not user_pressed and time.time() - start_time < 10:  # 10 second timeout
                # Create progress bar
                bar = ["░"] * bar_length
                bar[target_position] = "🎯"
                bar[current_position] = "█"
                
                bar_display = "".join(bar)
                print(f"\r{Colors.ACCENT}[{bar_display}]{Colors.RESET}", end="")
                
                # Check for input (simulated)
                time.sleep(speed)
                if random.random() < 0.1:  # Simulate user input timing
                    user_pressed = True
                    press_time = time.time()
                    press_position = current_position
                
                # Move cursor
                current_position += direction
                if current_position >= bar_length - 1 or current_position <= 0:
                    direction *= -1
                    current_position = max(0, min(bar_length - 1, current_position))
            
            print()
            print()
            
            if user_pressed:
                # Calculate accuracy
                distance = abs(press_position - target_position)
                max_distance = bar_length // 2
                accuracy = max(0, 100 - (distance / max_distance) * 100)
                round_score = int(accuracy * 10)
                
                if accuracy >= 95:
                    result = "🎯 PERFECT!"
                    color = Colors.PRIMARY
                elif accuracy >= 80:
                    result = "🔥 EXCELLENT!"
                    color = Colors.WARNING
                elif accuracy >= 60:
                    result = "👍 GOOD!"
                    color = Colors.SECONDARY
                else:
                    result = "📍 CLOSE..."
                    color = Colors.GRAY
                
                print(f"{Colors.ACCENT}Accuracy: {color}{accuracy:.1f}% - {result}{Colors.RESET}")
                print(f"{Colors.ACCENT}Round Score: {Colors.WHITE}{round_score}{Colors.RESET}")
                
                total_score += round_score
            else:
                print_error("⏰ Time's up! No input detected.")
            
            time.sleep(1.5)
        
        # Final results
        clear_screen()
        print_banner("🎯 PRECISION TIMING RESULTS 🎯")
        print()
        
        avg_score = total_score / rounds
        print(f"{Colors.ACCENT}Total Score: {Colors.PRIMARY}{total_score}{Colors.RESET}")
        print(f"{Colors.ACCENT}Average per Round: {Colors.PRIMARY}{avg_score:.1f}{Colors.RESET}")
        
        if avg_score >= 90:
            rating = "🎯 PRECISION MASTER!"
        elif avg_score >= 70:
            rating = "🔥 SHARP SHOOTER!"
        elif avg_score >= 50:
            rating = "👍 GOOD AIM!"
        else:
            rating = "🎯 KEEP PRACTICING!"
        
        print(f"{Colors.ACCENT}Rating: {Colors.PRIMARY}{rating}{Colors.RESET}")
        
        self.update_high_score("Precision Timing", total_score)
        press_enter_to_continue()
    
    def update_high_score(self, game_mode, score):
        """Update high score for a game mode"""
        score_entry = {
            "mode": game_mode,
            "score": score,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.high_scores.append(score_entry)
        
        # Keep only top 10 scores per mode
        mode_scores = [s for s in self.high_scores if s["mode"] == game_mode]
        mode_scores.sort(key=lambda x: x["score"], reverse=True)
        
        if len(mode_scores) > 10:
            # Remove excess scores
            for excess_score in mode_scores[10:]:
                self.high_scores.remove(excess_score)
        
        # Check if new high score
        if mode_scores and score == mode_scores[0]["score"]:
            print_success(f"🏆 NEW HIGH SCORE for {game_mode}: {score}!")
    
    def view_high_scores(self):
        """Display high scores"""
        clear_screen()
        print_banner("🏆 HIGH SCORES 🏆")
        print()
        
        if not self.high_scores:
            print_warning("No scores recorded yet!")
            print_info("Play some games to set records!")
            press_enter_to_continue()
            return
        
        # Group scores by mode
        modes = set(score["mode"] for score in self.high_scores)
        
        for mode in sorted(modes):
            mode_scores = [s for s in self.high_scores if s["mode"] == mode]
            mode_scores.sort(key=lambda x: x["score"], reverse=True)
            
            print(f"{Colors.ACCENT}{mode}:{Colors.RESET}")
            for i, score in enumerate(mode_scores[:5], 1):  # Top 5 per mode
                print(f"  {i}. {Colors.PRIMARY}{score['score']}{Colors.RESET} - {Colors.GRAY}{score['date']}{Colors.RESET}")
            print()
        
        press_enter_to_continue()
    
    def training_mode(self):
        """Training mode with tips and practice"""
        clear_screen()
        print_banner("🎯 TRAINING MODE 🎯")
        print()
        
        print("Training exercises:")
        print_menu_item(1, "Finger Warm-up")
        print_menu_item(2, "Reaction Training")
        print_menu_item(3, "Memory Exercises")
        print_menu_item(4, "Timing Practice")
        print_menu_item(5, "Back to Main Menu")
        
        print()
        choice = get_input("Select training (1-5): ")
        
        if choice == '1':
            self.finger_warmup()
        elif choice == '2':
            self.reaction_training()
        elif choice == '3':
            self.memory_exercises()
        elif choice == '4':
            self.timing_practice()
        elif choice == '5':
            return
        else:
            print_error("Invalid choice!")
            time.sleep(1)
    
    def finger_warmup(self):
        """Finger warm-up exercises"""
        clear_screen()
        print_banner("🤲 FINGER WARM-UP 🤲")
        print()
        
        exercises = [
            "Tap each finger on the table 10 times",
            "Make fists and release 10 times",
            "Stretch fingers wide and close 10 times",
            "Touch thumb to each finger 5 times",
            "Rotate wrists 10 times each direction"
        ]
        
        slow_print("Follow these warm-up exercises:", 0.02, Colors.ACCENT)
        print()
        
        for i, exercise in enumerate(exercises, 1):
            print(f"{Colors.SECONDARY}{i}. {Colors.WHITE}{exercise}{Colors.RESET}")
            input(f"   Press Enter when complete...")
            print_success("✓ Complete!")
            print()
        
        print_success("🔥 Warm-up complete! Your fingers are ready!")
        press_enter_to_continue()
    
    def reaction_training(self):
        """Reaction time training"""
        clear_screen()
        print_banner("⚡ REACTION TRAINING ⚡")
        print()
        
        slow_print("Quick reaction drills - respond as fast as possible!", 0.02, Colors.ACCENT)
        print()
        
        for round_num in range(1, 4):
            print(f"{Colors.ACCENT}Round {round_num}/3{Colors.RESET}")
            
            # Random delay
            delay = random.uniform(1, 4)
            time.sleep(delay)
            
            start_time = time.time()
            print(f"{Colors.ERROR}⚡ TAP!{Colors.RESET}")
            input()
            reaction_time = (time.time() - start_time) * 1000
            
            print(f"Reaction: {reaction_time:.0f}ms")
            print()
            time.sleep(1)
        
        print_success("Training complete! Your reactions are improving!")
        press_enter_to_continue()
    
    def memory_exercises(self):
        """Memory training exercises"""
        clear_screen()
        print_banner("🧠 MEMORY EXERCISES 🧠")
        print()
        
        # Simple number sequence memory
        sequences = [
            [1, 2, 3],
            [4, 7, 2, 9],
            [3, 1, 4, 1, 5],
            [9, 2, 6, 5, 3, 5]
        ]
        
        for i, sequence in enumerate(sequences, 1):
            print(f"{Colors.ACCENT}Exercise {i}: Memorize this sequence{Colors.RESET}")
            print(f"{Colors.PRIMARY}{' '.join(map(str, sequence))}{Colors.RESET}")
            
            time.sleep(2)
            clear_screen()
            
            user_input = get_input("Enter the sequence (space separated): ")
            user_sequence = user_input.split()
            
            if user_sequence == [str(x) for x in sequence]:
                print_success("✓ Correct!")
            else:
                print_error("✗ Incorrect. Try to focus more!")
            
            print()
            time.sleep(1)
        
        print_success("Memory training complete!")
        press_enter_to_continue()
    
    def timing_practice(self):
        """Timing practice exercises"""
        clear_screen()
        print_banner("⏰ TIMING PRACTICE ⏰")
        print()
        
        slow_print("Practice hitting exact timing intervals!", 0.02, Colors.ACCENT)
        print()
        
        intervals = [2, 3, 5]  # seconds
        
        for interval in intervals:
            print(f"{Colors.ACCENT}Hit Enter after exactly {interval} seconds:{Colors.RESET}")
            print("Starting... NOW!")
            
            start_time = time.time()
            input()
            actual_time = time.time() - start_time
            
            error = abs(actual_time - interval)
            accuracy = max(0, 100 - (error * 20))
            
            print(f"Target: {interval}s | Actual: {actual_time:.2f}s | Accuracy: {accuracy:.1f}%")
            print()
            time.sleep(1)
        
        print_success("Timing practice complete!")
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Fast tap ASCII art
            tap_art = """
    ███████╗ █████╗ ███████╗████████╗    ████████╗ █████╗ ██████╗ 
    ██╔════╝██╔══██╗██╔════╝╚══██╔══╝    ╚══██╔══╝██╔══██╗██╔══██╗
    █████╗  ███████║███████╗   ██║          ██║   ███████║██████╔╝
    ██╔══╝  ██╔══██║╚════██║   ██║          ██║   ██╔══██║██╔═══╝ 
    ██║     ██║  ██║███████║   ██║          ██║   ██║  ██║██║     
    ╚═╝     ╚═╝  ╚═╝╚══════╝   ╚═╝          ╚═╝   ╚═╝  ╚═╝╚═╝     
            """
            
            print_ascii_art(tap_art, Colors.ACCENT)
            print()
            slow_print("Test your speed and reflexes in the cyber arena!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "⚡ Speed Tapping")
            print_menu_item(2, "⚡ Reaction Time")
            print_menu_item(3, "🧠 Sequence Memory")
            print_menu_item(4, "🎯 Precision Timing")
            print_menu_item(5, "🏆 High Scores")
            print_menu_item(6, "🎯 Training Mode")
            print_menu_item(7, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.speed_tapping_game()
            elif choice == '2':
                self.reaction_time_game()
            elif choice == '3':
                self.sequence_memory_game()
            elif choice == '4':
                self.precision_timing_game()
            elif choice == '5':
                self.view_high_scores()
            elif choice == '6':
                self.training_mode()
            elif choice == '7':
                slow_print("Keep those reflexes sharp! ⚡", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)

def main():
    """Main function to run Fast Tap Game"""
    try:
        game = FastTapGame()
        game.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
