# Created by Bhavyansh Soni
# Idea Spark - Creative idea generator with cyberpunk inspiration

import sys
import os
import time
import random
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class IdeaSpark:
    def __init__(self):
        self.running = True
        self.generated_ideas = []
        self.favorite_ideas = []
        self.current_category = "general"
        
        # Idea components for generation
        self.idea_components = {
            "general": {
                "subjects": ["AI", "robots", "virtual reality", "blockchain", "quantum computing", "space exploration", "biotechnology", "nanotechnology", "cybersecurity", "sustainable energy"],
                "actions": ["revolutionize", "transform", "enhance", "automate", "optimize", "streamline", "innovate", "disrupt", "connect", "empower"],
                "objects": ["daily life", "education", "healthcare", "transportation", "communication", "entertainment", "work", "society", "environment", "economy"],
                "adjectives": ["intelligent", "efficient", "sustainable", "innovative", "futuristic", "connected", "automated", "personalized", "adaptive", "revolutionary"]
            },
            "startup": {
                "subjects": ["app", "platform", "service", "product", "system", "network", "marketplace", "community", "tool", "solution"],
                "actions": ["connects", "delivers", "provides", "creates", "builds", "enables", "facilitates", "streamlines", "automates", "personalizes"],
                "objects": ["entrepreneurs", "consumers", "businesses", "students", "professionals", "creators", "communities", "travelers", "learners", "users"],
                "adjectives": ["social", "mobile", "cloud-based", "AI-powered", "subscription-based", "on-demand", "peer-to-peer", "real-time", "personalized", "scalable"]
            },
            "art": {
                "subjects": ["digital art", "interactive installation", "VR experience", "augmented reality", "holographic display", "generative art", "sound sculpture", "light installation", "kinetic sculpture", "media art"],
                "actions": ["explores", "visualizes", "represents", "transforms", "captures", "interprets", "expresses", "embodies", "reflects", "challenges"],
                "objects": ["human emotion", "nature", "technology", "society", "consciousness", "time", "space", "identity", "memory", "dreams"],
                "adjectives": ["immersive", "interactive", "dynamic", "ethereal", "provocative", "contemplative", "surreal", "abstract", "symbolic", "experimental"]
            },
            "gaming": {
                "subjects": ["RPG", "strategy game", "puzzle game", "simulation", "adventure game", "multiplayer game", "mobile game", "VR game", "AR game", "indie game"],
                "actions": ["features", "combines", "introduces", "reimagines", "blends", "incorporates", "utilizes", "showcases", "explores", "presents"],
                "objects": ["time travel", "space exploration", "magic system", "survival mechanics", "city building", "character progression", "puzzle solving", "combat system", "story branching", "world building"],
                "adjectives": ["procedurally generated", "narrative-driven", "multiplayer", "cooperative", "competitive", "sandbox", "turn-based", "real-time", "open-world", "story-rich"]
            }
        }
        
        # Pre-written creative prompts
        self.creative_prompts = {
            "writing": [
                "Write about a world where memories can be traded like currency",
                "Create a story set in a city that exists only during thunderstorms",
                "Imagine a society where everyone gets a personal AI companion at birth",
                "Write about the last person on Earth who doesn't use technology",
                "Create a tale about a library that contains books from parallel universes"
            ],
            "business": [
                "Develop a service that helps people disconnect from digital devices",
                "Create a platform for sharing unused subscription services",
                "Build a network for connecting remote workers with local communities",
                "Design a system for turning household waste into useful products",
                "Create a marketplace for renting out specialized skills by the hour"
            ],
            "invention": [
                "Design a device that translates plant distress signals into human language",
                "Create a wearable that predicts weather changes through body sensors",
                "Invent a system that converts human movement into usable energy",
                "Design a tool that helps people learn languages through taste and smell",
                "Create a device that captures and replays ambient sounds from the past"
            ]
        }
        
        # Random word collections for additional inspiration
        self.inspiration_words = {
            "tech": ["neural", "quantum", "cyber", "digital", "virtual", "augmented", "synthetic", "bio", "nano", "cloud"],
            "nature": ["forest", "ocean", "mountain", "desert", "river", "sky", "earth", "wind", "fire", "ice"],
            "emotions": ["wonder", "curiosity", "passion", "serenity", "excitement", "mystery", "adventure", "discovery", "freedom", "connection"],
            "colors": ["neon", "electric", "aurora", "crimson", "azure", "golden", "silver", "obsidian", "crystal", "iridescent"]
        }
    
    def generate_random_idea(self):
        """Generate a random idea based on current category"""
        components = self.idea_components[self.current_category]
        
        subject = random.choice(components["subjects"])
        action = random.choice(components["actions"])
        obj = random.choice(components["objects"])
        adjective = random.choice(components["adjectives"])
        
        # Generate different idea formats
        formats = [
            f"An {adjective} {subject} that {action} {obj}",
            f"A {subject} designed to {action} {obj} in an {adjective} way",
            f"How to {action} {obj} using {adjective} {subject}",
            f"The future of {obj}: {adjective} {subject} solutions",
            f"Imagine {adjective} {subject} that completely {action} {obj}"
        ]
        
        idea = random.choice(formats)
        
        # Add timestamp and category
        idea_data = {
            "text": idea,
            "category": self.current_category,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.generated_ideas.append(idea_data)
        return idea_data
    
    def display_idea_animation(self, idea_text):
        """Display idea with cyberpunk animation"""
        clear_screen()
        
        # Lightning effect
        for _ in range(3):
            print(f"{Colors.WARNING}⚡ IDEA SPARK ⚡{Colors.RESET}")
            time.sleep(0.2)
            clear_screen()
            time.sleep(0.1)
        
        # Idea revelation
        print_banner("💡 IDEA GENERATED 💡")
        print()
        
        # Typewriter effect for the idea
        slow_print(idea_text, 0.03, Colors.PRIMARY)
        
        # Sparkle effect
        print()
        sparkles = "✨ ⭐ ✨ ⭐ ✨ ⭐ ✨ ⭐ ✨"
        print(f"{Colors.ACCENT}{sparkles}{Colors.RESET}")
    
    def spark_ideas(self):
        """Generate and display a new idea"""
        idea = self.generate_random_idea()
        self.display_idea_animation(idea["text"])
        
        print()
        print_separator()
        print(f"{Colors.ACCENT}Category: {Colors.WHITE}{idea['category'].title()}{Colors.RESET}")
        print(f"{Colors.ACCENT}Generated: {Colors.WHITE}{idea['timestamp']}{Colors.RESET}")
        
        print()
        print_menu_item(1, "💖 Add to Favorites")
        print_menu_item(2, "🔄 Generate Another")
        print_menu_item(3, "📝 Expand This Idea")
        print_menu_item(4, "🔙 Back to Menu")
        
        print()
        choice = get_input("Enter your choice (1-4): ")
        
        if choice == '1':
            self.add_to_favorites(idea)
        elif choice == '2':
            self.spark_ideas()
        elif choice == '3':
            self.expand_idea(idea)
        elif choice == '4':
            return
        else:
            print_error("Invalid choice!")
            time.sleep(1)
    
    def add_to_favorites(self, idea):
        """Add idea to favorites"""
        if idea not in self.favorite_ideas:
            self.favorite_ideas.append(idea)
            print_success("Idea added to favorites!")
        else:
            print_warning("Idea already in favorites!")
        time.sleep(1)
    
    def expand_idea(self, idea):
        """Expand on a generated idea"""
        clear_screen()
        print_banner("📝 IDEA EXPANSION 📝")
        print()
        
        print(f"{Colors.ACCENT}Original Idea:{Colors.RESET}")
        print(f"{Colors.PRIMARY}{idea['text']}{Colors.RESET}")
        print()
        
        # Generate expansion elements
        expansion_elements = [
            "Target Audience",
            "Key Features",
            "Potential Challenges",
            "Revenue Model",
            "Technical Requirements",
            "Market Opportunity"
        ]
        
        slow_print("Expanding idea...", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        for element in expansion_elements:
            print(f"{Colors.SECONDARY}{element}:{Colors.RESET}")
            
            # Generate relevant expansion text
            if element == "Target Audience":
                audiences = ["young professionals", "students", "small businesses", "creative professionals", "tech enthusiasts", "everyday consumers"]
                expansion = f"Primarily aimed at {random.choice(audiences)} who need innovative solutions"
            elif element == "Key Features":
                features = ["user-friendly interface", "real-time updates", "AI-powered recommendations", "cross-platform compatibility", "offline functionality"]
                expansion = f"Core features include {random.choice(features)} and seamless integration"
            elif element == "Potential Challenges":
                challenges = ["user adoption", "technical complexity", "market competition", "scalability issues", "regulatory compliance"]
                expansion = f"Main challenges may include {random.choice(challenges)} and resource requirements"
            elif element == "Revenue Model":
                models = ["subscription-based", "freemium", "one-time purchase", "advertising-supported", "transaction fees"]
                expansion = f"Potential revenue through {random.choice(models)} approach"
            elif element == "Technical Requirements":
                tech = ["cloud infrastructure", "mobile app development", "API integration", "database management", "security protocols"]
                expansion = f"Technical needs include {random.choice(tech)} and robust architecture"
            else:
                expansion = "Significant potential in emerging markets with growing demand"
            
            slow_print(f"  {expansion}", 0.02, Colors.WHITE)
            print()
        
        press_enter_to_continue()
    
    def creative_prompts(self):
        """Display creative prompts for inspiration"""
        clear_screen()
        print_banner("🎨 CREATIVE PROMPTS 🎨")
        print()
        
        prompt_categories = list(self.creative_prompts.keys())
        for i, category in enumerate(prompt_categories, 1):
            print_menu_item(i, category.title())
        
        print()
        choice = get_input("Select prompt category (1-3): ")
        
        try:
            selected_category = prompt_categories[int(choice) - 1]
            prompt = random.choice(self.creative_prompts[selected_category])
            
            clear_screen()
            print_banner(f"🎨 {selected_category.upper()} PROMPT 🎨")
            print()
            
            slow_print(prompt, 0.02, Colors.PRIMARY)
            
            print()
            print_separator()
            print(f"{Colors.ACCENT}Use this prompt as inspiration for your creative work!{Colors.RESET}")
            
        except (ValueError, IndexError):
            print_error("Invalid selection!")
        
        press_enter_to_continue()
    
    def word_association(self):
        """Generate word associations for inspiration"""
        clear_screen()
        print_banner("🔗 WORD ASSOCIATION 🔗")
        print()
        
        # Select random words from different categories
        categories = list(self.inspiration_words.keys())
        selected_words = []
        
        for category in categories:
            word = random.choice(self.inspiration_words[category])
            selected_words.append((word, category))
        
        slow_print("Generating word associations...", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        print()
        for word, category in selected_words:
            print(f"{Colors.SECONDARY}{category.title()}: {Colors.PRIMARY}{word.title()}{Colors.RESET}")
            time.sleep(0.3)
        
        print()
        print_separator()
        print(f"{Colors.ACCENT}Combine these words to create something unique!{Colors.RESET}")
        
        # Generate a combination idea
        combined_idea = f"Create something that combines {selected_words[0][0]} technology with {selected_words[1][0]} environments, evoking feelings of {selected_words[2][0]} through {selected_words[3][0]} aesthetics."
        
        print()
        slow_print("Combination Idea:", 0.02, Colors.WARNING)
        slow_print(combined_idea, 0.02, Colors.WHITE)
        
        press_enter_to_continue()
    
    def view_favorites(self):
        """View favorite ideas"""
        clear_screen()
        print_banner("💖 FAVORITE IDEAS 💖")
        print()
        
        if not self.favorite_ideas:
            print_warning("No favorite ideas yet!")
            print_info("Generate some ideas and add them to favorites.")
            press_enter_to_continue()
            return
        
        for i, idea in enumerate(self.favorite_ideas, 1):
            print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{idea['text']}{Colors.RESET}")
            print(f"     {Colors.GRAY}Category: {idea['category']} | {idea['timestamp']}{Colors.RESET}")
            print()
        
        print()
        choice = get_input("Enter idea number to expand (or press Enter to return): ")
        
        if choice.isdigit():
            try:
                idea_index = int(choice) - 1
                if 0 <= idea_index < len(self.favorite_ideas):
                    self.expand_idea(self.favorite_ideas[idea_index])
            except ValueError:
                pass
    
    def browse_categories(self):
        """Browse and switch idea categories"""
        clear_screen()
        print_banner("📚 IDEA CATEGORIES 📚")
        print()
        
        categories = list(self.idea_components.keys())
        for i, category in enumerate(categories, 1):
            current = " (Current)" if category == self.current_category else ""
            print_menu_item(i, f"{category.title()}{current}")
        
        print()
        choice = get_input("Select category (1-4): ")
        
        try:
            selected_category = categories[int(choice) - 1]
            self.current_category = selected_category
            print_success(f"Switched to {selected_category} category")
            
            # Generate a sample idea from the new category
            time.sleep(1)
            sample_idea = self.generate_random_idea()
            print()
            print(f"{Colors.ACCENT}Sample idea from {selected_category}:{Colors.RESET}")
            slow_print(sample_idea["text"], 0.02, Colors.PRIMARY)
            
        except (ValueError, IndexError):
            print_error("Invalid category selection!")
        
        time.sleep(2)
    
    def idea_storm(self):
        """Generate multiple ideas rapidly"""
        clear_screen()
        print_banner("🌪️ IDEA STORM 🌪️")
        print()
        
        num_ideas = 10
        slow_print(f"Generating {num_ideas} rapid-fire ideas...", 0.02, Colors.ACCENT)
        time.sleep(1)
        
        storm_ideas = []
        for i in range(num_ideas):
            idea = self.generate_random_idea()
            storm_ideas.append(idea)
            
            print(f"{Colors.SECONDARY}{i+1:2d}. {Colors.PRIMARY}{idea['text']}{Colors.RESET}")
            time.sleep(0.5)
        
        print()
        print_separator()
        print_success(f"Generated {num_ideas} ideas in your storm!")
        
        print()
        choice = get_input("Enter idea number to expand (or press Enter to continue): ")
        
        if choice.isdigit():
            try:
                idea_index = int(choice) - 1
                if 0 <= idea_index < len(storm_ideas):
                    self.expand_idea(storm_ideas[idea_index])
            except ValueError:
                pass
    
    def statistics(self):
        """Display idea generation statistics"""
        clear_screen()
        print_banner("📊 IDEA STATISTICS 📊")
        print()
        
        total_ideas = len(self.generated_ideas)
        favorite_count = len(self.favorite_ideas)
        
        slow_print(f"Total Ideas Generated: {total_ideas}", 0.02, Colors.ACCENT)
        slow_print(f"Favorite Ideas: {favorite_count}", 0.02, Colors.ACCENT)
        slow_print(f"Current Category: {self.current_category.title()}", 0.02, Colors.ACCENT)
        
        print()
        
        # Category breakdown
        category_counts = {}
        for idea in self.generated_ideas:
            cat = idea['category']
            category_counts[cat] = category_counts.get(cat, 0) + 1
        
        if category_counts:
            slow_print("Ideas by Category:", 0.02, Colors.PRIMARY)
            for category, count in category_counts.items():
                percentage = (count / total_ideas) * 100
                print(f"{Colors.SECONDARY}{category.title()}: {Colors.WHITE}{count} ideas ({percentage:.1f}%){Colors.RESET}")
        
        print()
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # ASCII art
            spark_art = """
    ██╗██████╗ ███████╗ █████╗     ███████╗██████╗  █████╗ ██████╗ ██╗  ██╗
    ██║██╔══██╗██╔════╝██╔══██╗    ██╔════╝██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝
    ██║██║  ██║█████╗  ███████║    ███████╗██████╔╝███████║██████╔╝█████╔╝ 
    ██║██║  ██║██╔══╝  ██╔══██║    ╚════██║██╔═══╝ ██╔══██║██╔══██╗██╔═██╗ 
    ██║██████╔╝███████╗██║  ██║    ███████║██║     ██║  ██║██║  ██║██║  ██╗
    ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝    ╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
            """
            
            print_ascii_art(spark_art, Colors.ACCENT)
            print()
            slow_print("Ignite your creativity with cyberpunk inspiration!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "💡 Spark Ideas")
            print_menu_item(2, "📚 Browse Categories")
            print_menu_item(3, "🎨 Creative Prompts")
            print_menu_item(4, "🔗 Word Association")
            print_menu_item(5, "💖 View Favorites")
            print_menu_item(6, "🌪️ Idea Storm")
            print_menu_item(7, "📊 Statistics")
            print_menu_item(8, "❌ Exit")
            
            print()
            print(f"{Colors.GRAY}Current Category: {Colors.WHITE}{self.current_category.title()}{Colors.RESET}")
            print()
            
            choice = get_input("Enter your choice (1-8): ")
            
            if choice == '1':
                self.spark_ideas()
            elif choice == '2':
                self.browse_categories()
            elif choice == '3':
                self.creative_prompts()
            elif choice == '4':
                self.word_association()
            elif choice == '5':
                self.view_favorites()
            elif choice == '6':
                self.idea_storm()
            elif choice == '7':
                self.statistics()
            elif choice == '8':
                slow_print("Keep the creative spark alive!", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-8.")
                time.sleep(1)

def main():
    """Main function to run Idea Spark"""
    try:
        idea_spark = IdeaSpark()
        idea_spark.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
