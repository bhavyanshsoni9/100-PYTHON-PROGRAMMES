# Created by Bhavyansh Soni
# Key Generator - Advanced password and key generation with cyberpunk style

import sys
import os
import time
import random
import string
import secrets
import hashlib
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class KeyGenerator:
    def __init__(self):
        self.running = True
        self.generated_keys = []
        self.key_templates = {
            "simple": {
                "chars": string.ascii_letters + string.digits,
                "length": 12,
                "description": "Letters and numbers only"
            },
            "complex": {
                "chars": string.ascii_letters + string.digits + "!@#$%^&*",
                "length": 16,
                "description": "Letters, numbers, and symbols"
            },
            "ultra": {
                "chars": string.ascii_letters + string.digits + string.punctuation,
                "length": 24,
                "description": "Maximum complexity"
            },
            "pin": {
                "chars": string.digits,
                "length": 6,
                "description": "Numeric PIN"
            },
            "hex": {
                "chars": "0123456789ABCDEF",
                "length": 32,
                "description": "Hexadecimal key"
            }
        }
    
    def calculate_entropy(self, password):
        """Calculate password entropy"""
        char_space = 0
        
        if any(c.islower() for c in password):
            char_space += 26
        if any(c.isupper() for c in password):
            char_space += 26
        if any(c.isdigit() for c in password):
            char_space += 10
        if any(c in string.punctuation for c in password):
            char_space += len(string.punctuation)
        
        if char_space == 0:
            return 0
        
        import math
        entropy = len(password) * math.log2(char_space)
        return entropy
    
    def assess_strength(self, password):
        """Assess password strength"""
        entropy = self.calculate_entropy(password)
        
        if entropy < 30:
            return "Very Weak", Colors.ERROR
        elif entropy < 40:
            return "Weak", Colors.WARNING
        elif entropy < 60:
            return "Moderate", Colors.SECONDARY
        elif entropy < 80:
            return "Strong", Colors.ACCENT
        else:
            return "Very Strong", Colors.PRIMARY
    
    def generate_password(self):
        """Generate secure password with options"""
        clear_screen()
        print_banner("🔐 PASSWORD GENERATOR 🔐")
        print()
        
        print("Password templates:")
        templates = list(self.key_templates.keys())
        for i, template_name in enumerate(templates, 1):
            template = self.key_templates[template_name]
            print_menu_item(i, f"{template_name.title()}: {template['description']} ({template['length']} chars)")
        
        print_menu_item(len(templates) + 1, "Custom Configuration")
        
        print()
        choice = get_input(f"Select template (1-{len(templates) + 1}): ")
        
        try:
            if choice == str(len(templates) + 1):
                # Custom configuration
                self.custom_password_config()
                return
            else:
                template_name = templates[int(choice) - 1]
                template = self.key_templates[template_name]
                chars = template["chars"]
                length = template["length"]
        except (ValueError, IndexError):
            print_error("Invalid template selection!")
            time.sleep(1)
            return
        
        # Generate password
        clear_screen()
        print_banner("🔐 GENERATING PASSWORD 🔐")
        print()
        
        slow_print("Initializing cryptographic random generator...", 0.02, Colors.ACCENT)
        animate_loading("Generating secure password", 2)
        
        # Use cryptographically secure random
        password = ''.join(secrets.choice(chars) for _ in range(length))
        
        self.display_password_result(password, template_name)
    
    def custom_password_config(self):
        """Custom password configuration"""
        clear_screen()
        print_banner("⚙️ CUSTOM PASSWORD CONFIG ⚙️")
        print()
        
        # Length
        try:
            length = int(get_input("Password length (4-128): "))
            if length < 4 or length > 128:
                print_error("Length must be between 4 and 128!")
                time.sleep(1)
                return
        except ValueError:
            print_error("Invalid length!")
            time.sleep(1)
            return
        
        # Character options
        chars = ""
        
        if get_input("Include lowercase letters? (Y/n): ").lower() != 'n':
            chars += string.ascii_lowercase
        
        if get_input("Include uppercase letters? (Y/n): ").lower() != 'n':
            chars += string.ascii_uppercase
        
        if get_input("Include numbers? (Y/n): ").lower() != 'n':
            chars += string.digits
        
        if get_input("Include symbols? (y/N): ").lower() == 'y':
            chars += "!@#$%^&*()-_=+[]{}|;:,.<>?"
        
        if get_input("Include all punctuation? (y/N): ").lower() == 'y':
            chars += string.punctuation
        
        if not chars:
            print_error("At least one character type must be selected!")
            time.sleep(1)
            return
        
        # Exclusions
        exclude = get_input("Characters to exclude (optional): ")
        for char in exclude:
            chars = chars.replace(char, '')
        
        if not chars:
            print_error("No characters left after exclusions!")
            time.sleep(1)
            return
        
        # Generate password
        clear_screen()
        print_banner("🔐 GENERATING CUSTOM PASSWORD 🔐")
        print()
        
        animate_loading("Creating password", 2)
        
        password = ''.join(secrets.choice(chars) for _ in range(length))
        self.display_password_result(password, "custom")
    
    def display_password_result(self, password, template_name):
        """Display generated password with analysis"""
        clear_screen()
        print_banner("🔐 GENERATED PASSWORD 🔐")
        print()
        
        # Display password
        print(f"{Colors.ACCENT}Password:{Colors.RESET}")
        print(f"{Colors.PRIMARY}{password}{Colors.RESET}")
        print()
        
        # Analysis
        entropy = self.calculate_entropy(password)
        strength, strength_color = self.assess_strength(password)
        
        print(f"{Colors.ACCENT}Template: {Colors.WHITE}{template_name.title()}{Colors.RESET}")
        print(f"{Colors.ACCENT}Length: {Colors.WHITE}{len(password)} characters{Colors.RESET}")
        print(f"{Colors.ACCENT}Entropy: {Colors.WHITE}{entropy:.1f} bits{Colors.RESET}")
        print(f"{Colors.ACCENT}Strength: {strength_color}{strength}{Colors.RESET}")
        
        print()
        
        # Character composition
        lowercase = sum(1 for c in password if c.islower())
        uppercase = sum(1 for c in password if c.isupper())
        digits = sum(1 for c in password if c.isdigit())
        symbols = sum(1 for c in password if c in string.punctuation)
        
        print(f"{Colors.ACCENT}Composition:{Colors.RESET}")
        if lowercase > 0:
            print(f"  Lowercase: {lowercase}")
        if uppercase > 0:
            print(f"  Uppercase: {uppercase}")
        if digits > 0:
            print(f"  Digits: {digits}")
        if symbols > 0:
            print(f"  Symbols: {symbols}")
        
        # Time to crack estimation
        self.estimate_crack_time(entropy)
        
        # Save option
        print()
        save_choice = get_input("Save this password? (y/N): ").lower()
        if save_choice == 'y':
            label = get_input("Enter label for this password: ")
            if label:
                password_entry = {
                    "password": password,
                    "label": label,
                    "template": template_name,
                    "entropy": entropy,
                    "strength": strength,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                self.generated_keys.append(password_entry)
                print_success("Password saved!")
        
        press_enter_to_continue()
    
    def estimate_crack_time(self, entropy):
        """Estimate time to crack password"""
        # Assume 1 billion attempts per second
        attempts_per_second = 1e9
        combinations = 2 ** entropy
        seconds_to_crack = combinations / (2 * attempts_per_second)  # Average case
        
        if seconds_to_crack < 60:
            time_str = f"{seconds_to_crack:.1f} seconds"
        elif seconds_to_crack < 3600:
            time_str = f"{seconds_to_crack/60:.1f} minutes"
        elif seconds_to_crack < 86400:
            time_str = f"{seconds_to_crack/3600:.1f} hours"
        elif seconds_to_crack < 31536000:
            time_str = f"{seconds_to_crack/86400:.1f} days"
        elif seconds_to_crack < 31536000 * 1000:
            time_str = f"{seconds_to_crack/31536000:.1f} years"
        else:
            time_str = "Centuries (practically uncrackable)"
        
        print()
        print(f"{Colors.ACCENT}Estimated crack time: {Colors.WHITE}{time_str}{Colors.RESET}")
        print(f"{Colors.GRAY}(Assuming 1 billion attempts/second){Colors.RESET}")
    
    def api_key_generator(self):
        """Generate API keys and tokens"""
        clear_screen()
        print_banner("🔑 API KEY GENERATOR 🔑")
        print()
        
        key_types = {
            "uuid": "UUID-4 format",
            "hex": "Hexadecimal key",
            "base64": "Base64 encoded key",
            "jwt_secret": "JWT signing secret",
            "api_token": "API token format"
        }
        
        for i, (key_type, description) in enumerate(key_types.items(), 1):
            print_menu_item(i, f"{key_type.upper()}: {description}")
        
        print()
        choice = get_input(f"Select key type (1-{len(key_types)}): ")
        
        try:
            key_type = list(key_types.keys())[int(choice) - 1]
        except (ValueError, IndexError):
            print_error("Invalid key type!")
            time.sleep(1)
            return
        
        clear_screen()
        print_banner(f"🔑 GENERATING {key_type.upper()} KEY 🔑")
        print()
        
        animate_loading("Creating secure key", 2)
        
        if key_type == "uuid":
            import uuid
            key = str(uuid.uuid4())
        
        elif key_type == "hex":
            key_bytes = secrets.token_bytes(32)
            key = key_bytes.hex().upper()
        
        elif key_type == "base64":
            import base64
            key_bytes = secrets.token_bytes(32)
            key = base64.b64encode(key_bytes).decode()
        
        elif key_type == "jwt_secret":
            key = secrets.token_urlsafe(64)
        
        elif key_type == "api_token":
            prefix = "sk_"  # Secret key prefix
            key_part = secrets.token_urlsafe(48)
            key = prefix + key_part
        
        print(f"{Colors.ACCENT}Generated {key_type.upper()} Key:{Colors.RESET}")
        print(f"{Colors.PRIMARY}{key}{Colors.RESET}")
        
        print()
        print(f"{Colors.ACCENT}Key Length: {Colors.WHITE}{len(key)} characters{Colors.RESET}")
        print(f"{Colors.ACCENT}Format: {Colors.WHITE}{key_types[key_type]}{Colors.RESET}")
        
        # Save option
        print()
        save_choice = get_input("Save this key? (y/N): ").lower()
        if save_choice == 'y':
            label = get_input("Enter label for this key: ")
            if label:
                key_entry = {
                    "password": key,
                    "label": label,
                    "template": key_type,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                self.generated_keys.append(key_entry)
                print_success("Key saved!")
        
        press_enter_to_continue()
    
    def passphrase_generator(self):
        """Generate memorable passphrases"""
        clear_screen()
        print_banner("📝 PASSPHRASE GENERATOR 📝")
        print()
        
        word_lists = {
            "common": ["apple", "beach", "chair", "dance", "eagle", "flame", "grape", "house", "ice", "jump"],
            "tech": ["crypto", "neural", "pixel", "quantum", "binary", "matrix", "cyber", "digital", "network", "algorithm"],
            "nature": ["mountain", "river", "forest", "ocean", "cloud", "storm", "sunset", "flower", "breeze", "thunder"],
            "colors": ["crimson", "azure", "golden", "silver", "violet", "emerald", "amber", "coral", "indigo", "scarlet"]
        }
        
        print("Word list themes:")
        themes = list(word_lists.keys())
        for i, theme in enumerate(themes, 1):
            print_menu_item(i, f"{theme.title()} words")
        
        print()
        theme_choice = get_input(f"Select theme (1-{len(themes)}): ")
        
        try:
            theme = themes[int(theme_choice) - 1]
            words = word_lists[theme]
        except (ValueError, IndexError):
            print_error("Invalid theme!")
            time.sleep(1)
            return
        
        try:
            word_count = int(get_input("Number of words (3-8): "))
            if word_count < 3 or word_count > 8:
                print_error("Word count must be between 3 and 8!")
                time.sleep(1)
                return
        except ValueError:
            print_error("Invalid word count!")
            time.sleep(1)
            return
        
        # Separator options
        print()
        print("Separator options:")
        print("1. Hyphen (-)")
        print("2. Underscore (_)")
        print("3. Space ( )")
        print("4. Numbers (random)")
        print("5. No separator")
        
        sep_choice = get_input("Select separator (1-5): ")
        separators = {
            "1": "-",
            "2": "_", 
            "3": " ",
            "4": "random",
            "5": ""
        }
        separator = separators.get(sep_choice, "-")
        
        # Generate passphrase
        clear_screen()
        print_banner("📝 GENERATING PASSPHRASE 📝")
        print()
        
        animate_loading("Creating memorable passphrase", 2)
        
        selected_words = secrets.SystemRandom().sample(words * 10, word_count)  # Allow repeats
        
        if separator == "random":
            passphrase_parts = []
            for i, word in enumerate(selected_words):
                passphrase_parts.append(word.title())
                if i < len(selected_words) - 1:
                    passphrase_parts.append(str(secrets.randbelow(100)))
            passphrase = "".join(passphrase_parts)
        else:
            passphrase = separator.join(word.title() for word in selected_words)
        
        print(f"{Colors.ACCENT}Generated Passphrase:{Colors.RESET}")
        print(f"{Colors.PRIMARY}{passphrase}{Colors.RESET}")
        
        print()
        entropy = self.calculate_entropy(passphrase)
        strength, strength_color = self.assess_strength(passphrase)
        
        print(f"{Colors.ACCENT}Length: {Colors.WHITE}{len(passphrase)} characters{Colors.RESET}")
        print(f"{Colors.ACCENT}Words: {Colors.WHITE}{word_count}{Colors.RESET}")
        print(f"{Colors.ACCENT}Theme: {Colors.WHITE}{theme.title()}{Colors.RESET}")
        print(f"{Colors.ACCENT}Entropy: {Colors.WHITE}{entropy:.1f} bits{Colors.RESET}")
        print(f"{Colors.ACCENT}Strength: {strength_color}{strength}{Colors.RESET}")
        
        # Save option
        print()
        save_choice = get_input("Save this passphrase? (y/N): ").lower()
        if save_choice == 'y':
            label = get_input("Enter label for this passphrase: ")
            if label:
                key_entry = {
                    "password": passphrase,
                    "label": label,
                    "template": f"passphrase_{theme}",
                    "entropy": entropy,
                    "strength": strength,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                self.generated_keys.append(key_entry)
                print_success("Passphrase saved!")
        
        press_enter_to_continue()
    
    def password_strength_checker(self):
        """Check strength of existing password"""
        clear_screen()
        print_banner("🔍 PASSWORD STRENGTH CHECKER 🔍")
        print()
        
        password = get_input("Enter password to analyze: ")
        if not password:
            print_error("Password cannot be empty!")
            time.sleep(1)
            return
        
        clear_screen()
        print_banner("🔍 PASSWORD ANALYSIS 🔍")
        print()
        
        # Basic info
        print(f"{Colors.ACCENT}Password: {Colors.WHITE}{'*' * len(password)}{Colors.RESET}")
        print(f"{Colors.ACCENT}Length: {Colors.WHITE}{len(password)} characters{Colors.RESET}")
        
        # Strength assessment
        entropy = self.calculate_entropy(password)
        strength, strength_color = self.assess_strength(password)
        
        print(f"{Colors.ACCENT}Entropy: {Colors.WHITE}{entropy:.1f} bits{Colors.RESET}")
        print(f"{Colors.ACCENT}Strength: {strength_color}{strength}{Colors.RESET}")
        
        # Character analysis
        print()
        print(f"{Colors.ACCENT}Character Analysis:{Colors.RESET}")
        
        has_lower = any(c.islower() for c in password)
        has_upper = any(c.isupper() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_symbol = any(c in string.punctuation for c in password)
        
        checks = [
            ("Lowercase letters", has_lower),
            ("Uppercase letters", has_upper),
            ("Numbers", has_digit),
            ("Symbols", has_symbol),
            ("Minimum 8 characters", len(password) >= 8),
            ("Minimum 12 characters", len(password) >= 12)
        ]
        
        for check_name, passed in checks:
            status = "✓" if passed else "✗"
            color = Colors.PRIMARY if passed else Colors.ERROR
            print(f"  {color}{status} {check_name}{Colors.RESET}")
        
        # Common patterns check
        print()
        print(f"{Colors.ACCENT}Pattern Analysis:{Colors.RESET}")
        
        patterns = [
            ("Sequential numbers", any(password[i:i+3] in "0123456789" for i in range(len(password)-2))),
            ("Sequential letters", any(password[i:i+3].lower() in "abcdefghijklmnopqrstuvwxyz" for i in range(len(password)-2))),
            ("Repeated characters", any(password[i] == password[i+1] == password[i+2] for i in range(len(password)-2))),
            ("Common keyboard patterns", any(pattern in password.lower() for pattern in ["qwerty", "123456", "password"]))
        ]
        
        for pattern_name, found in patterns:
            status = "⚠" if found else "✓"
            color = Colors.WARNING if found else Colors.PRIMARY
            print(f"  {color}{status} {pattern_name}{Colors.RESET}")
        
        # Recommendations
        print()
        print(f"{Colors.ACCENT}Recommendations:{Colors.RESET}")
        
        if len(password) < 12:
            print(f"  {Colors.WARNING}• Increase length to at least 12 characters{Colors.RESET}")
        
        if not has_upper:
            print(f"  {Colors.WARNING}• Add uppercase letters{Colors.RESET}")
        
        if not has_lower:
            print(f"  {Colors.WARNING}• Add lowercase letters{Colors.RESET}")
        
        if not has_digit:
            print(f"  {Colors.WARNING}• Add numbers{Colors.RESET}")
        
        if not has_symbol:
            print(f"  {Colors.WARNING}• Add symbols (!@#$%^&*){Colors.RESET}")
        
        if entropy > 80:
            print(f"  {Colors.PRIMARY}• Excellent password! Consider using a password manager{Colors.RESET}")
        
        self.estimate_crack_time(entropy)
        
        press_enter_to_continue()
    
    def view_saved_keys(self):
        """View saved passwords and keys"""
        clear_screen()
        print_banner("💾 SAVED KEYS & PASSWORDS 💾")
        print()
        
        if not self.generated_keys:
            print_warning("No saved keys or passwords!")
            press_enter_to_continue()
            return
        
        for i, entry in enumerate(self.generated_keys, 1):
            label = entry["label"]
            template = entry["template"]
            timestamp = entry["timestamp"]
            
            print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{label}{Colors.RESET}")
            print(f"     Type: {template.title()} | Created: {timestamp}")
            
            if "strength" in entry:
                strength = entry["strength"]
                if strength == "Very Strong":
                    strength_color = Colors.PRIMARY
                elif strength == "Strong":
                    strength_color = Colors.ACCENT
                elif strength == "Moderate":
                    strength_color = Colors.SECONDARY
                else:
                    strength_color = Colors.WARNING
                print(f"     Strength: {strength_color}{strength}{Colors.RESET}")
            
            print()
        
        choice = get_input("Enter number to view password (or press Enter to return): ")
        
        if choice.isdigit():
            try:
                index = int(choice) - 1
                if 0 <= index < len(self.generated_keys):
                    entry = self.generated_keys[index]
                    print()
                    print(f"{Colors.ACCENT}Password/Key:{Colors.RESET}")
                    print(f"{Colors.PRIMARY}{entry['password']}{Colors.RESET}")
                    
                    delete_choice = get_input("\nDelete this entry? (y/N): ").lower()
                    if delete_choice == 'y':
                        self.generated_keys.pop(index)
                        print_success("Entry deleted!")
                        time.sleep(1)
            except ValueError:
                pass
        
        if choice:
            press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Key generator ASCII art
            key_art = """
    ██╗  ██╗███████╗██╗   ██╗     ██████╗ ███████╗███╗   ██╗███████╗██████╗  █████╗ ████████╗ ██████╗ ██████╗ 
    ██║ ██╔╝██╔════╝╚██╗ ██╔╝    ██╔════╝ ██╔════╝████╗  ██║██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔═══██╗██╔══██╗
    █████╔╝ █████╗   ╚████╔╝     ██║  ███╗█████╗  ██╔██╗ ██║█████╗  ██████╔╝███████║   ██║   ██║   ██║██████╔╝
    ██╔═██╗ ██╔══╝    ╚██╔╝      ██║   ██║██╔══╝  ██║╚██╗██║██╔══╝  ██╔══██╗██╔══██║   ██║   ██║   ██║██╔══██╗
    ██║  ██╗███████╗   ██║       ╚██████╔╝███████╗██║ ╚████║███████╗██║  ██║██║  ██║   ██║   ╚██████╔╝██║  ██║
    ╚═╝  ╚═╝╚══════╝   ╚═╝        ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝
            """
            
            print_ascii_art(key_art, Colors.ACCENT)
            print()
            slow_print("Generate unbreakable keys and passwords!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🔐 Password Generator")
            print_menu_item(2, "🔑 API Key Generator")
            print_menu_item(3, "📝 Passphrase Generator")
            print_menu_item(4, "🔍 Password Strength Checker")
            print_menu_item(5, "💾 View Saved Keys")
            print_menu_item(6, "📊 Security Tips")
            print_menu_item(7, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.generate_password()
            elif choice == '2':
                self.api_key_generator()
            elif choice == '3':
                self.passphrase_generator()
            elif choice == '4':
                self.password_strength_checker()
            elif choice == '5':
                self.view_saved_keys()
            elif choice == '6':
                self.show_security_tips()
            elif choice == '7':
                slow_print("Stay secure in the digital realm! 🔐", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)
    
    def show_security_tips(self):
        """Display security tips and best practices"""
        clear_screen()
        print_banner("🛡️ SECURITY TIPS 🛡️")
        print()
        
        tips = [
            "Use unique passwords for every account",
            "Enable two-factor authentication (2FA) wherever possible",
            "Use a reputable password manager",
            "Regularly update your passwords",
            "Avoid using personal information in passwords",
            "Don't share passwords via email or text",
            "Use long passphrases for memorable passwords",
            "Regularly check for data breaches",
            "Keep your devices and software updated",
            "Be cautious of phishing attempts"
        ]
        
        for i, tip in enumerate(tips, 1):
            slow_print(f"{i:2d}. {tip}", 0.02, Colors.PRIMARY)
            time.sleep(0.1)
        
        press_enter_to_continue()

def main():
    """Main function to run Key Generator"""
    try:
        key_gen = KeyGenerator()
        key_gen.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
