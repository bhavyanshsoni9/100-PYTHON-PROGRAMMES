import random
from utils import slow_print, print_signature

RECIPES = {
    ('cheese', 'bread'): {
        'name': 'Grilled Cheese Sandwich',
        'recipe': '1. Butter bread slices\n2. Add cheese between slices\n3. Grill until golden brown 🧀'
    },
    ('pasta', 'tomato'): {
        'name': 'Quick Tomato Pasta',
        'recipe': '1. Boil pasta\n2. Chop & cook tomatoes\n3. Mix together with herbs 🍝'
    },
    ('egg', 'bread'): {
        'name': 'French Toast',
        'recipe': '1. Beat egg with milk\n2. Dip bread\n3. Fry until golden 🍞'
    },
    ('potato', 'cheese'): {
        'name': 'Cheesy Potato Wedges',
        'recipe': '1. Cut potatoes into wedges\n2. Season & bake\n3. Top with cheese 🥔'
    },
    ('rice', 'egg'): {
        'name': 'Egg Fried Rice',
        'recipe': '1. Cook rice\n2. Scramble egg\n3. Mix with soy sauce 🍚'
    },
    ('chicken', 'rice'): {
        'name': 'Simple Chicken Rice',
        'recipe': '1. Cook rice\n2. Grill seasoned chicken\n3. Serve together 🍗'
    }
}

def find_recipe(ingredients):
    """Find a recipe based on available ingredients."""
    ingredients = set(ingredients)
    possible_recipes = []
    
    for recipe_ingredients, recipe in RECIPES.items():
        if all(ing in ingredients for ing in recipe_ingredients):
            possible_recipes.append(recipe)
    
    return random.choice(possible_recipes) if possible_recipes else None

def main():
    slow_print("🍳 Welcome to the Lazy Chef Recipe Suggester! 🍳", color='green')
    slow_print("Enter 2-3 ingredients you have (separated by spaces)", color='yellow')
    slow_print("Type 'quit' to exit", color='yellow')
    
    while True:
        ingredients = input("\nWhat ingredients do you have? ").lower()
        if ingredients == 'quit':
            break
            
        ingredients = [ing.strip() for ing in ingredients.split()]
        recipe = find_recipe(ingredients)
        
        if recipe:
            slow_print(f"\n🎉 You can make: {recipe['name']}", color='green')
            slow_print("\nHere's how:", color='cyan')
            slow_print(recipe['recipe'], color='magenta')
        else:
            slow_print("\n😕 Sorry, couldn't find a recipe with those ingredients.", color='red')
            slow_print("Try different combinations!", color='yellow')
    
    print_signature()

if __name__ == "__main__":
    main() 