import random
from utils import slow_print, print_signature

MEMORIES = {
    1990: {
        'movie': 'Ghost',
        'song': 'Nothing Compares 2 U - Sinéad O\'Connor',
        'event': 'The World Wide Web was created'
    },
    1995: {
        'movie': 'Toy Story',
        'song': 'Gangsta\'s Paradise - Coolio',
        'event': 'JavaScript programming language was created'
    },
    2000: {
        'movie': 'Gladiator',
        'song': 'Say My Name - Destiny\'s Child',
        'event': 'The Y2K scare came and went'
    },
    2005: {
        'movie': 'Batman Begins',
        'song': 'We Belong Together - Mariah Carey',
        'event': 'YouTube was founded'
    },
    2010: {
        'movie': 'Inception',
        'song': 'Tik Tok - Kesha',
        'event': 'Instagram was launched'
    },
    2015: {
        'movie': 'Star Wars: The Force Awakens',
        'song': 'Uptown Funk - Mark Ronson ft. Bruno Mars',
        'event': 'NASA\'s New Horizons spacecraft reached Pluto'
    },
    2020: {
        'movie': 'Tenet',
        'song': 'Blinding Lights - The Weeknd',
        'event': 'Global COVID-19 pandemic began'
    }
}

def get_memories(year):
    """Get memories from a specific year."""
    # Find the closest year if exact year not found
    available_years = sorted(MEMORIES.keys())
    closest_year = min(available_years, key=lambda x: abs(x - year))
    
    if abs(closest_year - year) > 5:
        return None
    return closest_year, MEMORIES[closest_year]

def main():
    slow_print("🎬 Welcome to Memory Lane! 🎵", color='green')
    slow_print("Enter a year (1990-2020) to discover what happened!", color='yellow')
    slow_print("Type 'quit' to exit", color='yellow')
    
    while True:
        try:
            year_input = input("\nEnter a year: ")
            if year_input.lower() == 'quit':
                break
                
            year = int(year_input)
            result = get_memories(year)
            
            if result:
                actual_year, memories = result
                if actual_year != year:
                    slow_print(f"\nClosest year found: {actual_year}", color='yellow')
                
                slow_print(f"\n🎬 Popular Movie: {memories['movie']}", color='cyan')
                slow_print(f"🎵 Hit Song: {memories['song']}", color='magenta')
                slow_print(f"📅 Major Event: {memories['event']}", color='green')
            else:
                slow_print("\n❌ Sorry, no memories found for that year!", color='red')
                slow_print("Try a year between 1990-2020", color='yellow')
                
        except ValueError:
            slow_print("\n❌ Please enter a valid year!", color='red')
    
    print_signature()

if __name__ == "__main__":
    main() 