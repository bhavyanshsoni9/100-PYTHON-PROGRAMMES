# 🧠 Memory Palace

**Created by Bhavyansh Soni**

## Description
An innovative memory training game where players build a mental palace filled with themed rooms. Each room contains unique emoji sequences that must be memorized and recreated perfectly. Progress through 12 beautifully themed rooms, from cozy living spaces to cosmic voids!

## Gameplay Features
- 🏰 **12 Unique Themed Rooms**: Each with distinct emojis and atmosphere
- 🧠 **Progressive Difficulty**: Sequences get longer and viewing time decreases
- ❤️ **Life System**: 3 chances to complete each room
- 🏆 **Scoring System**: Points based on sequence length and room number
- 🎭 **Themed Emojis**: Each room has its own vocabulary of 6 unique emojis
- ⏰ **Time Pressure**: Limited viewing time adds challenge

## Room Themes
1. 🏠 **Living Room**: Furniture and home comfort items
2. 🍳 **Kitchen**: Cooking utensils and food items
3. 🛏️ **Bedroom**: Sleep and personal items
4. 🌸 **Garden**: Nature and outdoor elements
5. 📚 **Library**: Books and learning tools
6. 🎨 **Art Studio**: Creative and artistic items
7. 🔬 **Laboratory**: Scientific equipment
8. 🎵 **Music Room**: Musical instruments
9. 🌌 **Observatory**: Space and astronomy
10. 🏰 **Throne Room**: Royal and medieval items
11. 🌊 **Ocean Depths**: Marine life and water
12. 🌟 **Cosmic Void**: Mystical and infinite concepts

## How to Play
1. Enter each themed room and study its emoji vocabulary
2. Watch the sequence appear with emojis from that room
3. Memorize the exact order during the viewing time
4. Recreate the sequence by selecting numbers 1-6
5. Complete all positions correctly to advance
6. Build your memory palace by conquering all 12 rooms!

## Difficulty Progression
- **Sequence Length**: Starts at 3, increases every 2 rooms (max 8)
- **Viewing Time**: Starts at 3 seconds, decreases by 0.2s per room
- **Point Values**: Higher rooms give more points per emoji

## Memory Tips
- 💡 **Create Stories**: Link emojis together in a narrative
- 🔄 **Use Repetition**: Say the sequence aloud mentally
- 🎭 **Visualize Actions**: Imagine using or interacting with items
- 🏠 **Room Association**: Connect emojis to their room theme
- 🔗 **Chain Method**: Link each emoji to the next logically

## Scoring System
- **Points per emoji**: Sequence length × 10 × Room number
- **Example**: 4-emoji sequence in Room 5 = 4 × 10 × 5 = 200 points

## Achievement Levels
- 🌟 **Legendary Memory Master**: Complete all 12 rooms (100%)
- 🧠 **Exceptional Memory Architect**: 80%+ completion
- 🏆 **Skilled Memory Builder**: 60%+ completion
- 📚 **Developing Memory Scholar**: 40%+ completion
- 🌱 **Memory Apprentice**: Below 40% completion

## Mental Training Benefits
- Improves working memory capacity
- Enhances pattern recognition
- Develops concentration skills
- Strengthens sequential processing
- Builds mental visualization abilities
