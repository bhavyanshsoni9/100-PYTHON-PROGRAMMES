#!/usr/bin/env python3
"""
🧠 MEMORY PALACE 🧠
Created by Bhavyansh Soni

An original memory game where players build mental rooms filled with emoji sequences.
Remember the patterns, recreate them, and expand your palace of memories!
Each room gets more complex with longer sequences and time pressure.
"""

import random
import time
import sys
import os
from colorama import init, Fore, Back, Style

# Add parent directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
from utils.terminal_effects import slow_print, rainbow_text, clear_screen, create_banner, pulse_text

# Initialize colorama
init(autoreset=True)

class MemoryPalace:
    def __init__(self):
        self.rooms = 1
        self.current_room = 1
        self.lives = 3
        self.score = 0
        self.sequence_length = 3
        self.view_time = 2.0
        self.max_rooms = 12
        
        # Memory emoji categories for different rooms
        self.room_themes = {
            1: {"name": "🏠 Living Room", "emojis": ["🛋️", "📺", "🕯️", "📚", "🖼️", "🪴"], "color": Fore.YELLOW},
            2: {"name": "🍳 Kitchen", "emojis": ["🍳", "🥄", "🍽️", "☕", "🧄", "🥕"], "color": Fore.GREEN},
            3: {"name": "🛏️ Bedroom", "emojis": ["🛏️", "💤", "🕯️", "👕", "📖", "🧸"], "color": Fore.BLUE},
            4: {"name": "🌸 Garden", "emojis": ["🌸", "🌱", "🦋", "🐝", "🌳", "💧"], "color": Fore.MAGENTA},
            5: {"name": "📚 Library", "emojis": ["📚", "📝", "🖊️", "📜", "🔍", "💡"], "color": Fore.CYAN},
            6: {"name": "🎨 Art Studio", "emojis": ["🎨", "🖌️", "🎭", "🎪", "🌈", "✨"], "color": Fore.RED},
            7: {"name": "🔬 Laboratory", "emojis": ["🔬", "⚗️", "🧪", "⚛️", "🔬", "💊"], "color": Fore.WHITE},
            8: {"name": "🎵 Music Room", "emojis": ["🎵", "🎹", "🎸", "🥁", "🎤", "🎺"], "color": Fore.YELLOW},
            9: {"name": "🌌 Observatory", "emojis": ["🌌", "⭐", "🔭", "🌙", "🚀", "👽"], "color": Fore.BLUE},
            10: {"name": "🏰 Throne Room", "emojis": ["👑", "⚔️", "🛡️", "💎", "🏰", "🗝️"], "color": Fore.MAGENTA},
            11: {"name": "🌊 Ocean Depths", "emojis": ["🌊", "🐟", "🐙", "🦑", "🐚", "🔱"], "color": Fore.CYAN},
            12: {"name": "🌟 Cosmic Void", "emojis": ["🌟", "⚡", "🔮", "👁️", "🌀", "♾️"], "color": Fore.RED}
        }
        
        self.master_sequence = []
        self.player_sequence = []
        
    def show_intro(self):
        """Display game introduction"""
        clear_screen()
        
        intro_banner = create_banner("MEMORY PALACE", color=Fore.MAGENTA)
        print(intro_banner)
        
        slow_print(rainbow_text("🧠 Welcome to the most mind-bending memory challenge! 🧠"), delay=0.03)
        time.sleep(1)
        
        intro_text = [
            "\n🏰 BUILD YOUR PALACE OF MEMORIES:",
            "🔹 Watch emoji sequences appear in themed rooms",
            "🔹 Memorize the exact order and recreate it",
            "🔹 Each room has a unique theme and emojis",
            "🔹 Sequences get longer as you progress",
            "🔹 You have 3 lives to build your palace",
            "🔹 Complete all 12 rooms to become a Memory Master!",
            "\n💡 TIP: Create mental stories to remember sequences!",
        ]
        
        for text in intro_text:
            slow_print(Fore.WHITE + text, delay=0.02)
            time.sleep(0.4)
        
        slow_print(Fore.GREEN + "\n🧠 Ready to train your mind? Press ENTER to begin!", delay=0.03)
        input()
    
    def show_room_intro(self, room_num):
        """Show introduction for a specific room"""
        clear_screen()
        
        theme = self.room_themes[room_num]
        color = theme["color"]
        
        room_banner = create_banner(f"ROOM {room_num}", color=color)
        print(room_banner)
        
        slow_print(f"{color}🚪 Entering: {theme['name']}", delay=0.03)
        time.sleep(1)
        
        slow_print(f"{Fore.WHITE}📏 Sequence Length: {self.sequence_length}", delay=0.02)
        slow_print(f"{Fore.WHITE}⏰ View Time: {self.view_time:.1f} seconds", delay=0.02)
        slow_print(f"{Fore.WHITE}❤️ Lives Remaining: {self.lives}", delay=0.02)
        
        # Show room's emoji vocabulary
        slow_print(f"\n{color}🎭 Room Emojis:", delay=0.02)
        emoji_display = " ".join(theme["emojis"])
        slow_print(f"{color}   {emoji_display}", delay=0.05)
        
        time.sleep(2)
        slow_print(Fore.YELLOW + "\n🎯 Get ready to memorize the sequence...", delay=0.03)
        time.sleep(1)
    
    def generate_sequence(self, room_num):
        """Generate a sequence for the current room"""
        theme = self.room_themes[room_num]
        self.master_sequence = random.choices(theme["emojis"], k=self.sequence_length)
    
    def show_sequence(self, room_num):
        """Display the sequence for memorization"""
        clear_screen()
        
        theme = self.room_themes[room_num]
        color = theme["color"]
        
        slow_print(f"{color}🧠 MEMORIZE THIS SEQUENCE:", delay=0.03)
        print()
        
        # Show sequence with dramatic effect
        sequence_display = ""
        for i, emoji in enumerate(self.master_sequence):
            sequence_display += f"  {emoji}  "
            slow_print(f"{color}{sequence_display}", delay=0.3, end='\r')
        
        print()
        
        # Countdown timer
        slow_print(f"\n{Fore.WHITE}⏰ Memorization time remaining:", delay=0.02)
        
        for remaining in range(int(self.view_time), 0, -1):
            time_color = Fore.GREEN if remaining > 2 else Fore.RED
            print(f"\r{time_color}{remaining} seconds... ", end='', flush=True)
            time.sleep(1)
        
        print(f"\r{Fore.RED}Time's up!      ")
        time.sleep(0.5)
    
    def get_player_input(self, room_num):
        """Get the player's sequence input"""
        clear_screen()
        
        theme = self.room_themes[room_num]
        color = theme["color"]
        
        slow_print(f"{color}✍️ RECREATE THE SEQUENCE:", delay=0.03)
        slow_print(f"{Fore.WHITE}Enter the emojis in the exact order you saw them.", delay=0.02)
        
        # Show available emojis
        slow_print(f"\n{color}Available emojis:", delay=0.02)
        for i, emoji in enumerate(theme["emojis"], 1):
            print(f"{color}[{i}] {emoji}")
        
        self.player_sequence = []
        
        for position in range(self.sequence_length):
            while True:
                try:
                    slow_print(f"\n{Fore.YELLOW}Position {position + 1}: ", delay=0.02, end="")
                    choice = input().strip()
                    
                    if choice.isdigit() and 1 <= int(choice) <= len(theme["emojis"]):
                        emoji_index = int(choice) - 1
                        selected_emoji = theme["emojis"][emoji_index]
                        self.player_sequence.append(selected_emoji)
                        slow_print(f"{color}✓ Added: {selected_emoji}", delay=0.02)
                        break
                    else:
                        slow_print(Fore.RED + "❌ Invalid choice! Please enter a number 1-6.", delay=0.02)
                except ValueError:
                    slow_print(Fore.RED + "❌ Please enter a valid number.", delay=0.02)
    
    def check_sequence(self, room_num):
        """Check if the player's sequence matches the master sequence"""
        clear_screen()
        
        theme = self.room_themes[room_num]
        color = theme["color"]
        
        slow_print(f"{color}🔍 CHECKING YOUR MEMORY...", delay=0.03)
        time.sleep(1)
        
        # Show comparison
        slow_print(f"\n{Fore.WHITE}📝 Original sequence:", delay=0.02)
        original_display = "  ".join(self.master_sequence)
        slow_print(f"{color}   {original_display}", delay=0.05)
        
        slow_print(f"\n{Fore.WHITE}🧠 Your sequence:", delay=0.02)
        player_display = "  ".join(self.player_sequence)
        
        # Show each emoji with result
        result_display = ""
        correct_count = 0
        
        for i in range(len(self.master_sequence)):
            if i < len(self.player_sequence):
                if self.player_sequence[i] == self.master_sequence[i]:
                    result_display += f"  {Fore.GREEN}{self.player_sequence[i]}"
                    correct_count += 1
                else:
                    result_display += f"  {Fore.RED}{self.player_sequence[i]}"
            else:
                result_display += f"  {Fore.RED}❌"
        
        slow_print(result_display, delay=0.1)
        time.sleep(1)
        
        # Calculate score
        if self.player_sequence == self.master_sequence:
            points = self.sequence_length * 10 * room_num
            self.score += points
            
            slow_print(Fore.GREEN + "\n🎉 PERFECT MEMORY! 🎉", delay=0.03)
            slow_print(f"{Fore.YELLOW}💰 +{points} points! Total: {self.score}", delay=0.02)
            
            # Room completion effect
            pulse_text(f"🏆 {theme['name']} COMPLETED! 🏆", color=color, pulses=3)
            
            return True
        else:
            self.lives -= 1
            accuracy = (correct_count / len(self.master_sequence)) * 100
            
            slow_print(Fore.RED + "\n💔 Memory failed...", delay=0.03)
            slow_print(f"{Fore.WHITE}📊 Accuracy: {accuracy:.1f}%", delay=0.02)
            slow_print(f"{Fore.RED}❤️ Lives remaining: {self.lives}", delay=0.02)
            
            return False
    
    def update_difficulty(self):
        """Update difficulty for next room"""
        self.sequence_length = min(8, 3 + (self.current_room - 1) // 2)
        self.view_time = max(1.0, 3.0 - (self.current_room - 1) * 0.2)
    
    def show_palace_progress(self):
        """Show the player's progress through the palace"""
        clear_screen()
        
        progress_banner = create_banner("PALACE PROGRESS", color=Fore.MAGENTA)
        print(progress_banner)
        
        slow_print(f"{Fore.YELLOW}🏰 Rooms Completed: {self.current_room - 1}/{self.max_rooms}", delay=0.02)
        slow_print(f"{Fore.CYAN}🏆 Total Score: {self.score}", delay=0.02)
        slow_print(f"{Fore.RED}❤️ Lives Remaining: {self.lives}", delay=0.02)
        
        # Show completed rooms
        slow_print(f"\n{Fore.WHITE}🏛️ Your Memory Palace:", delay=0.02)
        for i in range(1, min(self.current_room, self.max_rooms + 1)):
            theme = self.room_themes[i]
            if i < self.current_room:
                slow_print(f"{theme['color']}  ✅ {theme['name']}", delay=0.01)
            else:
                slow_print(f"{Fore.WHITE}  🔒 {theme['name']} (Next)", delay=0.01)
        
        time.sleep(2)
    
    def show_game_over(self, victory=False):
        """Show final game results"""
        clear_screen()
        
        if victory:
            victory_banner = create_banner("MEMORY MASTER!", color=Fore.GOLD)
            print(victory_banner)
            
            slow_print(rainbow_text("🧠🏆 CONGRATULATIONS! YOU'VE BUILT THE COMPLETE MEMORY PALACE! 🏆🧠"), delay=0.05)
            time.sleep(2)
            
            slow_print(Fore.MAGENTA + "🌟 You are now a certified Memory Master! 🌟", delay=0.03)
        else:
            game_over_banner = create_banner("PALACE INCOMPLETE", color=Fore.RED)
            print(game_over_banner)
            
            slow_print(Fore.RED + "💔 Your memory palace remains unfinished...", delay=0.03)
        
        # Show final statistics
        stats = [
            f"\n📊 FINAL STATISTICS:",
            f"🏰 Rooms Completed: {self.current_room - 1}/{self.max_rooms}",
            f"🏆 Final Score: {self.score}",
            f"❤️ Lives Remaining: {self.lives}",
            f"🧠 Longest Sequence: {max(3, self.sequence_length - 1)}",
        ]
        
        for stat in stats:
            slow_print(Fore.CYAN + stat, delay=0.02)
            time.sleep(0.5)
        
        # Memory evaluation
        completion_rate = ((self.current_room - 1) / self.max_rooms) * 100
        
        if completion_rate == 100:
            slow_print(rainbow_text("🌟 LEGENDARY MEMORY MASTER! 🌟"), delay=0.05)
        elif completion_rate >= 80:
            slow_print(Fore.YELLOW + "🧠 Exceptional Memory Architect! 🧠", delay=0.03)
        elif completion_rate >= 60:
            slow_print(Fore.GREEN + "🏆 Skilled Memory Builder! 🏆", delay=0.03)
        elif completion_rate >= 40:
            slow_print(Fore.BLUE + "📚 Developing Memory Scholar! 📚", delay=0.03)
        else:
            slow_print(Fore.WHITE + "🌱 Memory Apprentice - Keep practicing! 🌱", delay=0.03)
        
        slow_print(Fore.WHITE + "\n🎮 Press ENTER to return to main menu...", delay=0.02)
        input()
    
    def game_loop(self):
        """Main game loop"""
        while self.current_room <= self.max_rooms and self.lives > 0:
            # Show progress
            if self.current_room > 1:
                self.show_palace_progress()
            
            # Room introduction
            self.show_room_intro(self.current_room)
            
            # Generate and show sequence
            self.generate_sequence(self.current_room)
            self.show_sequence(self.current_room)
            
            # Get player input and check result
            self.get_player_input(self.current_room)
            success = self.check_sequence(self.current_room)
            
            if success:
                self.current_room += 1
                self.update_difficulty()
                time.sleep(2)
            else:
                if self.lives > 0:
                    slow_print(Fore.YELLOW + "\n🔄 Try this room again...", delay=0.03)
                    time.sleep(2)
        
        # Show final results
        victory = self.current_room > self.max_rooms
        self.show_game_over(victory)

def main():
    """Main game entry point"""
    try:
        game = MemoryPalace()
        game.show_intro()
        game.game_loop()
    except KeyboardInterrupt:
        clear_screen()
        slow_print(Fore.YELLOW + "👋 Your memory palace awaits your return!", delay=0.03)
    except Exception as e:
        clear_screen()
        slow_print(Fore.RED + f"🚫 Game error: {e}", delay=0.02)
        slow_print(Fore.WHITE + "Press ENTER to continue...", delay=0.02)
        input()

if __name__ == "__main__":
    main()
