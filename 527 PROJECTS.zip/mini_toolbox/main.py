# Created by Bhavyansh Soni
# Mini Toolbox - Collection of handy utilities in cyberpunk style

import sys
import os
import time
import random
import base64
import hashlib
import json
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class MiniToolbox:
    def __init__(self):
        self.running = True
        
    def text_encoder_decoder(self):
        """Text encoding/decoding utilities"""
        clear_screen()
        print_banner("🔐 TEXT ENCODER/DECODER 🔐")
        print()
        
        print_menu_item(1, "Base64 Encode")
        print_menu_item(2, "Base64 Decode")
        print_menu_item(3, "URL Encode")
        print_menu_item(4, "URL Decode")
        print_menu_item(5, "Hash Generator")
        print_menu_item(6, "Back to Main Menu")
        
        print()
        choice = get_input("Select encoding option (1-6): ")
        
        if choice == '1':
            text = get_input("Enter text to encode: ")
            if text:
                encoded = base64.b64encode(text.encode()).decode()
                print(f"{Colors.PRIMARY}Base64: {encoded}{Colors.RESET}")
        
        elif choice == '2':
            text = get_input("Enter Base64 to decode: ")
            if text:
                try:
                    decoded = base64.b64decode(text.encode()).decode()
                    print(f"{Colors.PRIMARY}Decoded: {decoded}{Colors.RESET}")
                except:
                    print_error("Invalid Base64 format!")
        
        elif choice == '3':
            text = get_input("Enter text to URL encode: ")
            if text:
                import urllib.parse
                encoded = urllib.parse.quote(text)
                print(f"{Colors.PRIMARY}URL Encoded: {encoded}{Colors.RESET}")
        
        elif choice == '4':
            text = get_input("Enter URL encoded text to decode: ")
            if text:
                try:
                    import urllib.parse
                    decoded = urllib.parse.unquote(text)
                    print(f"{Colors.PRIMARY}Decoded: {decoded}{Colors.RESET}")
                except:
                    print_error("Invalid URL encoding!")
        
        elif choice == '5':
            text = get_input("Enter text to hash: ")
            if text:
                md5_hash = hashlib.md5(text.encode()).hexdigest()
                sha1_hash = hashlib.sha1(text.encode()).hexdigest()
                sha256_hash = hashlib.sha256(text.encode()).hexdigest()
                
                print(f"{Colors.ACCENT}MD5: {Colors.PRIMARY}{md5_hash}{Colors.RESET}")
                print(f"{Colors.ACCENT}SHA1: {Colors.PRIMARY}{sha1_hash}{Colors.RESET}")
                print(f"{Colors.ACCENT}SHA256: {Colors.PRIMARY}{sha256_hash}{Colors.RESET}")
        
        elif choice == '6':
            return
        
        if choice != '6':
            press_enter_to_continue()
    
    def unit_converter(self):
        """Unit conversion utilities"""
        clear_screen()
        print_banner("📏 UNIT CONVERTER 📏")
        print()
        
        print_menu_item(1, "Length Converter")
        print_menu_item(2, "Weight Converter")
        print_menu_item(3, "Temperature Converter")
        print_menu_item(4, "Data Size Converter")
        print_menu_item(5, "Back to Main Menu")
        
        print()
        choice = get_input("Select converter (1-5): ")
        
        if choice == '1':
            self.length_converter()
        elif choice == '2':
            self.weight_converter()
        elif choice == '3':
            self.temperature_converter()
        elif choice == '4':
            self.data_size_converter()
        elif choice == '5':
            return
        else:
            print_error("Invalid choice!")
            time.sleep(1)
    
    def length_converter(self):
        """Convert length units"""
        print()
        print("Length units: 1=mm, 2=cm, 3=m, 4=km, 5=in, 6=ft, 7=yd, 8=mi")
        
        try:
            value = float(get_input("Enter value: "))
            from_unit = int(get_input("From unit (1-8): "))
            to_unit = int(get_input("To unit (1-8): "))
            
            # Convert to meters first
            to_meters = {
                1: 0.001,      # mm
                2: 0.01,       # cm
                3: 1.0,        # m
                4: 1000.0,     # km
                5: 0.0254,     # in
                6: 0.3048,     # ft
                7: 0.9144,     # yd
                8: 1609.344    # mi
            }
            
            unit_names = {
                1: "mm", 2: "cm", 3: "m", 4: "km",
                5: "in", 6: "ft", 7: "yd", 8: "mi"
            }
            
            if from_unit in to_meters and to_unit in to_meters:
                meters = value * to_meters[from_unit]
                result = meters / to_meters[to_unit]
                
                print(f"{Colors.PRIMARY}{value} {unit_names[from_unit]} = {result:.6f} {unit_names[to_unit]}{Colors.RESET}")
            else:
                print_error("Invalid unit selection!")
        
        except ValueError:
            print_error("Invalid input!")
        
        press_enter_to_continue()
    
    def weight_converter(self):
        """Convert weight units"""
        print()
        print("Weight units: 1=mg, 2=g, 3=kg, 4=oz, 5=lb, 6=ton")
        
        try:
            value = float(get_input("Enter value: "))
            from_unit = int(get_input("From unit (1-6): "))
            to_unit = int(get_input("To unit (1-6): "))
            
            # Convert to grams first
            to_grams = {
                1: 0.001,      # mg
                2: 1.0,        # g
                3: 1000.0,     # kg
                4: 28.3495,    # oz
                5: 453.592,    # lb
                6: 1000000.0   # ton
            }
            
            unit_names = {
                1: "mg", 2: "g", 3: "kg", 4: "oz", 5: "lb", 6: "ton"
            }
            
            if from_unit in to_grams and to_unit in to_grams:
                grams = value * to_grams[from_unit]
                result = grams / to_grams[to_unit]
                
                print(f"{Colors.PRIMARY}{value} {unit_names[from_unit]} = {result:.6f} {unit_names[to_unit]}{Colors.RESET}")
            else:
                print_error("Invalid unit selection!")
        
        except ValueError:
            print_error("Invalid input!")
        
        press_enter_to_continue()
    
    def temperature_converter(self):
        """Convert temperature units"""
        print()
        print("Temperature units: 1=Celsius, 2=Fahrenheit, 3=Kelvin")
        
        try:
            value = float(get_input("Enter temperature value: "))
            from_unit = int(get_input("From unit (1-3): "))
            to_unit = int(get_input("To unit (1-3): "))
            
            # Convert to Celsius first
            if from_unit == 1:  # Celsius
                celsius = value
            elif from_unit == 2:  # Fahrenheit
                celsius = (value - 32) * 5/9
            elif from_unit == 3:  # Kelvin
                celsius = value - 273.15
            else:
                print_error("Invalid from unit!")
                return
            
            # Convert from Celsius to target
            if to_unit == 1:  # Celsius
                result = celsius
                unit_name = "°C"
            elif to_unit == 2:  # Fahrenheit
                result = celsius * 9/5 + 32
                unit_name = "°F"
            elif to_unit == 3:  # Kelvin
                result = celsius + 273.15
                unit_name = "K"
            else:
                print_error("Invalid to unit!")
                return
            
            from_names = {1: "°C", 2: "°F", 3: "K"}
            print(f"{Colors.PRIMARY}{value}{from_names[from_unit]} = {result:.2f}{unit_name}{Colors.RESET}")
        
        except ValueError:
            print_error("Invalid input!")
        
        press_enter_to_continue()
    
    def data_size_converter(self):
        """Convert data size units"""
        print()
        print("Data units: 1=B, 2=KB, 3=MB, 4=GB, 5=TB, 6=PB")
        
        try:
            value = float(get_input("Enter data size: "))
            from_unit = int(get_input("From unit (1-6): "))
            to_unit = int(get_input("To unit (1-6): "))
            
            # Convert to bytes first
            to_bytes = {
                1: 1,                    # B
                2: 1024,                 # KB
                3: 1024**2,              # MB
                4: 1024**3,              # GB
                5: 1024**4,              # TB
                6: 1024**5               # PB
            }
            
            unit_names = {
                1: "B", 2: "KB", 3: "MB", 4: "GB", 5: "TB", 6: "PB"
            }
            
            if from_unit in to_bytes and to_unit in to_bytes:
                bytes_value = value * to_bytes[from_unit]
                result = bytes_value / to_bytes[to_unit]
                
                print(f"{Colors.PRIMARY}{value} {unit_names[from_unit]} = {result:.6f} {unit_names[to_unit]}{Colors.RESET}")
            else:
                print_error("Invalid unit selection!")
        
        except ValueError:
            print_error("Invalid input!")
        
        press_enter_to_continue()
    
    def text_utilities(self):
        """Text manipulation utilities"""
        clear_screen()
        print_banner("📝 TEXT UTILITIES 📝")
        print()
        
        print_menu_item(1, "Character Counter")
        print_menu_item(2, "Word Counter")
        print_menu_item(3, "Text Case Converter")
        print_menu_item(4, "Text Reverser")
        print_menu_item(5, "Remove Duplicates")
        print_menu_item(6, "Back to Main Menu")
        
        print()
        choice = get_input("Select utility (1-6): ")
        
        if choice == '1':
            text = get_input("Enter text: ")
            if text:
                char_count = len(text)
                char_no_spaces = len(text.replace(' ', ''))
                print(f"{Colors.PRIMARY}Characters (with spaces): {char_count}{Colors.RESET}")
                print(f"{Colors.PRIMARY}Characters (no spaces): {char_no_spaces}{Colors.RESET}")
        
        elif choice == '2':
            text = get_input("Enter text: ")
            if text:
                words = text.split()
                word_count = len(words)
                unique_words = len(set(word.lower() for word in words))
                print(f"{Colors.PRIMARY}Total words: {word_count}{Colors.RESET}")
                print(f"{Colors.PRIMARY}Unique words: {unique_words}{Colors.RESET}")
        
        elif choice == '3':
            text = get_input("Enter text: ")
            if text:
                print(f"{Colors.ACCENT}UPPERCASE: {Colors.PRIMARY}{text.upper()}{Colors.RESET}")
                print(f"{Colors.ACCENT}lowercase: {Colors.PRIMARY}{text.lower()}{Colors.RESET}")
                print(f"{Colors.ACCENT}Title Case: {Colors.PRIMARY}{text.title()}{Colors.RESET}")
                print(f"{Colors.ACCENT}sWaP cAsE: {Colors.PRIMARY}{text.swapcase()}{Colors.RESET}")
        
        elif choice == '4':
            text = get_input("Enter text: ")
            if text:
                reversed_text = text[::-1]
                print(f"{Colors.PRIMARY}Reversed: {reversed_text}{Colors.RESET}")
        
        elif choice == '5':
            text = get_input("Enter text with duplicate words: ")
            if text:
                words = text.split()
                unique_words = []
                seen = set()
                for word in words:
                    if word.lower() not in seen:
                        unique_words.append(word)
                        seen.add(word.lower())
                result = ' '.join(unique_words)
                print(f"{Colors.PRIMARY}Without duplicates: {result}{Colors.RESET}")
        
        elif choice == '6':
            return
        
        if choice != '6':
            press_enter_to_continue()
    
    def number_utilities(self):
        """Number manipulation utilities"""
        clear_screen()
        print_banner("🔢 NUMBER UTILITIES 🔢")
        print()
        
        print_menu_item(1, "Number Base Converter")
        print_menu_item(2, "Random Number Generator")
        print_menu_item(3, "Prime Checker")
        print_menu_item(4, "Factorial Calculator")
        print_menu_item(5, "Fibonacci Generator")
        print_menu_item(6, "Back to Main Menu")
        
        print()
        choice = get_input("Select utility (1-6): ")
        
        if choice == '1':
            self.number_base_converter()
        elif choice == '2':
            self.random_number_generator()
        elif choice == '3':
            self.prime_checker()
        elif choice == '4':
            self.factorial_calculator()
        elif choice == '5':
            self.fibonacci_generator()
        elif choice == '6':
            return
        else:
            print_error("Invalid choice!")
            time.sleep(1)
    
    def number_base_converter(self):
        """Convert number between different bases"""
        print()
        print("Bases: 2=Binary, 8=Octal, 10=Decimal, 16=Hexadecimal")
        
        try:
            number = get_input("Enter number: ")
            from_base = int(get_input("From base (2/8/10/16): "))
            to_base = int(get_input("To base (2/8/10/16): "))
            
            if from_base not in [2, 8, 10, 16] or to_base not in [2, 8, 10, 16]:
                print_error("Invalid base! Use 2, 8, 10, or 16.")
                return
            
            # Convert to decimal first
            if from_base == 10:
                decimal = int(number)
            else:
                decimal = int(number, from_base)
            
            # Convert to target base
            if to_base == 2:
                result = bin(decimal)[2:]
            elif to_base == 8:
                result = oct(decimal)[2:]
            elif to_base == 10:
                result = str(decimal)
            elif to_base == 16:
                result = hex(decimal)[2:].upper()
            
            base_names = {2: "Binary", 8: "Octal", 10: "Decimal", 16: "Hexadecimal"}
            print(f"{Colors.PRIMARY}{number} ({base_names[from_base]}) = {result} ({base_names[to_base]}){Colors.RESET}")
        
        except ValueError:
            print_error("Invalid number or base!")
        
        press_enter_to_continue()
    
    def random_number_generator(self):
        """Generate random numbers"""
        print()
        try:
            min_val = int(get_input("Minimum value: "))
            max_val = int(get_input("Maximum value: "))
            count = int(get_input("How many numbers: "))
            
            if min_val > max_val:
                print_error("Minimum cannot be greater than maximum!")
                return
            
            if count <= 0 or count > 100:
                print_error("Count must be between 1 and 100!")
                return
            
            numbers = [random.randint(min_val, max_val) for _ in range(count)]
            print(f"{Colors.PRIMARY}Random numbers: {', '.join(map(str, numbers))}{Colors.RESET}")
            
            if count > 1:
                print(f"{Colors.ACCENT}Sum: {sum(numbers)}{Colors.RESET}")
                print(f"{Colors.ACCENT}Average: {sum(numbers)/len(numbers):.2f}{Colors.RESET}")
        
        except ValueError:
            print_error("Invalid input! Please enter valid numbers.")
        
        press_enter_to_continue()
    
    def prime_checker(self):
        """Check if a number is prime"""
        print()
        try:
            number = int(get_input("Enter number to check: "))
            
            if number < 2:
                print(f"{Colors.ERROR}{number} is not prime{Colors.RESET}")
                return
            
            is_prime = True
            for i in range(2, int(number ** 0.5) + 1):
                if number % i == 0:
                    is_prime = False
                    break
            
            if is_prime:
                print(f"{Colors.PRIMARY}{number} is prime! ✨{Colors.RESET}")
            else:
                print(f"{Colors.ERROR}{number} is not prime{Colors.RESET}")
        
        except ValueError:
            print_error("Invalid input! Please enter a valid number.")
        
        press_enter_to_continue()
    
    def factorial_calculator(self):
        """Calculate factorial of a number"""
        print()
        try:
            number = int(get_input("Enter number for factorial: "))
            
            if number < 0:
                print_error("Factorial is not defined for negative numbers!")
                return
            
            if number > 20:
                print_error("Number too large! Please enter a number ≤ 20.")
                return
            
            factorial = 1
            for i in range(1, number + 1):
                factorial *= i
            
            print(f"{Colors.PRIMARY}{number}! = {factorial}{Colors.RESET}")
        
        except ValueError:
            print_error("Invalid input! Please enter a valid number.")
        
        press_enter_to_continue()
    
    def fibonacci_generator(self):
        """Generate Fibonacci sequence"""
        print()
        try:
            count = int(get_input("How many Fibonacci numbers: "))
            
            if count <= 0 or count > 50:
                print_error("Count must be between 1 and 50!")
                return
            
            fib_sequence = []
            a, b = 0, 1
            
            for _ in range(count):
                fib_sequence.append(a)
                a, b = b, a + b
            
            print(f"{Colors.PRIMARY}Fibonacci sequence: {', '.join(map(str, fib_sequence))}{Colors.RESET}")
        
        except ValueError:
            print_error("Invalid input! Please enter a valid number.")
        
        press_enter_to_continue()
    
    def system_info(self):
        """Display system information"""
        clear_screen()
        print_banner("💻 SYSTEM INFO 💻")
        print()
        
        import platform
        
        slow_print(f"System: {platform.system()}", 0.02, Colors.ACCENT)
        slow_print(f"Node: {platform.node()}", 0.02, Colors.ACCENT)
        slow_print(f"Release: {platform.release()}", 0.02, Colors.ACCENT)
        slow_print(f"Version: {platform.version()}", 0.02, Colors.ACCENT)
        slow_print(f"Machine: {platform.machine()}", 0.02, Colors.ACCENT)
        slow_print(f"Processor: {platform.processor()}", 0.02, Colors.ACCENT)
        slow_print(f"Python Version: {platform.python_version()}", 0.02, Colors.ACCENT)
        
        print()
        
        # Current time
        current_time = datetime.now()
        slow_print(f"Current Time: {current_time.strftime('%Y-%m-%d %H:%M:%S')}", 0.02, Colors.PRIMARY)
        slow_print(f"Timestamp: {int(current_time.timestamp())}", 0.02, Colors.PRIMARY)
        
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Mini toolbox ASCII art
            toolbox_art = """
    ███╗   ███╗██╗███╗   ██╗██╗    ████████╗ ██████╗  ██████╗ ██╗     ██████╗  ██████╗ ██╗  ██╗
    ████╗ ████║██║████╗  ██║██║    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔══██╗██╔═══██╗╚██╗██╔╝
    ██╔████╔██║██║██╔██╗ ██║██║       ██║   ██║   ██║██║   ██║██║     ██████╔╝██║   ██║ ╚███╔╝ 
    ██║╚██╔╝██║██║██║╚██╗██║██║       ██║   ██║   ██║██║   ██║██║     ██╔══██╗██║   ██║ ██╔██╗ 
    ██║ ╚═╝ ██║██║██║ ╚████║██║       ██║   ╚██████╔╝╚██████╔╝███████╗██████╔╝╚██████╔╝██╔╝ ██╗
    ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝
            """
            
            print_ascii_art(toolbox_art, Colors.ACCENT)
            print()
            slow_print("Your cyberpunk utility collection!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🔐 Text Encoder/Decoder")
            print_menu_item(2, "📏 Unit Converter")
            print_menu_item(3, "📝 Text Utilities")
            print_menu_item(4, "🔢 Number Utilities")
            print_menu_item(5, "💻 System Info")
            print_menu_item(6, "🎲 Random Generators")
            print_menu_item(7, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.text_encoder_decoder()
            elif choice == '2':
                self.unit_converter()
            elif choice == '3':
                self.text_utilities()
            elif choice == '4':
                self.number_utilities()
            elif choice == '5':
                self.system_info()
            elif choice == '6':
                self.random_generators()
            elif choice == '7':
                slow_print("Toolbox closed. Keep building! 🔧", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)
    
    def random_generators(self):
        """Various random generators"""
        clear_screen()
        print_banner("🎲 RANDOM GENERATORS 🎲")
        print()
        
        print_menu_item(1, "Random UUID")
        print_menu_item(2, "Random Color")
        print_menu_item(3, "Random Quote")
        print_menu_item(4, "Random Joke")
        print_menu_item(5, "Back to Main Menu")
        
        print()
        choice = get_input("Select generator (1-5): ")
        
        if choice == '1':
            import uuid
            random_uuid = str(uuid.uuid4())
            print(f"{Colors.PRIMARY}Random UUID: {random_uuid}{Colors.RESET}")
        
        elif choice == '2':
            r = random.randint(0, 255)
            g = random.randint(0, 255)
            b = random.randint(0, 255)
            hex_color = f"#{r:02x}{g:02x}{b:02x}"
            print(f"{Colors.PRIMARY}Random Color: {hex_color.upper()}{Colors.RESET}")
            print(f"{Colors.ACCENT}RGB: ({r}, {g}, {b}){Colors.RESET}")
        
        elif choice == '3':
            quotes = [
                "The future belongs to those who believe in the beauty of their dreams.",
                "Innovation distinguishes between a leader and a follower.",
                "The only way to do great work is to love what you do.",
                "Code is poetry written in logic.",
                "Technology is best when it brings people together."
            ]
            quote = random.choice(quotes)
            print(f"{Colors.PRIMARY}Random Quote: {quote}{Colors.RESET}")
        
        elif choice == '4':
            jokes = [
                "Why do programmers prefer dark mode? Because light attracts bugs!",
                "How many programmers does it take to change a light bulb? None, that's a hardware problem!",
                "Why don't programmers like nature? It has too many bugs.",
                "What's a programmer's favorite hangout place? Foo Bar!",
                "Why did the programmer quit his job? He didn't get arrays!"
            ]
            joke = random.choice(jokes)
            print(f"{Colors.PRIMARY}Random Joke: {joke}{Colors.RESET}")
        
        elif choice == '5':
            return
        
        if choice != '5':
            press_enter_to_continue()

def main():
    """Main function to run Mini Toolbox"""
    try:
        toolbox = MiniToolbox()
        toolbox.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
