# Created by Bhavyansh Soni
# Mood Detector - Analyze mood through text input and sentiment analysis

import sys
import os
import time
import random
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class MoodDetector:
    def __init__(self):
        self.running = True
        self.mood_history = []
        self.daily_moods = {}
        
        # Mood keywords and weights
        self.mood_keywords = {
            "happy": {
                "keywords": ["happy", "joy", "excited", "great", "awesome", "amazing", "wonderful", "fantastic", "love", "perfect", "excellent", "brilliant", "cheerful", "delighted", "thrilled"],
                "weight": 2,
                "emoji": "😊",
                "color": Colors.PRIMARY
            },
            "sad": {
                "keywords": ["sad", "depressed", "down", "unhappy", "miserable", "awful", "terrible", "horrible", "devastated", "heartbroken", "gloomy", "melancholy", "sorrowful"],
                "weight": -2,
                "emoji": "😢",
                "color": Colors.ERROR
            },
            "angry": {
                "keywords": ["angry", "mad", "furious", "rage", "annoyed", "irritated", "frustrated", "pissed", "outraged", "livid", "infuriated", "aggravated"],
                "weight": -1,
                "emoji": "😠",
                "color": Colors.ERROR
            },
            "anxious": {
                "keywords": ["anxious", "worried", "nervous", "stressed", "concerned", "uneasy", "troubled", "fearful", "panic", "overwhelmed", "tense"],
                "weight": -1,
                "emoji": "😰",
                "color": Colors.WARNING
            },
            "calm": {
                "keywords": ["calm", "peaceful", "relaxed", "serene", "tranquil", "content", "composed", "zen", "balanced", "centered", "quiet"],
                "weight": 1,
                "emoji": "😌",
                "color": Colors.ACCENT
            },
            "excited": {
                "keywords": ["excited", "thrilled", "pumped", "hyped", "energetic", "enthusiastic", "eager", "elated", "ecstatic", "euphoric"],
                "weight": 2,
                "emoji": "🤩",
                "color": Colors.PRIMARY
            },
            "tired": {
                "keywords": ["tired", "exhausted", "drained", "weary", "fatigued", "sleepy", "worn out", "depleted", "spent"],
                "weight": -0.5,
                "emoji": "😴",
                "color": Colors.GRAY
            },
            "confused": {
                "keywords": ["confused", "puzzled", "lost", "uncertain", "unclear", "bewildered", "perplexed", "baffled"],
                "weight": -0.5,
                "emoji": "🤔",
                "color": Colors.SECONDARY
            }
        }
        
        # Mood suggestions
        self.mood_suggestions = {
            "happy": [
                "Keep spreading those positive vibes! 🌟",
                "Your happiness is contagious! Share it with others!",
                "Celebrate this wonderful mood! 🎉"
            ],
            "sad": [
                "It's okay to feel sad sometimes. Take care of yourself. 💙",
                "Consider talking to someone you trust about how you feel.",
                "Remember: this feeling is temporary. Better days are coming."
            ],
            "angry": [
                "Take deep breaths and count to ten. 🌬️",
                "Channel that energy into something productive!",
                "Consider taking a walk or doing some exercise."
            ],
            "anxious": [
                "Try some breathing exercises or meditation. 🧘",
                "Break down your worries into smaller, manageable parts.",
                "Remember: you've overcome challenges before."
            ],
            "calm": [
                "Enjoy this peaceful moment! 🕯️",
                "This is a great time for reflection or creativity.",
                "Share your calm energy with others who might need it."
            ],
            "excited": [
                "Channel that excitement into your goals! ⚡",
                "Your energy is inspiring! Use it wisely!",
                "Great things happen when you're this motivated!"
            ],
            "tired": [
                "Make sure you're getting enough rest. 💤",
                "Consider taking a short break or power nap.",
                "Don't forget to stay hydrated and eat well."
            ],
            "confused": [
                "Take time to gather more information. 📚",
                "Sometimes talking it through helps clarify things.",
                "Break the problem down into smaller pieces."
            ]
        }
    
    def analyze_text_mood(self, text):
        """Analyze mood from text input"""
        text_lower = text.lower()
        mood_scores = {}
        
        # Initialize scores
        for mood in self.mood_keywords:
            mood_scores[mood] = 0
        
        # Count keyword matches
        words = text_lower.split()
        for word in words:
            for mood, data in self.mood_keywords.items():
                if word in data["keywords"]:
                    mood_scores[mood] += data["weight"]
        
        # Find dominant mood
        if max(mood_scores.values()) == 0:
            return "neutral", 0, "😐"
        
        dominant_mood = max(mood_scores, key=mood_scores.get)
        confidence = abs(mood_scores[dominant_mood])
        
        return dominant_mood, confidence, self.mood_keywords[dominant_mood]["emoji"]
    
    def quick_mood_check(self):
        """Quick mood analysis from text"""
        clear_screen()
        print_banner("🧠 QUICK MOOD CHECK 🧠")
        print()
        
        slow_print("Tell me how you're feeling today...", 0.02, Colors.ACCENT)
        print()
        
        text = get_input("Your thoughts: ")
        if not text.strip():
            print_error("Please share something about your mood!")
            time.sleep(1)
            return
        
        # Analyze mood
        mood, confidence, emoji = self.analyze_text_mood(text)
        
        clear_screen()
        print_banner("🧠 MOOD ANALYSIS RESULTS 🧠")
        print()
        
        # Display analysis
        if mood == "neutral":
            print(f"{Colors.ACCENT}Detected Mood: {Colors.WHITE}Neutral {emoji}{Colors.RESET}")
            print(f"{Colors.ACCENT}Analysis: Your text seems emotionally balanced.{Colors.RESET}")
        else:
            mood_color = self.mood_keywords[mood]["color"]
            print(f"{Colors.ACCENT}Detected Mood: {mood_color}{mood.title()} {emoji}{Colors.RESET}")
            print(f"{Colors.ACCENT}Confidence: {Colors.WHITE}{confidence:.1f}/5{Colors.RESET}")
        
        print()
        print(f"{Colors.ACCENT}Your text: {Colors.WHITE}\"{text}\"{Colors.RESET}")
        
        # Provide suggestions
        if mood != "neutral":
            print()
            print_separator()
            print(f"{Colors.ACCENT}Suggestion:{Colors.RESET}")
            suggestion = random.choice(self.mood_suggestions[mood])
            slow_print(suggestion, 0.02, Colors.PRIMARY)
        
        # Save to history
        mood_entry = {
            "text": text,
            "mood": mood,
            "confidence": confidence,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.mood_history.append(mood_entry)
        
        # Update daily mood
        today = datetime.now().strftime("%Y-%m-%d")
        if today not in self.daily_moods:
            self.daily_moods[today] = []
        self.daily_moods[today].append(mood_entry)
        
        press_enter_to_continue()
    
    def mood_journal(self):
        """Detailed mood journaling"""
        clear_screen()
        print_banner("📔 MOOD JOURNAL 📔")
        print()
        
        slow_print("Let's dive deeper into your emotional state...", 0.02, Colors.ACCENT)
        print()
        
        # Multiple questions for better analysis
        questions = [
            "How was your day overall?",
            "What's the main thing on your mind right now?",
            "Describe your energy level and feelings:",
            "What would you like to change about your current mood?"
        ]
        
        responses = []
        for i, question in enumerate(questions, 1):
            print(f"{Colors.ACCENT}Question {i}/4:{Colors.RESET}")
            print(f"{Colors.PRIMARY}{question}{Colors.RESET}")
            print()
            
            response = get_input("Your response: ")
            if response.strip():
                responses.append(response)
            print()
        
        if not responses:
            print_error("No responses provided!")
            time.sleep(1)
            return
        
        # Analyze combined responses
        combined_text = " ".join(responses)
        mood, confidence, emoji = self.analyze_text_mood(combined_text)
        
        # Detailed analysis
        clear_screen()
        print_banner("📔 JOURNAL ANALYSIS 📔")
        print()
        
        # Show mood timeline for today
        today = datetime.now().strftime("%Y-%m-%d")
        if today in self.daily_moods:
            print(f"{Colors.ACCENT}Today's Mood Journey:{Colors.RESET}")
            for entry in self.daily_moods[today]:
                time_str = entry["timestamp"].split(" ")[1][:5]
                mood_emoji = self.mood_keywords.get(entry["mood"], {}).get("emoji", "😐")
                print(f"  {time_str} - {entry['mood'].title()} {mood_emoji}")
            print()
        
        # Current analysis
        if mood != "neutral":
            mood_color = self.mood_keywords[mood]["color"]
            print(f"{Colors.ACCENT}Overall Mood: {mood_color}{mood.title()} {emoji}{Colors.RESET}")
            print(f"{Colors.ACCENT}Confidence: {Colors.WHITE}{confidence:.1f}/5{Colors.RESET}")
        else:
            print(f"{Colors.ACCENT}Overall Mood: {Colors.WHITE}Neutral {emoji}{Colors.RESET}")
        
        print()
        print(f"{Colors.ACCENT}Journal Entry:{Colors.RESET}")
        for i, response in enumerate(responses, 1):
            print(f"{i}. {Colors.WHITE}{response}{Colors.RESET}")
        
        # Comprehensive suggestions
        if mood != "neutral":
            print()
            print_separator()
            print(f"{Colors.ACCENT}Personalized Recommendations:{Colors.RESET}")
            
            # Multiple suggestions
            suggestions = self.mood_suggestions.get(mood, [])
            if suggestions:
                for suggestion in suggestions[:2]:  # Show 2 suggestions
                    slow_print(f"• {suggestion}", 0.02, Colors.PRIMARY)
        
        # Save detailed entry
        journal_entry = {
            "type": "journal",
            "responses": responses,
            "mood": mood,
            "confidence": confidence,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.mood_history.append(journal_entry)
        
        press_enter_to_continue()
    
    def mood_tracker(self):
        """Simple numerical mood tracking"""
        clear_screen()
        print_banner("📊 MOOD TRACKER 📊")
        print()
        
        slow_print("Rate your current mood on a scale of 1-10:", 0.02, Colors.ACCENT)
        print()
        
        # Visual scale
        scale_colors = [Colors.ERROR, Colors.ERROR, Colors.WARNING, Colors.WARNING, 
                       Colors.SECONDARY, Colors.SECONDARY, Colors.ACCENT, Colors.ACCENT,
                       Colors.PRIMARY, Colors.PRIMARY]
        
        print("Mood Scale:")
        for i in range(1, 11):
            color = scale_colors[i-1]
            print(f"{color}{i:2d}: {'█' * i}{Colors.RESET}")
        
        print()
        try:
            mood_rating = int(get_input("Your mood (1-10): "))
            if mood_rating < 1 or mood_rating > 10:
                print_error("Please enter a number between 1 and 10!")
                time.sleep(1)
                return
        except ValueError:
            print_error("Invalid number!")
            time.sleep(1)
            return
        
        # Get optional note
        print()
        note = get_input("Optional note about your mood: ")
        
        # Categorize mood
        if mood_rating <= 3:
            mood_category = "low"
            mood_emoji = "😞"
            mood_color = Colors.ERROR
        elif mood_rating <= 5:
            mood_category = "moderate"
            mood_emoji = "😐"
            mood_color = Colors.WARNING
        elif mood_rating <= 7:
            mood_category = "good"
            mood_emoji = "🙂"
            mood_color = Colors.ACCENT
        else:
            mood_category = "excellent"
            mood_emoji = "😊"
            mood_color = Colors.PRIMARY
        
        clear_screen()
        print_banner("📊 MOOD TRACKED 📊")
        print()
        
        print(f"{Colors.ACCENT}Mood Rating: {mood_color}{mood_rating}/10 {mood_emoji}{Colors.RESET}")
        print(f"{Colors.ACCENT}Category: {mood_color}{mood_category.title()}{Colors.RESET}")
        
        if note:
            print(f"{Colors.ACCENT}Note: {Colors.WHITE}{note}{Colors.RESET}")
        
        # Save tracking entry
        tracker_entry = {
            "type": "tracker",
            "rating": mood_rating,
            "category": mood_category,
            "note": note,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.mood_history.append(tracker_entry)
        
        # Update daily average
        today = datetime.now().strftime("%Y-%m-%d")
        if today not in self.daily_moods:
            self.daily_moods[today] = []
        
        # Show daily progress
        today_ratings = []
        for entry in self.mood_history:
            if (entry.get("type") == "tracker" and 
                entry["timestamp"].startswith(today)):
                today_ratings.append(entry["rating"])
        
        if len(today_ratings) > 1:
            avg_today = sum(today_ratings) / len(today_ratings)
            print()
            print(f"{Colors.ACCENT}Today's Average: {Colors.WHITE}{avg_today:.1f}/10{Colors.RESET}")
            print(f"{Colors.ACCENT}Entries Today: {Colors.WHITE}{len(today_ratings)}{Colors.RESET}")
        
        press_enter_to_continue()
    
    def mood_patterns(self):
        """Analyze mood patterns and trends"""
        clear_screen()
        print_banner("📈 MOOD PATTERNS 📈")
        print()
        
        if not self.mood_history:
            print_warning("No mood data available!")
            print_info("Start tracking your mood to see patterns!")
            press_enter_to_continue()
            return
        
        # Analyze recent mood trends
        recent_entries = self.mood_history[-10:]  # Last 10 entries
        
        slow_print("Recent Mood Analysis:", 0.02, Colors.ACCENT)
        print()
        
        # Show recent moods
        mood_counts = {}
        rating_sum = 0
        rating_count = 0
        
        for entry in recent_entries:
            if entry.get("mood"):
                mood = entry["mood"]
                mood_counts[mood] = mood_counts.get(mood, 0) + 1
            
            if entry.get("rating"):
                rating_sum += entry["rating"]
                rating_count += 1
        
        # Most common mood
        if mood_counts:
            most_common = max(mood_counts, key=mood_counts.get)
            emoji = self.mood_keywords.get(most_common, {}).get("emoji", "😐")
            print(f"{Colors.ACCENT}Most Common Mood: {Colors.PRIMARY}{most_common.title()} {emoji}{Colors.RESET}")
        
        # Average rating
        if rating_count > 0:
            avg_rating = rating_sum / rating_count
            print(f"{Colors.ACCENT}Average Rating: {Colors.PRIMARY}{avg_rating:.1f}/10{Colors.RESET}")
        
        print()
        
        # Daily mood summary
        slow_print("Daily Mood Summary:", 0.02, Colors.ACCENT)
        
        for date, moods in list(self.daily_moods.items())[-7:]:  # Last 7 days
            mood_emojis = []
            for mood_entry in moods:
                if mood_entry.get("mood"):
                    emoji = self.mood_keywords.get(mood_entry["mood"], {}).get("emoji", "😐")
                    mood_emojis.append(emoji)
            
            if mood_emojis:
                print(f"{Colors.SECONDARY}{date}: {Colors.WHITE}{''.join(mood_emojis)}{Colors.RESET}")
        
        print()
        
        # Mood improvement suggestions
        if mood_counts:
            negative_moods = ["sad", "angry", "anxious", "tired"]
            has_negative = any(mood in mood_counts for mood in negative_moods)
            
            if has_negative:
                print_separator()
                print(f"{Colors.ACCENT}Wellness Suggestions:{Colors.RESET}")
                wellness_tips = [
                    "Try practicing gratitude daily 🙏",
                    "Consider regular exercise for mood boost 💪",
                    "Ensure you're getting quality sleep 😴",
                    "Connect with friends and family 👥",
                    "Take breaks from stressful activities 🌿"
                ]
                
                for tip in random.sample(wellness_tips, 3):
                    slow_print(f"• {tip}", 0.02, Colors.PRIMARY)
        
        press_enter_to_continue()
    
    def mood_statistics(self):
        """Display comprehensive mood statistics"""
        clear_screen()
        print_banner("📊 MOOD STATISTICS 📊")
        print()
        
        if not self.mood_history:
            print_warning("No mood data available!")
            press_enter_to_continue()
            return
        
        total_entries = len(self.mood_history)
        slow_print(f"Total Mood Entries: {total_entries}", 0.02, Colors.ACCENT)
        
        # Mood type distribution
        mood_type_counts = {}
        for entry in self.mood_history:
            entry_type = entry.get("type", "analysis")
            mood_type_counts[entry_type] = mood_type_counts.get(entry_type, 0) + 1
        
        print()
        slow_print("Entry Types:", 0.02, Colors.ACCENT)
        for entry_type, count in mood_type_counts.items():
            percentage = (count / total_entries) * 100
            print(f"{Colors.SECONDARY}{entry_type.title()}: {Colors.WHITE}{count} ({percentage:.1f}%){Colors.RESET}")
        
        # Mood distribution
        all_moods = {}
        for entry in self.mood_history:
            if entry.get("mood"):
                mood = entry["mood"]
                all_moods[mood] = all_moods.get(mood, 0) + 1
        
        if all_moods:
            print()
            slow_print("Mood Distribution:", 0.02, Colors.ACCENT)
            for mood, count in sorted(all_moods.items(), key=lambda x: x[1], reverse=True):
                percentage = (count / len([e for e in self.mood_history if e.get("mood")])) * 100
                emoji = self.mood_keywords.get(mood, {}).get("emoji", "😐")
                print(f"{Colors.SECONDARY}{mood.title()}: {Colors.WHITE}{count} ({percentage:.1f}%) {emoji}{Colors.RESET}")
        
        # Rating statistics
        all_ratings = [entry["rating"] for entry in self.mood_history if entry.get("rating")]
        if all_ratings:
            print()
            slow_print("Rating Statistics:", 0.02, Colors.ACCENT)
            avg_rating = sum(all_ratings) / len(all_ratings)
            max_rating = max(all_ratings)
            min_rating = min(all_ratings)
            
            print(f"{Colors.SECONDARY}Average Rating: {Colors.WHITE}{avg_rating:.1f}/10{Colors.RESET}")
            print(f"{Colors.SECONDARY}Highest Rating: {Colors.WHITE}{max_rating}/10{Colors.RESET}")
            print(f"{Colors.SECONDARY}Lowest Rating: {Colors.WHITE}{min_rating}/10{Colors.RESET}")
        
        # Time-based analysis
        print()
        slow_print("Activity Timeline:", 0.02, Colors.ACCENT)
        
        # Group by date
        dates = {}
        for entry in self.mood_history:
            date = entry["timestamp"].split(" ")[0]
            dates[date] = dates.get(date, 0) + 1
        
        recent_dates = sorted(dates.items(), key=lambda x: x[0], reverse=True)[:7]
        for date, count in recent_dates:
            print(f"{Colors.SECONDARY}{date}: {Colors.WHITE}{count} entries{Colors.RESET}")
        
        press_enter_to_continue()
    
    def export_mood_data(self):
        """Export mood data"""
        clear_screen()
        print_banner("📤 EXPORT MOOD DATA 📤")
        print()
        
        if not self.mood_history:
            print_warning("No mood data to export!")
            time.sleep(1)
            return
        
        filename = get_input("Enter filename (without extension): ")
        if not filename:
            filename = f"mood_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Simulate export
        print()
        slow_print("Preparing mood data for export...", 0.02, Colors.ACCENT)
        
        export_summary = [
            f"Total Entries: {len(self.mood_history)}",
            f"Date Range: {self.mood_history[0]['timestamp']} to {self.mood_history[-1]['timestamp']}",
            f"Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        ]
        
        print()
        for line in export_summary:
            slow_print(line, 0.02, Colors.WHITE)
        
        animate_loading("Exporting data", 2)
        print_success(f"Mood data exported to {filename}.csv")
        
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Mood detector ASCII art
            mood_art = """
    ███╗   ███╗ ██████╗  ██████╗ ██████╗     ██████╗ ███████╗████████╗███████╗ ██████╗████████╗ ██████╗ ██████╗ 
    ████╗ ████║██╔═══██╗██╔═══██╗██╔══██╗    ██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗
    ██╔████╔██║██║   ██║██║   ██║██║  ██║    ██║  ██║█████╗     ██║   █████╗  ██║        ██║   ██║   ██║██████╔╝
    ██║╚██╔╝██║██║   ██║██║   ██║██║  ██║    ██║  ██║██╔══╝     ██║   ██╔══╝  ██║        ██║   ██║   ██║██╔══██╗
    ██║ ╚═╝ ██║╚██████╔╝╚██████╔╝██████╔╝    ██████╔╝███████╗   ██║   ███████╗╚██████╗   ██║   ╚██████╔╝██║  ██║
    ╚═╝     ╚═╝ ╚═════╝  ╚═════╝ ╚═════╝     ╚═════╝ ╚══════╝   ╚═╝   ╚══════╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝
            """
            
            print_ascii_art(mood_art, Colors.ACCENT)
            print()
            slow_print("Understand your emotional landscape through AI analysis...", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🧠 Quick Mood Check")
            print_menu_item(2, "📔 Mood Journal")
            print_menu_item(3, "📊 Mood Tracker")
            print_menu_item(4, "📈 Mood Patterns")
            print_menu_item(5, "📊 Statistics")
            print_menu_item(6, "📤 Export Data")
            print_menu_item(7, "❌ Exit")
            
            print()
            if self.mood_history:
                last_entry = self.mood_history[-1]
                if last_entry.get("mood"):
                    emoji = self.mood_keywords.get(last_entry["mood"], {}).get("emoji", "😐")
                    print(f"{Colors.GRAY}Last detected mood: {last_entry['mood'].title()} {emoji}{Colors.RESET}")
                elif last_entry.get("rating"):
                    print(f"{Colors.GRAY}Last rating: {last_entry['rating']}/10{Colors.RESET}")
            print()
            
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.quick_mood_check()
            elif choice == '2':
                self.mood_journal()
            elif choice == '3':
                self.mood_tracker()
            elif choice == '4':
                self.mood_patterns()
            elif choice == '5':
                self.mood_statistics()
            elif choice == '6':
                self.export_mood_data()
            elif choice == '7':
                slow_print("Take care of your mental health! 💙", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)

def main():
    """Main function to run Mood Detector"""
    try:
        mood_detector = MoodDetector()
        mood_detector.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
