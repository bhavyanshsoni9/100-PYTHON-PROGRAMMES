from utils import slow_print, print_signature

# Dictionary mapping moods to YouTube song links
MOOD_TO_SONG = {
    'happy': 'https://www.youtube.com/watch?v=ZbZSe6N_BXs',  # Happy - Pharrell Williams
    'sad': 'https://www.youtube.com/watch?v=oyEuk8j8imI',    # Fix You - Coldplay
    'energetic': 'https://www.youtube.com/watch?v=btPJPFnesV4', # Eye of the Tiger - Survivor
    'calm': 'https://www.youtube.com/watch?v=2bosouX_d8Y',    # River Flows in You - Yiruma
    'romantic': 'https://www.youtube.com/watch?v=lp-EO5I60KA', # Perfect - Ed Sheeran
    'angry': 'https://www.youtube.com/watch?v=eVTXPUF4Oz4',   # In the End - Linkin Park
    'motivated': 'https://www.youtube.com/watch?v=KxNGMvNIvP8', # Stronger - Kanye West
    'relaxed': 'https://www.youtube.com/watch?v=mWRsgZuwf_8',  # Demons - Imagine Dragons
    'party': 'https://www.youtube.com/watch?v=CevxZvSJLk8',   # Roar - Katy Perry
}

def suggest_song(mood):
    """Suggest a song based on the given mood."""
    return MOOD_TO_SONG.get(mood.lower(), None)

def main():
    slow_print("🎵 Welcome to the Mood-based Music Suggester! 🎵", color='green')
    slow_print("\nAvailable moods:", color='yellow')
    for mood in MOOD_TO_SONG.keys():
        slow_print(f"- {mood}", color='cyan')
    
    while True:
        mood = input("\nHow are you feeling? (or 'quit' to exit): ").lower()
        if mood == 'quit':
            break
            
        song_link = suggest_song(mood)
        if song_link:
            slow_print("\nBased on your mood, I suggest this song:", color='green')
            slow_print(song_link, color='magenta')
        else:
            slow_print("\nSorry, I don't have a song for that mood yet! Try another one.", color='red')
    
    print_signature()

if __name__ == "__main__":
    main() 