# Created by Bhavyansh Soni
# Music Moodboard - Create and manage music playlists based on moods and themes

import sys
import os
import time
import random
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class MusicMoodboard:
    def __init__(self):
        self.running = True
        self.moodboards = []
        self.music_library = self.initialize_music_library()
        self.mood_presets = self.initialize_mood_presets()
        
    def initialize_music_library(self):
        """Initialize sample music library"""
        return {
            "cyberpunk": [
                {"title": "Neon Dreams", "artist": "Synthwave Collective", "duration": "3:45", "energy": 8},
                {"title": "Digital Rain", "artist": "Cyber Ghost", "duration": "4:12", "energy": 7},
                {"title": "Terminal Love", "artist": "Code Runners", "duration": "2:58", "energy": 6},
                {"title": "Binary Sunset", "artist": "Data Stream", "duration": "5:23", "energy": 5},
                {"title": "Hack the Planet", "artist": "Neural Network", "duration": "3:33", "energy": 9},
                {"title": "Matrix Reborn", "artist": "Quantum Pulse", "duration": "4:07", "energy": 8},
                {"title": "Electric Memories", "artist": "Pixel Dreams", "duration": "3:51", "energy": 7},
                {"title": "Cyber Cafe", "artist": "Neon Nights", "duration": "2:44", "energy": 4},
                {"title": "Ghost in the Shell", "artist": "Android Echo", "duration": "4:28", "energy": 6},
                {"title": "Future Noir", "artist": "Dystopian Sound", "duration": "6:15", "energy": 5}
            ],
            "ambient": [
                {"title": "Floating Clouds", "artist": "Atmospheric", "duration": "4:30", "energy": 2},
                {"title": "Deep Space", "artist": "Cosmic Sounds", "duration": "5:45", "energy": 1},
                {"title": "Ocean Waves", "artist": "Nature's Symphony", "duration": "3:20", "energy": 2},
                {"title": "Meditation Garden", "artist": "Zen Master", "duration": "6:00", "energy": 1},
                {"title": "Starlight", "artist": "Celestial Choir", "duration": "4:15", "energy": 2}
            ],
            "energetic": [
                {"title": "Power Surge", "artist": "Electric Storm", "duration": "3:22", "energy": 10},
                {"title": "Adrenaline Rush", "artist": "High Voltage", "duration": "2:55", "energy": 9},
                {"title": "Lightning Strike", "artist": "Thunder Gods", "duration": "3:47", "energy": 10},
                {"title": "Maximum Overdrive", "artist": "Speed Demons", "duration": "3:12", "energy": 9},
                {"title": "Rocket Fuel", "artist": "Space Racers", "duration": "2:48", "energy": 10}
            ],
            "chill": [
                {"title": "Lazy Sunday", "artist": "Weekend Vibes", "duration": "4:22", "energy": 3},
                {"title": "Coffee Shop", "artist": "Urban Lounge", "duration": "3:55", "energy": 4},
                {"title": "Sunset Boulevard", "artist": "City Lights", "duration": "4:18", "energy": 3},
                {"title": "Rain on Glass", "artist": "Ambient Café", "duration": "5:12", "energy": 2},
                {"title": "Night Drive", "artist": "Midnight Cruise", "duration": "4:45", "energy": 4}
            ]
        }
    
    def initialize_mood_presets(self):
        """Initialize mood presets with color schemes and descriptors"""
        return {
            "energetic": {
                "color": Colors.ERROR,
                "energy_range": (8, 10),
                "keywords": ["high", "intense", "powerful", "dynamic"],
                "emoji": "⚡",
                "description": "High energy music for workouts and motivation"
            },
            "focused": {
                "color": Colors.ACCENT,
                "energy_range": (5, 7),
                "keywords": ["concentration", "study", "work", "productivity"],
                "emoji": "🎯",
                "description": "Music to enhance focus and concentration"
            },
            "relaxed": {
                "color": Colors.PRIMARY,
                "energy_range": (2, 4),
                "keywords": ["calm", "peaceful", "chill", "mellow"],
                "emoji": "😌",
                "description": "Soothing music for relaxation and unwinding"
            },
            "creative": {
                "color": Colors.WARNING,
                "energy_range": (4, 8),
                "keywords": ["artistic", "inspiring", "imaginative", "flowing"],
                "emoji": "🎨",
                "description": "Inspiring music to boost creativity"
            },
            "ambient": {
                "color": Colors.SECONDARY,
                "energy_range": (1, 3),
                "keywords": ["atmospheric", "background", "subtle", "ethereal"],
                "emoji": "🌙",
                "description": "Atmospheric background music"
            },
            "nostalgic": {
                "color": Colors.GRAY,
                "energy_range": (3, 6),
                "keywords": ["memories", "retro", "vintage", "emotional"],
                "emoji": "💭",
                "description": "Music that evokes memories and emotions"
            }
        }
    
    def create_moodboard(self):
        """Create a new music moodboard"""
        clear_screen()
        print_banner("🎵 CREATE MOODBOARD 🎵")
        print()
        
        # Get moodboard name
        name = get_input("Moodboard name: ")
        if not name:
            print_error("Name cannot be empty!")
            time.sleep(1)
            return
        
        # Select mood preset or create custom
        print()
        print("Choose a mood preset:")
        presets = list(self.mood_presets.keys())
        for i, preset in enumerate(presets, 1):
            mood_data = self.mood_presets[preset]
            print(f"{mood_data['color']}{i}. {mood_data['emoji']} {preset.title()}: {mood_data['description']}{Colors.RESET}")
        
        print_menu_item(len(presets) + 1, "🎨 Create Custom Mood")
        
        print()
        choice = get_input(f"Select option (1-{len(presets) + 1}): ")
        
        try:
            if choice == str(len(presets) + 1):
                mood_config = self.create_custom_mood()
            else:
                mood_name = presets[int(choice) - 1]
                mood_config = self.mood_presets[mood_name].copy()
                mood_config["name"] = mood_name
        except (ValueError, IndexError):
            print_error("Invalid mood selection!")
            time.sleep(1)
            return
        
        if not mood_config:
            return
        
        # Generate playlist based on mood
        playlist = self.generate_mood_playlist(mood_config)
        
        # Create moodboard
        moodboard = {
            "name": name,
            "mood": mood_config,
            "playlist": playlist,
            "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "play_count": 0
        }
        
        self.moodboards.append(moodboard)
        
        # Display created moodboard
        self.display_moodboard(moodboard)
        print_success("Moodboard created successfully!")
        
        press_enter_to_continue()
    
    def create_custom_mood(self):
        """Create custom mood configuration"""
        clear_screen()
        print_banner("🎨 CUSTOM MOOD CREATOR 🎨")
        print()
        
        mood_name = get_input("Custom mood name: ")
        if not mood_name:
            print_error("Mood name cannot be empty!")
            time.sleep(1)
            return None
        
        description = get_input("Mood description: ")
        
        # Energy level
        print()
        print("Energy levels:")
        print("1-2: Very Low (Ambient, Sleep)")
        print("3-4: Low (Relaxing, Chill)")
        print("5-6: Medium (Focus, Background)")
        print("7-8: High (Upbeat, Active)")
        print("9-10: Very High (Intense, Workout)")
        
        try:
            min_energy = int(get_input("Minimum energy level (1-10): "))
            max_energy = int(get_input("Maximum energy level (1-10): "))
            
            if min_energy < 1 or max_energy > 10 or min_energy > max_energy:
                print_error("Invalid energy range!")
                time.sleep(1)
                return None
        except ValueError:
            print_error("Invalid energy values!")
            time.sleep(1)
            return None
        
        # Color selection
        print()
        print("Choose mood color:")
        colors = [
            ("Red", Colors.ERROR),
            ("Orange", Colors.WARNING),
            ("Green", Colors.PRIMARY),
            ("Blue", Colors.ACCENT),
            ("Purple", Colors.SECONDARY),
            ("Gray", Colors.GRAY)
        ]
        
        for i, (color_name, color_code) in enumerate(colors, 1):
            print(f"{color_code}{i}. {color_name}{Colors.RESET}")
        
        try:
            color_choice = int(get_input("Select color (1-6): ")) - 1
            selected_color = colors[color_choice][1]
        except (ValueError, IndexError):
            selected_color = Colors.ACCENT
        
        # Keywords
        keywords = get_input("Keywords (comma-separated): ").split(',')
        keywords = [k.strip() for k in keywords if k.strip()]
        
        # Emoji
        emoji = get_input("Mood emoji (optional): ") or "🎵"
        
        return {
            "name": mood_name,
            "color": selected_color,
            "energy_range": (min_energy, max_energy),
            "keywords": keywords,
            "emoji": emoji,
            "description": description or f"Custom mood: {mood_name}"
        }
    
    def generate_mood_playlist(self, mood_config):
        """Generate playlist based on mood configuration"""
        playlist = []
        min_energy, max_energy = mood_config["energy_range"]
        
        # Collect matching songs from all genres
        matching_songs = []
        for genre_songs in self.music_library.values():
            for song in genre_songs:
                if min_energy <= song["energy"] <= max_energy:
                    matching_songs.append(song)
        
        # Select random songs for playlist
        playlist_size = min(10, len(matching_songs))
        if matching_songs:
            playlist = random.sample(matching_songs, playlist_size)
        
        return playlist
    
    def display_moodboard(self, moodboard):
        """Display a moodboard with its playlist"""
        clear_screen()
        mood = moodboard["mood"]
        
        print_banner(f"{mood['emoji']} {moodboard['name'].upper()} {mood['emoji']}")
        print()
        
        # Mood info
        print(f"{Colors.ACCENT}Mood: {mood['color']}{mood.get('name', 'Custom').title()}{Colors.RESET}")
        print(f"{Colors.ACCENT}Description: {Colors.WHITE}{mood['description']}{Colors.RESET}")
        print(f"{Colors.ACCENT}Energy Range: {Colors.WHITE}{mood['energy_range'][0]}-{mood['energy_range'][1]}/10{Colors.RESET}")
        
        if mood["keywords"]:
            print(f"{Colors.ACCENT}Keywords: {Colors.WHITE}{', '.join(mood['keywords'])}{Colors.RESET}")
        
        print(f"{Colors.ACCENT}Created: {Colors.WHITE}{moodboard['created_date']}{Colors.RESET}")
        print(f"{Colors.ACCENT}Play Count: {Colors.WHITE}{moodboard['play_count']}{Colors.RESET}")
        
        print()
        print_separator()
        
        # Playlist
        if moodboard["playlist"]:
            print(f"{Colors.ACCENT}Playlist ({len(moodboard['playlist'])} tracks):{Colors.RESET}")
            print()
            
            total_duration = 0
            for i, song in enumerate(moodboard["playlist"], 1):
                # Convert duration to seconds for calculation
                duration_parts = song["duration"].split(":")
                duration_seconds = int(duration_parts[0]) * 60 + int(duration_parts[1])
                total_duration += duration_seconds
                
                # Energy indicator
                energy_bar = "█" * song["energy"] + "░" * (10 - song["energy"])
                energy_color = Colors.ERROR if song["energy"] >= 8 else Colors.WARNING if song["energy"] >= 6 else Colors.ACCENT
                
                print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{song['title']}{Colors.RESET}")
                print(f"     {Colors.SECONDARY}{song['artist']} - {song['duration']} | Energy: {energy_color}{energy_bar}{Colors.RESET}")
            
            # Total duration
            total_minutes = total_duration // 60
            total_seconds = total_duration % 60
            print()
            print(f"{Colors.ACCENT}Total Duration: {Colors.WHITE}{total_minutes}:{total_seconds:02d}{Colors.RESET}")
        else:
            print_warning("No matching songs found for this mood!")
    
    def view_moodboards(self):
        """View all created moodboards"""
        clear_screen()
        print_banner("📋 MY MOODBOARDS 📋")
        print()
        
        if not self.moodboards:
            print_warning("No moodboards created yet!")
            print_info("Create a moodboard to get started!")
            press_enter_to_continue()
            return
        
        for i, moodboard in enumerate(self.moodboards, 1):
            mood = moodboard["mood"]
            playlist_count = len(moodboard["playlist"])
            
            print(f"{mood['color']}{i:2d}. {mood['emoji']} {Colors.PRIMARY}{moodboard['name']}{Colors.RESET}")
            print(f"     {mood['color']}{mood.get('name', 'Custom').title()}{Colors.RESET} | {playlist_count} tracks | Played {moodboard['play_count']} times")
        
        print()
        choice = get_input("Enter moodboard number to view (or press Enter to return): ")
        
        if choice.isdigit():
            try:
                index = int(choice) - 1
                if 0 <= index < len(self.moodboards):
                    self.moodboard_details(self.moodboards[index])
            except ValueError:
                pass
    
    def moodboard_details(self, moodboard):
        """Show detailed moodboard view with options"""
        while True:
            self.display_moodboard(moodboard)
            
            print()
            print_separator()
            print_menu_item(1, "▶️ Play Moodboard")
            print_menu_item(2, "🔀 Shuffle Playlist")
            print_menu_item(3, "➕ Add Songs")
            print_menu_item(4, "➖ Remove Songs")
            print_menu_item(5, "📊 Mood Analysis")
            print_menu_item(6, "🗑️ Delete Moodboard")
            print_menu_item(7, "🔙 Back to List")
            
            print()
            choice = get_input("Select action (1-7): ")
            
            if choice == '1':
                self.play_moodboard(moodboard)
            elif choice == '2':
                self.shuffle_playlist(moodboard)
            elif choice == '3':
                self.add_songs_to_moodboard(moodboard)
            elif choice == '4':
                self.remove_songs_from_moodboard(moodboard)
            elif choice == '5':
                self.analyze_moodboard(moodboard)
            elif choice == '6':
                if self.delete_moodboard(moodboard):
                    break
            elif choice == '7':
                break
            else:
                print_error("Invalid choice!")
                time.sleep(1)
    
    def play_moodboard(self, moodboard):
        """Simulate playing a moodboard"""
        clear_screen()
        print_banner(f"▶️ PLAYING: {moodboard['name'].upper()}")
        print()
        
        if not moodboard["playlist"]:
            print_warning("This moodboard has no songs!")
            press_enter_to_continue()
            return
        
        moodboard["play_count"] += 1
        
        # Simulate playing songs
        for i, song in enumerate(moodboard["playlist"], 1):
            mood_color = moodboard["mood"]["color"]
            
            print(f"{mood_color}♪ Now Playing ({i}/{len(moodboard['playlist'])}): {Colors.PRIMARY}{song['title']}{Colors.RESET}")
            print(f"   {Colors.SECONDARY}{song['artist']} - {song['duration']}{Colors.RESET}")
            
            # Progress bar simulation
            duration_parts = song["duration"].split(":")
            total_seconds = int(duration_parts[0]) * 60 + int(duration_parts[1])
            
            for second in range(0, total_seconds, max(1, total_seconds // 20)):
                progress = (second / total_seconds) * 100
                bar_length = 30
                filled_length = int(bar_length * progress / 100)
                bar = "█" * filled_length + "░" * (bar_length - filled_length)
                
                elapsed_minutes = second // 60
                elapsed_seconds = second % 60
                print(f"\r   {mood_color}[{bar}] {elapsed_minutes}:{elapsed_seconds:02d}/{song['duration']}{Colors.RESET}", end="")
                time.sleep(0.1)
            
            print(f"\r   {mood_color}[{'█' * 30}] {song['duration']}/{song['duration']} ✓{Colors.RESET}")
            print()
            
            if i < len(moodboard["playlist"]):
                time.sleep(0.5)
        
        print()
        print_success("Moodboard playback complete!")
        press_enter_to_continue()
    
    def shuffle_playlist(self, moodboard):
        """Shuffle the playlist order"""
        if moodboard["playlist"]:
            random.shuffle(moodboard["playlist"])
            print_success("Playlist shuffled!")
        else:
            print_warning("No songs to shuffle!")
        time.sleep(1)
    
    def add_songs_to_moodboard(self, moodboard):
        """Add songs to moodboard playlist"""
        clear_screen()
        print_banner("➕ ADD SONGS TO MOODBOARD")
        print()
        
        # Show available songs that match the mood
        mood = moodboard["mood"]
        min_energy, max_energy = mood["energy_range"]
        
        available_songs = []
        current_titles = {song["title"] for song in moodboard["playlist"]}
        
        for genre_songs in self.music_library.values():
            for song in genre_songs:
                if (min_energy <= song["energy"] <= max_energy and 
                    song["title"] not in current_titles):
                    available_songs.append(song)
        
        if not available_songs:
            print_warning("No additional songs match this mood!")
            press_enter_to_continue()
            return
        
        print("Available songs:")
        for i, song in enumerate(available_songs, 1):
            energy_bar = "█" * song["energy"] + "░" * (10 - song["energy"])
            print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{song['title']}{Colors.RESET}")
            print(f"     {Colors.SECONDARY}{song['artist']} - {song['duration']} | Energy: {energy_bar}{Colors.RESET}")
        
        print()
        selections = get_input("Enter song numbers to add (comma-separated): ")
        
        try:
            indices = [int(x.strip()) - 1 for x in selections.split(',') if x.strip()]
            added_count = 0
            
            for index in indices:
                if 0 <= index < len(available_songs):
                    moodboard["playlist"].append(available_songs[index])
                    added_count += 1
            
            if added_count > 0:
                print_success(f"Added {added_count} songs to moodboard!")
            else:
                print_error("No valid songs selected!")
        
        except ValueError:
            print_error("Invalid input format!")
        
        time.sleep(1)
    
    def remove_songs_from_moodboard(self, moodboard):
        """Remove songs from moodboard playlist"""
        clear_screen()
        print_banner("➖ REMOVE SONGS FROM MOODBOARD")
        print()
        
        if not moodboard["playlist"]:
            print_warning("No songs to remove!")
            press_enter_to_continue()
            return
        
        print("Current playlist:")
        for i, song in enumerate(moodboard["playlist"], 1):
            print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{song['title']}{Colors.RESET}")
            print(f"     {Colors.SECONDARY}{song['artist']} - {song['duration']}{Colors.RESET}")
        
        print()
        selections = get_input("Enter song numbers to remove (comma-separated): ")
        
        try:
            indices = sorted([int(x.strip()) - 1 for x in selections.split(',') if x.strip()], reverse=True)
            removed_count = 0
            
            for index in indices:
                if 0 <= index < len(moodboard["playlist"]):
                    moodboard["playlist"].pop(index)
                    removed_count += 1
            
            if removed_count > 0:
                print_success(f"Removed {removed_count} songs from moodboard!")
            else:
                print_error("No valid songs selected!")
        
        except ValueError:
            print_error("Invalid input format!")
        
        time.sleep(1)
    
    def analyze_moodboard(self, moodboard):
        """Analyze moodboard statistics"""
        clear_screen()
        print_banner(f"📊 ANALYZING: {moodboard['name'].upper()}")
        print()
        
        playlist = moodboard["playlist"]
        if not playlist:
            print_warning("No songs to analyze!")
            press_enter_to_continue()
            return
        
        # Energy analysis
        energies = [song["energy"] for song in playlist]
        avg_energy = sum(energies) / len(energies)
        min_energy = min(energies)
        max_energy = max(energies)
        
        print(f"{Colors.ACCENT}Energy Analysis:{Colors.RESET}")
        print(f"  Average Energy: {avg_energy:.1f}/10")
        print(f"  Energy Range: {min_energy}-{max_energy}/10")
        
        # Energy distribution
        energy_counts = {}
        for energy in energies:
            energy_counts[energy] = energy_counts.get(energy, 0) + 1
        
        print()
        print(f"{Colors.ACCENT}Energy Distribution:{Colors.RESET}")
        for energy in sorted(energy_counts.keys()):
            count = energy_counts[energy]
            percentage = (count / len(playlist)) * 100
            bar = "█" * int(percentage / 5) + "░" * (20 - int(percentage / 5))
            print(f"  Energy {energy}: {bar} {count} songs ({percentage:.1f}%)")
        
        # Duration analysis
        total_seconds = 0
        for song in playlist:
            duration_parts = song["duration"].split(":")
            total_seconds += int(duration_parts[0]) * 60 + int(duration_parts[1])
        
        total_minutes = total_seconds // 60
        avg_duration_seconds = total_seconds // len(playlist)
        avg_minutes = avg_duration_seconds // 60
        avg_seconds = avg_duration_seconds % 60
        
        print()
        print(f"{Colors.ACCENT}Duration Analysis:{Colors.RESET}")
        print(f"  Total Duration: {total_minutes // 60}h {total_minutes % 60}m")
        print(f"  Average Song Length: {avg_minutes}:{avg_seconds:02d}")
        print(f"  Number of Songs: {len(playlist)}")
        
        # Artist diversity
        artists = [song["artist"] for song in playlist]
        unique_artists = len(set(artists))
        diversity = (unique_artists / len(playlist)) * 100
        
        print()
        print(f"{Colors.ACCENT}Artist Diversity:{Colors.RESET}")
        print(f"  Unique Artists: {unique_artists}/{len(playlist)}")
        print(f"  Diversity Score: {diversity:.1f}%")
        
        press_enter_to_continue()
    
    def delete_moodboard(self, moodboard):
        """Delete a moodboard"""
        print()
        confirm = get_input(f"Delete moodboard '{moodboard['name']}'? (y/N): ").lower()
        if confirm == 'y':
            self.moodboards.remove(moodboard)
            print_success("Moodboard deleted!")
            time.sleep(1)
            return True
        return False
    
    def browse_music_library(self):
        """Browse the music library by genre"""
        clear_screen()
        print_banner("📚 MUSIC LIBRARY 📚")
        print()
        
        genres = list(self.music_library.keys())
        for i, genre in enumerate(genres, 1):
            song_count = len(self.music_library[genre])
            print_menu_item(i, f"{genre.title()} ({song_count} songs)")
        
        print()
        choice = get_input(f"Select genre (1-{len(genres)}): ")
        
        try:
            genre = genres[int(choice) - 1]
            self.view_genre_songs(genre)
        except (ValueError, IndexError):
            print_error("Invalid genre selection!")
            time.sleep(1)
    
    def view_genre_songs(self, genre):
        """View songs in a specific genre"""
        clear_screen()
        print_banner(f"🎵 {genre.upper()} SONGS 🎵")
        print()
        
        songs = self.music_library[genre]
        
        for i, song in enumerate(songs, 1):
            energy_bar = "█" * song["energy"] + "░" * (10 - song["energy"])
            energy_color = Colors.ERROR if song["energy"] >= 8 else Colors.WARNING if song["energy"] >= 6 else Colors.ACCENT
            
            print(f"{Colors.ACCENT}{i:2d}. {Colors.PRIMARY}{song['title']}{Colors.RESET}")
            print(f"     {Colors.SECONDARY}{song['artist']} - {song['duration']} | Energy: {energy_color}{energy_bar}{Colors.RESET}")
        
        # Genre statistics
        energies = [song["energy"] for song in songs]
        avg_energy = sum(energies) / len(energies)
        
        print()
        print(f"{Colors.ACCENT}Genre Stats:{Colors.RESET}")
        print(f"  Songs: {len(songs)}")
        print(f"  Average Energy: {avg_energy:.1f}/10")
        print(f"  Energy Range: {min(energies)}-{max(energies)}/10")
        
        press_enter_to_continue()
    
    def mood_statistics(self):
        """Display mood and moodboard statistics"""
        clear_screen()
        print_banner("📊 MOOD STATISTICS 📊")
        print()
        
        if not self.moodboards:
            print_warning("No moodboards created yet!")
            press_enter_to_continue()
            return
        
        total_moodboards = len(self.moodboards)
        total_songs = sum(len(mb["playlist"]) for mb in self.moodboards)
        total_plays = sum(mb["play_count"] for mb in self.moodboards)
        
        slow_print(f"Total Moodboards: {total_moodboards}", 0.02, Colors.ACCENT)
        slow_print(f"Total Songs: {total_songs}", 0.02, Colors.ACCENT)
        slow_print(f"Total Plays: {total_plays}", 0.02, Colors.ACCENT)
        
        if total_plays > 0:
            avg_plays = total_plays / total_moodboards
            slow_print(f"Average Plays per Moodboard: {avg_plays:.1f}", 0.02, Colors.ACCENT)
        
        print()
        
        # Most played moodboard
        if self.moodboards:
            most_played = max(self.moodboards, key=lambda x: x["play_count"])
            if most_played["play_count"] > 0:
                slow_print("Most Played Moodboard:", 0.02, Colors.PRIMARY)
                mood_color = most_played["mood"]["color"]
                emoji = most_played["mood"]["emoji"]
                print(f"{mood_color}{emoji} {most_played['name']} ({most_played['play_count']} plays){Colors.RESET}")
        
        # Mood type distribution
        print()
        slow_print("Mood Types:", 0.02, Colors.PRIMARY)
        mood_counts = {}
        for moodboard in self.moodboards:
            mood_name = moodboard["mood"].get("name", "Custom")
            mood_counts[mood_name] = mood_counts.get(mood_name, 0) + 1
        
        for mood_type, count in mood_counts.items():
            percentage = (count / total_moodboards) * 100
            print(f"  {mood_type.title()}: {count} ({percentage:.1f}%)")
        
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Music moodboard ASCII art
            music_art = """
    ███╗   ███╗██╗   ██╗███████╗██╗ ██████╗    ███╗   ███╗ ██████╗  ██████╗ ██████╗ ██████╗  ██████╗  █████╗ ██████╗ ██████╗ 
    ████╗ ████║██║   ██║██╔════╝██║██╔════╝    ████╗ ████║██╔═══██╗██╔═══██╗██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗
    ██╔████╔██║██║   ██║███████╗██║██║         ██╔████╔██║██║   ██║██║   ██║██║  ██║██████╔╝██║   ██║███████║██████╔╝██║  ██║
    ██║╚██╔╝██║██║   ██║╚════██║██║██║         ██║╚██╔╝██║██║   ██║██║   ██║██║  ██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║
    ██║ ╚═╝ ██║╚██████╔╝███████║██║╚██████╗    ██║ ╚═╝ ██║╚██████╔╝╚██████╔╝██████╔╝██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝
    ╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚═╝ ╚═════╝    ╚═╝     ╚═╝ ╚═════╝  ╚═════╝ ╚═════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ 
            """
            
            print_ascii_art(music_art, Colors.ACCENT)
            print()
            slow_print("Curate perfect playlists for every mood!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🎵 Create Moodboard")
            print_menu_item(2, "📋 View Moodboards")
            print_menu_item(3, "📚 Browse Music Library")
            print_menu_item(4, "🎯 Mood Presets")
            print_menu_item(5, "📊 Statistics")
            print_menu_item(6, "🔀 Random Moodboard")
            print_menu_item(7, "❌ Exit")
            
            print()
            if self.moodboards:
                print(f"{Colors.GRAY}Created {len(self.moodboards)} moodboards{Colors.RESET}")
            print()
            
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.create_moodboard()
            elif choice == '2':
                self.view_moodboards()
            elif choice == '3':
                self.browse_music_library()
            elif choice == '4':
                self.view_mood_presets()
            elif choice == '5':
                self.mood_statistics()
            elif choice == '6':
                self.create_random_moodboard()
            elif choice == '7':
                slow_print("Keep the music playing! 🎵", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)
    
    def view_mood_presets(self):
        """View available mood presets"""
        clear_screen()
        print_banner("🎯 MOOD PRESETS 🎯")
        print()
        
        for mood_name, mood_data in self.mood_presets.items():
            print(f"{mood_data['color']}{mood_data['emoji']} {mood_name.title()}{Colors.RESET}")
            print(f"   {mood_data['description']}")
            print(f"   Energy: {mood_data['energy_range'][0]}-{mood_data['energy_range'][1]}/10")
            print(f"   Keywords: {', '.join(mood_data['keywords'])}")
            print()
        
        press_enter_to_continue()
    
    def create_random_moodboard(self):
        """Create a random moodboard"""
        clear_screen()
        print_banner("🔀 RANDOM MOODBOARD 🔀")
        print()
        
        slow_print("Generating random moodboard...", 0.02, Colors.ACCENT)
        animate_loading("Creating mood", 2)
        
        # Select random mood preset
        mood_name = random.choice(list(self.mood_presets.keys()))
        mood_config = self.mood_presets[mood_name].copy()
        mood_config["name"] = mood_name
        
        # Generate random name
        adjectives = ["Cosmic", "Electric", "Mystic", "Neon", "Digital", "Ethereal", "Vibrant", "Serene"]
        nouns = ["Vibes", "Journey", "Dreams", "Waves", "Flow", "Pulse", "Harmony", "Rhythm"]
        
        name = f"{random.choice(adjectives)} {random.choice(nouns)}"
        
        # Generate playlist
        playlist = self.generate_mood_playlist(mood_config)
        
        # Create moodboard
        moodboard = {
            "name": name,
            "mood": mood_config,
            "playlist": playlist,
            "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "play_count": 0
        }
        
        self.moodboards.append(moodboard)
        
        # Display
        self.display_moodboard(moodboard)
        print_success("Random moodboard created!")
        
        press_enter_to_continue()

def main():
    """Main function to run Music Moodboard"""
    try:
        moodboard = MusicMoodboard()
        moodboard.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
