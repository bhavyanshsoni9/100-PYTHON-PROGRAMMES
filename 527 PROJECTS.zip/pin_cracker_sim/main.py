# Created by Bhavyansh Soni
# Pin Cracker Simulator - A cyberpunk-themed security simulation game

import sys
import os
import time
import random
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class PinCrackerSim:
    def __init__(self):
        self.running = True
        self.current_target = None
        self.attempts = 0
        self.max_attempts = 3
        self.score = 0
        self.level = 1
        self.cracked_pins = 0
        
        # Different difficulty levels
        self.difficulty_levels = {
            1: {"pin_length": 4, "time_limit": 30, "max_attempts": 5},
            2: {"pin_length": 5, "time_limit": 25, "max_attempts": 4},
            3: {"pin_length": 6, "time_limit": 20, "max_attempts": 3},
            4: {"pin_length": 7, "time_limit": 15, "max_attempts": 2},
            5: {"pin_length": 8, "time_limit": 10, "max_attempts": 1}
        }
        
        # Security system names
        self.system_names = [
            "Corporate Mainframe",
            "Government Database",
            "Bank Security System",
            "Military Network",
            "Space Station Control",
            "Cyber Defense Grid",
            "Neural Network Core",
            "Quantum Encryption",
            "AI Security Protocol",
            "Biometric Scanner"
        ]
    
    def generate_target_pin(self):
        """Generate a random PIN based on current level"""
        level_info = self.difficulty_levels[min(self.level, 5)]
        pin_length = level_info["pin_length"]
        
        # Generate PIN with some patterns for hints
        pin = ""
        for _ in range(pin_length):
            pin += str(random.randint(0, 9))
        
        return pin
    
    def display_hacking_animation(self):
        """Display cyberpunk hacking animation"""
        animations = [
            "🔓 ACCESSING SYSTEM...",
            "🌐 CONNECTING TO NETWORK...",
            "🔍 SCANNING FOR VULNERABILITIES...",
            "⚡ INITIALIZING CRACK SEQUENCE...",
            "💻 READY TO HACK!"
        ]
        
        for animation in animations:
            slow_print(animation, 0.05, Colors.ACCENT)
            time.sleep(0.8)
    
    def display_pin_interface(self, pin_length, attempts_left):
        """Display the PIN cracking interface"""
        clear_screen()
        
        # Display target system
        system_name = random.choice(self.system_names)
        print_banner(f"🔒 TARGET: {system_name} 🔒")
        print()
        
        # Display PIN input boxes
        boxes = "┌─┐ " * pin_length
        print(f"{Colors.ACCENT}{boxes}{Colors.RESET}")
        
        empty_boxes = "│ │ " * pin_length
        print(f"{Colors.ACCENT}{empty_boxes}{Colors.RESET}")
        
        bottom_boxes = "└─┘ " * pin_length
        print(f"{Colors.ACCENT}{bottom_boxes}{Colors.RESET}")
        
        print()
        print(f"{Colors.WARNING}PIN Length: {pin_length} digits{Colors.RESET}")
        print(f"{Colors.ERROR}Attempts remaining: {attempts_left}{Colors.RESET}")
        print(f"{Colors.PRIMARY}Level: {self.level}{Colors.RESET}")
        print(f"{Colors.SECONDARY}Score: {self.score}{Colors.RESET}")
        
        print_separator()
    
    def provide_hint(self, target_pin, guess):
        """Provide hints based on the guess"""
        hints = []
        
        # Check for correct digits in correct positions
        correct_positions = sum(1 for i, (t, g) in enumerate(zip(target_pin, guess)) if t == g)
        
        # Check for correct digits in wrong positions
        target_digits = list(target_pin)
        guess_digits = list(guess)
        
        # Remove correct position matches
        for i in range(len(target_pin)):
            if target_pin[i] == guess[i]:
                target_digits[i] = None
                guess_digits[i] = None
        
        # Count wrong position matches
        wrong_positions = 0
        for digit in guess_digits:
            if digit and digit in target_digits:
                target_digits.remove(digit)
                wrong_positions += 1
        
        if correct_positions > 0:
            print_success(f"✓ {correct_positions} digit(s) in correct position")
        
        if wrong_positions > 0:
            print_warning(f"? {wrong_positions} digit(s) in wrong position")
        
        if correct_positions == 0 and wrong_positions == 0:
            print_error("✗ No digits match")
        
        # Additional hints based on patterns
        if len(target_pin) >= 4:
            # Check for ascending/descending patterns
            if all(int(target_pin[i]) < int(target_pin[i+1]) for i in range(len(target_pin)-1)):
                print_info("🔍 HINT: Digits are in ascending order")
            elif all(int(target_pin[i]) > int(target_pin[i+1]) for i in range(len(target_pin)-1)):
                print_info("🔍 HINT: Digits are in descending order")
    
    def crack_pin_game(self):
        """Main PIN cracking game logic"""
        target_pin = self.generate_target_pin()
        level_info = self.difficulty_levels[min(self.level, 5)]
        attempts_left = level_info["max_attempts"]
        time_limit = level_info["time_limit"]
        
        start_time = time.time()
        
        while attempts_left > 0:
            self.display_pin_interface(len(target_pin), attempts_left)
            
            # Check time limit
            elapsed_time = time.time() - start_time
            if elapsed_time > time_limit:
                print_error("⏰ TIME'S UP! Security system locked!")
                return False
            
            remaining_time = time_limit - elapsed_time
            print(f"{Colors.WARNING}Time remaining: {remaining_time:.1f}s{Colors.RESET}")
            print()
            
            # Get user input
            guess = get_input(f"Enter {len(target_pin)}-digit PIN: ")
            
            # Validate input
            if not guess.isdigit() or len(guess) != len(target_pin):
                print_error(f"Invalid input! Please enter exactly {len(target_pin)} digits.")
                time.sleep(1)
                continue
            
            # Check if guess is correct
            if guess == target_pin:
                clear_screen()
                print_banner("🎉 ACCESS GRANTED! 🎉")
                print()
                slow_print("🔓 PIN CRACKED SUCCESSFULLY!", 0.03, Colors.PRIMARY)
                
                # Calculate score
                time_bonus = max(0, int(remaining_time * 10))
                attempt_bonus = attempts_left * 50
                total_points = 100 + time_bonus + attempt_bonus
                
                self.score += total_points
                self.cracked_pins += 1
                
                print()
                print(f"{Colors.ACCENT}Base Score: {Colors.WHITE}100{Colors.RESET}")
                print(f"{Colors.ACCENT}Time Bonus: {Colors.WHITE}{time_bonus}{Colors.RESET}")
                print(f"{Colors.ACCENT}Attempt Bonus: {Colors.WHITE}{attempt_bonus}{Colors.RESET}")
                print(f"{Colors.PRIMARY}Total Points: {Colors.WHITE}{total_points}{Colors.RESET}")
                
                return True
            else:
                attempts_left -= 1
                if attempts_left > 0:
                    print_error(f"❌ INCORRECT PIN! {attempts_left} attempts remaining.")
                    print()
                    self.provide_hint(target_pin, guess)
                    press_enter_to_continue()
        
        # Failed to crack
        clear_screen()
        print_banner("🚨 SECURITY BREACH DETECTED! 🚨")
        print()
        print_error("🔒 SYSTEM LOCKED! PIN cracking failed.")
        print(f"{Colors.WARNING}The correct PIN was: {Colors.WHITE}{target_pin}{Colors.RESET}")
        
        return False
    
    def training_mode(self):
        """Training mode with easier settings"""
        clear_screen()
        print_banner("🎯 TRAINING MODE 🎯")
        print()
        slow_print("Practice your PIN cracking skills!", 0.02, Colors.ACCENT)
        print()
        
        # Easy settings
        target_pin = str(random.randint(1000, 9999))  # 4-digit PIN
        attempts_left = 10
        
        while attempts_left > 0:
            self.display_pin_interface(4, attempts_left)
            
            guess = get_input("Enter 4-digit PIN: ")
            
            if not guess.isdigit() or len(guess) != 4:
                print_error("Invalid input! Please enter exactly 4 digits.")
                time.sleep(1)
                continue
            
            if guess == target_pin:
                print_success("🎉 Training successful! PIN cracked!")
                return
            else:
                attempts_left -= 1
                if attempts_left > 0:
                    print_error(f"❌ Incorrect! {attempts_left} attempts remaining.")
                    self.provide_hint(target_pin, guess)
                    press_enter_to_continue()
        
        print_error(f"Training failed! The correct PIN was: {target_pin}")
        press_enter_to_continue()
    
    def challenge_mode(self):
        """Challenge mode with increasing difficulty"""
        clear_screen()
        print_banner("🏆 CHALLENGE MODE 🏆")
        print()
        slow_print("Face increasingly difficult security systems!", 0.02, Colors.WARNING)
        print()
        
        level = 1
        while level <= 5:
            print(f"{Colors.ACCENT}Level {level}: {self.system_names[level-1]}{Colors.RESET}")
            print()
            
            # Set current level
            self.level = level
            
            if self.crack_pin_game():
                print_success(f"Level {level} completed!")
                level += 1
                if level <= 5:
                    slow_print("Preparing next challenge...", 0.02, Colors.ACCENT)
                    time.sleep(2)
            else:
                print_error(f"Challenge failed at level {level}")
                break
        
        if level > 5:
            print_banner("🎊 CHALLENGE COMPLETED! 🎊")
            print()
            slow_print("You've mastered all security systems!", 0.02, Colors.PRIMARY)
        
        press_enter_to_continue()
    
    def show_statistics(self):
        """Display player statistics"""
        clear_screen()
        print_banner("📊 HACKER STATISTICS 📊")
        print()
        
        # Calculate success rate
        success_rate = (self.cracked_pins / max(1, self.cracked_pins + 1)) * 100
        
        slow_print(f"Total Score: {self.score}", 0.02, Colors.ACCENT)
        slow_print(f"PINs Cracked: {self.cracked_pins}", 0.02, Colors.ACCENT)
        slow_print(f"Current Level: {self.level}", 0.02, Colors.ACCENT)
        slow_print(f"Success Rate: {success_rate:.1f}%", 0.02, Colors.ACCENT)
        
        print()
        
        # Rank system
        if self.score >= 1000:
            rank = "🥇 Elite Hacker"
            rank_color = Colors.PRIMARY
        elif self.score >= 500:
            rank = "🥈 Advanced Cracker"
            rank_color = Colors.SECONDARY
        elif self.score >= 200:
            rank = "🥉 Script Kiddie"
            rank_color = Colors.WARNING
        else:
            rank = "🔰 Novice"
            rank_color = Colors.GRAY
        
        print(f"{Colors.ACCENT}Rank: {rank_color}{rank}{Colors.RESET}")
        
        print()
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Display hacking animation on first run
            if self.score == 0 and self.cracked_pins == 0:
                self.display_hacking_animation()
                clear_screen()
            
            # ASCII art for PIN cracker
            pin_art = """
    ██████╗ ██╗███╗   ██╗     ██████╗██████╗  █████╗  ██████╗██╗  ██╗███████╗██████╗ 
    ██╔══██╗██║████╗  ██║    ██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
    ██████╔╝██║██╔██╗ ██║    ██║     ██████╔╝███████║██║     █████╔╝ █████╗  ██████╔╝
    ██╔═══╝ ██║██║╚██╗██║    ██║     ██╔══██╗██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗
    ██║     ██║██║ ╚████║    ╚██████╗██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║
    ╚═╝     ╚═╝╚═╝  ╚═══╝     ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
            """
            
            print_ascii_art(pin_art, Colors.ACCENT)
            print()
            slow_print("Welcome to the cyberpunk PIN cracking simulator!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "🎯 Training Mode")
            print_menu_item(2, "🏆 Challenge Mode")
            print_menu_item(3, "🎮 Quick Crack")
            print_menu_item(4, "📊 Statistics")
            print_menu_item(5, "⚙️ Settings")
            print_menu_item(6, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-6): ")
            
            if choice == '1':
                self.training_mode()
            elif choice == '2':
                self.challenge_mode()
            elif choice == '3':
                self.level = 1
                result = self.crack_pin_game()
                if result:
                    print_success("Quick crack successful!")
                else:
                    print_error("Quick crack failed!")
                press_enter_to_continue()
            elif choice == '4':
                self.show_statistics()
            elif choice == '5':
                self.settings_menu()
            elif choice == '6':
                slow_print("Disconnecting from the matrix...", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-6.")
                time.sleep(1)
    
    def settings_menu(self):
        """Display settings menu"""
        clear_screen()
        print_banner("⚙️ SETTINGS ⚙️")
        print()
        
        print_menu_item(1, "🔄 Reset Statistics")
        print_menu_item(2, "📋 View Difficulty Levels")
        print_menu_item(3, "🔙 Back to Main Menu")
        
        print()
        choice = get_input("Enter your choice (1-3): ")
        
        if choice == '1':
            confirm = get_input("Are you sure you want to reset statistics? (y/N): ")
            if confirm.lower() == 'y':
                self.score = 0
                self.level = 1
                self.cracked_pins = 0
                print_success("Statistics reset successfully!")
            else:
                print_info("Reset cancelled.")
        elif choice == '2':
            self.show_difficulty_levels()
        elif choice == '3':
            return
        else:
            print_error("Invalid choice!")
        
        time.sleep(1)
    
    def show_difficulty_levels(self):
        """Display difficulty level information"""
        clear_screen()
        print_banner("📋 DIFFICULTY LEVELS 📋")
        print()
        
        for level, info in self.difficulty_levels.items():
            print(f"{Colors.ACCENT}Level {level}:{Colors.RESET}")
            print(f"  PIN Length: {info['pin_length']} digits")
            print(f"  Time Limit: {info['time_limit']} seconds")
            print(f"  Max Attempts: {info['max_attempts']}")
            print()
        
        press_enter_to_continue()

def main():
    """Main function to run PIN Cracker Simulator"""
    try:
        pin_cracker = PinCrackerSim()
        pin_cracker.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
