# 🧪 Pixel Alchemist

**Created by Bhavyansh Soni**

## Description
An enchanting ASCII transmutation game where players become master alchemists, transforming simple symbols into stunning visual art! Discover the ancient secrets of pixel alchemy by combining elemental ASCII characters using mystical formulas to create beautiful patterns and unlock the legendary Philosopher's Stone.

## Core Philosophy
"In the beginning, there were only simple symbols... But through the mystic art of pixel alchemy, these humble characters can be transmuted into works of transcendent beauty and power!"

## Gameplay Features
- 🧪 **9 Mastery Levels**: Progress from simple flames to the ultimate Philosopher's Stone
- ⚗️ **7 Elemental Types**: Fire, Water, Earth, Air, Light, Shadow, and Void
- 📜 **Transmutation Formulas**: Learn ancient recipes for creating ASCII art
- 🔮 **Transmutation Circle**: Combine elements in the mystical circle
- 💎 **Philosopher Points**: Earn points for successful transmutations
- ✨ **Beautiful ASCII Art**: Watch symbols transform into stunning patterns

## The Seven Elements

### 🔥 **Fire Element**
- **Symbols**: ▲, △, 🔥, ※, ✦, ✧, ⟡, ⋄
- **Properties**: High energy (8/10), high volatility (0.9)
- **Essence**: Passion and transformation
- **Color**: Red - burns bright but unpredictable

### 💧 **Water Element**
- **Symbols**: ▽, ∇, ≈, ~, 〜, ⟁, ∽, ⌇
- **Properties**: Medium energy (6/10), low volatility (0.3)
- **Essence**: Flow and adaptability
- **Color**: Blue - stable and flowing

### 🌍 **Earth Element**
- **Symbols**: ■, ▪, ▫, □, ⬛, ⬜, ◼, ◻
- **Properties**: Low energy (4/10), very low volatility (0.1)
- **Essence**: Stability and foundation
- **Color**: Green - solid and reliable

### 💨 **Air Element**
- **Symbols**: ○, ◯, ◦, ●, ⚬, ⚭, ⚮, ⚯
- **Properties**: High energy (7/10), high volatility (0.7)
- **Essence**: Freedom and movement
- **Color**: Cyan - light and ethereal

### ✨ **Light Element**
- **Symbols**: ★, ☆, ✦, ✧, ✩, ✪, ✫, ✬
- **Properties**: Very high energy (9/10), high volatility (0.8)
- **Essence**: Illumination and revelation
- **Color**: Yellow - brilliant and radiant

### 🌑 **Shadow Element**
- **Symbols**: ▓, ▒, ░, ▚, ▞, ▙, ▟, ▛
- **Properties**: Medium energy (5/10), medium volatility (0.6)
- **Essence**: Mystery and depth
- **Color**: Magenta - hidden and enigmatic

### 🕳️ **Void Element**
- **Symbols**: (space), ⠀, ⠁, ⠂, ⠃, ⠄, ⠅, ⠆
- **Properties**: Maximum energy (10/10), maximum volatility (1.0)
- **Essence**: Infinite potential
- **Color**: Black - contains all possibilities

## The Nine Transmutation Formulas

### 🔥 **Level 1: Flame Pattern**
- **Elements**: Fire + Fire + Air
- **Difficulty**: 1/6
- **Result**: Dancing triangular flame
- **Learning**: Basic element combination

### 💧 **Level 2: Water Drop**
- **Elements**: Water + Water + Earth
- **Difficulty**: 1/6
- **Result**: Perfect droplet form
- **Learning**: Stability through grounding

### 🌟 **Level 3: Star Burst**
- **Elements**: Light + Fire + Air + Light
- **Difficulty**: 2/6
- **Result**: Radial star explosion
- **Learning**: Light amplification techniques

### 🌙 **Level 4: Crescent Moon**
- **Elements**: Shadow + Void + Light
- **Difficulty**: 2/6
- **Result**: Balanced light and darkness
- **Learning**: Opposing force harmony

### 🌊 **Level 5: Ocean Wave**
- **Elements**: Water + Air + Water + Earth
- **Difficulty**: 3/6
- **Result**: Flowing wave motion
- **Learning**: Complex element interaction

### 🏔️ **Level 6: Mountain Peak**
- **Elements**: Earth + Earth + Earth + Air + Shadow
- **Difficulty**: 3/6
- **Result**: Towering mountain form
- **Learning**: Structural stability through repetition

### 🌀 **Level 7: Spiral Galaxy**
- **Elements**: Void + Light + Shadow + Air + Light
- **Difficulty**: 4/6
- **Result**: Cosmic spiral pattern
- **Learning**: Advanced cosmic forces

### 🔮 **Level 8: Crystal Mandala**
- **Elements**: Earth + Light + Water + Fire + Air + Shadow
- **Difficulty**: 5/6
- **Result**: Perfect geometric harmony
- **Learning**: Six-element balance mastery

### ♾️ **Level 9: Philosopher's Stone**
- **Elements**: Fire + Water + Earth + Air + Light + Shadow + Void
- **Difficulty**: 6/6
- **Result**: Infinite symbol of ultimate power
- **Learning**: Mastery of all elemental forces

## Alchemical Operations

### **Element Management**
- `add <element>` - Add element to transmutation circle
- `remove <element>` - Remove element from circle
- `clear` - Clear entire transmutation circle

### **Transmutation Process**
- `transmute` - Attempt current transmutation (costs 20% energy)
- `analyze` - Analyze circle composition and stability
- `gather` - Venture forth to collect more elements (costs 15% energy)

### **Knowledge Management**
- `formulas` - View all discovered transmutation formulas
- `quit` - Exit the alchemical laboratory

## Energy System
- **Starting Energy**: 100% per level
- **Element Addition**: Costs 5% energy per element
- **Transmutation**: Costs 20% energy per attempt
- **Gathering**: Costs 15% energy, yields 2-4 random elements
- **Regeneration**: Slowly recovers 1% per turn
- **Level Advancement**: Restores 30% energy

## Transmutation Mechanics

### **Formula Matching**
- Must place exact elements required by formula
- Order doesn't matter, but composition must be perfect
- Missing or extra elements cause transmutation failure

### **Energy Management**
- Failed transmutations cost 10% energy
- Successful transmutations cost 20% energy but advance level
- Gathering expeditions replenish element supplies

### **Volatility System**
- High volatility elements (Fire, Light, Void) are powerful but unpredictable
- Low volatility elements (Earth, Water) provide stability
- Circle analysis helps predict transmutation success

## Scoring System
- **Base Points**: Difficulty level × 50 points
- **Energy Bonus**: Remaining energy ÷ 10 additional points
- **Example**: Level 5 (difficulty 3) with 60% energy = 150 + 6 = 156 points

## Achievement Levels
- 🌟 **Philosopher's Stone Achieved**: Complete all 9 levels (100%)
- 🔮 **Master Transmutator**: Complete 7+ levels (80%+)
- ✨ **Skilled Alchemist**: Complete 5+ levels (60%+)
- 🧪 **Apprentice Transmutator**: Complete 3+ levels (40%+)
- 🌱 **Novice Alchemist**: Beginning the alchemical journey

## Strategic Tips

### **Element Gathering**
1. **Stock Up Early**: Gather elements before attempting complex formulas
2. **Balance Inventory**: Maintain supplies of all element types
3. **Energy Conservation**: Gather when energy is high for better results

### **Transmutation Strategy**
1. **Read Formulas Carefully**: Exact element combinations required
2. **Analyze Before Transmuting**: Check circle stability first
3. **Manage Volatility**: Balance high and low volatility elements
4. **Energy Planning**: Ensure sufficient energy for transmutation

### **Advanced Techniques**
1. **Element Synergy**: Understand which elements work well together
2. **Volatility Balancing**: Use stable elements to control volatile ones
3. **Energy Efficiency**: Plan multiple transmutations per gathering session
4. **Pattern Recognition**: Learn to visualize results before transmuting

## Educational Value
- **Chemistry Concepts**: Basic understanding of element combination
- **Pattern Recognition**: Visual and logical pattern analysis
- **Resource Management**: Strategic planning and conservation
- **Problem Solving**: Formula analysis and troubleshooting
- **Artistic Appreciation**: ASCII art creation and design principles
- **Mathematical Thinking**: Ratio and proportion understanding

## Alchemical Lore & Philosophy
The game draws inspiration from historical alchemy while creating a unique fantasy system:

- **Hermetic Principles**: "As above, so below" - patterns repeat at different scales
- **Elemental Balance**: Ancient four elements plus modern additions (Light, Shadow, Void)
- **Transmutation Philosophy**: Transformation through understanding and harmony
- **The Great Work**: Progressive mastery leading to ultimate achievement
- **Sacred Geometry**: Patterns that reflect universal principles

## ASCII Art Patterns
Each successful transmutation creates beautiful ASCII art:
- **Geometric Forms**: Triangles, circles, spirals, mandalas
- **Natural Patterns**: Flames, waves, mountains, celestial bodies
- **Symbolic Designs**: Sacred geometry and mystical symbols
- **Complex Compositions**: Multi-element artistic expressions

## The Philosophy of Pixel Alchemy
"True alchemy is not about turning lead into gold, but about understanding the fundamental patterns that underlie all creation. In Pixel Alchemy, each ASCII character is a building block of reality, and through the proper combination of elements and intention, even the simplest symbols can be transformed into expressions of transcendent beauty. The alchemist learns that creation is not about forcing change, but about discovering the hidden harmonies that already exist within the fabric of possibility."


