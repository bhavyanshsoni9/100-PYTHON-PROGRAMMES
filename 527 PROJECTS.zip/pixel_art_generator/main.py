# Created by Bhavyansh Soni
# Pixel Art Generator - Create ASCII and colored terminal art

import sys
import os
import time
import random

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.terminal_styles import *

class PixelArtGenerator:
    def __init__(self):
        self.running = True
        self.canvas_width = 20
        self.canvas_height = 10
        self.current_canvas = []
        self.palette = {
            '1': Colors.PRIMARY,
            '2': Colors.SECONDARY,
            '3': Colors.ACCENT,
            '4': Colors.WARNING,
            '5': Colors.ERROR,
            '6': Colors.WHITE,
            '7': Colors.GRAY,
            '0': Colors.RESET
        }
        
        # Predefined patterns
        self.patterns = {
            "heart": [
                "  ██  ██  ",
                "████████████",
                "████████████",
                " ██████████ ",
                "  ████████  ",
                "   ██████   ",
                "    ████    ",
                "     ██     "
            ],
            "smiley": [
                "   ██████   ",
                " ██████████ ",
                "██  ██  ██  ██",
                "██  ██  ██  ██",
                "██          ██",
                "██  ██████  ██",
                " ██████████ ",
                "   ██████   "
            ]
        }
    
    def initialize_canvas(self):
        """Initialize empty canvas"""
        self.current_canvas = []
        for _ in range(self.canvas_height):
            row = [' '] * self.canvas_width
            self.current_canvas.append(row)
    
    def display_canvas(self):
        """Display the current canvas"""
        print_banner("🎨 PIXEL ART CANVAS 🎨")
        print()
        
        # Display column numbers
        numbers = "  "
        for i in range(self.canvas_width):
            numbers += f"{i%10}"
        print(f"{Colors.GRAY}{numbers}{Colors.RESET}")
        
        # Display canvas with row numbers
        for i, row in enumerate(self.current_canvas):
            row_str = f"{i%10} "
            for cell in row:
                if cell == ' ':
                    row_str += '·'
                else:
                    row_str += cell
            print(f"{Colors.GRAY}{i%10} {Colors.RESET}{row_str}")
        
        print()
        self.display_palette()
    
    def display_palette(self):
        """Display color palette"""
        print(f"{Colors.ACCENT}Color Palette:{Colors.RESET}")
        palette_str = ""
        for key, color in self.palette.items():
            if key == '0':
                palette_str += f"{Colors.GRAY}[{key}]Clear {Colors.RESET}"
            else:
                palette_str += f"{color}[{key}]███ {Colors.RESET}"
        print(palette_str)
    
    def draw_pixel(self, x, y, color_key):
        """Draw a pixel at specified coordinates"""
        if 0 <= x < self.canvas_width and 0 <= y < self.canvas_height:
            if color_key == '0':
                self.current_canvas[y][x] = ' '
            else:
                color = self.palette.get(color_key, Colors.RESET)
                self.current_canvas[y][x] = f"{color}█{Colors.RESET}"
            return True
        return False
    
    def manual_drawing(self):
        """Manual pixel drawing mode"""
        self.initialize_canvas()
        
        while True:
            clear_screen()
            self.display_canvas()
            
            print("\nCommands:")
            print("• 'x,y,color' - Draw pixel (e.g., '5,3,1')")
            print("• 'clear' - Clear canvas")
            print("• 'save' - Save artwork")
            print("• 'quit' - Return to menu")
            
            command = get_input("\nEnter command: ").lower().strip()
            
            if command == 'quit':
                break
            elif command == 'clear':
                self.initialize_canvas()
                print_success("Canvas cleared!")
            elif command == 'save':
                self.save_artwork()
            elif ',' in command:
                try:
                    parts = command.split(',')
                    x, y, color = int(parts[0]), int(parts[1]), parts[2]
                    if self.draw_pixel(x, y, color):
                        print_success(f"Pixel drawn at ({x},{y})")
                    else:
                        print_error("Invalid coordinates!")
                except:
                    print_error("Invalid format! Use: x,y,color")
            else:
                print_error("Unknown command!")
            
            time.sleep(0.5)
    
    def generate_random_art(self):
        """Generate random pixel art"""
        self.initialize_canvas()
        
        patterns = ['noise', 'gradient', 'checkerboard', 'spiral']
        pattern = random.choice(patterns)
        
        print_info(f"Generating {pattern} pattern...")
        animate_loading("Creating art", 2)
        
        if pattern == 'noise':
            self.generate_noise_pattern()
        elif pattern == 'gradient':
            self.generate_gradient_pattern()
        elif pattern == 'checkerboard':
            self.generate_checkerboard_pattern()
        elif pattern == 'spiral':
            self.generate_spiral_pattern()
        
        clear_screen()
        self.display_canvas()
        press_enter_to_continue()
    
    def generate_noise_pattern(self):
        """Generate random noise pattern"""
        for y in range(self.canvas_height):
            for x in range(self.canvas_width):
                if random.random() < 0.3:  # 30% chance to place pixel
                    color_key = random.choice(['1', '2', '3', '4', '5'])
                    self.draw_pixel(x, y, color_key)
    
    def generate_gradient_pattern(self):
        """Generate gradient pattern"""
        colors = ['1', '2', '3', '4', '5']
        for y in range(self.canvas_height):
            color_index = int((y / self.canvas_height) * len(colors))
            color_key = colors[min(color_index, len(colors) - 1)]
            
            for x in range(self.canvas_width):
                if random.random() < 0.7:  # 70% chance
                    self.draw_pixel(x, y, color_key)
    
    def generate_checkerboard_pattern(self):
        """Generate checkerboard pattern"""
        for y in range(self.canvas_height):
            for x in range(self.canvas_width):
                if (x + y) % 2 == 0:
                    self.draw_pixel(x, y, '1')
                else:
                    self.draw_pixel(x, y, '2')
    
    def generate_spiral_pattern(self):
        """Generate spiral pattern"""
        center_x, center_y = self.canvas_width // 2, self.canvas_height // 2
        max_radius = min(center_x, center_y)
        
        for radius in range(max_radius):
            for angle in range(0, 360, 10):
                x = int(center_x + radius * 0.7 * (angle / 360))
                y = int(center_y + radius * 0.7 * ((angle + 90) / 360))
                
                if 0 <= x < self.canvas_width and 0 <= y < self.canvas_height:
                    color_key = str((radius % 5) + 1)
                    self.draw_pixel(x, y, color_key)
    
    def load_pattern(self):
        """Load a predefined pattern"""
        clear_screen()
        print_banner("📂 LOAD PATTERN 📂")
        print()
        
        for i, pattern_name in enumerate(self.patterns.keys(), 1):
            print_menu_item(i, pattern_name.title())
        
        choice = get_input("\nSelect pattern: ")
        
        try:
            pattern_name = list(self.patterns.keys())[int(choice) - 1]
            self.load_pattern_data(pattern_name)
            print_success(f"Pattern '{pattern_name}' loaded!")
        except:
            print_error("Invalid pattern selection!")
        
        time.sleep(1)
    
    def load_pattern_data(self, pattern_name):
        """Load pattern data to canvas"""
        self.initialize_canvas()
        pattern_data = self.patterns[pattern_name]
        
        for y, row in enumerate(pattern_data):
            if y >= self.canvas_height:
                break
            for x, char in enumerate(row):
                if x >= self.canvas_width:
                    break
                if char == '█':
                    self.draw_pixel(x, y, '1')  # Default color
    
    def save_artwork(self):
        """Save current artwork"""
        filename = get_input("Enter filename (without extension): ")
        if not filename:
            filename = f"pixel_art_{int(time.time())}"
        
        # Simulate saving
        animate_loading("Saving artwork", 1)
        print_success(f"Artwork saved as {filename}.txt")
    
    def ascii_art_mode(self):
        """ASCII art creation mode"""
        clear_screen()
        print_banner("🔤 ASCII ART MODE 🔤")
        print()
        
        ascii_chars = ['@', '#', '$', '%', '&', '*', '+', '=', '-', ':', '.', ' ']
        
        print("Available characters:")
        for i, char in enumerate(ascii_chars):
            print(f"{i}: '{char}'")
        
        print()
        text = get_input("Enter text to convert to ASCII art: ")
        
        if text:
            self.create_ascii_text(text)
    
    def create_ascii_text(self, text):
        """Create ASCII art from text"""
        clear_screen()
        print_banner("🎨 ASCII ART RESULT 🎨")
        print()
        
        # Simple ASCII art generation
        for char in text.upper():
            if char == 'A':
                art = [
                    "  ███  ",
                    " █   █ ",
                    "█     █",
                    "███████",
                    "█     █",
                    "█     █"
                ]
            elif char == 'B':
                art = [
                    "██████ ",
                    "█     █",
                    "██████ ",
                    "██████ ",
                    "█     █",
                    "██████ "
                ]
            elif char == ' ':
                art = [
                    "   ",
                    "   ",
                    "   ",
                    "   ",
                    "   ",
                    "   "
                ]
            else:
                art = [
                    "█████",
                    "█   █",
                    "█   █",
                    "█   █",
                    "█   █",
                    "█████"
                ]
            
            # Display character art
            for line in art:
                print(f"{Colors.PRIMARY}{line}{Colors.RESET}")
            print()
        
        press_enter_to_continue()
    
    def main_menu(self):
        """Display main menu"""
        while self.running:
            clear_screen()
            
            # Display pixel art title
            title_art = """
    ██████╗ ██╗██╗  ██╗███████╗██╗         ██████╗ ██████╗ ████████╗
    ██╔══██╗██║╚██╗██╔╝██╔════╝██║        ██╔═══██╗██╔══██╗╚══██╔══╝
    ██████╔╝██║ ╚███╔╝ █████╗  ██║        ██║   ██║██████╔╝   ██║   
    ██╔═══╝ ██║ ██╔██╗ ██╔══╝  ██║        ██║   ██║██╔══██╗   ██║   
    ██║     ██║██╔╝ ██╗███████╗███████╗   ╚██████╔╝██║  ██║   ██║   
    ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝    ╚═════╝ ╚═╝  ╚═╝   ╚═╝   
            """
            
            print_ascii_art(title_art, Colors.ACCENT)
            print()
            slow_print("Create amazing pixel art in your terminal!", 0.02, Colors.PRIMARY)
            print()
            
            print_menu_item(1, "✏️ Manual Drawing")
            print_menu_item(2, "🎲 Random Art Generator")
            print_menu_item(3, "📂 Load Pattern")
            print_menu_item(4, "🔤 ASCII Art Mode")
            print_menu_item(5, "🎨 Gallery")
            print_menu_item(6, "⚙️ Settings")
            print_menu_item(7, "❌ Exit")
            
            print()
            choice = get_input("Enter your choice (1-7): ")
            
            if choice == '1':
                self.manual_drawing()
            elif choice == '2':
                self.generate_random_art()
            elif choice == '3':
                self.load_pattern()
            elif choice == '4':
                self.ascii_art_mode()
            elif choice == '5':
                self.show_gallery()
            elif choice == '6':
                self.settings_menu()
            elif choice == '7':
                slow_print("Closing Pixel Art Generator...", 0.02, Colors.SECONDARY)
                self.running = False
            else:
                print_error("Invalid choice! Please select 1-7.")
                time.sleep(1)
    
    def show_gallery(self):
        """Show gallery of saved artworks"""
        clear_screen()
        print_banner("🖼️ ART GALLERY 🖼️")
        print()
        slow_print("Your saved artworks would appear here!", 0.02, Colors.ACCENT)
        print()
        press_enter_to_continue()
    
    def settings_menu(self):
        """Display settings menu"""
        clear_screen()
        print_banner("⚙️ SETTINGS ⚙️")
        print()
        
        print_menu_item(1, f"Canvas Size: {self.canvas_width}x{self.canvas_height}")
        print_menu_item(2, "Color Palette")
        print_menu_item(3, "🔙 Back to Main Menu")
        
        print()
        choice = get_input("Enter your choice (1-3): ")
        
        if choice == '1':
            self.change_canvas_size()
        elif choice == '2':
            self.edit_palette()
        elif choice == '3':
            return
        else:
            print_error("Invalid choice!")
        
        time.sleep(1)
    
    def change_canvas_size(self):
        """Change canvas dimensions"""
        print()
        try:
            width = int(get_input("Enter new width (10-40): "))
            height = int(get_input("Enter new height (5-20): "))
            
            if 10 <= width <= 40 and 5 <= height <= 20:
                self.canvas_width = width
                self.canvas_height = height
                print_success("Canvas size updated!")
            else:
                print_error("Invalid dimensions!")
        except ValueError:
            print_error("Please enter valid numbers!")
    
    def edit_palette(self):
        """Edit color palette"""
        clear_screen()
        print_banner("🎨 COLOR PALETTE 🎨")
        print()
        self.display_palette()
        print()
        print_info("Color palette is currently fixed but can be customized!")
        press_enter_to_continue()

def main():
    """Main function to run Pixel Art Generator"""
    try:
        pixel_art = PixelArtGenerator()
        pixel_art.main_menu()
    except KeyboardInterrupt:
        print()
        slow_print("Program interrupted by user.", 0.02, Colors.WARNING)
    except Exception as e:
        print_error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
